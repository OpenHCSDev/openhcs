"""Launch bounded, read-only remote numerical replays; keep outputs locally."""
import argparse
import ast
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--runner', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--software', required=True)
parser.add_argument('--engine-sha256', required=True)
parser.add_argument('--engine-commit', required=True)
parser.add_argument('--inventory', required=True)
parser.add_argument('--custom-freeze', type=Path, required=True)
parser.add_argument('--partitions', type=int, default=1)
parser.add_argument('--author', action='append', default=[])
parser.add_argument('--field', nargs=2, action='append', default=[])
parser.add_argument('--timeout', type=int, required=True)
arguments = parser.parse_args()
assert arguments.partitions > 0
sys.path.insert(0, str(arguments.root / 'paper/figures'))
from compare_personal_neurite import read_rows

folder = arguments.root / 'paper/supplementary/personal_neurite_autonomous'
cohort = json.loads((folder / 'cohort.json').read_text())
freeze = json.loads(arguments.custom_freeze.read_text())
controls = {}
for record in freeze['control_files']:
    controls.setdefault(Path(record['path']).stem, []).append(record)
arguments.output.mkdir(parents=True, exist_ok=False)
source_hash = hashlib.sha256(arguments.runner.read_bytes()).hexdigest()
jobs = []
assert set(arguments.author) <= {author['tables'] for author in cohort['authors']}
selected_authors = [author for author in cohort['authors']
                    if not arguments.author or author['tables'] in arguments.author]
for author in selected_authors:
    pipeline = folder / author['tables'] / author['pipeline']
    assert hashlib.sha256(pipeline.read_bytes()).hexdigest() == author['pipeline_sha256']
    fields = sorted({(row['coded_well'], int(row['site'])) for row in read_rows(pipeline.parent / 'paired_sites.csv')})
    requested = [(well, int(site)) for well, site in arguments.field]
    if requested:
        assert set(requested) <= set(fields)
        fields = requested
    custom_sources = []
    for node in ast.parse(pipeline.read_text()).body:
        match node:
            case ast.ImportFrom(module='openhcs.processing.custom_functions', names=names):
                for name in names:
                    record, = [record for record in controls[name.name]
                               if Path(record['path']).parent == Path(author['original_pipeline']).parent]
                    custom_sources.extend(('--custom-source', record['path'], record['sha256']))
    for partition in range(arguments.partitions):
        selected = fields[partition::arguments.partitions]
        if not selected:
            continue
        remote = ['/home/ts/code/projects/openhcs/.venv/bin/python', '-B', '-',
                  '--software', arguments.software, '--pipeline', author['original_pipeline'],
                  '--inventory', arguments.inventory, '--engine-sha256', arguments.engine_sha256,
                  '--pipeline-sha256', author['pipeline_sha256'],
                  '--function-repository', '/home/ts/code/projects/openhcs',
                  '--function-commit', arguments.engine_commit, *custom_sources]
        for well, site in selected:
            remote.extend(('--field', well, str(site)))
        command = ['timeout', '-s', 'INT', str(arguments.timeout), 'ssh',
                   '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5', 'desktop',
                   shlex.join(['nice', '-n', '10', *remote])]
        jobs.append({'author': author['tables'], 'partition': partition,
                     'fields': selected, 'command': command})
manifest = {'runner': str(arguments.runner), 'runner_sha256': source_hash,
            'source_cohort_sha256': hashlib.sha256((folder / 'cohort.json').read_bytes()).hexdigest(),
            'software': arguments.software, 'engine_sha256': arguments.engine_sha256,
            'engine_commit': arguments.engine_commit, 'jobs': jobs}
(arguments.output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

def execute(job):
    name = f"{job['author']}-part{job['partition']}"
    print(f"START {name}: {len(job['fields'])} fields", flush=True)
    with arguments.runner.open('rb') as source, (arguments.output / f'{name}.jsonl').open('wb') as result, (arguments.output / f'{name}.stderr.log').open('wb') as error:
        process = subprocess.Popen(job['command'], stdin=source, stdout=result, stderr=error)
        outcome = process.wait()
    (arguments.output / f'{name}.exit').write_text(str(outcome) + '\n')
    print(f"END {name}: exit {outcome}", flush=True)
    return {'name': name, 'exit': outcome, 'expected_fields': len(job['fields'])}

with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
    results = [future.result() for future in as_completed([pool.submit(execute, job) for job in jobs])]
(arguments.output / 'outcomes.json').write_text(json.dumps(results, indent=2) + '\n')
assert all(result['exit'] == 0 for result in results), results
print('COMPLETE: all declared jobs exited successfully', flush=True)
