"""Validate complete measured replays and build separate comparison tables.

The existing native-plane reader owns measurement validation. SiteMean owns
nine-site aggregation; endpoint declarations own effects and paired differences.
Frozen paired tables retain the evaluation-only coded/physical identity map.
No private source key is invented and no original table is overwritten.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--run', type=Path, action='append', required=True)
parser.add_argument('--original-pilots', type=Path, required=True)
parser.add_argument('--runtime-record', type=Path, action='append', default=[])
parser.add_argument('--output', type=Path, required=True)
arguments = parser.parse_args()
sys.path.insert(0, str(arguments.root / 'paper/figures'))
from compare_personal_neurite import (
    NativeSummary, SiteMeanWellAggregation, WellEndpoints,
    endpoint_declarations, read_rows, write_rows,
)

cohort_root = arguments.root / 'paper/supplementary/personal_neurite_autonomous'
cohort_path = cohort_root / 'cohort.json'
cohort = json.loads(cohort_path.read_text())
authors = {author['tables']: author for author in cohort['authors']}
declarations = endpoint_declarations()
records = {name: {} for name in authors}
inputs = [cohort_path, Path(__file__), *arguments.runtime_record]
engine_contexts = set()
for run in arguments.run:
    manifest_path, outcomes_path = run / 'manifest.json', run / 'outcomes.json'
    manifest, outcomes = json.loads(manifest_path.read_text()), json.loads(outcomes_path.read_text())
    assert all(result['exit'] == 0 for result in outcomes), outcomes
    assert manifest['source_cohort_sha256'] == hashlib.sha256(cohort_path.read_bytes()).hexdigest()
    engine_contexts.add((manifest['software'], manifest['engine_commit'], manifest['engine_sha256']))
    inputs.extend((manifest_path, outcomes_path, Path(manifest['runner'])))
    assert hashlib.sha256(Path(manifest['runner']).read_bytes()).hexdigest() == manifest['runner_sha256']
    for job in manifest['jobs']:
        name = job['author']
        prefix = f"{name}-part{job['partition']}"
        path = run / f'{prefix}.jsonl'
        assert (run / f'{prefix}.exit').read_text().strip() == '0'
        lines = path.read_text().splitlines(keepends=True)
        assert all(line.endswith('\n') for line in lines), path
        observations = [json.loads(line) for line in lines]
        expected = {(well, int(site)) for well, site in job['fields']}
        assert len(observations) == len(expected)
        assert {(row['coded_well'], row['site']) for row in observations} == expected
        for row in observations:
            assert row['engine_sha256'] == manifest['engine_sha256']
            assert row['function_ast_matches_original']
            assert row['pipeline_sha256'] == authors[name]['pipeline_sha256']
            identity = row['coded_well'], row['site']
            assert identity not in records[name], (name, identity)
            records[name][identity] = row
        inputs.append(path)

assert len(engine_contexts) == 1, engine_contexts
original_sites = {}
for name in authors:
    path = cohort_root / name / 'paired_sites.csv'
    sites = read_rows(path)
    original_sites[name] = {(row['coded_well'], int(row['site'])): row for row in sites}
    assert len(sites) == len(original_sites[name]) == 180
    assert records[name].keys() == original_sites[name].keys(), name
    inputs.append(path)
arguments.output.mkdir(parents=True, exist_ok=False)
aggregation = SiteMeanWellAggregation()
reports = []


def saved_endpoints(row, prefix):
    """Decode the established CSV empty-value representation, not a zero."""
    return WellEndpoints(**{name: None if row[f'{prefix}{name}'] == '' else float(row[f'{prefix}{name}'])
                            for name in declarations})


for name, author in authors.items():
    original = cohort_root / name
    output = arguments.output / name
    native = output / 'measured-planes'
    native.mkdir(parents=True)
    # Retain the exact historical programs as inputs, not edited current-API programs.
    for source in original.glob('*.py'):
        (output / source.name).write_bytes(source.read_bytes())
    pilot_path = arguments.original_pilots / f'{name}-part0.jsonl'
    pilot = json.loads(pilot_path.read_text())
    inputs.extend((pilot_path, original / 'joined_wells.csv', original / 'treatment_effects.csv',
                   original / 'source_evidence.json', original / author['pipeline']))
    observations = records[name]
    cell_columns = list(next(row['cells'][0] for row in observations.values() if row['cells']))
    paired_sites = []
    physical = {}
    for identity, row in sorted(observations.items()):
        assert row['pixel_size'] == pilot['pixel_size']
        old = original_sites[name][identity]
        # The input contract is a single 2-D acquisition plane at Z/time 1.
        # These are source labels attached to real measurements, not measured values.
        context = {'well': identity[0], 'site': str(identity[1]), 'z_index': 1, 'timepoint': 1}
        summary = {**row['summary'], **context}
        cells = [{**cell, **context} for cell in row['cells']]
        path = native / f'{identity[0]}_s{identity[1]}_neurite_outgrowth_summary_replay_details.csv'
        write_rows(path, [summary])
        with NativeSummary.cells_path(path).open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(dict.fromkeys([*cell_columns, *context])), lineterminator='\n')
            writer.writeheader()
            writer.writerows(cells)
        measured = NativeSummary.read(path)
        guided = saved_endpoints(old, 'guided_openhcs_')
        paired_sites.append({**old, **measured.endpoints.paired_values(guided, declarations)})
        target = old['plate'], old['well']
        assert identity[0] not in physical or physical[identity[0]] == target
        physical[identity[0]] = target
    wells, _ = aggregation.load(native)
    measured_wells = {physical[coded]: endpoint for coded, endpoint in wells.items()}
    old_wells = read_rows(original / 'joined_wells.csv')
    assert len(old_wells) == len(measured_wells) == 20
    joined = []
    for old in old_wells:
        value = measured_wells[old['plate'], old['well']]
        joined.append({**old, **value.paired_values(saved_endpoints(old, 'guided_openhcs_'), declarations)})
    well_index = {(row['plate'], row['well']): row for row in joined}
    effects = []
    for old in read_rows(original / 'treatment_effects.csv'):
        declaration = declarations[old['metric']]
        controls = [well_index[old['plate'], well] for well in old['baseline_wells'].split(';')]
        treated = [well_index[old['plate'], well] for well in old['treatment_wells'].split(';')]
        column = f"openhcs_{old['metric']}"
        effect = declaration.treatment_effect([row[column] for row in controls], [row[column] for row in treated])
        updated = {**old, **{f'openhcs_{key}': value for key, value in effect.items()}}
        reference_change = (None if old['metaxpress_fractional_change'] == '' else
                            float(old['metaxpress_fractional_change']))
        updated['fractional_change_difference'] = (None if effect['fractional_change'] is None or reference_change is None else
                                                    effect['fractional_change'] - reference_change)
        effects.append(updated)
    write_rows(output / 'paired_sites.csv', paired_sites)
    write_rows(output / 'joined_wells.csv', joined)
    write_rows(output / 'treatment_effects.csv', effects)
    evidence = {'comparison': 'post-freeze fixed-code re-evaluation; not new blind development or manual tracing accuracy',
                'aggregation_protocol': aggregation.name, 'aggregation': aggregation.description,
                'protocol_figure_label': aggregation.figure_label,
                'coordinate_unit': NativeSummary.coordinate_unit,
                'endpoint_units': {key: declaration.unit for key, declaration in declarations.items()},
                'matched_sites': len(observations), 'matched_wells': len(joined),
                'frozen_evaluation_evidence': json.loads((original / 'source_evidence.json').read_text()),
                'sources_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}}
    (output / 'source_evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
    reports.append({'author': name, 'sites': len(observations), 'wells': len(joined), 'effect_rows': len(effects)})
cohort['re_evaluation'] = {'scope': 'fixed original function chains, corrected engine; original development remains blind',
                         'run_manifests': [str(run / 'manifest.json') for run in arguments.run],
                         'original_cohort_sha256': hashlib.sha256(cohort_path.read_bytes()).hexdigest()}
(arguments.output / 'cohort.json').write_text(json.dumps(cohort, indent=2) + '\n')
(arguments.output / 'validation.json').write_text(json.dumps({'complete': True, 'analyses': reports}, indent=2) + '\n')
print(json.dumps(reports, indent=2))
