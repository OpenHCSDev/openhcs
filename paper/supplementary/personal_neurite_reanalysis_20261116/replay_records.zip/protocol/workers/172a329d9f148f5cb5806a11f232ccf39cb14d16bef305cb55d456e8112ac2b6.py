"""Replay declared image-analysis steps in retained software, emitting JSON lines.

A recorded Git definition supplies the crossing function; every other engine
binding stays unchanged. Original FunctionStep declarations and their existing
normalizer own preprocessing and arguments. Custom sources are loaded through
the original manager without persistence or UI signals. No remote file is written.
"""

import argparse
import ast
import faulthandler
import hashlib
from dataclasses import asdict
import json
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--software", type=Path, required=True)
parser.add_argument("--pipeline", type=Path, required=True)
parser.add_argument("--inventory", type=Path, required=True)
parser.add_argument("--field", nargs=2, action="append", required=True, metavar=("CODED_WELL", "SITE"))
parser.add_argument("--engine-sha256", required=True)
parser.add_argument("--pipeline-sha256", required=True)
parser.add_argument("--function-repository", type=Path, required=True)
parser.add_argument("--function-commit", required=True)
parser.add_argument("--custom-source", nargs=2, action="append", default=[], metavar=("PATH", "SHA256"))
parser.add_argument("--step-index", type=int, default=0)
arguments = parser.parse_args()
sys.path.insert(0, str(arguments.software))

import numpy as np
import tifffile
from openhcs.core.function_patterns import normalize_function_pattern
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.custom_functions import CustomFunctionManager
import openhcs.processing.backends.analysis.neurite_outgrowth as engine

engine_path = Path(engine.__file__).resolve()
assert engine_path.is_relative_to(arguments.software.resolve())
engine_source = engine_path.read_bytes()
assert hashlib.sha256(engine_source).hexdigest() == arguments.engine_sha256
function_name = engine._crossing_pairs.__name__
function_blob = subprocess.check_output([
    "git", "-C", str(arguments.function_repository), "show",
    f"{arguments.function_commit}:{engine_path.relative_to(arguments.software.resolve())}",
], text=True)
original_function, = [node for node in ast.walk(ast.parse(engine_source))
                       if isinstance(node, ast.FunctionDef) and node.name == function_name]
selected_function, = [node for node in ast.walk(ast.parse(function_blob))
                       if isinstance(node, ast.FunctionDef) and node.name == function_name]
assert ast.dump(original_function.args) == ast.dump(selected_function.args)
function_source = ast.get_source_segment(function_blob, selected_function)
assert function_source is not None
namespace_before = dict(vars(engine))
exec(compile(ast.Module(body=[selected_function], type_ignores=[]),
             f"<git:{arguments.function_commit}:{function_name}>", "exec"), vars(engine))
changed_bindings = [name for name, value in namespace_before.items()
                    if vars(engine)[name] is not value]
assert changed_bindings == [function_name]

manager = CustomFunctionManager(create_storage=False)
custom_sources = []
for source_path, expected_hash in arguments.custom_source:
    source_path = Path(source_path)
    source = source_path.read_bytes()
    assert hashlib.sha256(source).hexdigest() == expected_hash
    manager.register_from_code(source.decode(), persist=False, emit_signal=False,
                               expected_function_name=source_path.stem)
    custom_sources.append({"path": str(source_path), "sha256": expected_hash})
pipeline_source = arguments.pipeline.read_bytes()
assert hashlib.sha256(pipeline_source).hexdigest() == arguments.pipeline_sha256
syntax = ast.parse(pipeline_source, filename=str(arguments.pipeline))
function_expressions = []
spacing_expressions = []
for node in ast.walk(syntax):
    match node:
        case ast.Call(func=ast.Name(id="FunctionStep"), keywords=keywords):
            function_expressions.extend(keyword.value for keyword in keywords if keyword.arg == "func")
        case ast.Call(func=ast.Name(id="SourceVoxelSpacing")):
            spacing_expressions.append(node)
function_expression = function_expressions[arguments.step_index]
spacing_expression, = spacing_expressions
required_names = {node.id for expression in (function_expression, spacing_expression)
                  for node in ast.walk(expression) if isinstance(node, ast.Name)}
imports = []
for node in syntax.body:
    match node:
        case ast.ImportFrom(module=module, names=names, level=level):
            selected = [alias for alias in names if (alias.asname or alias.name) in required_names]
            if selected:
                imports.append(ast.ImportFrom(module=module, names=selected, level=level))
namespace = {}
exec(compile(ast.fix_missing_locations(ast.Module(body=imports, type_ignores=[])),
             str(arguments.pipeline), "exec"), namespace)
function_specification = eval(compile(ast.Expression(function_expression), str(arguments.pipeline), "eval"), namespace)
spacing = eval(compile(ast.Expression(spacing_expression), str(arguments.pipeline), "eval"), namespace)
step = FunctionStep(func=function_specification)
pattern = normalize_function_pattern(step.function_spec()).with_artifact_input_values(
    {"pixel_size": spacing.isotropic_xy_spacing},
)
assert not pattern.is_grouped
*preprocessing, analysis = pattern.iter_items()
function_arguments = [
    {"module": item.func.__module__, "name": item.func.__qualname__, "arguments": item.kwargs_dict}
    for item in [*preprocessing, analysis]
]

images_by_field = {}
for record in json.loads(arguments.inventory.read_text()):
    images_by_field.setdefault((record["well"], record["site"]), []).append(record)
for coded_well, site in arguments.field:
    site = int(site)
    images = sorted(images_by_field[coded_well, site], key=lambda record: record["channel"])
    assert [record["channel"] for record in images] == [1, 2]
    planes = []
    for record in images:
        image_path = Path(record["original"])
        assert hashlib.sha256(image_path.read_bytes()).hexdigest() == record["sha256"]
        plane = tifffile.imread(image_path)
        assert plane.shape == tuple(record["image_shape_yx"])
        assert plane.dtype == np.dtype(record["source_dtype"])
        planes.append(plane)
    image = np.stack(planes)
    faulthandler.dump_traceback_later(60)
    started = time.monotonic()
    for item in preprocessing:
        image = item.contract.resolve_raw_runtime_callable()(image, **item.kwargs_dict)
    outputs = analysis.contract.resolve_raw_runtime_callable()(image, **analysis.kwargs_dict)
    elapsed = time.monotonic() - started
    faulthandler.cancel_dump_traceback_later()
    summary, = outputs[1].row_mappings()
    cells = outputs[2].row_mappings()
    print(json.dumps({
        "scope": "controlled original-source replay; not updated publication results",
        "function_name": function_name,
        "function_source_commit": arguments.function_commit,
        "function_source_blob_sha256": hashlib.sha256(function_blob.encode()).hexdigest(),
        "function_declaration_sha256": hashlib.sha256(function_source.encode()).hexdigest(),
        "function_ast_matches_original": ast.dump(original_function) == ast.dump(selected_function),
        "changed_engine_bindings": changed_bindings,
        "python": sys.version,
        "engine": str(engine_path),
        "engine_sha256": arguments.engine_sha256,
        "pipeline": str(arguments.pipeline),
        "pipeline_sha256": arguments.pipeline_sha256,
        "pipeline_step": step.name,
        "function_arguments": function_arguments,
        "custom_sources": custom_sources,
        "coded_well": coded_well,
        "site": site,
        "inputs": images,
        "pixel_size": spacing.isotropic_xy_spacing,
        "summary": summary,
        "cell_rows": len(cells),
        "cells": cells,
        "elapsed_seconds_diagnostic_only": elapsed,
    }, default=asdict), flush=True)
