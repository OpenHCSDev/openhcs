"""Append to a measured field replay to capture its actual imported code."""
import base64
import importlib.machinery
from types import ModuleType

loaded = []
source_blobs = {}
for module_name, module in sorted(sys.modules.items()):
    match module:
        case ModuleType(__file__=str() as filename):
            path = Path(filename).resolve()
            if path.is_file():
                blob = path.read_bytes()
                digest = hashlib.sha256(blob).hexdigest()
                loaded.append({'module': module_name, 'path': str(path), 'sha256': digest})
                if str(path).endswith(tuple(importlib.machinery.SOURCE_SUFFIXES)):
                    source_blobs.setdefault(digest, base64.b64encode(blob).decode('ascii'))
            else:
                loaded.append({'module': module_name, 'origin': filename, 'source_file_present': False})
        case ModuleType():
            loaded.append({'module': module_name, 'file_origin_declared': False})
        case None:
            loaded.append({'module': module_name, 'loaded': False})
        case other:
            loaded.append({'module': module_name, 'file_origin_unscored': True,
                           'runtime_type': f'{type(other).__module__}.{type(other).__qualname__}'})
print(json.dumps({'scope': 'actual modules loaded by the preceding matched field replay; Python source bytes retained, binary modules fingerprinted',
                  'modules': loaded, 'python_source_blobs_base64': source_blobs}), flush=True)
