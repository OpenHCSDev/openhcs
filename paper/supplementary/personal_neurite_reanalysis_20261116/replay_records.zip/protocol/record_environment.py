"""Read the existing replay environment and editable Python-source changes."""
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
from urllib.parse import unquote, urlsplit

packages = []
editable_paths = set()
for distribution in importlib.metadata.distributions():
    metadata = distribution.metadata
    package = {'name': metadata['Name'], 'version': distribution.version}
    direct = distribution.read_text('direct_url.json')
    if direct is not None:
        package['direct_url'] = json.loads(direct)
        url = urlsplit(package['direct_url']['url'])
        if url.scheme == 'file' and package['direct_url'].get('dir_info', {}).get('editable', False):
            editable_paths.add(Path(unquote(url.path)).resolve())
    packages.append(package)

repositories = {}
for path in sorted(editable_paths):
    root = subprocess.run(['git', '-C', str(path), 'rev-parse', '--show-toplevel'], capture_output=True, text=True)
    if root.returncode != 0:
        repositories[str(path)] = {'git_error': root.stderr, 'exit': root.returncode}
        continue
    repository = root.stdout.strip()
    if repository in repositories:
        continue
    head = subprocess.check_output(['git', '-C', repository, 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', repository, 'status', '--short'], text=True)
    source_diff = subprocess.check_output(['git', '-C', repository, 'diff', 'HEAD', '--', '*.py', '*.pyi'], text=True)
    repositories[repository] = {'head': head, 'status': status, 'tracked_python_source_diff': source_diff,
                                'tracked_python_source_diff_sha256': hashlib.sha256(source_diff.encode()).hexdigest()}
executable = Path(sys.executable).resolve()
print(json.dumps({'scope': 'existing installed distribution versions and editable repository state; recorded during fixed replay, not a recreated environment',
                  'python': sys.version, 'executable': str(executable),
                  'executable_sha256': hashlib.sha256(executable.read_bytes()).hexdigest(),
                  'packages': sorted(packages, key=lambda record: record['name'].casefold()),
                  'editable_repositories': repositories}, indent=2))
