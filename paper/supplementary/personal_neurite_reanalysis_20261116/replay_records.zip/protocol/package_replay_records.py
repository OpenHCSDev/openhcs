"""Package measured replay records without changing their original contents."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[2]
scratch = Path('/home/ts/.cache/agent-scratch/openhcs-paper/alyson-nov13')
protocol = root / 'tmp/branching-replay'
dataset = root / 'paper/supplementary/personal_neurite_reanalysis_20261116'
entries = {}
with ZipFile(dataset / 'replay_records.zip', 'x', compression=ZIP_DEFLATED, compresslevel=6) as archive:
    def put(name, blob):
        archive.writestr(name, blob)
        entries[name] = hashlib.sha256(blob).hexdigest()

    for run_name in ('corrected-cohort-114-115', 'corrected-cohort-116'):
        run = scratch / run_name
        manifest = json.loads((run / 'manifest.json').read_text())
        assert all(result['exit'] == 0 for result in json.loads((run / 'outcomes.json').read_text()))
        worker = Path(manifest['runner'])
        assert hashlib.sha256(worker.read_bytes()).hexdigest() == manifest['runner_sha256']
        put(f'protocol/workers/{worker.name}', worker.read_bytes())
        for path in sorted(run.iterdir()):
            assert path.is_file()
            put(f'runs/{run_name}/{path.name}', path.read_bytes())
    for name in ('launch_replays.py', 'assemble_replay_tables.py', 'package_replay_records.py',
                 'record_environment.py', 'loaded_module_receipt.py'):
        put(f'protocol/{name}', (protocol / name).read_bytes())
    for name in ('projected-original-baseline-proof.json', 'corrected-numerical-claims.json',
                 'corrected-pooling-sensitivity.json'):
        put(f'validation/{name}', (scratch / name).read_bytes())
    put('validation/native-transport-proof.json', (scratch / 'native-transport-proof/proof.json').read_bytes())
    put('validation/prepared-source-proof.json', (scratch / 'prepared-corrected116-pilot/prepared-source-proof.json').read_bytes())
    environment = json.loads((protocol / 'runtime-environment.json').read_text())
    for repository in environment['editable_repositories'].values():
        repository.pop('tracked_python_source_diff', None)
    environment['projection'] = 'Source-diff text omitted; original diff fingerprints retained. Full recovery record preserved separately.'
    put('provenance/environment-fingerprints.json', (json.dumps(environment, indent=2) + '\n').encode())
    with (protocol / 'measured-runtime-modules-v2.jsonl').open() as stream:
        measured = json.loads(next(stream))
        modules = json.loads(next(stream))
        assert next(stream, None) is None
    modules.pop('python_source_blobs_base64')
    modules['projection'] = 'Actual module origins and fingerprints; Python source recovery bytes retained separately.'
    put('provenance/matched-field-measurement.json', (json.dumps(measured, indent=2) + '\n').encode())
    put('provenance/loaded-module-fingerprints.json', (json.dumps(modules, indent=2) + '\n').encode())
    put('archive-manifest.json', (json.dumps({'sha256': entries, 'cohort_evaluations': 540,
                                           'scope': 'New fixed-code replay; originals remain separate'}, indent=2) + '\n').encode())
with ZipFile(dataset / 'replay_records.zip') as archive:
    assert archive.testzip() is None
    for name, digest in entries.items():
        if name != 'archive-manifest.json':
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest
print('Verified replay archive:', dataset / 'replay_records.zip', len(entries), 'entries')
