import { useState, useEffect, useRef, useCallback } from "react";
import * as d3 from "d3";
import { computeStats, isArtifact, buildAdj, findRoots, bfs, FILTERS, applyFilters, identifyInvariants, validateTruePaths, detectCycles } from "./graph_utils";

// Demo data representing the structure of the 4-paper infrastructure
// Replace with actual graph.json from #export_graph_json
const DEMO_DATA = generateDemoGraph();

function generateDemoGraph() {
  const modules = [
    // Paper 1: AbstractClassSystem
    { prefix: "ACS", count: 40, kind: "theorem", paper: 1 },
    { prefix: "ACS.Def", count: 15, kind: "definition", paper: 1 },
    // Paper 2: SSOT
    { prefix: "Ssot", count: 25, kind: "theorem", paper: 2 },
    { prefix: "Ssot.Def", count: 10, kind: "definition", paper: 2 },
    // Paper 3: Leverage
    { prefix: "Leverage", count: 30, kind: "theorem", paper: 3 },
    { prefix: "Leverage.Def", count: 12, kind: "definition", paper: 3 },
    // Paper 4: DecisionQuotient
    { prefix: "DQ", count: 60, kind: "theorem", paper: 4 },
    { prefix: "DQ.Def", count: 25, kind: "definition", paper: 4 },
    { prefix: "DQ.Thermo", count: 20, kind: "theorem", paper: 4 },
    // Bridge
    { prefix: "Bridge", count: 15, kind: "theorem", paper: 0 },
    // Core
    { prefix: "Core.Nat", count: 3, kind: "axiom", paper: -1 },
  ];

  const nodes = [];
  const edges = [];
  let id = 0;

  for (const mod of modules) {
    for (let i = 0; i < mod.count; i++) {
      nodes.push({
        id: `${mod.prefix}.${i}`,
        kind: mod.kind,
        paper: mod.paper,
      });
      id++;
    }
  }

  // Create dense connectivity within modules
  for (const mod of modules) {
    const modNodes = nodes.filter((n) => n.id.startsWith(mod.prefix + "."));
    for (let i = 1; i < modNodes.length; i++) {
      edges.push({ source: modNodes[i].id, target: modNodes[i - 1].id });
      if (i > 2 && Math.random() > 0.6) {
        const j = Math.floor(Math.random() * (i - 1));
        edges.push({ source: modNodes[i].id, target: modNodes[j].id });
      }
    }
  }

  // Cross-module dependencies (papers depend on earlier papers)
  const paperNodes = (p) => nodes.filter((n) => n.paper === p);
  const connect = (fromPaper, toPaper, count) => {
    const from = paperNodes(fromPaper);
    const to = paperNodes(toPaper);
    for (let i = 0; i < count; i++) {
      const f = from[Math.floor(Math.random() * from.length)];
      const t = to[Math.floor(Math.random() * to.length)];
      edges.push({ source: f.id, target: t.id });
    }
  };

  // Core -> everything
  const core = paperNodes(-1);
  for (const p of [1, 2, 3, 4]) {
    const pn = paperNodes(p);
    for (let i = 0; i < 5; i++) {
      edges.push({
        source: pn[Math.floor(Math.random() * pn.length)].id,
        target: core[Math.floor(Math.random() * core.length)].id,
      });
    }
  }

  connect(2, 1, 12); // SSOT depends on ACS
  connect(3, 1, 8); // Leverage depends on ACS
  connect(3, 2, 10); // Leverage depends on SSOT
  connect(4, 1, 6); // DQ depends on ACS
  connect(0, 3, 8); // Bridge depends on Leverage
  connect(0, 4, 8); // Bridge depends on DQ
  connect(0, 2, 4); // Bridge depends on SSOT

  return { nodes, edges };
}

const PAPER_COLORS = {
  [-1]: "#ef4444", // Core/Nat — red
  0: "#f59e0b", // Bridge — amber
  1: "#3b82f6", // Paper 1: ACS — blue
  2: "#8b5cf6", // Paper 2: SSOT — purple
  3: "#10b981", // Paper 3: Leverage — green
  4: "#ec4899", // Paper 4: DQ — pink
};

const PAPER_NAMES = {
  [-1]: "Core Axioms (ℕ)",
  0: "Bridge Theorems",
  1: "Paper 1: AbstractClassSystem",
  2: "Paper 2: SSOT",
  3: "Paper 3: Leverage",
  4: "Paper 4: DecisionQuotient",
};

const KIND_SHAPES = {
  theorem: "circle",
  definition: "square",
  axiom: "diamond",
  other: "circle",
};

// computeStats provided by graph_utils.js (imported above)

function ForceGraph({ data, width, height, highlightPaper }) {
  const svgRef = useRef(null);
  const simRef = useRef(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const g = svg.append("g");

    // Zoom
    const zoom = d3.zoom().scaleExtent([0.1, 8]).on("zoom", (event) => {
      g.attr("transform", event.transform);
    });
    svg.call(zoom);

    const nodes = data.nodes.map((d) => ({ ...d }));
    const edges = data.edges.map((d) => ({ ...d }));

    const sim = d3
      .forceSimulation(nodes)
      .force(
        "link",
        d3
          .forceLink(edges)
          .id((d) => d.id)
          .distance(15)
          .strength(0.3)
      )
      .force("charge", d3.forceManyBody().strength(-8).distanceMax(150))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("collision", d3.forceCollide(4))
      .force(
        "cluster",
        d3.forceX(width / 2).strength(0.01)
      )
      .force("clusterY", d3.forceY(height / 2).strength(0.01));

    simRef.current = sim;

    const link = g
      .append("g")
      .selectAll("line")
      .data(edges)
      .join("line")
      .attr("stroke", "#ffffff08")
      .attr("stroke-width", 0.5);

    const node = g
      .append("g")
      .selectAll("circle")
      .data(nodes)
      .join("circle")
      .attr("r", (d) => (d.kind === "axiom" ? 5 : d.kind === "definition" ? 3.5 : 2.5))
      .attr("fill", (d) => PAPER_COLORS[d.paper] || "#666")
      .attr("stroke", "none")
      .attr("opacity", 0.85)
      .call(
        d3
          .drag()
          .on("start", (event, d) => {
            if (!event.active) sim.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
          })
          .on("drag", (event, d) => {
            d.fx = event.x;
            d.fy = event.y;
          })
          .on("end", (event, d) => {
            if (!event.active) sim.alphaTarget(0);
            d.fx = null;
            d.fy = null;
          })
      );

    node.append("title").text((d) => `${d.id} (${d.kind})`);

    sim.on("tick", () => {
      link
        .attr("x1", (d) => d.source.x)
        .attr("y1", (d) => d.source.y)
        .attr("x2", (d) => d.target.x)
        .attr("y2", (d) => d.target.y);
      node.attr("cx", (d) => d.x).attr("cy", (d) => d.y);
    });

    // Highlight paper on hover
    if (highlightPaper !== null) {
      node
        .attr("opacity", (d) =>
          d.paper === highlightPaper ? 1 : 0.08
        )
        .attr("r", (d) =>
          d.paper === highlightPaper
            ? d.kind === "axiom" ? 7 : d.kind === "definition" ? 5 : 4
            : d.kind === "axiom" ? 5 : d.kind === "definition" ? 3.5 : 2.5
        );
      link.attr("stroke", (d) => {
        const s = typeof d.source === "object" ? d.source : nodes.find((n) => n.id === d.source);
        const t = typeof d.target === "object" ? d.target : nodes.find((n) => n.id === d.target);
        return s?.paper === highlightPaper || t?.paper === highlightPaper
          ? PAPER_COLORS[highlightPaper] + "40"
          : "#ffffff03";
      });
    } else {
      node.attr("opacity", 0.85);
      link.attr("stroke", "#ffffff08");
    }

    return () => sim.stop();
  }, [data, width, height, highlightPaper]);

  return (
    <svg
      ref={svgRef}
      width={width}
      height={height}
      style={{ background: "#0a0a0a", borderRadius: 8 }}
    />
  );
}

export default function DependencyGraphViewer() {
  const [data] = useState(DEMO_DATA);
  const [stats, setStats] = useState(null);
  const [highlightPaper, setHighlightPaper] = useState(null);
  const [jsonInput, setJsonInput] = useState("");
  const [customData, setCustomData] = useState(null);
  const [hideArtifacts, setHideArtifacts] = useState(true);
  const [viewMode, setViewMode] = useState('forcing'); // 'forcing' | 'claims' | 'full'
  const [traceNode, setTraceNode] = useState("");
  const [tracePath, setTracePath] = useState(null);
  const [additionalJson, setAdditionalJson] = useState("");
  const [restrictPaper, setRestrictPaper] = useState(null);
  const [depthLimit, setDepthLimit] = useState(null);
  const [activeFilters, setActiveFilters] = useState([]);
  const [selectedNode, setSelectedNode] = useState(null);
  // True Path Enforcement state
  const [showTruePaths, setShowTruePaths] = useState(false);
  const [highlightInvariants, setHighlightInvariants] = useState(false);
  const [excludeTrivialCycles, setExcludeTrivialCycles] = useState(false);
  const [truePathValidation, setTruePathValidation] = useState(null);

  const rawData = customData || data;

  // Compute true path validation on data change
  useEffect(() => {
    if (rawData?.nodes?.length > 0) {
      const validation = validateTruePaths(rawData);
      setTruePathValidation(validation);
    }
  }, [rawData]);

  // Build active filter list and apply them deterministically
  useEffect(() => {
    const f = [];
    if (viewMode === 'forcing') {
      f.push({ name: 'forcingChain' });
    } else if (viewMode === 'claims') {
      f.push({ name: 'claimsOnly' });
    } else {
      if (hideArtifacts) f.push({ name: 'hideArtifacts' });
    }
    if (restrictPaper != null) f.push({ name: 'restrictToPaper', params: { paper: restrictPaper } });
    if (depthLimit != null && depthLimit !== "") f.push({ name: 'depthLimit', params: { depth: Number(depthLimit) } });
    // True path filters
    if (showTruePaths) f.push({ name: 'truePathsOnly' });
    if (highlightInvariants) f.push({ name: 'highlightInvariants' });
    if (excludeTrivialCycles) f.push({ name: 'excludeTrivialCycles' });
    setActiveFilters(f);
  }, [viewMode, hideArtifacts, restrictPaper, depthLimit, showTruePaths, highlightInvariants, excludeTrivialCycles]);

  const activeData = applyFilters(rawData, activeFilters);

  useEffect(() => {
    setStats(computeStats(activeData));
  }, [activeData]);

  const handleLoadJson = useCallback(() => {
    try {
      const parsed = JSON.parse(jsonInput);
      // Assign papers based on prefix if not present
      for (const n of parsed.nodes) {
        if (n.paper === undefined) {
          if (n.id.startsWith("AbstractClassSystem")) n.paper = 1;
          else if (n.id.startsWith("Ssot")) n.paper = 2;
          else if (n.id.startsWith("Leverage")) n.paper = 3;
          else if (n.id.startsWith("DecisionQuotient")) n.paper = 4;
          else if (n.id.includes("Nat") || n.id.includes("Core")) n.paper = -1;
          else n.paper = 0;
        }
      }
      setCustomData(parsed);
    } catch {
      // silent
    }
  }, [jsonInput]);

  const handleMergeGraphs = useCallback(() => {
    try {
      const base = customData || JSON.parse(jsonInput || "null") || data;
      const extra = JSON.parse(additionalJson);
      const nodeMap = new Map();
      for (const n of base.nodes || []) nodeMap.set(n.id, n);
      for (const n of extra.nodes || []) nodeMap.set(n.id, { ...(nodeMap.get(n.id) || {}), ...n });
      const edgesSet = new Set();
      const edges = [];
      const addEdge = (e) => {
        const s = typeof e.source === 'object' ? e.source.id : e.source;
        const t = typeof e.target === 'object' ? e.target.id : e.target;
        const key = `${s}->${t}`;
        if (!edgesSet.has(key)) { edgesSet.add(key); edges.push({ source: s, target: t }); }
      };
      for (const e of base.edges || []) addEdge(e);
      for (const e of extra.edges || []) addEdge(e);
      const merged = { nodes: Array.from(nodeMap.values()), edges };
      setCustomData(merged);
    } catch (err) {
      // ignore parse errors for now
      console.error('merge error', err);
    }
  }, [customData, jsonInput, additionalJson, data]);

  const handleTrace = useCallback(() => {
    try {
      const adj = buildAdj(activeData.nodes, activeData.edges);
      const roots = findRoots(activeData.nodes, adj);
      const path = bfs(traceNode, adj, roots);
      setTracePath(path);
    } catch (e) {
      setTracePath([`error: ${e.message}`]);
    }
  }, [activeData, traceNode]);

  return (
    <div
      style={{
        fontFamily: "'JetBrains Mono', 'SF Mono', 'Fira Code', monospace",
        background: "#0a0a0a",
        color: "#e0e0e0",
        minHeight: "100vh",
        padding: 0,
        margin: 0,
      }}
    >
      {/* Header */}
      <div
        style={{
          borderBottom: "1px solid #1a1a1a",
          padding: "20px 28px",
          display: "flex",
          alignItems: "baseline",
          gap: 16,
        }}
      >
        <span
          style={{
            fontSize: 15,
            fontWeight: 700,
            letterSpacing: "0.08em",
            color: "#fff",
          }}
        >
          PROOF INTEGRITY GRAPH
        </span>
        <span style={{ fontSize: 11, color: "#555", letterSpacing: "0.05em" }}>
          ONE LOGIC GRAPH · ZERO EXITS
        </span>
      </div>

      {/* Controls */}
      <div style={{ padding: "12px 28px", borderBottom: "1px solid #1a1a1a", display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        {/* View Mode Toggle */}
        <div style={{ display: 'flex', gap: 4, background: '#0d0d0d', padding: 4, borderRadius: 4, border: '1px solid #222' }}>
          <button
            onClick={() => setViewMode('forcing')}
            style={{
              padding: '6px 12px',
              background: viewMode === 'forcing' ? '#ef4444' : 'transparent',
              color: viewMode === 'forcing' ? '#fff' : '#888',
              border: 'none',
              borderRadius: 3,
              fontSize: 11,
              fontWeight: viewMode === 'forcing' ? 600 : 400,
              cursor: 'pointer',
              letterSpacing: '0.03em',
            }}
          >
            FORCING CHAIN
          </button>
          <button
            onClick={() => setViewMode('claims')}
            style={{
              padding: '6px 12px',
              background: viewMode === 'claims' ? '#10b981' : 'transparent',
              color: viewMode === 'claims' ? '#000' : '#888',
              border: 'none',
              borderRadius: 3,
              fontSize: 11,
              fontWeight: viewMode === 'claims' ? 600 : 400,
              cursor: 'pointer',
              letterSpacing: '0.03em',
            }}
          >
            CLAIMS ONLY
          </button>
          <button
            onClick={() => setViewMode('full')}
            style={{
              padding: '6px 12px',
              background: viewMode === 'full' ? '#f59e0b' : 'transparent',
              color: viewMode === 'full' ? '#000' : '#888',
              border: 'none',
              borderRadius: 3,
              fontSize: 11,
              fontWeight: viewMode === 'full' ? 600 : 400,
              cursor: 'pointer',
              letterSpacing: '0.03em',
            }}
          >
            FULL GRAPH
          </button>
        </div>
        
        {viewMode === 'full' && (
          <label style={{ fontSize: 12, color: '#ccc' }}>
            <input type="checkbox" checked={hideArtifacts} onChange={(e) => setHideArtifacts(e.target.checked)} /> Hide artifacts
          </label>
        )}
        {/* Restrict-to-paper and depth controls */}
        <button
          onClick={() => setRestrictPaper(restrictPaper === highlightPaper ? null : highlightPaper)}
          title="Restrict view to currently highlighted paper"
          style={{ padding: '6px 10px', marginLeft: 6, fontSize: 11, cursor: 'pointer' }}
        >
          {restrictPaper == null ? 'Restrict to highlighted paper' : `Restricted: ${PAPER_NAMES[restrictPaper] || restrictPaper}`}
        </button>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <input
            type="number"
            placeholder="depth"
            value={depthLimit == null ? '' : depthLimit}
            onChange={(e) => setDepthLimit(e.target.value)}
            style={{ width: 64, background:'#0d0d0d', border:'1px solid #222', color:'#ddd', padding:'6px 8px' }}
          />
          <button onClick={() => setDepthLimit(null)} style={{ padding:'6px 8px' }}>Clear depth</button>
        </div>
        
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input placeholder="node id to trace" value={traceNode} onChange={(e) => setTraceNode(e.target.value)}
            style={{ background:'#0d0d0d', border:'1px solid #222', color:'#ddd', padding:'6px 8px' }} />
          <button onClick={handleTrace} style={{ padding:'6px 10px' }}>Trace</button>
        </div>

        <div style={{ marginLeft: 'auto', fontSize: 12, color: '#888' }}>{stats ? `${stats.totalNodes} nodes · ${stats.totalEdges} edges` : ''}</div>
      </div>

      {/* True Path Enforcement Controls */}
      <div style={{ padding: "8px 28px", borderBottom: "1px solid #1a1a1a", display: "flex", gap: 16, alignItems: "center", background: "#0d0d15" }}>
        <span style={{ fontSize: 10, color: '#666', letterSpacing: '0.1em' }}>TRUE PATHS:</span>
        <label style={{ fontSize: 12, color: '#ccc', cursor: 'pointer' }}>
          <input type="checkbox" checked={showTruePaths} onChange={(e) => setShowTruePaths(e.target.checked)} style={{ marginRight: 4 }} />
          Show True Paths Only
        </label>
        <label style={{ fontSize: 12, color: '#ccc', cursor: 'pointer' }}>
          <input type="checkbox" checked={highlightInvariants} onChange={(e) => setHighlightInvariants(e.target.checked)} style={{ marginRight: 4 }} />
          Highlight Invariants
        </label>
        <label style={{ fontSize: 12, color: '#ccc', cursor: 'pointer' }}>
          <input type="checkbox" checked={excludeTrivialCycles} onChange={(e) => setExcludeTrivialCycles(e.target.checked)} style={{ marginRight: 4 }} />
          Exclude Trivial Cycles
        </label>
        {truePathValidation && (
          <span style={{
            marginLeft: 'auto',
            fontSize: 11,
            color: truePathValidation.valid ? '#10b981' : '#ef4444',
            fontWeight: 500
          }}>
            {truePathValidation.valid ? '✓' : '✗'} {truePathValidation.pathCount}/{truePathValidation.claimCount} paths ·
            {truePathValidation.invariants?.length || 0} invariants ·
            {truePathValidation.cycles?.length || 0} cycles
          </span>
        )}
      </div>

      {/* View Mode Explanation */}
      <div style={{ padding: "10px 28px", borderBottom: "1px solid #1a1a1a", background: viewMode === 'forcing' ? '#1a0d0d' : viewMode === 'claims' ? '#0d291e' : '#291f0d' }}>
        <div style={{ fontSize: 11, color: viewMode === 'forcing' ? '#ef4444' : viewMode === 'claims' ? '#10b981' : '#f59e0b', letterSpacing: '0.03em' }}>
          {viewMode === 'forcing' ? (
            <>
              <strong>FORCING CHAIN:</strong> Shows only the path from claims to first principles.
              Red nodes = forcing theorems. Blue nodes = pure math (counting, lists, logic).
              <strong> To reject a claim, you must reject counting.</strong>
            </>
          ) : viewMode === 'claims' ? (
            <>
              <strong>CLAIMS ONLY MODE:</strong> Shows only theorems and definitions cited in the paper, connected through the proof structure. 
              Hides auxiliary lemmas and Lean-generated artifacts that are implementation details.
            </>
          ) : (
            <>
              <strong>FULL GRAPH MODE:</strong> Shows all nodes including auxiliary lemmas and technical infrastructure. 
              Disconnected clusters are internal proof machinery not cited in the paper text.
            </>
          )}
        </div>
      </div>

      {/* Stats row */}
      {stats && (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            borderBottom: "1px solid #1a1a1a",
          }}
        >
          {[
            {
              label: viewMode === 'claims' ? "PROOF STRUCTURE" : "CONNECTED COMPONENTS",
              value: stats.components,
              target: 1,
              color: stats.components === 1 ? "#10b981" : "#ef4444",
              subtext: viewMode === 'claims' 
                ? (stats.components === 1 ? "✓ UNIFIED" : "✗ FRAGMENTED")
                : (stats.components === 1 ? "✓ VERIFIED" : "✗ INTEGRITY VIOLATION"),
            },
            {
              label: viewMode === 'claims' ? "UNREACHABLE CLAIMS" : "COUNTING REJECTIONS",
              value: stats.orphans,
              target: 0,
              color: stats.orphans === 0 ? "#10b981" : "#ef4444",
              subtext: stats.orphans === 0 ? "✓ ALL CONNECTED" : "✗ DISCONNECTED NODES",
            },
            {
              label: "SORRY COUNT",
              value: 0,
              target: 0,
              color: "#10b981",
              subtext: "✓ COMPLETE",
            },
            {
              label: viewMode === 'claims' ? "CITED CLAIMS" : "DECLARATIONS",
              value: stats.totalNodes,
              target: null,
              color: "#3b82f6",
              subtext: viewMode === 'claims' ? "IN PAPER" : "TOTAL",
            },
          ].map((s, i) => (
            <div
              key={i}
              style={{
                padding: "18px 28px",
                borderRight: i < 3 ? "1px solid #1a1a1a" : "none",
              }}
            >
              <div
                style={{
                  fontSize: 36,
                  fontWeight: 800,
                  color: s.color,
                  lineHeight: 1,
                  fontVariantNumeric: "tabular-nums",
                }}
              >
                {s.value}
              </div>
              <div
                style={{
                  fontSize: 9,
                  color: "#555",
                  letterSpacing: "0.12em",
                  marginTop: 6,
                }}
              >
                {s.label}
              </div>
              {s.subtext && (
                <div
                  style={{
                    fontSize: 9,
                    color: s.color,
                    marginTop: 2,
                  }}
                >
                  {s.subtext}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Breakdown row */}
      {stats && (
        <div
          style={{
            display: "flex",
            gap: 24,
            padding: "12px 28px",
            borderBottom: "1px solid #1a1a1a",
            fontSize: 11,
            color: "#666",
          }}
        >
          <span>
            theorems:{" "}
            <span style={{ color: "#e0e0e0" }}>{stats.theorems}</span>
          </span>
          <span>
            definitions:{" "}
            <span style={{ color: "#e0e0e0" }}>{stats.definitions}</span>
          </span>
          <span>
            axioms:{" "}
            <span style={{ color: "#e0e0e0" }}>{stats.axioms}</span>
          </span>
          <span>
            edges:{" "}
            <span style={{ color: "#e0e0e0" }}>{stats.totalEdges}</span>
          </span>
          <span>
            reachable from ℕ:{" "}
            <span style={{ color: "#10b981" }}>{stats.reachableFromCore}</span>
            <span style={{ color: "#555" }}>/{stats.totalNodes}</span>
          </span>
        </div>
      )}

      {/* Legend */}
      <div
        style={{
          display: "flex",
          gap: 2,
          padding: "10px 28px",
          borderBottom: "1px solid #1a1a1a",
          flexWrap: "wrap",
        }}
      >
        {Object.entries(PAPER_NAMES).map(([key, name]) => (
          <button
            key={key}
            onClick={() =>
              setHighlightPaper(
                highlightPaper === Number(key) ? null : Number(key)
              )
            }
            style={{
              background:
                highlightPaper === Number(key)
                  ? PAPER_COLORS[Number(key)] + "20"
                  : "transparent",
              border: `1px solid ${
                highlightPaper === Number(key)
                  ? PAPER_COLORS[Number(key)]
                  : "#222"
              }`,
              borderRadius: 4,
              padding: "4px 10px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontSize: 10,
              color:
                highlightPaper === Number(key)
                  ? PAPER_COLORS[Number(key)]
                  : "#888",
              transition: "all 0.15s",
            }}
          >
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: PAPER_COLORS[Number(key)],
                display: "inline-block",
              }}
            />
            {name}
          </button>
        ))}
      </div>

      {/* Graph + Sidebar */}
      <div style={{ display: 'flex', padding: "0 28px" }}>
        <div style={{ flex: 1 }}>
          <ForceGraph
            data={activeData}
            width={700}
            height={500}
            highlightPaper={highlightPaper}
          />
        </div>
        
        {/* Rejection Cost Sidebar */}
        {viewMode === 'forcing' && (
          <div style={{ width: 200, paddingLeft: 16, borderLeft: '1px solid #1a1a1a' }}>
            <div style={{ fontSize: 10, color: '#666', letterSpacing: '0.1em', marginBottom: 12 }}>
              REJECTION COST
            </div>
            
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 11, color: '#ef4444', fontWeight: 600, marginBottom: 4 }}>
                FORCING THEOREMS
              </div>
              <div style={{ fontSize: 10, color: '#888', lineHeight: 1.4 }}>
                First-principles theorems. Rejecting requires rejecting logic.
              </div>
            </div>
            
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 11, color: '#3b82f6', fontWeight: 600, marginBottom: 4 }}>
                PURE MATH (Nat, List)
              </div>
              <div style={{ fontSize: 10, color: '#888', lineHeight: 1.4 }}>
                Counting, arithmetic, ordering. Undeniable.
              </div>
            </div>
            
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 11, color: '#10b981', fontWeight: 600, marginBottom: 4 }}>
                CLAIMS
              </div>
              <div style={{ fontSize: 10, color: '#888', lineHeight: 1.4 }}>
                Paper results. Each traces to forcing → math.
              </div>
            </div>
            
            <div style={{ marginTop: 24, padding: 8, background: '#1a0d0d', borderRadius: 4, border: '1px solid #331111' }}>
              <div style={{ fontSize: 10, color: '#ef4444', lineHeight: 1.5 }}>
                <strong>To reject any claim:</strong><br/>
                You must reject counting (Nat.add).<br/>
                You must reject logic (Decidable).<br/>
                <strong>You must lie.</strong>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Trace output */}
      <div style={{ padding: '8px 28px', minHeight: 36 }}>
        {tracePath && (
          <div style={{ background: '#0d0d0d', border: '1px solid #222', padding: 8, borderRadius: 4, color:'#ddd', fontSize:12 }}>
            <strong>Trace path:</strong> {tracePath.join(' → ')}
          </div>
        )}
      </div>

      {/* Import section */}
      <div
        style={{
          padding: "16px 28px",
          borderTop: "1px solid #1a1a1a",
        }}
      >
        <div
          style={{
            fontSize: 9,
            color: "#555",
            letterSpacing: "0.1em",
            marginBottom: 8,
          }}
        >
          LOAD GRAPH.JSON FROM{" "}
          <span style={{ color: "#888" }}>#export_graph_json</span>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <textarea
            value={jsonInput}
            onChange={(e) => setJsonInput(e.target.value)}
            placeholder='Paste graph.json contents here...'
            style={{
              flex: 1,
              background: "#111",
              border: "1px solid #222",
              borderRadius: 4,
              color: "#888",
              fontFamily: "inherit",
              fontSize: 10,
              padding: "8px 12px",
              resize: "vertical",
              minHeight: 36,
              maxHeight: 120,
            }}
          />
          <button
            onClick={handleLoadJson}
            style={{
              background: "#1a1a1a",
              border: "1px solid #333",
              borderRadius: 4,
              color: "#e0e0e0",
              fontFamily: "inherit",
              fontSize: 10,
              padding: "8px 16px",
              cursor: "pointer",
              letterSpacing: "0.05em",
              whiteSpace: "nowrap",
            }}
          >
            LOAD
          </button>
        </div>
      </div>

      {/* Footer */}
      <div
        style={{
          padding: "16px 28px",
          borderTop: "1px solid #1a1a1a",
          fontSize: 9,
          color: "#333",
          letterSpacing: "0.05em",
        }}
      >
        {viewMode === 'forcing' ? (
          <>
            <strong style={{ color: '#ef4444' }}>FORCING CHAIN:</strong> Every claim traces to counting (Nat) and logic (Decidable).
            To reject any theorem here, you must reject arithmetic itself. The chain is visible. The cost is explicit.
          </>
        ) : (
          <>
            To reject any node in this graph, trace the dependency chain to its root.
            The root is ℕ. To reject any definition, you must reject counting.
          </>
        )}
      </div>
    </div>
  );
}
