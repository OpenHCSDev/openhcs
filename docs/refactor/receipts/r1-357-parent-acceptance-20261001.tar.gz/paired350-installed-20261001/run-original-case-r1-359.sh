#!/bin/bash
# Parent qualification of the reviewed original-consumer repair on retained failure.
set -euo pipefail
unset PYTHONPATH
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export XDG_CACHE_HOME=/home/ts/.cache/agent-scratch/r1-357-parent-20261001/cache
export TMPDIR=/home/ts/.cache/agent-scratch/r1-357-parent-20261001
export GIT_CONFIG_COUNT=2
export GIT_CONFIG_KEY_0=core.packedGitWindowSize GIT_CONFIG_VALUE_0=8m
export GIT_CONFIG_KEY_1=core.packedGitLimit GIT_CONFIG_VALUE_1=128m
mkdir -p "$TMPDIR" "$XDG_CACHE_HOME"
test "$(git -C /home/ts/wt/openhcs-r1-revision-staging-357-20261001 rev-parse HEAD)" = 59899d30b53c43e0bd3ecfd460d3d424848addbc
test "$(git -C /home/ts/wt/nra-bounded-full-audit-20260929 rev-parse HEAD)" = 673c062fc656e9c74f1eddcab30f036c9befbc1f
cd /home/ts/wt/openhcs-ui-workflow-rendering-20261001
exec /home/ts/wt/openhcs-generated-inputs-installed-parent-20261001/.venv/bin/python -I -B -c \
  'import runpy,sys; from pathlib import Path; sys.path.insert(0,"/home/ts/wt/nra-bounded-full-audit-20260929"); import nominal_refactor_advisor; assert Path(nominal_refactor_advisor.__file__).is_relative_to(Path("/home/ts/wt/nra-bounded-full-audit-20260929")); runpy.run_path("/home/ts/wt/openhcs-r1-revision-staging-357-20261001/scripts/check_refactor_r1.py",run_name="__main__")' \
  --base c81963475e6221961be5209c47c36f5f4c222521 \
  --head 901e9a49a6e18f0b9c86574210568d1a3efbae67 \
  --scratch-root /home/ts/.cache/agent-scratch/r1-357-parent-20261001/r1 \
  --budget-seconds 160
