"""One finite #433 VALUES repeat, using existing measured/science/memory owners."""
from pathlib import Path
from dataclasses import replace
import argparse, fcntl, importlib.util, json, os, shutil, sys, time

PREP=Path(__file__).parent
SOURCE=PREP.parent/'issue433-controlled-values-a6-source'
OUTPUT=PREP.parent/'issue433-controlled-values-a6-qualified'
GOLD=PREP.parent/'canonical-runtime-cache-client-paired-v12-qualified'
HEAD='a6c0e1e030ae6b9859c7447541a7f1f89531e1cd'
V12=PREP.parent/'canonical-runtime-cache-client-paired-v12-preparation/controller.py'
spec=importlib.util.spec_from_file_location('existing_paired_owner',V12)
c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c);c.SOURCE=SOURCE
sys.path.insert(0,str(SOURCE))
base,ordinary,sparse=c.helpers();sparse.SUPPLEMENT=PREP/'sparse-supplement'
os.environ.update(c.environment(ordinary,OUTPUT))
from benchmark.runtime_env import configure_headless_cpu_benchmark_runtime
configure_headless_cpu_benchmark_runtime('WARNING')
import openhcs
assert Path(openhcs.__file__).resolve().parent.parent==SOURCE
from openhcs.runtime import zmq_config
zmq_config.OPENHCS_ZMQ_CONFIG=replace(zmq_config.OPENHCS_ZMQ_CONFIG,client_connect_timeout_seconds=180.0)

CASES=c.CASES
SEQUENCE=(CASES[0],CASES[1],CASES[2],CASES[0])*4
CAP_MB=6144
DISK_LIMIT=1024**3

def write(path,value): c.write(path,value)
def native_hashes():
    return {str(p):c.sha(p) for case in CASES for repeat in range(2)
        for p in sorted((GOLD/'native'/case/'outputs'/str(repeat)).rglob('*')) if p.is_file()}

def prepare():
    assert not OUTPUT.exists()
    assert c.git(SOURCE,'rev-parse','HEAD')==HEAD and not c.git(SOURCE,'status','--porcelain')
    assert shutil.disk_usage(OUTPUT.parent).free>3*1024**3
    OUTPUT.mkdir();(OUTPUT/'tmp').mkdir()
    frozen=c.source_state(base,sparse,ordinary,OUTPUT)
    gold_science=json.loads((GOLD/'strict-science.json').read_text())
    assert gold_science['status']=='PASS' and len(gold_science['comparisons'])==12
    write(OUTPUT/'source-freeze.json',{'source_state':frozen,'native_output_hashes':native_hashes(),
        'native_science_sha256':c.sha(GOLD/'strict-science.json'),'native_freeze_sha256':c.sha(GOLD/'source-freeze.json'),
        'controller_sha256':c.sha(Path(__file__)),'sequence':SEQUENCE,'aggregate_cap_mb':CAP_MB,
        'disk_limit_bytes':DISK_LIMIT,'scope':'Finite one-server VALUES repeat, not latency or full30 qualification. No forced GC/global clear/threshold changes/restarts. Native outputs reused solely for science.'})
    print(json.dumps({'status':'PREPARED_NOT_RUN','source_head':HEAD,'sequence':SEQUENCE,'cap_mb':CAP_MB,'output':str(OUTPUT)}),flush=True)

def validate(f):
    assert c.source_state(base,sparse,ordinary,OUTPUT)==f['source_state'],'Source/environment/input drift'
    assert native_hashes()==f['native_output_hashes'],'Native golden drift'
    assert c.sha(GOLD/'strict-science.json')==f['native_science_sha256']
    assert c.sha(GOLD/'source-freeze.json')==f['native_freeze_sha256']
    assert c.sha(Path(__file__))==f['controller_sha256']

def disk_budget():
    size=sum(p.stat().st_size for p in OUTPUT.rglob('*') if p.is_file())
    assert size<DISK_LIMIT,('Retained output budget',size)
    return size

def prepared_cases():
    from openhcs.core.input_workspace import InputWorkspacePreparationRequest
    from openhcs.interop.cellprofiler.plate_workspace import prepare_cellprofiler_input_workspace
    from benchmark.well_throughput_scaling import _replicate_source_binding_workspace_wells,_synthetic_well_ids
    goldfreeze=json.loads((GOLD/'source-freeze.json').read_text());result={}
    for case in c.resolved_cases():
        folder=OUTPUT/'inputs'/case.name;folder.mkdir(parents=True)
        prepared=prepare_cellprofiler_input_workspace(InputWorkspacePreparationRequest(
            selected_path=case.dataset_path,selected_pipeline_path=case.cppipe_path,
            workspace_root=folder/'source_workspace',generated_source_path=folder/'imported_pipeline.py'))
        assert prepared.pipeline_import_error is None and prepared.materialization is not None
        assert prepared.pipeline_steps is not None and prepared.pipeline_config is not None
        ids=_replicate_source_binding_workspace_wells(prepared.materialization.metadata_path,
            _synthetic_well_ids(1),source_well_filter=case.well_filter_config)
        assert c.projection_rows(prepared.execution_plate_path)==tuple(goldfreeze['requests'][case.name]['expected_source_rows'])
        result[case.name]=(case,prepared,ids)
    return result

def submission_for(index,name,prepared):
    from openhcs.core.config import GlobalPipelineConfig,AnalysisConsolidationConfig,LazyWellFilterConfig,LazyPathPlanningConfig,LazyVFSConfig,MaterializationBackend,MultiprocessingStartMethod
    from objectstate.lazy_factory import rebuild_lazy_config_with_new_global_reference
    from openhcs.core.function_step_transport import FunctionStepTransportAuthority
    from openhcs.core.pipeline_document import PipelineDocumentAuthority
    from openhcs.runtime.zmq_execution_client import OpenHCSExecutionSubmission
    from openhcs.runtime.zmq_execution_signature import ZMQAuxiliaryExecutionParams,ZMQRuntimeObservationExportScope
    case,prep,ids=prepared
    folder=OUTPUT/'jobs'/f'{index:02d}-{name}';folder.mkdir(parents=True)
    global_config=GlobalPipelineConfig(num_workers=1,use_threading=True,multiprocessing_start_method=MultiprocessingStartMethod.FORK,
        analysis_consolidation_config=AnalysisConsolidationConfig(enabled=False),materialize_runtime_artifacts=False)
    config=rebuild_lazy_config_with_new_global_reference(replace(prep.pipeline_config,num_workers=None,use_threading=None,
        multiprocessing_start_method=None,materialize_runtime_artifacts=False,well_filter_config=LazyWellFilterConfig(well_filter=list(ids)),
        path_planning_config=LazyPathPlanningConfig(well_filter=0,global_output_folder=folder,output_dir_suffix='_controlled_values'),
        vfs_config=LazyVFSConfig(materialization_backend=MaterializationBackend.DISK)),global_config,GlobalPipelineConfig)
    return OpenHCSExecutionSubmission(plate_id=case.dataset_path,execution_plate_id=prep.execution_plate_path,
        selected_pipeline_path=case.cppipe_path,pipeline_document=PipelineDocumentAuthority.from_values(pipeline_config=config,
        pipeline_steps=FunctionStepTransportAuthority.normalize_pipeline(prep.pipeline_steps)),global_config=global_config).with_auxiliary_params(
        ZMQAuxiliaryExecutionParams(runtime_observation_export_path=(folder/'evidence/runtime_values.pkl.gz').resolve(),
            runtime_observation_export_scope=ZMQRuntimeObservationExportScope.VALUES))

def compare(name,completed):
    # Exact scientific/inventory operations from the qualified V12 controller.
    from benchmark.adapters.openhcs import _strict_cellprofiler_runtime_equivalence_policy
    from benchmark.matched_cellprofiler_batch import _require_compared_output_inventory
    from openhcs.core.equivalence.outputs import RuntimeOutputSnapshot
    from openhcs.core.equivalence.comparison import runtime_image_differences
    from openhcs.core.equivalence.policy import RuntimeEquivalencePolicy
    from openhcs.core.runtime_exports import RuntimeExportObservation
    from openhcs.core.runtime_equivalence import RuntimeMeasurementSnapshot,runtime_measurement_equivalence
    from openhcs.core.source_matching import SourceImageSetIdentityPolicy
    from openhcs.constants.constants import AllComponents
    from openhcs.core.virtual_workspace_metadata import METADATA_CONFIG
    goldfreeze=json.loads((GOLD/'source-freeze.json').read_text());policy=_strict_cellprofiler_runtime_equivalence_policy()
    roots=completed.output_roots;ce=RuntimeExportObservation.from_output_roots(roots)
    identity_policy=SourceImageSetIdentityPolicy(frozenset(AllComponents(v) for v in goldfreeze['requests'][name]['plane_members']))
    cs=RuntimeOutputSnapshot.from_export_observation(ce,source_workspaces=roots,image_set_policy=identity_policy)
    cm=RuntimeMeasurementSnapshot.from_output_snapshot(cs,policy=policy);cm.required_relationship_correlations();results=[]
    for repeat in range(2):
        native_root=GOLD/'native'/name/'outputs'/str(repeat)
        ne=RuntimeExportObservation.from_output_root(native_root);ns=RuntimeOutputSnapshot.from_export_observation(ne)
        files=tuple(frozenset(p for root in rs for p in root.rglob('*') if p.is_file()) for rs in ((native_root,),roots))
        hashes={str(p):c.sha(p) for group in files for p in group}
        nm=RuntimeMeasurementSnapshot.from_output_snapshot(ns,policy=policy);nm.required_relationship_correlations()
        measurements=runtime_measurement_equivalence(nm,cm,policy=policy)
        image_policy=RuntimeEquivalencePolicy(image_abs_tolerance=0,image_rel_tolerance=0) if name==CASES[0] else policy
        images=runtime_image_differences(ns.images,cs.images,image_policy)
        assert measurements.is_equivalent,measurements.failure_messages();assert not images,images
        _require_compared_output_inventory(reference_files=files[0],candidate_files=files[1],reference_exports=ne,candidate_exports=ce,
            reference_snapshot=ns,candidate_snapshot=cs,candidate_managed_files=frozenset(p for root in roots for p in METADATA_CONFIG.managed_paths(root)))
        assert ns.tables and cs.tables and all(t.rows for t in (*ns.tables,*cs.tables) if t.participates_in_comparison)
        assert {str(p):c.sha(p) for group in files for p in group}==hashes
        results.append({'native_repeat':repeat,'measurement_differences':0,'image_differences':0,'tables':[len(ns.tables),len(cs.tables)],
            'physical_images':[len(ne.image_outputs),len(ce.image_outputs)],'logical_images':[len(ns.images),len(cs.images)],
            'known_relationship_keys':[len(nm.required_relationship_correlations()),len(cm.required_relationship_correlations())]})
    return results

def run():
    import psutil
    from benchmark.metrics.memory import MemoryMetric
    from benchmark.well_throughput_scaling import ChildProcessTerminator
    from benchmark.openhcs_measured_run import _ZMQProgressTimingObserver,execute_measured_openhcs_pipeline_on_client
    from benchmark.timing import PhaseTimingTrace
    from openhcs.runtime.zmq_execution_client import ZMQExecutionClient
    from zmqruntime import DataControlPortPairAuthority
    from scripts.mcp_thesis_demo_live import official_runtime_lock_path
    assert sorted(os.sched_getaffinity(0))==[5]
    f=json.loads((OUTPUT/'source-freeze.json').read_text());validate(f)
    prepared=prepared_cases();disk_budget()
    observer=_ZMQProgressTimingObserver();config=zmq_config.OPENHCS_ZMQ_CONFIG
    port=DataControlPortPairAuthority.acquire(config,transport_mode=config.transport_mode).data_port
    class RetainedSamples(MemoryMetric):
        # Only journal already-owned RSS samples. No replacement discovery/sampler.
        def _sample_process_tree_rss(self):
            rss,children=super()._sample_process_tree_rss()
            child_samples=[]
            for child in children:
                try:child_samples.append((child.pid,child.memory_info().rss))
                except (psutil.NoSuchProcess,psutil.AccessDenied):continue
            journal.write(json.dumps({'epoch':time.time(),'aggregate_rss_bytes':rss,'children':child_samples})+'\n')
            journal.flush();return rss,children
    records=[]
    with official_runtime_lock_path().open('a+') as lease:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with (OUTPUT/'rss-samples.jsonl').open('x') as journal,RetainedSamples(interval_seconds=.05,
                max_memory_mb=CAP_MB,on_limit_exceeded=ChildProcessTerminator(),interrupt_main_on_limit=True) as memory:
            with ZMQExecutionClient(port=port,persistent=False,progress_callback=observer) as client:
                assert client.owned_server_process_is_alive() is True
                first=client.get_server_info_snapshot();assert first.ready and first.process_identity is not None
                identity=first.process_identity;server=psutil.Process(identity.pid)
                def endpoint():
                    current=client.get_server_info_snapshot()
                    assert current.ready and current.process_identity==identity and current.port==first.port
                    assert client.owned_server_process_is_alive() is True and server.create_time()==identity.create_time
                    return {'pid':identity.pid,'create_time':identity.create_time,'port':first.port,'server_rss_bytes':server.memory_info().rss,
                        'epoch':time.time()}
                write(OUTPUT/'ready-endpoint.json',{'endpoint':endpoint(),'log_file':first.log_file_path,'memory_cap_mb':CAP_MB})
                for index,name in enumerate(SEQUENCE):
                    assert not memory.limit_exceeded
                    observer.on_event=None
                    before=endpoint();submission=submission_for(index,name,prepared[name])
                    trace=PhaseTimingTrace(run_id=f'controlled-values-{index}',pipeline_name=name,tool='OpenHCS')
                    completed,_=execute_measured_openhcs_pipeline_on_client(client=client,submission=submission,
                        phase_timing=trace,timing_observer=observer,expected_axis_count=1,require_owned_server=True)
                    assert completed.receipt.observation_export_scope.value=='values'
                    assert any(completed.observation_export.records_by_axis.values()),'VALUES export must retain actual records'
                    assert completed.endpoint_provenance.endpoint_pid==identity.pid
                    assert completed.endpoint_provenance.endpoint_create_time_epoch_seconds==identity.create_time
                    after=endpoint();science=compare(name,completed)
                    status=client.poll_status(completed.execution_id)
                    assert status['execution']['status']=='complete',status
                    compile_inspection=None
                    try:client.get_compiled_artifact_inspection(completed.receipt.compile_artifact_id)
                    except RuntimeError as error:
                        compile_inspection=str(error)
                        assert 'unavailable' in compile_inspection and completed.receipt.compile_artifact_id in compile_inspection
                    assert compile_inspection is not None,'Ordinary compile artifact unexpectedly retained'
                    record={'index':index,'case':name,'execution_id':completed.execution_id,'compile_id':completed.receipt.compile_artifact_id,
                        'before':before,'after':after,'science':science,'terminal_status':status,
                        'compile_inspection_unavailable':compile_inspection,'receipt':json.loads((completed.receipt.observation_export_path.parent/'measured_pipeline_receipt.json').read_text()),
                        'retained_record_counts':{axis:len(values) for axis,values in completed.observation_export.records_by_axis.items()},
                        'observation_export_bytes':completed.receipt.observation_export_path.stat().st_size}
                    # Keep receipts/serialized summaries, never accumulating completed value owners in this controller.
                    del completed,submission
                    record['after_controller_release']=endpoint();record['peak_aggregate_mb_so_far']=memory.get_result()
                    record['retained_output_bytes']=disk_budget();records.append(record)
                    write(OUTPUT/f'job-{index:02d}.json',record)
                    print(json.dumps({'job':index,'case':name,'science':'PASS2','postjob_rss_mb':record['after']['server_rss_bytes']/2**20,
                        'peak_aggregate_mb':record['peak_aggregate_mb_so_far']}),flush=True)
                final=endpoint();write(OUTPUT/'ready-endpoint-final.json',final)
            assert not memory.limit_exceeded
            peak=memory.get_result()
    validate(f)
    write(OUTPUT/'decision.json',{'status':'PASS','source_head':HEAD,'completed_jobs':len(records),'strict_comparisons':sum(len(r['science']) for r in records),
        'one_endpoint':{'pid':identity.pid,'create_time':identity.create_time,'port':first.port},'peak_aggregate_mb':peak,
        'cap_mb':CAP_MB,'postjob_server_rss_mb':[r['after']['server_rss_bytes']/2**20 for r in records],
        'scope':f['scope'],'live_extra_inspection':'Unavailable in existing wire protocol; STATUS deliberately excludes ExecutionRecord.metadata. Consumed compilation availability tested via existing compiled-artifact inspection.',
        'memory_samples_sha256':c.sha(OUTPUT/'rss-samples.jsonl'),'source_freeze_sha256':c.sha(OUTPUT/'source-freeze.json')})
    print(json.dumps({'status':'PASS','completed_jobs':len(records),'strict_comparisons':32,'peak_aggregate_mb':peak}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=('prepare','run'))
    args=parser.parse_args()
    if args.action=='prepare':prepare()
    else:run()
