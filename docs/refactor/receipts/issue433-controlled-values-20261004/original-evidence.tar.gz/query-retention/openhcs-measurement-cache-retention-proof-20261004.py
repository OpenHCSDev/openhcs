import gc, json, weakref
import numpy as np
from openhcs.core.runtime_artifact_queries import MeasurementLabelSliceFeatureBatchQuery, MeasurementLabelSliceFeatureBatchQueryCache
from openhcs.core.measurement_feature_queries import MeasurementObjectFeatureAxisBatchQueryCache, MeasurementObjectFeatureVectorBatchQueryCache, ColumnarMeasurementTableSchemaCache, MeasurementTableObjectFeatureSemanticsCache, RuntimeObjectLabelMeasurementQuery, RuntimeObjectLabelMeasurementQueryCache
from openhcs.core.runtime_measurements import MeasurementTable, MeasurementSubject, MeasurementScope, MeasurementRowAxisField
from openhcs.core.runtime_tabular_values import FieldSpec
from openhcs.core.measurement_row_materialization import MeasurementSparseColumnarRows
from openhcs.core.runtime_object_labels import ObjectLabelSet, ObjectLabelVariantData
from openhcs.core.runtime_object_label_domains import ObjectLabelDomain, ObjectLabelDomainScope
from openhcs.core.runtime_plane_projection import RuntimePlaneAxis, RuntimePlaneProjection
from openhcs.core.runtime_stores import RuntimeValueStore
from openhcs.core.runtime_artifact_values import RuntimeValue
from openhcs.core.artifacts import ArtifactOutputPlan, MeasurementsArtifactType, ObjectLabelsArtifactType
from openhcs.interop.cellprofiler.measurement_dialect import CELLPROFILER_MEASUREMENT_LOOKUP_DIALECT

caches=(MeasurementLabelSliceFeatureBatchQueryCache, MeasurementObjectFeatureAxisBatchQueryCache, MeasurementObjectFeatureVectorBatchQueryCache, ColumnarMeasurementTableSchemaCache, MeasurementTableObjectFeatureSemanticsCache)
# This is a new standalone process. No server/global-runtime cache is touched.
assert all(not c.process_cache().entries for c in caches)
store=RuntimeValueStore()
pixels_by_name={name:np.ones((2,256,256),dtype=np.int32) for name in ('Cells','Nuclei')}
labels={name:ObjectLabelSet(name=name, variant_data=ObjectLabelVariantData(labels=pixels),domain=ObjectLabelDomain.declared(scope=ObjectLabelDomainScope.PLANE,declared_object_id_domains=((1,),(1,))),plane_axis=RuntimePlaneAxis.RUNTIME_SLICE) for name,pixels in pixels_by_name.items()}
rows=MeasurementSparseColumnarRows(columns={'slice_index':np.asarray([0,1,0,1]),'object_name':np.asarray(['Cells','Cells','Nuclei','Nuclei']),'object_label':np.ones(4,dtype=np.int32),'FormFactor':np.asarray([.5,.9,1.5,1.9])},fields=(FieldSpec('slice_index',int),FieldSpec('object_name',str),FieldSpec('object_label',int),FieldSpec('FormFactor',float)))
table=MeasurementTable(name='MixedShapeMeasurements',rows=rows,subject=MeasurementSubject(MeasurementScope.ARTIFACT,'MixedShapeMeasurements'))
for name,payload,kind in [('MixedShapeMeasurements',table,MeasurementsArtifactType)]+[(name,value,ObjectLabelsArtifactType) for name,value in labels.items()]:
    store.record(RuntimeValue.normalize(ArtifactOutputPlan(name=name,path='/memory/'+name,artifact_type=kind),payload,axis_id='A01'),path='/memory/'+name,backend='memory')
query=MeasurementLabelSliceFeatureBatchQuery(measurement_tables=(table,),feature_name='AreaShape_FormFactor',dialect=CELLPROFILER_MEASUREMENT_LOOKUP_DIALECT,row_axis=MeasurementRowAxisField.SLICE_INDEX,plane_projector=RuntimePlaneProjection.stack(2),labels_by_object=labels)
values=query.values_by_object()
owned=store.query_cache(RuntimeObjectLabelMeasurementQueryCache)
for name,vectors in values.items():
    owned.store_value(RuntimeObjectLabelMeasurementQuery(axis_id='A01',group_key=None,object_name=name,feature_name='AreaShape_FormFactor',label_domain=(1,),label_plane_domains=((1,),(1,))),vectors)
result={'first_vectors':{k:[v.tolist() for v in vs] for k,vs in values.items()},'pixel_buffer_bytes':sum(p.nbytes for p in pixels_by_name.values()),'cache_entries':{c.__name__:len(c.process_cache().entries) for c in caches}}
# Same owner + real store replacement creates a new runtime revision.
rows.columns['FormFactor'][0]=7.5
rev=store.revision
store.replace(RuntimeValue.normalize(ArtifactOutputPlan(name=table.name,path='/memory/'+table.name,artifact_type=MeasurementsArtifactType),table,axis_id='A01'),path='/memory/'+table.name,backend='memory')
result['revision_after_replace']=store.revision
result['revision_before_replace']=rev
result['store_cache_entries_after_replace']=len(owned.entries)
result['same_query_after_replace']=query.values_by_object()['Cells'][0].tolist()
MeasurementLabelSliceFeatureBatchQueryCache.clear_process_cache()
result['after_label_cache_clear']=query.values_by_object()['Cells'][0].tolist()
MeasurementLabelSliceFeatureBatchQueryCache.clear_process_cache()
MeasurementObjectFeatureAxisBatchQueryCache.clear_process_cache()
result['after_label_and_axis_clear']=query.values_by_object()['Cells'][0].tolist()
refs={name:weakref.ref(pixels) for name,pixels in pixels_by_name.items()}
row_ref=weakref.ref(rows.columns['FormFactor'])
store.clear()
result['store_records_after_clear']=len(store)
result['store_owned_entries_after_clear']=len(owned.entries)
del query, values, labels, table, rows, pixels_by_name, payload, vectors
# gc.collect is confined to this standalone proof process.
gc.collect()
result['pixels_retained_after_store_clear']={name:ref() is not None for name,ref in refs.items()}
result['feature_column_retained_after_store_clear']=row_ref() is not None
MeasurementLabelSliceFeatureBatchQueryCache.clear_process_cache()
gc.collect()
result['pixels_retained_after_process_label_cache_clear']={name:ref() is not None for name,ref in refs.items()}
for c in caches[1:]: c.clear_process_cache()
gc.collect()
result['feature_column_retained_after_all_process_caches_clear']=row_ref() is not None
print(json.dumps(result,indent=2))
