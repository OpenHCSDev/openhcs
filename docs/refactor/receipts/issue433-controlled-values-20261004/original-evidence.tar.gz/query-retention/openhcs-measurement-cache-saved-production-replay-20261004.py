import json
from pathlib import Path
from dataclasses import replace
import numpy as np
from openhcs.core.equivalence.tables import RuntimeTableSnapshot
from openhcs.core.measurement_feature_queries import MeasurementObjectFeatureVectorBatchQuery
from openhcs.core.runtime_measurements import MeasurementScalarLiteral
from openhcs.core.measurement_row_materialization import MeasurementProjectedColumnarRows
from openhcs.interop.cellprofiler.measurement_dialect import CELLPROFILER_MEASUREMENT_LOOKUP_DIALECT

ROOT=Path('/home/ts/.local/state/openhcs-maintenance/20261004/canonical-runtime-chains-paired-v11-qualified/ordinary-0')
CASES=(
 ('cp_tutorial_3d_monolayer','images_3d_monolayer_final_source_workspace_well_throughput','3d_monolayer_Nuclei.csv',('Intensity_MeanIntensity_origDNA','Intensity_MeanIntensity_origMemb','AreaShape_Volume')),
 ('cp_tutorial_3d_monolayer','images_3d_monolayer_final_source_workspace_well_throughput','3d_monolayer_Cells.csv',('Intensity_MeanIntensity_origDNA','Intensity_MeanIntensity_origMemb','AreaShape_Volume')),
 ('cp_tutorial_beginner_segmentation_final','images_Illum-corrected_segmentation_final_source_workspace_well_throughput','MyExpt_Nuclei.csv',('AreaShape_Area','Children_Cells_Count','Mean_Nucleoli_AreaShape_Area')),
 ('cp_tutorial_beginner_segmentation_final','images_Illum-corrected_segmentation_final_source_workspace_well_throughput','MyExpt_Cells.csv',('AreaShape_Area','Parent_Nuclei','Intensity_MeanIntensity_OrigER')),
)
result=[]
for case,workspace,filename,features in CASES:
 path=ROOT/case/'wells_1/workers_1'/workspace/'results'/filename
 snapshot=RuntimeTableSnapshot.from_csv(path)
 table,=snapshot.measurement_tables()
 object_name=table.subject.object_name
 columns=table.rows.columns
 for feature in features:
  assert feature in snapshot.header,feature
  expected={}
  for image,label,value in zip(columns['image_number'],columns['object_label'],columns[feature],strict=True):
   if MeasurementScalarLiteral(value).is_present_measurement_value:
    expected.setdefault(int(float(image)),{})[int(float(label))]=float(value)
  actual={}
  for image in sorted(expected):
   source_indices=tuple(index for index,value in enumerate(columns['image_number']) if int(float(value))==image)
   projected=replace(table,rows=MeasurementProjectedColumnarRows.from_columnar_rows(table.rows,row_indices=source_indices,declared_object_measurement_domain_covered=table.rows.covers_declared_object_measurement_domain,object_row_identity=table.rows.object_row_identity))
   actual[image]=MeasurementObjectFeatureVectorBatchQuery(feature,(object_name,),dialect=CELLPROFILER_MEASUREMENT_LOOKUP_DIALECT).value_indexes({object_name:(projected,)})[object_name][0]
  assert tuple(sorted(actual))==tuple(sorted(expected)),(filename,feature,actual.keys(),expected.keys())
  for axis,values in expected.items():
   assert tuple(sorted(actual[axis]))==tuple(sorted(values)),(filename,feature,axis)
   np.testing.assert_equal([actual[axis][label] for label in sorted(values)],[values[label] for label in sorted(values)])
  result.append({'file':str(path),'feature':feature,'image_values':sorted(actual),'correlated_object_values':sum(len(v) for v in actual.values()),'status':'PASS'})
print(json.dumps({'scope':'retained qualified-v11 CSV values through existing snapshot/table and current object/axis query owners; no pipeline execution or new native qualification','queries':result},indent=2))
