# OpenHCS pipeline

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
    Microscope,
    VariableComponents,
)
from openhcs.core.config import (
    LazyNapariStreamingConfig,
    LazyPathPlanningConfig,
    LazyProcessingConfig,
    LazyStepMaterializationConfig,
    LazyWellFilterConfig,
    PipelineConfig,
)
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazySourceBindingsConfig,
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceFilterClause,
    SourceFilterMatchType,
    SourceFilterSubject,
    SourceSelector,
)
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.classification import ClassificationThresholdMethod
from openhcs.processing.func_registry import get_function
from zmqruntime.config import TransportMode

pipeline_config = PipelineConfig(
    materialize_runtime_artifacts=True,
    num_workers=1,
    microscope=Microscope.SOURCE_BINDINGS,
    use_threading=True,
    well_filter_config=LazyWellFilterConfig(
        well_filter=[
            'A01'
        ]
    ),
    source_bindings_config=LazySourceBindingsConfig(
        bindings=(
            NamedSourceBinding(
                alias='engineering_raw',
                selector=SourceSelector(
                    components=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='1'
                        ),
                    ),
                    filters=(
                        SourceFilterClause(
                            subject=SourceFilterSubject.FILE,
                            match_type=SourceFilterMatchType.CONTAINS,
                            value='_w1_'
                        ),
                    )
                )
            ),
        ),
        source_voxel_spacing=SourceVoxelSpacing(
            values_zyx=(
                1.3556,
                1.3556
            )
        )
    ),
    path_planning_config=LazyPathPlanningConfig(
        output_dir_suffix='_classification388_paired397_enum_fixed_fresh_owned'
    )
)

pipeline_steps = [
    FunctionStep(
        func=get_function('openhcs:engineering_calibration_classification_fixture'),
        name='engineering_fixture',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.NONE
        ),
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True
        ),
        step_materialization_config=LazyStepMaterializationConfig(
            enabled=True
        ),
        napari_streaming_config=LazyNapariStreamingConfig(
            enabled=True,
            persistent=True,
            host='127.0.0.1',
            transport_mode=TransportMode.TCP,
            port=5992
        )
    ),
    FunctionStep(
        func=(get_function('openhcs:cellprofiler_classify_objects_two_measurements'), {
                'measurement1_feature': 'pixel_count',
                'measurement2_feature': 'calibration_um',
                'threshold1_method': ClassificationThresholdMethod.CUSTOM,
                'threshold1_value': 100.0,
                'threshold2_method': ClassificationThresholdMethod.CUSTOM,
                'threshold2_value': 2.0,
                'select_the_object_to_be_classified': 'engineering_cells'
            }),
        name='engineering_pair_classification',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.NONE
        ),
        step_materialization_config=LazyStepMaterializationConfig(
            enabled=True
        ),
        napari_streaming_config=LazyNapariStreamingConfig(
            enabled=True,
            persistent=True,
            host='127.0.0.1',
            transport_mode=TransportMode.TCP,
            port=5992
        )
    )
]