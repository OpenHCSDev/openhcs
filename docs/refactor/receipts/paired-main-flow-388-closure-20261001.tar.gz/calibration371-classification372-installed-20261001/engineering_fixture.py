"""Independent ABI/calibration/classification fixture, not an analysis recipe."""
from dataclasses import dataclass
import numpy as np

from openhcs.core.memory import numpy
from openhcs.core.artifacts import (
    ImageArtifactType, MainFlowStackOutputSpec, MeasurementsArtifactType,
    ObjectLabelsArtifactType, ObjectMeasurementSubjectRelation,
)
from openhcs.core.measurement_row_materialization import DataclassMeasurementColumnarRows
from openhcs.core.pipeline.function_contracts import artifact_inputs, artifact_outputs
from openhcs.core.runtime_measurements import RuntimeMeasurementFeature, RuntimeMeasurementFeatureOwner
from openhcs.processing.backends.lib_registry.unified_registry import ProcessingContract
from openhcs.processing.materialization import CsvOptions, MaterializationSpec, ROIOptions


class EngineeringFeature(RuntimeMeasurementFeature):
    PIXEL_COUNT = "pixel_count"
    CALIBRATION = "calibration_um"


class EngineeringFeatureOwner(RuntimeMeasurementFeatureOwner):
    @classmethod
    def owns_measurement_feature_name(cls, feature_name: str) -> bool:
        return any(feature.feature_name == feature_name for feature in EngineeringFeature)

    @classmethod
    def owns_primary_measurement_feature_name(cls, feature_name: str) -> bool:
        return cls.owns_measurement_feature_name(feature_name)


@dataclass(frozen=True)
class EngineeringObjectRow:
    slice_index: int
    object_label: int
    pixel_count: int
    calibration_um: float


ENGINEERING_IMAGE = MainFlowStackOutputSpec.output("engineering_calibration_image", ImageArtifactType)
ENGINEERING_LABELS = MainFlowStackOutputSpec.output(
    "engineering_cells", ObjectLabelsArtifactType,
    materialization=MaterializationSpec(ROIOptions(min_area=0)),
)
ENGINEERING_ROWS = MainFlowStackOutputSpec.output(
    "engineering_object_rows", MeasurementsArtifactType,
    measurement_feature_owner=EngineeringFeatureOwner,
    relations=(ObjectMeasurementSubjectRelation(source=ENGINEERING_LABELS.ref(), id_field="object_label"),),
    materialization=MaterializationSpec(CsvOptions()),
)


@numpy(contract=ProcessingContract.PURE_2D)
@artifact_inputs("pixel_size")
@artifact_outputs(ENGINEERING_IMAGE, ENGINEERING_LABELS, ENGINEERING_ROWS)
def engineering_calibration_classification_fixture(image: np.ndarray, pixel_size: float):
    """Emit two known rectangles and the unmodified runtime-supplied calibration."""
    if image.shape != (64, 64):
        raise ValueError("This engineering fixture requires exactly one64x64 plane")
    if not np.isfinite(pixel_size) or pixel_size <= 0:
        raise ValueError("Required source calibration must be positive and finite")
    labels = np.zeros(image.shape, dtype=np.int32)
    labels[8:16, 8:16] = 1
    labels[32:48, 32:48] = 2
    rows = tuple(
        EngineeringObjectRow(0, int(label), int(np.count_nonzero(labels == label)), float(pixel_size))
        for label in np.unique(labels) if label != 0
    )
    return np.full(image.shape, pixel_size, dtype=np.float64), labels, DataclassMeasurementColumnarRows(
        rows, row_type=EngineeringObjectRow,
    )
