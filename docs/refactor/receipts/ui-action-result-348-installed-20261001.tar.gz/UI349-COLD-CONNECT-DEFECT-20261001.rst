GUI synchronous cold connect stops before catalogue readiness
=============================================================

Parent OpenHCS integration owns diagnosis and follow-through. Observed on own
private installed0.8.7, source8119577 and again merged901e9a49, isolated display91,
configured loopback execution5993/6993, UI5994. No provider/data/Fiji download.

The normal GUI startup path calls PlateManager.ensure_execution_server through
the ZMQClientService's synchronous ATTACH_OR_START bridge. It starts the child,
reports catalogue/preparation activity, then returns False and stops the exact
child before a cold catalogue is ready. Current private backing ZMQRuntime
client.py::_connect_locked (spawn/wait block around1060..1116) explicitly
calls process.stop and endpoint.cleanup when _wait_for_endpoint_ready returns
None. The UI traceback ends "Failed to connect to ZMQ execution server".
The child is authoritatively absent afterward; it was not inferred from timeout.
The exact initiating budget/observer defect remains to be isolated before a fix.

Counterexample: existing exposed openhcs_start_owned_runtime starts the same
explicit pair promptly with an exact PID+creation-time handle; observation stays
read-only. Child1168146/create1790850562.06 reaches native readiness in about109s,
with266callables and continuous preparation receipts. No deadline increase,
restart of a live child, foreign adoption or scientific replay. Original complete
handle is ui349-installed-20261001/owned-runtime-handle.json. This is a separate
engineering runtime, not a continuation of the frozen blind trial.

Keep the original GUI startup failures/logs and successful owned-runtime journal.
Extend the existing lifecycle/readiness owners, preserving their exact incarnation,
cancellation and terminality guarantees. Do not merely increase timeout or copy
bootstrap/process management into the GUI. Acceptance: fresh empty-cache normal
GUI startup stays responsive, preserves one child while actual startup activity
continues, and attaches after readiness; cancellation and truly stalled/terminal
negative controls remain bounded. Verify actual installed GUI/MCP entrypoints.
No fix or fresh-GUI acceptance is claimed in this issue checkpoint.
