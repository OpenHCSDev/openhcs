Installed widget-tree CLI rendering failure
==========================================

Integration owner: parent agent, PR349 existing command/rendering surface.
Observed installed wheel6bc699fc5c35652bfe81b07163f069dc821c7e0c28d36ff9d34629f20fd91029,
source8119577a0d087e7349d7eff62104bdc5f47bacb2,2026-10-01.

Reproducer in real persistent dev CLI: ``widget-tree WINDOW --descriptor-file-path
OWN_DESCRIPTOR``. The read-only tool returns, then CapabilityBackedCommandSpec's
new retained-result path reads args.json. WidgetTreeCommandSpec declares
--output outline/json (with --json mapped to output), not a json attribute.
Exact terminal error: ``MCP persistent session failed: 'Namespace' object has
no attribute 'json'``. Original PTY29411 exits1. This is a real regression;
the200 earlier checks covered its old render_response, not live render_result.

Fix belongs to the command declaration's output-selection hook, shared by
retained and serialized paths. WidgetTree projects its existing declared format;
no getattr/default, second json flag, consumer type/name switch, or new registry.
Keep compact outline, --output json, --json alias and generic call semantics.
Add real CLI/codec-path regression with only the wire controlled, then rebuild
the private wheel and verify actual installed widget-tree and subsequent health
in the same live shell. Continue selected workflow's installed GUI acceptance.

Other engineering setup failure retained separately: ui-config.seed.config
used a string rather than Path, typed validation rejected it, then GUI used
defaults and refused foreign7777's0.8.6 version. No scientific job submitted.
Cancelled version mismatch via declared Cancel widget2.1; main_window close
capability explicitly rejects normal bridge close. Exact owned empty GUI1135701
was terminated normally through its QtProcessSignalRelay; exit143 and cleanup
verified. Original GUI log moved to gui-seed-rejected.log. New corrected GUI
1140171 starts own5993/6993 and bridge5994 on display91. No foreign signal.

Transcript limitation: initial engineering shell log files were overwritten by
the second script launch before --append was added. Original tool outputs remain
in the parent session; this receipt preserves the exact error and terminal handle,
but is not a byte-for-byte original first-shell transcript. Frozen scientific
transcripts and frozen installed environment remain unchanged.
