#!/bin/bash
# Parent-owned offline R1 context. Git declarations own all membership.
set -euo pipefail
task_repo=/home/ts/wt/openhcs-ui-workflow-rendering-20261001
task_donor=/home/ts/code/projects/openhcs
cd "$task_repo"
test "$(git rev-parse HEAD)" = 901e9a49a6e18f0b9c86574210568d1a3efbae67
while IFS= read -r -d '' entry; do
    metadata=${entry%%$'\t'*}
    relative_path=${entry#*$'\t'}
    read -r mode kind object_id <<< "$metadata"
    test "$mode" = 160000 || continue
    test "$kind" = commit
    test "$(git -C "$task_donor/$relative_path" cat-file -t "$object_id")" = commit
    test -d "$task_repo/$relative_path"
    test -z "$(find "$task_repo/$relative_path" -mindepth 1 -maxdepth 1 -print -quit)"
done < <(git ls-tree -r -z HEAD external)
while IFS= read -r -d '' entry; do
    metadata=${entry%%$'\t'*}
    relative_path=${entry#*$'\t'}
    read -r mode kind object_id <<< "$metadata"
    test "$mode" = 160000 || continue
    git clone --no-hardlinks --no-checkout "$task_donor/$relative_path" "$task_repo/$relative_path"
    git -C "$task_repo/$relative_path" checkout --detach "$object_id"
    test "$(git -C "$task_repo/$relative_path" rev-parse HEAD)" = "$object_id"
    test -z "$(git -C "$task_repo/$relative_path" status --porcelain)"
    test -z "$(git -C "$task_repo/$relative_path" ls-tree -r HEAD | awk '$1 == "160000"')"
done < <(git ls-tree -r -z HEAD external)
git submodule status
