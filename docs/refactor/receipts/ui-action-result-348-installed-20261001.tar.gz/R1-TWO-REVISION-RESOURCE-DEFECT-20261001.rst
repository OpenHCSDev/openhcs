R1 two-revision resource failure
===============================

Parent integration owns follow-through. Independent of PR349's UI renderer
and PR351's source/viewer owners. No current source patch or passing gate claim.

Actual unchanged consumer scripts/check_refactor_r1.py at OpenHCS901e9a49,
basec81963475, original NRA0844525 production via reviewed read-only673c062f
checkout, installed Python3.12 dependencies. All eight Git-recorded child
repositories were initialized offline at exact recorded SHAs in the private
worktree. Donor dirty trees/configuration and installed dependencies unchanged.

Reproducer:
/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/run-r1.sh
under the existing producer-installed-20261001/run_bounded_r1.py supervisor.
Unchanged limits:512MiB combined process-group RSS,165seconds wall,
160seconds NRA budget. No detector/context/report omission or limit increase.

Receipt producer-installed-20261001/ui349-r1-full-context-20261001.command.json:
exit-9,122.45seconds,551.88MiB observed peak. The baseline scan completed:
3068 projections,112.790seconds preparation,6.291seconds analysis,cache miss.
The next revision scan had started when the resource owner terminated it.
No head counts/comparison or global-clean assertion can be derived from that.

Diagnosis lead, not established cause: the consumer materializes base/head at
different absolute snapshot roots while NRA's declaration/collected-family
cache identities include source paths. Examine owned graph lifetime and
authenticated cache invalidation before changing anything. Do not respond by
increasing timeout/RAM, deleting dependencies, copying detectors, reusing stale
counts, changing the original pin, or introducing a second schema authority.

Acceptance: the original full-context two-detector plus semantic-descent graph
comparison completes under unchanged160/165seconds and512MiB, preserves exact
Git membership and fresh resolution of changed/removed/added declarations,
and passes negative controls that genuine new raw-record/type-check debt fails.
Retain this failure. Optimize the existing owner/cache mechanism, not the rule.
