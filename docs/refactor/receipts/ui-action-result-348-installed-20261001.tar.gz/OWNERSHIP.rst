PR349 private installed acceptance
=================================

Parent integration owns source8119577a0d087e7349d7eff62104bdc5f47bacb2,
/home/ts/wt/openhcs-ui-workflow-rendering-20261001. Reviewed production is the
200-check/R0 checkpointb6cdef197;8119577 changes only evidence/docs.
No global/backing environment changes. Private wheel/environment only here
and ownsourceWT/.venv; retain source and installed proof separately.

Source checks remain oneCPU/512MiB/60s. Real MCP/UI acceptance has a separate
serialized slot and actual measured RAM admission (11GiB startup/8GiB operations)
because simultaneous client/server/UI owners cannot be treated as one small
provider-free test process. No provider/Fiji/data/dependency download. Shared
Fiji downloadfalse. Preserve desktop0, H00290/7790/5690 and display91/VNC5991.
Use synthetic engineering fixtures only; no continuation/replay/evaluation of
the frozen neurite trial. No biological acceptance claim.

Runtime scratch planned /home/ts/.cache/agent-scratch/ui349-installed-20261001,
owned disposable caches/logs. Build, wheel, configuration, seeds, transcript,
timing, launch scripts and final acceptance receipts stay persistent here.
Archive logs before exact owned cleanup. Parent owns nativevalidation.lock;
Schrodinger350source work does not acquire it until coordinated release.
