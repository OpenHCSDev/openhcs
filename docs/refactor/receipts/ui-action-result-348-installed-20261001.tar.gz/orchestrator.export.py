# Complete declarations exported from the installed UI code-document MCP owner.
# Byte-original 648-byte source and its digest remain in mcp.stdout.
from openhcs.core.config import GlobalPipelineConfig, PipelineConfig
from openhcs.core.steps.function_step import FunctionStep
from pathlib import Path
from skimage.exposure.exposure import adjust_gamma

path_1 = Path('/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/synthetic-plate')
plate_paths = [path_1]
global_config = GlobalPipelineConfig()
per_plate_configs = {path_1: PipelineConfig()}
pipeline_data = {
    path_1: [FunctionStep(func=adjust_gamma, name='IdentityEngineering')]
}
