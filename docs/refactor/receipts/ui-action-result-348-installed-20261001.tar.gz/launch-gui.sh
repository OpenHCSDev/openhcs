#!/bin/sh
set -eu
unset PYTHONPATH OPENHCS_METADATA_FILENAME
export POLYSTORE_METADATA_FILENAME=generic-private.json
export PYTHONDONTWRITEBYTECODE=1 OPENHCS_CPU_ONLY=true CUDA_VISIBLE_DEVICES=
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1 JAX_PLATFORMS=cpu
export POLYSTORE_IMAGEJ_CACHE_ROOT=/home/ts/.cache/polystore/imagej POLYSTORE_IMAGEJ_ALLOW_DOWNLOAD=false
export XDG_CACHE_HOME=/home/ts/.cache/agent-scratch/ui349-installed-20261001/cache
export XDG_CONFIG_HOME=/home/ts/.cache/agent-scratch/ui349-installed-20261001/config
export XDG_DATA_HOME=/home/ts/.cache/agent-scratch/ui349-installed-20261001/data
export XDG_STATE_HOME=/home/ts/.cache/agent-scratch/ui349-installed-20261001/state
export XDG_RUNTIME_DIR=/home/ts/.cache/agent-scratch/ui349-installed-20261001/runtime
export TMPDIR=/home/ts/.cache/agent-scratch/ui349-installed-20261001
export NUMBA_CACHE_DIR=/home/ts/.cache/agent-scratch/ui349-installed-20261001/numba
export MPLCONFIGDIR=/home/ts/.cache/agent-scratch/ui349-installed-20261001/matplotlib
export OPENHCS_UI_CONFIG_CACHE_FILE=/home/ts/.cache/agent-scratch/ui349-installed-20261001/ui_config.config
export OPENHCS_UI_BRIDGE_DESCRIPTOR=/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/ui-bridge.json
export OPENHCS_AGENT_READ_ROOTS=/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001:/home/ts/.cache/agent-scratch/ui349-installed-20261001:/home/ts/.openhcs/tcp/5993.startup.lock:/home/ts/.openhcs/tcp/6993.startup.lock
export OPENHCS_AGENT_WRITE_ROOTS=$OPENHCS_AGENT_READ_ROOTS
export DISPLAY=:91 QT_QPA_PLATFORM=xcb LIBGL_ALWAYS_SOFTWARE=1 QT_X11_NO_MITSHM=1
cd /home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001
exec /home/ts/wt/openhcs-ui-workflow-rendering-20261001/.venv/bin/python -I -B -m openhcs.cli gui --no-gpu --log-file /home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/gui.log
