# Edit this orchestrator configuration and save to apply changes
from openhcs.core.config import GlobalPipelineConfig, PipelineConfig
from openhcs.core.steps.function_step import FunctionStep
from skimage.exposure.exposure import adjust_gamma

plate_paths = ["/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/synthetic-plate"]
global_config = GlobalPipelineConfig()
per_plate_configs = {
    "/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/synthetic-plate": PipelineConfig(),
}
pipeline_data = {
    "/home/ts/wt/openhcs-issue-batch-20260929/ui349-installed-20261001/synthetic-plate": [
        FunctionStep(func=adjust_gamma, name="IdentityEngineering"),
    ],
}
