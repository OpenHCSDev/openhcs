"""Prepare by default; reviewed --run uses fresh public MCP stdio tools only."""
from __future__ import annotations

import argparse
import ast
import asyncio
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

SOURCE = Path('/var/tmp/openhcs-resolved-pipeline-owner-20261004')
HEAD = 'ba522b7da6904325c7a79118cd6ed7353b8dff1d'
ROOT = Path('/home/ts/code/projects/openhcs')
PYTHON = ROOT / '.venv/bin/python'
OUTPUT = Path('/home/ts/.local/state/openhcs-maintenance/20261004/installed-consumer-419-435-450-v2')
ISSUE = Path('/var/tmp/openhcs-issue435-current-20261002.json')
NATIVE = ('openhcs/core/_tabular_native.abi3.so',
          'openhcs/processing/backends/cellprofiler/_granularity_native.abi3.so')
ORIGINAL_SHA = 'f7304c7c25507f648d40c250604bba8e4b3537fbedbdc114ef2016eec6800d98'
ALIASES = ('raw_body_processing_role', 'capped_outgrowth_processing_role')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(path, *arguments):
    return subprocess.check_output(['git', '-C', str(path), *arguments], text=True).strip()


def tracked(path):
    files = subprocess.check_output(['git', '-C', str(path), 'ls-files', '-z']).split(b'\0')
    return {os.fsdecode(name): sha(path / os.fsdecode(name)) for name in files
            if name and (path / os.fsdecode(name)).is_file()}


def dependencies():
    declarations = git(ROOT, 'config', '--file', '.gitmodules', '--get-regexp', 'path$')
    return {relative: {'head': git(ROOT / relative, 'rev-parse', 'HEAD'),
                       'status': git(ROOT / relative, 'status', '--porcelain'),
                       'files': tracked(ROOT / relative)}
            for line in declarations.splitlines() for _, relative in [line.split(maxsplit=1)]}


def installed_environment():
    return json.loads(subprocess.check_output([str(PYTHON), '-I', '-c',
        "import importlib.metadata as m,json,sys;print(json.dumps({'python':sys.version,'versions':{d.metadata['Name']:d.version for d in m.distributions()}}))"], text=True))


def environment(transport_write_paths=()):
    env = dict(os.environ)
    for key in tuple(env):
        if key.startswith('OPENHCS_DIAGNOSTIC_') or key.startswith('OPENHCS_PROFILE_'):
            del env[key]
    env.update(PYTHONPATH=str(SOURCE), PYTHONDONTWRITEBYTECODE='1',
               OPENHCS_CPU_ONLY='true', OPENHCS_HEADLESS='true',
               OPENHCS_SUBPROCESS_NO_GPU='1', POLYSTORE_SUBPROCESS_NO_GPU='1',
               CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
               OPENHCS_AGENT_READ_ROOTS=os.pathsep.join((str(OUTPUT), str(SOURCE), *transport_write_paths)),
               OPENHCS_AGENT_WRITE_ROOTS=os.pathsep.join((str(OUTPUT), *transport_write_paths)), POLYSTORE_IMAGEJ_ALLOW_DOWNLOAD='false',
               XDG_DATA_HOME=str(OUTPUT/'owned/data'), XDG_CACHE_HOME=str(OUTPUT/'owned/cache'),
               XDG_CONFIG_HOME=str(OUTPUT/'owned/config'), XDG_STATE_HOME=str(OUTPUT/'owned/state'),
               XDG_RUNTIME_DIR=str(OUTPUT/'owned/runtime'), MPLCONFIGDIR=str(OUTPUT/'owned/matplotlib'),
               NUMBA_CACHE_DIR=str(OUTPUT/'owned/numba'),
               OPENHCS_UI_CONFIG_CACHE_FILE=str(OUTPUT/'owned/ui-config.config'),
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
               NUMEXPR_NUM_THREADS='1', NUMBA_NUM_THREADS='1', BLIS_NUM_THREADS='1',
               VECLIB_MAXIMUM_THREADS='1', PYTHONHASHSEED='0')
    return env


def transport_preflight(port):
    # Native owner declarations determine both ports and exact lock-file paths.
    # Read-only: no endpoint start, cache warmup, lock creation or owner adoption.
    code = """
import sys,json,socket
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import openhcs
from zmqruntime.config import TransportMode
from zmqruntime.transport import TransportEndpoint
from openhcs.runtime.zmq_config import OPENHCS_ZMQ_CONFIG
endpoint=TransportEndpoint('127.0.0.1',int(sys.argv[2]),TransportMode.TCP)
ports=sorted(endpoint.port_pair(OPENHCS_ZMQ_CONFIG).ports)
rows=[]
for port in ports:
    path=TransportMode.TCP.declaration.startup_lock_path(port,OPENHCS_ZMQ_CONFIG)
    assert not path.exists(), f'Existing native reservation path; no adoption: {path}'
    with socket.socket() as connection:
        connection.settimeout(.2)
        listening=connection.connect_ex(('127.0.0.1',port))==0
    assert not listening, f'Existing endpoint on port {port}; no attach/takeover.'
    rows.append({'port':port,'path':str(path),'existed':False,'listening':False})
print(json.dumps({'source':str(Path(openhcs.__file__).resolve()),'app_name':OPENHCS_ZMQ_CONFIG.app_name,'reservations':rows}))
"""
    return json.loads(subprocess.check_output(['/usr/bin/taskset', '-c', '3', str(PYTHON), '-B', '-c', code,
                                               str(SOURCE), str(port)], cwd='/var/tmp', env=environment(), text=True))


def prepare(port):
    assert git(SOURCE, 'rev-parse', 'HEAD') == HEAD
    assert not git(SOURCE, 'status', '--porcelain')
    transport = transport_preflight(port)
    assert transport['source'] == str(SOURCE/'openhcs/__init__.py')
    transport_write_paths = tuple(row['path'] for row in transport['reservations'])
    assert not OUTPUT.exists(), 'Never overwrite acceptance evidence.'
    document = json.loads(ISSUE.read_text())
    comment = next(row for row in document['comments'] if ORIGINAL_SHA in row['body'])
    original = comment['body'].split('```python', 1)[1].split('```', 1)[0].strip()+'\n'
    assert hashlib.sha256(original.encode()).hexdigest() == ORIGINAL_SHA
    tree = ast.parse(original)
    dapi = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name) and node.func.id == 'NamedSourceBinding'
            and any(k.arg == 'alias' and isinstance(k.value, ast.Constant)
                    and k.value.value == 'DAPI' for k in node.keywords)]
    assert len(dapi) == 1
    lines = original.splitlines(keepends=True)
    omitted = ''.join(lines[dapi[0].lineno-1:dapi[0].end_lineno])
    assert lines[dapi[0].end_lineno-1].strip() == '),'
    synthetic = ''.join(lines[:dapi[0].lineno-1]+lines[dapi[0].end_lineno:])
    old_output = '/home/ts/wt/openhcs-issue-batch-20260929/neurite-development-skill383-20261001/output/assisted-5-434/carrier-proof'
    assert synthetic.count(old_output) == 2
    synthetic = synthetic.replace(old_output, str(OUTPUT/'outputs'))
    synthetic_tree = ast.parse(synthetic)
    old_steps = next(n.value for n in tree.body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == 'pipeline_steps' for t in n.targets))
    new_steps = next(n.value for n in synthetic_tree.body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == 'pipeline_steps' for t in n.targets))
    assert ast.dump(old_steps, include_attributes=False) == ast.dump(new_steps, include_attributes=False)
    assert len(new_steps.elts) == 5
    OUTPUT.mkdir(parents=True)
    (OUTPUT/'input').mkdir()
    (OUTPUT/'expected').mkdir()
    (OUTPUT/'original-pipeline.py').write_text(original)
    (OUTPUT/'synthetic-pipeline.py').write_text(synthetic)
    (OUTPUT/'omitted-unused-DAPI-binding.txt').write_text(omitted)
    # Preparation writes only the owned deterministic physical input. No server,
    # registry warmup, private compiler, executor or metadata writer is called.
    fixture_code = (
        "import sys;sys.path.insert(0,sys.argv[1]);import openhcs;"
        "import numpy as np,tifffile;from pathlib import Path;"
        "y,x=np.indices((1024,1024),dtype=np.uint32);"
        "a=((y*317+x*113+39)%65536).astype(np.uint16);"
        "a[0,:9]=np.array([0,38,39,40,260,5999,6000,6001,65535],dtype=np.uint16);"
        "tifffile.imwrite(Path(sys.argv[2]),a,photometric='minisblack');"
        "np.save(Path(sys.argv[3])/'raw_body_processing_role.npy',(a.astype(np.float64)/65535).astype(np.float32));"
        "np.save(Path(sys.argv[3])/'capped_outgrowth_processing_role.npy',np.clip((a.astype(np.float64)-39)/5961,0,1).astype(np.float32));"
        "print(a.shape,a.dtype,int(a.min()),int(a.max()))"
    )
    image = OUTPUT/'input/A01_s001_w2_z001_t001.tif'
    subprocess.run(['/usr/bin/taskset', '-c', '3', str(PYTHON), '-B', '-c', fixture_code,
                    str(SOURCE), str(image), str(OUTPUT/'expected')], check=True, cwd='/var/tmp', env=environment())
    native = {}
    for relative in NATIVE:
        path = SOURCE / relative
        if not path.exists():
            path.symlink_to(ROOT / relative)
        assert sha(path) == sha(ROOT / relative)
        native[relative] = {'path': str(path.resolve()), 'sha256': sha(path)}
    assert not git(SOURCE, 'status', '--porcelain')
    requests = {'start_owned_runtime': {'port': port, 'host': '127.0.0.1', 'transport_mode': 'tcp', 'timeout_ms': 500},
                'start_function_catalog_preparation': {'port': port, 'host': '127.0.0.1', 'transport_mode': 'tcp'},
                'create_session': {'plate_path': str(image.parent), 'pipeline_source': synthetic,
                                   'port': port, 'host': '127.0.0.1', 'transport_mode': 'tcp', 'persistent': True},
                'execution_export': {'runtime_observation_export_path': str(OUTPUT/'outcomes.pkl.gz'),
                                     'runtime_observation_export_scope': 'outcomes'}}
    (OUTPUT/'seed').mkdir()
    seed_code = "import numpy as np,tifffile,sys;a=np.zeros((32,32),np.uint16);a[2:7,2:7]=65535;a[12:15,20:24]=65535;tifffile.imwrite(sys.argv[1],a,photometric='minisblack')"
    subprocess.run([str(PYTHON), '-B', '-c', seed_code, str(OUTPUT/'seed/A01_s001_w2_z001_t001.tif')], check=True, env=environment())
    (OUTPUT/'prepared-requests.json').write_text(json.dumps(requests, indent=2)+'\n')
    versions = installed_environment()
    freeze = {'status': 'PREPARED_NOT_RUN', 'scope': 'Synthetic public MCP compiler/executor acceptance only. Original biological input and #419 authored source are absent. Exact original #435 five-step AST plus representative registered saved-IPO Shape/DISTANCE/Resize. No biological replay or performance claim.',
              'source': str(SOURCE), 'head': HEAD, 'files': tracked(SOURCE),
              'dependencies': dependencies(), 'native': native,
              'controller_sha256': sha(__file__), 'python': {'path': str(PYTHON.resolve()), 'sha256': sha(PYTHON.resolve())},
              'installed_environment': versions, 'environment_overrides': {key: value for key,value in environment(transport_write_paths).items() if key.startswith(('OPENHCS_', 'POLYSTORE_', 'XDG_')) or key in ('PYTHONPATH','NUMBA_CACHE_DIR','MPLCONFIGDIR','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','NUMBA_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','CUDA_VISIBLE_DEVICES','QT_QPA_PLATFORM','PYTHONHASHSEED','PYTHONDONTWRITEBYTECODE')},
              'native_transport_preflight': transport, 'runtime_transport_write_paths': transport_write_paths,
              'native_transport_authority': 'zmqruntime.transport_modes.TcpTransportDeclaration.startup_lock_path: Path.home() / .<config.app_name> / tcp / <port>.startup.lock. No XDG override is supported. Only the actual declared data/control files are additional admitted roots.',
              'input_files': {str(path): sha(path) for path in (image, OUTPUT/'seed/A01_s001_w2_z001_t001.tif', ISSUE, OUTPUT/'original-pipeline.py', OUTPUT/'synthetic-pipeline.py', OUTPUT/'omitted-unused-DAPI-binding.txt', OUTPUT/'prepared-requests.json', *(OUTPUT/'expected').glob('*.npy'))},
              'original_source_sha256': ORIGINAL_SHA, 'processing_step_ast_identical': True,
              'only_authored_changes': ['global_output_folder and materialization_results_path under owned outputs', 'omit unused required DAPI/C1 binding for the single-physical-C2 synthetic fixture'],
              'fixture': {'shape': [1024,1024], 'dtype': 'uint16', 'physical_channel': '2', 'physical_image_count': 1,
                          'spacing_yx': [1.3556,1.3556], 'unit': 'micrometers', 'edge_counts_first_row': [0,38,39,40,260,5999,6000,6001,65535]},
              'runtime_bounds': {'deadline_seconds': 900, 'disk_bytes': 1024**3, 'cpu': 3, 'startup_and_catalog_before_compile': True}, 'requests': requests}
    (OUTPUT/'source-freeze.json').write_text(json.dumps(freeze, indent=2)+'\n')
    print(json.dumps({k:freeze[k] for k in ('status','source','head','scope','only_authored_changes')}, indent=2))


def validate(freeze):
    assert freeze['controller_sha256'] == sha(__file__)
    assert git(SOURCE, 'rev-parse', 'HEAD') == freeze['head'] and not git(SOURCE, 'status', '--porcelain')
    assert tracked(SOURCE) == freeze['files']
    assert dependencies() == freeze['dependencies']
    assert all(sha(path) == digest for path,digest in freeze['input_files'].items())
    assert all(sha(SOURCE/relative) == row['sha256'] for relative,row in freeze['native'].items())
    assert sha(PYTHON.resolve()) == freeze['python']['sha256']
    assert installed_environment() == freeze['installed_environment']


async def worker():
    # The controller process inserts selected source BEFORE importing OpenHCS or
    # any editable dependency. Native MCP/runtime launch inherits that authority.
    sys.path.insert(0, str(SOURCE))
    import openhcs
    assert Path(openhcs.__file__).resolve() == SOURCE/'openhcs/__init__.py'
    import numpy as np
    import tifffile
    from openhcs.mcp.dev_client_core import McpDevServerSpec, McpDevStdioSession, McpDevToolResult
    from openhcs.serialization.json import to_jsonable
    from openhcs.core.artifacts import ImageArtifactType
    from benchmark.cellprofiler_reference_exports import CellProfilerReferenceExportArtifact, CellProfilerReferenceArtifactComparison
    from openhcs.core.virtual_workspace_metadata import METADATA_CONFIG
    from zmqruntime.messages import ExecutionStatus, ProcessIdentity
    freeze = json.loads((OUTPUT/'source-freeze.json').read_text())
    validate(freeze)
    receipt = {'accepted': False, 'scope': freeze['scope'], 'head': HEAD, 'calls': [], 'owned_runtime_terminal': False, 'mcp_processes': [], 'failure': None}
    began = time.monotonic()
    mcp_children = []
    close_attempted = False
    def save():
        (OUTPUT/'journey.json').write_text(json.dumps(receipt, indent=2)+'\n')
    def bound():
        assert time.monotonic()-began < 900, 'Finite public journey deadline exceeded.'
        assert sum(path.stat().st_size for path in OUTPUT.rglob('*') if path.is_file()) < 1024**3, 'Owned output exceeds 1GiB bound.'
    async def call(session, name, arguments):
        nonlocal runtime_handle
        bound()
        row = {'tool': name, 'arguments': arguments, 'status': 'dispatched', 'started_unix': time.time()}
        receipt['calls'].append(row)
        save()
        start = time.monotonic()
        result = await session.call_tool(name, arguments, timeout_seconds=180)
        row.update(status='returned', seconds=time.monotonic()-start, response=result)
        save()
        decoded = McpDevToolResult.from_payload(name, result)
        value = to_jsonable(decoded.first_decoded_payload())
        if name == 'openhcs_start_owned_runtime' and isinstance(value, dict) and 'handle' in value:
            runtime_handle = value['handle']
            receipt['owned_runtime_handle'] = runtime_handle
            save()
        assert not decoded.has_errors(), to_jsonable(decoded.diagnostic_errors())
        assert isinstance(value, dict)
        print(name, row['seconds'], flush=True)
        return value
    async def finish(session, ref):
        while True:
            state = await call(session, 'openhcs_get_execution_status', {'job_id': ref['job_id'], 'timeout_ms': 1000})
            status = ExecutionStatus.from_wire(state['status'])
            assert status is not None, state
            if status.is_terminal:
                assert status in (ExecutionStatus.COMPLETE, ExecutionStatus.COMPLETED), state
                return state
            await asyncio.sleep(0.25)
    runtime_handle = None
    first_inventory = None
    first_samples = {}
    async def inspect_outputs(session, phase):
        # Read the public execution's declared output-plate authority, never
        # select a source workspace merely because it also has a metadata file.
        roots = set()
        def collect(value):
            if isinstance(value, dict):
                for key, item in value.items():
                    if key == 'output_plate_root' and item is not None:
                        assert isinstance(item, str)
                        roots.add(item)
                    else:
                        collect(item)
            elif isinstance(value, list):
                for item in value:
                    collect(item)
        collect(receipt['execution_status']['response'])
        assert len(roots) == 1, receipt['execution_status']
        plate = Path(next(iter(roots))).resolve()
        assert plate.is_relative_to(OUTPUT/'outputs')
        metadata_file = METADATA_CONFIG.metadata_path(plate)
        assert metadata_file.is_file(), metadata_file
        inspection = await call(session, 'openhcs_inspect_plate_path', {'plate_path': str(plate), 'microscope_type': 'auto'})
        assert inspection['status'] == 'partial' and not inspection['errors'], inspection
        assert [w['code'] for w in inspection['warnings']] == ['plate_grid_dimensions_unavailable'], inspection
        assert abs(inspection['pixel_size']-1.3556) < 1e-12, inspection
        inventory = await call(session, 'openhcs_query_plate_files', {'plate_path': str(plate), 'microscope_type': 'auto', 'kind': 'image', 'limit': 100, 'include_previews': False})
        assert not inventory['truncated_count']
        records = inventory['records']
        assert len({record['virtual_path'] for record in records}) == len(records), 'Duplicate public virtual paths.'
        selected = {}
        for alias in ALIASES:
            matches = [record for record in records if alias in Path(record['virtual_path']).name]
            assert len(matches) == 1, (alias, matches)
            selected[alias] = matches[0]
        samples = {}
        for alias, record in selected.items():
            source_file = Path(record['source_path'])
            assert source_file.resolve().is_relative_to(OUTPUT.resolve()), source_file
            data = tifffile.imread(source_file)
            assert data.shape == (1024,1024) and data.dtype == np.float32
            # Full physical output comparison is an independent complete-pixel
            # oracle; public sample/reopen must then expose the same role pixels.
            artifact = CellProfilerReferenceExportArtifact.from_terminal_spec(alias, ImageArtifactType)
            comparison = CellProfilerReferenceArtifactComparison.compare(artifact, OUTPUT/'expected'/f'{alias}.npy', source_file)
            assert comparison.equivalent and comparison.out_of_tolerance_pixel_count == 0, comparison
            sample = await call(session, 'openhcs_sample_plate_image', {'plate_path': str(plate), 'image_path': record['virtual_path'], 'microscope_type': 'auto', 'y': 0, 'x': 0, 'height': 1, 'width': 9, 'resolution_index': 0, 'max_array_elements': 9, 'include_array_values': True})
            assert sample['sample_included'] and tuple(sample['shape']) == (1024,1024), sample
            np.testing.assert_array_equal(np.asarray(sample['sample_values'], dtype=np.float32).reshape(1,9), data[:1,:9])
            metadata = sample['source_metadata']
            assert str(metadata['channel']) == '2', metadata
            assert all(abs(float(v)-1.3556)<1e-12 for v in metadata['OpenHCSSourceVoxelSpacingZYX'].split(',')), metadata
            samples[alias] = sample
            receipt.setdefault('complete_pixel_comparisons', {})[phase+'-'+alias] = to_jsonable(comparison)
        document = json.loads(metadata_file.read_text())
        all_rows = [row for directory in document['subdirectories'].values() for row in directory.get('source_projection', [])]
        roles = {alias: [row for row in all_rows if alias in Path(row['virtual_path']).name] for alias in ALIASES}
        for alias, rows in roles.items():
            assert len(rows) == 1, (alias, rows)
            assert rows[0]['address']['channel'] == '2'
            assert rows[0]['source_alias'] == alias
        assert len({(row['virtual_path'],row['projection_role']) for row in all_rows}) == len(all_rows)
        receipt[phase] = {'plate': str(plate), 'inspection': inspection, 'inventory': inventory, 'samples': samples,
                          'complete_role_pixels': True, 'metadata_sha256': sha(metadata_file), 'role_projection_rows': roles}
        save()
        return inventory, samples
    from dataclasses import replace
    from csv import DictReader
    from scipy.ndimage import distance_transform_edt
    from openhcs.core.pipeline_document import PipelineDocumentAuthority
    from openhcs.core.config import LazyStepMaterializationConfig, LazyProcessingConfig, LazyPathPlanningConfig
    from openhcs.core.steps.function_step import FunctionStep
    from openhcs.core.source_bindings import NamedSourceBinding, SourceSelector, SourceFilterClause, SourceFilterSubject, SourceFilterMatchType, LazySourceBindingsConfig, LazyStepSourceBindingsConfig
    from openhcs.core.source_bindings import SourceProjectionRole
    from openhcs.core.artifacts import ArtifactInputPlan, ArtifactOutputPlan, ObjectLabelsArtifactType
    from openhcs.constants.constants import VariableComponents, GroupBy
    from openhcs.constants.input_source import InputSource
    from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects, IdentifyPrimaryObjectsModule, UnclumpMethod, WatershedMethod
    from openhcs.processing.backends.cellprofiler.thresholding import CellProfilerThresholdMethod
    from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape, MeasureObjectSizeShapeModule
    from openhcs.processing.backends.cellprofiler.morphology import morph, MorphOperation, RepeatMode
    from openhcs.processing.backends.cellprofiler.image_geometry import resize, InterpolationMethod
    from openhcs.processing.backends.cellprofiler.image_math import image_math, ImageMathOperation

    # Actual document save/reopen, retaining canonical FunctionReferences. No private compiler.
    def saved_source(name, document):
        path=OUTPUT/(name+'-saved-pipeline.py')
        path.write_text(PipelineDocumentAuthority.render(document))
        reopened=PipelineDocumentAuthority.from_source(path.read_text())
        assert len(reopened.pipeline_steps)==len(document.pipeline_steps)
        receipt.setdefault('saved_documents',{})[name]={'path':str(path),'sha256':sha(path),'step_count':len(reopened.pipeline_steps),'authority':'PipelineDocumentAuthority.render/from_source'}
        save()
        return PipelineDocumentAuthority.execution_source(reopened)
    base_document=PipelineDocumentAuthority.from_source(freeze['requests']['create_session']['pipeline_source'])
    source_binding=base_document.pipeline_config.source_bindings_config.bindings[0]
    def case_config(name, bindings):
        root=OUTPUT/'outputs'/name
        return replace(base_document.pipeline_config,
            path_planning_config=LazyPathPlanningConfig(well_filter='A01',global_output_folder=root),
            materialization_results_path=root/'results',
            step_materialization_config=LazyStepMaterializationConfig(enabled=True,well_filter='A01'),
            source_bindings_config=replace(base_document.pipeline_config.source_bindings_config,bindings=tuple(bindings)))
    def step(name,func,kwargs,start=True):
        return FunctionStep(name=name,func=(func,kwargs),processing_config=LazyProcessingConfig(variable_components=[VariableComponents.CHANNEL],group_by=GroupBy.NONE,input_source=InputSource.PIPELINE_START if start else InputSource.PREVIOUS_STEP),source_bindings=LazyStepSourceBindingsConfig(enabled=start))
    def binding_name(module,plan_type,kind):
        (binding,)=module.declared_artifact_bindings(plan_type=plan_type,artifact_type=kind)
        return binding.require_parameter_name()
    def roots_from_status(status):
        roots=set()
        def collect(value):
            if isinstance(value,dict):
                for key,item in value.items():
                    if key=='output_plate_root' and item is not None: roots.add(item)
                    else: collect(item)
            elif isinstance(value,list):
                for item in value: collect(item)
        collect(status['response'])
        assert len(roots)==1,status
        root=Path(next(iter(roots))).resolve()
        assert root.is_relative_to(OUTPUT/'outputs')
        return root
    async def execute_document(session,name,plate,document):
        source=saved_source(name,document)
        args={**freeze['requests']['create_session'],'plate_path':str(plate),'pipeline_source':source}
        created=await call(session,'openhcs_create_orchestrator_session_from_pipeline_source',args)
        compiled=await finish(session,await call(session,'openhcs_submit_compile',{'session_id':created['session_id'],'wait':False}))
        executed=await finish(session,await call(session,'openhcs_submit_pipeline_execution',{'session_id':created['session_id'],'wait':False,'runtime_observation_export_path':str(OUTPUT/(name+'-outcomes.pkl.gz')),'runtime_observation_export_scope':'outcomes'}))
        receipt.setdefault('installed_cases',{})[name]={'compile':compiled,'execution':executed}
        save()
        return roots_from_status(executed)
    async def inspect_saved_case(session,phase):
        root=Path(receipt['installed_cases']['saved-label-geometry-distance-resize']['plate'])
        inspection=await call(session,'openhcs_inspect_plate_path',{'plate_path':str(root),'microscope_type':'auto'})
        assert not inspection['errors'],inspection
        assert {w['code'] for w in inspection['warnings']} <= {'plate_grid_dimensions_unavailable'},inspection
        inventory=await call(session,'openhcs_query_plate_files',{'plate_path':str(root),'microscope_type':'auto','kind':'image','limit':100,'include_previews':False})
        assert not inventory['truncated_count']
        assert len({r['virtual_path'] for r in inventory['records']})==len(inventory['records'])
        expected={'SavedDistance':distance_transform_edt(np.asarray(receipt['saved_labels_array'])!=0).astype(np.float32)}
        expected['ResizedDistance']=np.repeat(np.repeat(expected['SavedDistance'],2,axis=0),2,axis=1)
        expected['ResizedConsumer']=expected['ResizedDistance']
        samples={}
        for alias,pixels in expected.items():
            records=[r for r in inventory['records'] if Path(r['virtual_path']).stem.endswith('_'+alias)]
            assert len(records)==1,(alias,records,inventory)
            record=records[0]; path=Path(record['source_path'])
            actual=tifffile.imread(path)
            np.testing.assert_allclose(actual,pixels,rtol=1e-6,atol=1e-6)
            assert actual.shape==pixels.shape and actual.dtype==np.float32,(alias,actual.shape,actual.dtype)
            sample=await call(session,'openhcs_sample_plate_image',{'plate_path':str(root),'image_path':record['virtual_path'],'microscope_type':'auto','y':0,'x':0,'height':2,'width':2,'max_array_elements':4,'include_array_values':True})
            assert tuple(sample['shape'])==pixels.shape and sample['sample_included'],sample
            metadata=sample['source_metadata']; assert str(metadata['channel'])=='2',metadata
            spacing=tuple(float(v) for v in metadata['OpenHCSSourceVoxelSpacingZYX'].split(','))
            wanted=1.3556 if alias=='SavedDistance' else .6778
            assert len(spacing)==2 and all(abs(v-wanted)<1e-12 for v in spacing),(alias,metadata)
            assert metadata['OpenHCSSourceVoxelSpacingUnit']=='micrometers'
            samples[alias]=sample
        csvs=list(root.rglob('*.csv'))
        area_rows=[]
        for path in csvs:
            with path.open() as stream:
                reader=DictReader(stream)
                fields=reader.fieldnames or []
                areas=[f for f in fields if f.lower()=='area' or f.endswith('_Area')]
                if areas:
                    assert len(areas)==1,(path,areas)
                    rows=list(reader)
                    assert all(not (f.lower()=='volume' or f.endswith('_Volume')) for f in fields),fields
                    area_rows.extend(float(row[areas[0]]) for row in rows)
        assert sorted(area_rows)==[12.,25.],(csvs,area_rows)
        assert sha(receipt['saved_label_path'])==receipt['saved_label_sha256'],'Saved IPO acquisition pixels changed.'
        result={'inspection':inspection,'inventory':inventory,'samples':samples,'areas':area_rows,'csv_files':[str(p) for p in csvs]}
        receipt[phase+'-419-450']=result; save(); return result
    try:
        with (OUTPUT/'mcp-first-stderr.log').open('w') as stderr:
            async with McpDevStdioSession(McpDevServerSpec(str(PYTHON)), stderr) as session:
                process = session.require_process()
                mcp_children.append(process)
                receipt['mcp_processes'].append({'pid': process.pid, 'source': str(SOURCE)})
                await session.initialize(timeout_seconds=180)
                tools = await session.list_tools(timeout_seconds=180)
                (OUTPUT/'public-tools.json').write_text(json.dumps(tools, indent=2)+'\n')
                health = await call(session, 'openhcs_health_check', {})
                assert Path(health['server_source_path']).resolve() == SOURCE/'openhcs/mcp/server.py'
                started = await call(session, 'openhcs_start_owned_runtime', freeze['requests']['start_owned_runtime'])
                runtime_handle = started['handle']
                receipt['owned_runtime_handle'] = runtime_handle
                save()
                while not started['ready']:
                    assert started['process_alive'] is not False, started
                    await asyncio.sleep(0.5)
                    started = await call(session, 'openhcs_observe_owned_runtime', {'handle': runtime_handle})
                prepared = await call(session, 'openhcs_start_function_catalog_preparation', freeze['requests']['start_function_catalog_preparation'])
                while prepared['outcome'] != 'ready':
                    assert prepared['outcome'] not in ('failed','cancelled'), prepared
                    await asyncio.sleep(0.5)
                    prepared = await call(session, 'openhcs_get_function_catalog_preparation_status', prepared['handle'])
                receipt['startup_catalog_complete_before_compile'] = True
                created = await call(session, 'openhcs_create_orchestrator_session_from_pipeline_source', {**freeze['requests']['create_session'], 'pipeline_source':saved_source('original-five-step-435',base_document)})
                ref = await call(session, 'openhcs_submit_compile', {'session_id': created['session_id'], 'wait': False})
                receipt['compile_status'] = await finish(session, ref)
                execution = await call(session, 'openhcs_submit_pipeline_execution', {'session_id': created['session_id'], 'wait': False, **freeze['requests']['execution_export']})
                receipt['execution_status'] = await finish(session, execution)
                first_inventory, first_samples = await inspect_outputs(session, 'first_public_readback')
                ipo=step('ProduceSavedIPO',identify_primary_objects,{
                    binding_name(IdentifyPrimaryObjectsModule,ArtifactInputPlan,ImageArtifactType):'FITC',
                    binding_name(IdentifyPrimaryObjectsModule,ArtifactOutputPlan,ObjectLabelsArtifactType):'SavedIPO',
                    'exclude_size':False,'exclude_border_objects':False,'unclump_method':UnclumpMethod.NONE,'watershed_method':WatershedMethod.NONE,'threshold_method':CellProfilerThresholdMethod.MANUAL,'manual_threshold':.5,'threshold_smoothing_scale':0.})
                ipo_root=await execute_document(session,'produce-saved-ipo',OUTPUT/'seed',PipelineDocumentAuthority.from_values(pipeline_config=case_config('ipo',(source_binding,)),pipeline_steps=[ipo]))
                label_paths=[p for p in ipo_root.rglob('*.tif') if p.stem.endswith('_SavedIPO')]
                assert len(label_paths)==1,(ipo_root,list(ipo_root.rglob('*.tif')))
                label_path=label_paths[0]; labels=tifffile.imread(label_path)
                assert labels.shape==(32,32) and np.issubdtype(labels.dtype,np.integer),(labels.shape,labels.dtype)
                assert sorted(int(np.count_nonzero(labels==v)) for v in np.unique(labels) if v)==[12,25]
                receipt['saved_label_path']=str(label_path);receipt['saved_label_sha256']=sha(label_path)
                receipt['saved_labels_array']=labels.tolist()
                selected=replace(source_binding,alias='SavedImage',selector=SourceSelector(filters=(SourceFilterClause(subject=SourceFilterSubject.FILE,match_type=SourceFilterMatchType.EQUALS,value=label_path.name),)))
                saved_objects=replace(selected,alias='SavedIPO',artifact_kind=ObjectLabelsArtifactType,projection_role=SourceProjectionRole.SOURCE_ARTIFACT)
                shape=step('SavedIPOShape',measure_object_size_shape,{MeasureObjectSizeShapeModule.object_measurement_binding.require_parameter_name():('SavedIPO',),'calculate_advanced':False,'calculate_zernikes':False})
                distance=step('SavedIPODistance',morph,{'operation':MorphOperation.DISTANCE,'repeat_mode':RepeatMode.ONCE,'rescale_values':False,'select_the_input_image':'SavedImage','name_the_output_image':'SavedDistance'})
                resized=step('PreparedSavedDistanceResize',resize,{'resizing_factor_x':2.,'resizing_factor_y':2.,'interpolation':InterpolationMethod.NEAREST_NEIGHBOR,'name_the_output_image':'ResizedDistance'},False)
                consumed=step('ConsumePreparedResize',image_math,{'operation':ImageMathOperation.NONE,'truncate_low':False,'truncate_high':False,'name_the_output_image':'ResizedConsumer'},False)
                saved_root=await execute_document(session,'saved-label-geometry-distance-resize',label_path.parent,PipelineDocumentAuthority.from_values(pipeline_config=case_config('saved',(selected,saved_objects)),pipeline_steps=[shape,distance,resized,consumed]))
                receipt['installed_cases']['saved-label-geometry-distance-resize']['plate']=str(saved_root)
                first_saved=await inspect_saved_case(session,'first_public_readback')

                close_attempted = True
                closed = await call(session, 'openhcs_close_owned_runtime', {'handle': runtime_handle, 'mode': 'force'})
                assert closed['handle'] == runtime_handle and closed['outcome']['process_exited'] is True, closed
                assert not ProcessIdentity.from_dict(runtime_handle['process_identity']).is_alive()
                receipt['owned_runtime_terminal'] = True
                runtime_handle = None
            receipt['mcp_processes'][0]['returncode'] = process.returncode
            assert process.returncode is not None
        with (OUTPUT/'mcp-reopen-stderr.log').open('w') as stderr:
            async with McpDevStdioSession(McpDevServerSpec(str(PYTHON)), stderr) as session:
                process = session.require_process()
                mcp_children.append(process)
                receipt['mcp_processes'].append({'pid': process.pid, 'source': str(SOURCE)})
                await session.initialize(timeout_seconds=180)
                await session.list_tools(timeout_seconds=180)
                inventory, samples = await inspect_outputs(session, 'fresh_process_reopen')
                assert inventory == first_inventory and samples == first_samples, 'Fresh public reopen changed inventory or pixel/provenance facts.'
                assert await inspect_saved_case(session,'fresh_process_reopen') == first_saved
            receipt['mcp_processes'][1]['returncode'] = process.returncode
            assert process.returncode is not None
        validate(freeze)
        receipt['accepted'] = True
    except BaseException as error:
        receipt['failure'] = {'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()}
        # One explicit public close of the exact retained handle, through a
        # fresh SDK session after transport unwind. No mutating job is retried.
        if runtime_handle is not None:
            receipt['unresolved_owned_runtime_handle'] = runtime_handle
        if runtime_handle is not None and not close_attempted:
            try:
                with (OUTPUT/'mcp-cleanup-stderr.log').open('w') as stderr:
                    async with McpDevStdioSession(McpDevServerSpec(str(PYTHON)), stderr) as cleanup:
                        cleanup_process = cleanup.require_process()
                        mcp_children.append(cleanup_process)
                        await cleanup.initialize(timeout_seconds=180)
                        close_attempted = True
                        closed = await call(cleanup, 'openhcs_close_owned_runtime', {'handle': runtime_handle, 'mode': 'force'})
                        receipt['failure_cleanup'] = closed
                        receipt['owned_runtime_terminal'] = closed['outcome']['process_exited'] is True
                        if receipt['owned_runtime_terminal']:
                            del receipt['unresolved_owned_runtime_handle']
                    receipt['cleanup_mcp_returncode'] = cleanup_process.returncode
            except BaseException as cleanup_error:
                receipt['cleanup_failure'] = {'type': type(cleanup_error).__name__, 'message': str(cleanup_error)}
        raise
    finally:
        receipt['all_observed_mcp_children'] = [{'pid': child.pid, 'returncode': child.returncode} for child in mcp_children]
        receipt['mcp_children_terminal'] = all(child.returncode is not None for child in mcp_children)
        receipt['elapsed_seconds'] = time.monotonic()-began
        save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--port', type=int, default=6549)
    args = parser.parse_args()
    if args.worker:
        asyncio.run(worker())
    elif args.run:
        freeze = json.loads((OUTPUT/'source-freeze.json').read_text())
        validate(freeze)
        lease = Path('/tmp/openhcs-benchmark-xdg-cache/openhcs/official30-runtime.lock')
        lease.parent.mkdir(parents=True, exist_ok=True)
        with lease.open('a+') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            current_transport = transport_preflight(freeze['requests']['start_owned_runtime']['port'])
            assert current_transport == freeze['native_transport_preflight'], 'Endpoint ownership changed after prepare.'
            with (OUTPUT/'controller.log').open('x') as log:
                command = ['/usr/bin/taskset', '-c', '3', str(PYTHON), '-B', str(Path(__file__).resolve()), '--worker']
                result = subprocess.run(command, cwd='/var/tmp', env=environment(freeze['runtime_transport_write_paths']), stdout=log, stderr=subprocess.STDOUT, timeout=960)
            print(json.dumps({'returncode': result.returncode, 'journey': str(OUTPUT/'journey.json')}))
            sys.exit(result.returncode)
    else:
        prepare(args.port)


if __name__ == '__main__':
    main()
