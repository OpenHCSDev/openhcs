PR372 independent cooperative-hook new-case proof
================================================

Reviewed checkpoint: 364090ae5f920febda1380bf9743c10069b8e036.
Production remains identical to a5a0972e481d9e5062aef8e9126806c356f25551.
New test file SHA256:
ea81a9a03ec20c6040707978b1ce6c828ea9d7b67561cf2275d57f44165722d7.

Source suites: complete artifact declarations, invocation provider and new
object-subject test modules, 77 passed, 44.54s wall, 383.20MiB combined RSS.
cooperative-hook-review.json contains the exact bounded command. Matching
log retains full output. No native/install/science/provider launch; oneCPU,
512MiB/60s and readonly dependencies with explicit own source. No exclusions.

Independent capability's measurement_output_relations uses cooperative super,
the original setting binding, exact artifact lookup and typed stack relation.
New leaf supplies only names/binding. Shared output consumer is unchanged.
Assertion observes generic provenance/domain, exact object subject and selected
stack source together; first image is deliberately unselected. Original native
declaration validation and independent recording policy are exercised, not
merely inheritance identity. No production violation found; corrected test
coverage gap only. Original failure archive and R0 receipts remain unchanged.

Parent is qualifying private installed metadata371 + production372 separately.
This source-only proof neither reruns that slot nor asserts installed/biological,
snapshot/global acceptance. No worktree or files of another owner changed.
