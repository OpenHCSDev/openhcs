"""Read-only actual installed CLI reproducer; no server/UI/provider invoked."""
import contextlib
import io
import json
import sys

from openhcs.agent.capabilities import agent_capabilities
from openhcs.agent.dto.common import SCHEMA_VERSION
from openhcs.agent.dto.ui_bridge import (
    UiActionIdentity,
    UiActionInvokeResult,
    UiMutationReceipt,
    UiMutationRequestToken,
    UiSelectedPlateWorkflowKind,
    UiSelectedPlateWorkflowResult,
)
from openhcs.mcp import dev_client
from openhcs.mcp.dev_client_core import (
    McpDevServerSpec,
    McpDevToolBatchResponse,
    McpDevToolResult,
)
from openhcs.serialization.json import to_jsonable

native = UiSelectedPlateWorkflowResult(
    SCHEMA_VERSION,
    UiSelectedPlateWorkflowKind("run_plate"),
    UiActionInvokeResult(
        SCHEMA_VERSION,
        UiActionIdentity(widget_id="plate_manager", action_id="run_plate"),
        "accepted",
        UiMutationReceipt(UiMutationRequestToken(), accepted=True),
        target_scope_ids=("engineering-scope",),
    ),
)
response = McpDevToolBatchResponse.from_results(
    McpDevServerSpec(sys.executable),
    (McpDevToolResult.from_payload(
        agent_capabilities.ui_selected_plate_workflow.name,
        {"isError": False, "structuredContent": to_jsonable(native), "content": []},
    ),),
)

async def controlled_wire_result(args):
    return response

dev_client._run_async = controlled_wire_result
output = io.StringIO()
with contextlib.redirect_stdout(output):
    exit_code = dev_client.main([
        "call", agent_capabilities.ui_selected_plate_workflow.name,
        "--arguments", json.dumps({"workflow": "run_plate"}),
    ])
rendered = output.getvalue()
print(rendered)
print(f"actual_cli_exit={exit_code}; source={dev_client.__file__}")
assert exit_code == 0
assert "status=accepted" in rendered, "Compact CLI lost the native action status"
assert "accepted=True" in rendered, "Compact CLI lost the native receipt acceptance"
assert "engineering-scope" in rendered, "Compact CLI lost the selected target"
