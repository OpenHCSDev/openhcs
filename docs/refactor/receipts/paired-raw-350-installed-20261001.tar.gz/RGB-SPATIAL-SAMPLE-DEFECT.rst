Semantic image sampling applies Y/X bounds to X/color on RGB payloads
===================================================================

Discovered by parent during installed PR351 acceptance on2026-10-01.
Integration/source owner requested: Singer, alongside the managed-viewer QA
capture repair, without overlapping parent source-binding/axis work.

Reproducer
----------

Installed source3d58912d6e74e4b3dd4fa9e07a6b4a9d7dd9c7e4, wheel SHA
8c0e591ae24ff70f95b0dcb4d160db5f6ba9b73aa501a30c94b8f235364100cc.
MCP5993 executionedc013c2-a856-415a-ac2a-99e160dc8e5b streams an RGB
float32 payload shaped64x64x3 to managed Napari5992 on isolated display:91.
Call openhcs_sample_viewer_window_image for that exact route with
y=16,x=0,height=16,width=64,include_array_values=true,
max_array_elements=4096,max_records=1,axis_indices={channel:0}.

The successful response reports requested_slice_ranges=((16,32),(0,64)),
but applied slice_ranges=((0,64),(16,32),(0,3)), shape64x16x3.
The requested Y strip becomes an X strip. A nonzero X request can clip the
color axis or return no values, silently invalidating same-coordinate QA.
Four returned X strips still cover this complete engineering image, but their
requested spatial coordinates are not accepted as a matched-crop witness.
Full requests and values are retained in mcp.stdin/mcp.stdout beside this file.

Owning boundary and acceptance
-----------------------------

ViewerWindowImageSampleRequest.array_slices lowers semantic Y/X directly to
the generic payload array_slices; NapariViewerPayloadProjection.array_value_sample
applies those slices to the trailing array dimensions. Generic raw-array slicing
is a separate contract and must keep its existing behavior. ImagePayloadMetadata
already owns spatial_axes_yx(data); reuse its declared layout, not ndarray-rank,
last-dimension-size, function-name or title heuristics. Decode once, shared
ancestor implementation and small nominal hooks; no alternate array sampler.

Acceptance: asymmetric same-coordinate Y/X requests return the exact expected
gray and RGB values, preserve every declared color component, correct applied
spatial bounds and the original max_array_elements omission policy. Cover
non-square crops, nonzero X/Y, bounds clipping, and undeclared spatial layouts
failing explicitly. Test the existing real viewer/model path with typed payload
metadata, then parent verifies the installed MCP entrypoint. Retain the original
request/result failure. Do not change scientific pixels or source bindings.
