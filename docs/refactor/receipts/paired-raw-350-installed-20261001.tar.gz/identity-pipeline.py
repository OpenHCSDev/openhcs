# OpenHCS pipeline

from openhcs.core.config import (
    LazyNapariStreamingConfig,
    LazyPathPlanningConfig,
    LazyWellFilterConfig,
    NapariDimensionMode,
    PipelineConfig,
)
from openhcs.core.steps.function_step import FunctionStep
from skimage.exposure.exposure import adjust_gamma
from zmqruntime.config import TransportMode

pipeline_config = PipelineConfig(
    num_workers=1,
    use_threading=True,
    well_filter_config=LazyWellFilterConfig(
        well_filter=[
            'A01'
        ]
    ),
    path_planning_config=LazyPathPlanningConfig(
        output_dir_suffix='_paired350_identity'
    )
)

pipeline_steps = [
    FunctionStep(
        func=adjust_gamma,
        name='paired350_identity',
        napari_streaming_config=LazyNapariStreamingConfig(
            channel_mode=NapariDimensionMode.LAYER,
            enabled=True,
            persistent=True,
            host='127.0.0.1',
            transport_mode=TransportMode.TCP,
            port=5992
        )
    )
]
