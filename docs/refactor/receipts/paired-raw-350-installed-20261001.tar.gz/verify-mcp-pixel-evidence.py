"""Recheck engineering pixels returned by MCP, never local image files."""
import argparse
import json
import re
import struct
from pathlib import Path


def envelopes(transcript):
    decoder = json.JSONDecoder()
    for start in re.finditer(r"(?m)^\{", transcript):
        try:
            envelope, _ = decoder.raw_decode(transcript, start.start())
        except json.JSONDecodeError:
            continue
        yield envelope


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("transcript", type=Path)
    args = parser.parse_args()
    records = []
    for envelope in envelopes(args.transcript.read_text()):
        for result in envelope.get("results", ()):
            if result.get("tool") != "openhcs_sample_viewer_window_image":
                continue
            for payload in result["payloads"]:
                assert not payload["errors"]
                assert payload["sample_omitted_count"] == 0
                assert payload["records_truncated_count"] == 0
                records.extend(payload["records"])

    def exact_record(channel, route_token, shape):
        matches = [record for record in records
                   if record["components"]["channel"] == channel
                   and route_token in record["layer_route_key"]
                   and record["array_value_summary"]["shape"] == shape]
        assert len(matches) == 1, (channel, route_token, len(matches))
        record = matches[0]
        assert record["array_value_summary"]["included"]
        return record

    for channel in (1, 2):
        raw = exact_record(channel, "origin_manual", [64, 64])
        output = exact_record(channel, "paired350_identity", [64, 64])
        assert raw["array_values"] == output["array_values"]
        assert raw["array_value_summary"]["dtype"] == "uint16"
        assert output["array_value_summary"]["dtype"] == "uint16"

    dapi = exact_record("DAPI", "origin_manual", [64, 64])["array_values"]
    fitc = exact_record("FITC", "origin_manual", [64, 64])["array_values"]
    color = exact_record("FITC", "alias_color_ordered", [64, 64, 3])
    assert color["array_value_summary"]["dtype"] == "float32"
    assert color["array_value_summary"]["slice_ranges"] == [[0, 64], [0, 64], [0, 3]]

    def as_float32(value):
        return struct.unpack("f", struct.pack("f", value))[0]

    for y in range(64):
        for x in range(64):
            expected = [as_float32(fitc[y][x] / 65535), 0,
                        as_float32(dapi[y][x] / 65535)]
            assert color["array_values"][y][x] == expected, (y, x)
    print(json.dumps({"identity_pixels_checked": 8192,
                      "color_pixels_checked": 4096,
                      "color_scalars_checked": 12288,
                      "color_mapping": "red FITC, green zero, blue DAPI",
                      "unequal_values": 0,
                      "data_origin": "complete MCP-returned native samples"}))


if __name__ == "__main__":
    main()
