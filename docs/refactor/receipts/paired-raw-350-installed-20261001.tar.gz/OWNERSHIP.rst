PR351 private installed paired-raw acceptance
===========================================

Parent integration/source/live owner, Schrodinger reviewed source350 checkpoint
5a65824be. Parent private WTopenhcs-paired-raw-installed-parent-20261001, integration
branchintegrate/paired-raw-installed-20261001. Normal merge of main7640fd95 yields
df412c48e82004096319ae03988333b73d1bc8c3, published by fast-forward to SAME PR351.
Old worker worktree/frozen trial remains unchanged; worker now owns355 separately.

Four changed production paths reviewed against current main. Source identity
projection stays on SourcePatternResolutionContext ancestor; shared projection
stays on ViewerComponentAxisSemantics; existing MI domain/name context inherits.
No consumer type/name/channel switches, mirrored registries or copied algorithms.
No numerical/persisted/dependency/native-source changes. Exact reviewed349 abi3
bytes copied to this ownsourceWT; dependencies reused read-only, no downloads.

Owned private venv/wheel only. Default provider-free checks1CPU/512MiB/60seconds.
Native/UI/MCP acceptance serialized by existing validation.lock, measured RAM
11GiBstartup/8GiBoperations and2GiBdisk.20GiBhelperdisk warning not hard limit.
Owned output/scratch512MiB cap. Runtime/cache temporary namespace
/home/ts/.cache/agent-scratch/paired350-installed-20261001. Persistent engineering
artifacts/transcripts/captures stay here; remove ownscratch only after exact exit
and archived logs. No backing/global packages or user desktop state changes.

Display91/softwareGL/CPUonly; reserve exact runtime5993/6993 and viewer5992 plus
progress6992 only after proven absence. Preserve desktop0,H00290/7790/5690 and
foreign7777. All biology/viewer actions MCP-only; no mouse/X injection/console
or direct scientific arrays. Use tiny synthetic engineering fixtures, NEVER
replay/retune frozen blind trial or access held-out/reference/evaluator answers.
