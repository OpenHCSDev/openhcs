# OpenHCS pipeline

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
    Microscope,
    VariableComponents,
)
from openhcs.core.config import (
    LazyNapariStreamingConfig,
    LazyPathPlanningConfig,
    LazyProcessingConfig,
    LazyWellFilterConfig,
    NapariDimensionMode,
    PipelineConfig,
)
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazySourceBindingsConfig,
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceSelector,
    SourceFilterClause,
    SourceFilterSubject,
    SourceFilterMatchType,
)
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.color import gray_to_color
from zmqruntime.config import TransportMode

pipeline_config = PipelineConfig(
    microscope=Microscope.SOURCE_BINDINGS,
    num_workers=1,
    use_threading=True,
    well_filter_config=LazyWellFilterConfig(
        well_filter=[
            'A01'
        ]
    ),
    source_bindings_config=LazySourceBindingsConfig(
        source_voxel_spacing=SourceVoxelSpacing(values_zyx=(0.65, 0.65)),
        bindings=(
            NamedSourceBinding(
                alias='DAPI',
                selector=SourceSelector(
                    filters=(SourceFilterClause(SourceFilterSubject.FILE, SourceFilterMatchType.CONTAINS, '_w1_'),),
                    components=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='1'
                        ),
                    )
                ),
                component_identity=(
                    ComponentSelector(
                        component=AllComponents.CHANNEL,
                        value='DAPI'
                    ),
                )
            ),
            NamedSourceBinding(
                alias='FITC',
                selector=SourceSelector(
                    filters=(SourceFilterClause(SourceFilterSubject.FILE, SourceFilterMatchType.CONTAINS, '_w2_'),),
                    components=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='2'
                        ),
                    )
                ),
                component_identity=(
                    ComponentSelector(
                        component=AllComponents.CHANNEL,
                        value='FITC'
                    ),
                )
            )
        )
    ),
    path_planning_config=LazyPathPlanningConfig(
        output_dir_suffix='_paired350_alias_color'
    )
)

pipeline_steps = [
    FunctionStep(
        func=(gray_to_color, {
                'rescale_intensity': False,
                'red_channel': 1,
                'blue_channel': 0,
                'select_the_image_to_be_colored_red': 'FITC',
                'select_the_image_to_be_colored_blue': 'DAPI',
                'name_the_output_image': 'paired350_color'
            }),
        name='paired350_alias_color',
        source_bindings=LazyStepSourceBindingsConfig(enabled=True),
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.NONE
        ),
        napari_streaming_config=LazyNapariStreamingConfig(
            channel_mode=NapariDimensionMode.LAYER,
            enabled=True,
            persistent=True,
            host='127.0.0.1',
            transport_mode=TransportMode.TCP,
            port=5992
        )
    )
]
