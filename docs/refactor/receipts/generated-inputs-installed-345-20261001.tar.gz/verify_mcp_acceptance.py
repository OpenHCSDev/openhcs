"""Replay recorded installed CLI/MCP evidence; no native calls or science IO."""
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
transcript = (root / "mcp.stdout").read_text()
stdin = (root / "mcp.stdin").read_text()
decoder = json.JSONDecoder()
payloads = {}
errors = []
for match in re.finditer(r"(?m)^\{", transcript):
    document, _ = decoder.raw_decode(transcript, match.start())
    errors.extend(document.get("errors", []))
    for result in document.get("results", []):
        assert result["mcp_error"] is False
        for payload in result["payloads"]:
            payloads.setdefault(result["tool"], []).append(payload)
            errors.extend(payload.get("errors", []))
health = payloads["openhcs_health_check"]
assert len(health) == 2 and all(p["status"] == "ok" for p in health)
assert {p["server_process_id"] for p in health} == {972454}
assert all(not p["restart_required"] for p in health)
assert all("openhcs-generated-inputs-installed-parent-20261001/.venv" in p["server_source_path"] for p in health)
launches = payloads["openhcs_start_owned_runtime"]
assert len(launches) == 1
handle = launches[0]["handle"]
identity = {"pid":973791,"create_time":1790842852.46}
connection = {"host":"127.0.0.1","port":5993,"transport_mode":"tcp","persistent":True}
assert handle["process_identity"] == identity and handle["connection"] == connection
expected = {"connection":connection,"server_identity":identity}
start = payloads["openhcs_start_function_catalog_preparation"]
assert len(start) == 1 and start[0]["outcome"] == "ready" and start[0]["handle"] == expected
statuses = payloads["openhcs_get_function_catalog_preparation_status"]
assert len(statuses) == 3 and statuses[0] == statuses[1]
assert statuses[0]["outcome"] == "ready" and statuses[0]["handle"] == expected
assert len(errors) == 1 and "handle is stale" in errors[0]["message"]
cancel = payloads["openhcs_cancel_function_catalog_preparation"]
assert len(cancel) == 1 and cancel[0]["outcome"] == "ready" and cancel[0]["handle"] == expected
assert "invalid int value: 'true'" in transcript
assert "FunctionCatalogPreparationHandle.connection must be an object" in transcript
for command in ("start-function-catalog-preparation --host 127.0.0.1 --port 5993 --transport-mode tcp --persistent --json", "get-function-catalog-preparation-status --connection", "cancel-function-catalog-preparation --connection", "call openhcs_get_function_catalog_preparation_status --arguments"):
    assert command in stdin
close = payloads["openhcs_close_owned_runtime"]
assert len(close) == 1 and close[0]["handle"] == handle
assert close[0]["outcome"]["process_exited"] and close[0]["outcome"]["succeeded"]
assert close[0]["outcome"]["process_identity"] == identity
print(json.dumps({"status":"PASS","generated_controls":3,"generic_status_equal":True,
    "expected_stale_rejection":1,"local_input_rejections":2,
    "cancel_scope":"already-ready terminal future","owned_runtime_exited":True}))
