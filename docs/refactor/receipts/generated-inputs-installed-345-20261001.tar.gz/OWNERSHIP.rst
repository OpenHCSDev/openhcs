PR345 installed generated-input acceptance
==========================================

Owner parent integration; source owner Arendt. Candidate822c24a9b normally
merges reviewed38487a3ee with verified main e7f7c055c (merged344).
Private source/venv /home/ts/wt/openhcs-generated-inputs-installed-parent-20261001.
Dependencies reuse read-only CP344 paired backing; no global/frozen install,
download or Fiji copy. Build/test shards oneCPU/512MiB/60seconds, validation.lock
exclusive; one owned native runtime and exact handle through installed MCP.

Disposable cache/runtime /home/ts/.cache/agent-scratch/generated-inputs-installed-20261001.
Small supervisor/build logs still use parent's reviewed imagexpress-installed
scratch helper; generated-inputs-* files belong to this gate and are archived
before cleanup. CP344 archive-check.bFUCZc may be retired now its verifier passed.
No blind/reference/held-out data is used by this technical control check.

Required: healthy fresh installed handshake; generated start command sends exact
host/port/transport/persistence; generated status/cancel use complete incarnation-
bound connection+server_identity handle; generic call arguments match. Preserve
invalid input/missing-field receipts and exact owned native close. Source tests,
parser help, normal cold-preparation READY and stale-owner rejection are distinct
from installed live routing/lifecycle acceptance. Full R1 remains unqualified.
