PR367 issue360 authoring handoff, 2026-10-01
===========================================

Owner Dewey/Codex. Persistent source worktree
/home/ts/wt/openhcs-authoring-compile-selectors-360-20261001;
branch fix/authoring-compile-selectors-360-20261001.
Draft https://github.com/OpenHCSDev/openhcs/pull/367, stacked on PR365.
Production source9a0dfc9a5d3c2ce945bc0d232a31f887dd8dec90.
PR365 remains frozen at6f18daea291de61ceb22b3d347d65e264e1eee9b.

Source53 cases pass; adjacent activation/cardinality19 pass; original pinned
R0 against frozen365 passes,5188 measures/increased[]. Exact receipts and
source/installed strength are documented in docs/refactor/
MCP-compile-selector-authoring-360.rst and validation/README.rst.
All failed original/intermediate receipts stay in validation. Disposable
source-test output is only this owned persistent validation directory (~1.6MiB),
archived into the tracked receipt before delivery. No additional scratch,
installed environment writes, child/native/UI/MCP processes or heavy locks.

Remaining boundary: parent controls installed/native acceptance after blind
slot termination. Explicit numeric channel choices are preserved, not fixed.
Selector-only engineering source outside authoring gets block reconstruction
but no runtime kwarg injection. Full global85 NRA unqualified.

Adjacent original provider test fails classification measurement-subject
validation both here and on frozen365:25 pass/1 fail. Interface and named
parent/release scientific declaration handoff recorded; no scientific edits
or waiver. No self-merge. After parent accepts/merges365, integrate current
main normally into this independent follow-up; do not move the reviewed365head.
