Issue360 / PR367 compile-selector source receipts
================================================

Source: 9a0dfc9a5d3c2ce945bc0d232a31f887dd8dec90.
Base: frozen PR365 6f18daea291de61ceb22b3d347d65e264e1eee9b.
Every JSON records exact command, source root, exit/limit, wall time and
combined command-process-group RSS; its paired log is complete output.
Use the original read-only PR359 run_bounded.py supervisor, unchanged limits
512MiB/60s, CPU0 and thread pools1. No installations/native/science launches.

authoring-full: all53 source cases pass, 7.41s / 396.36MiB, no deselection.
reconstruction-adjacent: all19 declaration reconstruction cases pass,
4.32s / 300.37MiB, including ordinary unnamed three-input RGB behavior.
r0-initial: original pinned R0, actual Python3.14, read-only metaclass backing;
PASS, 16.83s / 82.68MiB, 5188 measures and increased[].

selectors-original: initial ten new witnesses against original production
before any patch, 6 failed / 4 passed, 4.05s / 302.12MiB. Retained.
selectors-first-patch: those ten pass, 4.15s / 301.89MiB.
selectors-expanded: thirteen expanded cases pass, 4.39s / 303.45MiB.
selectors-and-provider: fourteen final new cases pass; original adjacent
provider suite has25 pass /1 failure. Combined39 pass /1 failure,
7.54s /387.90MiB. NOT a passing adjacent-suite receipt.
provider-original: all26 original provider cases against explicit frozen365
production source: same25 pass /1 failure,6.80s /383.46MiB. ClassifyObjects
measurement-subject declaration rejection remains an out-of-scope named
parent/release scientific declaration handoff, not waived or fixed here.

No original parent mutation or transcript is replayed or overwritten.
Parent owns installed acceptance. R0 is a source ratchet, not R1 or FULL.
Engineering selector-only source gets exact block reconstruction; runtime
numeric defaults and execution ABI are unchanged. Authored source instead
derives omitted numeric choices through the existing declaration projection.
