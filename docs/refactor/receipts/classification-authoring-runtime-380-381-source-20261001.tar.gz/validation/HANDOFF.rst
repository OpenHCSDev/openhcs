PR382 source handoff
====================

Dewey owns issues380/381 and this worktree only. Parent controls installed
engineering/native acceptance and the serialized validation slot. No installs,
native launches, science pipelines, provider calls or original mutation replay.
No memory writes. Parent fixtures and all other owner trees stay readonly.

Source qualified: 502bb6481d0f3bd1d1dfe0a90a51e7737a6fb39b.
Integrated main: 66ed7ef634e4a57151766e85adb7002b36810e4f (includes merged372).
Initial production: 1d374f72e98976bad2f9f7fd621c657649e82a65.
Only two production owners differ from main; test and evidence commits only
after this working production checkpoint. No numerical or assertion edits.

113 complete integrated source cases PASS8.25s429.64MiB, CPU0/singlethreads,
combined512MiB/60s unchanged/native-child guard. Exact command/log:
integrated-complete-source.json/.log. Source target is explicit own worktree;
readonly dependency interpreter and native table-extension backing only.
Original custom fixture contract PASS6.43s388.57MiB, no function execution.
Original fixture SHA3157e246de9348b0522f8e4d2712b84df06db71185d8c09ce868b6f74c7349ce
unchanged. Both reference roles plus owner/name/type/source/group negatives.
Actual independent declaration/callable MI hook execution preserves both vector
and compiled retained image; generic consumer is not edited for the new case.

Pinned original R0 actualPython3.14 main66ed->502bb PASS17.24s74.66MiB,
5171entries increased=[], one fewer BooleanChainTerms. Pinned tool/backing paths
asserted in command; no copied detector. Previous frozen372base R0 remains.
Full NRA/R1/global85 FULL not run or qualified for this follow-up.

Original scalar red exact ValueError (0,) != (), original prior-feature
rejection, all intermediate test reds and resource failure remain immutable.
Standalone complete conditional18PASS and final113PASS do not erase original
combined512.56MiB failure. Initial aggregate-row fixture assertion corrected
to original one aggregate result per rule. Public two-vector helper witnessed
missing parsed mode (0 !=1); only correct parsed-mode vector binding is tested,
no claim to have repaired that separate convenience authoring boundary.

Source hashes:
classification.py a2afaed2c935fe20d439209819312606d86793285d478cde6c9dcd3844dce75b
module_artifact_declarations.py c459a1e65a671e0b15e83edba097484d018c4e9236c0e4999565221072096b31
test_classification_interop_boundaries.py 21265e39ea2769eaf47e6cd4319e39690928e5374ccf82b4e65da6bc23cf7f35

Next: parent inspects exact published head, qualifies original engineering
native scalar named image plus custom pixel_count producer. No frozen biology
replay. Whole installed classification runtime remains FAILED/pending until
this acceptance succeeds. Worker does not merge itself.

Persistent small evidence: this validation directory and tracked receipt archive.
No large disposable scratch or spawned child remains. Keep original failures;
no cleanup of parent-owned evidence/source and no worktree deletion.
