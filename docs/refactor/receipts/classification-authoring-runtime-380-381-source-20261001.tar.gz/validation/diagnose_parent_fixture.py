"""Source-only prior-feature selection; never invoke the engineering callable."""

import importlib.util
import sys
from pathlib import Path

from openhcs.core.artifacts import ArtifactInputPlan, ArtifactSpecCollection
from openhcs.core.callable_contract import CallableContract
from openhcs.core.function_patterns import DEFAULT_GROUP_KEY, FunctionInvocationKey
from openhcs.core.invocation_artifacts import ArtifactDeclarationStepContext
from openhcs.core.pipeline.artifact_planning import artifact_producers_for_outputs
from openhcs.interop.cellprofiler.parser import ModuleBlock, ModuleSetting
from openhcs.processing.backends.cellprofiler.classification import (
    ClassifyObjectsSingleMeasurementModule,
)


fixture_path = Path(
    "/home/ts/wt/openhcs-issue-batch-20260929/"
    "calibration371-classification372-installed-20261001/engineering_fixture.py"
)
spec = importlib.util.spec_from_file_location("prior_feature_engineering_probe", fixture_path)
fixture = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = fixture
spec.loader.exec_module(fixture)
contract = CallableContract.from_callable(
    fixture.engineering_calibration_classification_fixture
)
rows = contract.artifact_outputs.by_ref(fixture.ENGINEERING_ROWS.ref())
labels = contract.artifact_outputs.by_ref(fixture.ENGINEERING_LABELS.ref())
inputs = ArtifactSpecCollection((labels.for_plan_type(ArtifactInputPlan),))
context = ArtifactDeclarationStepContext(
    step_name="engineering_classification",
    step_index=1,
    available_artifacts=contract.artifact_outputs,
    main_flow_artifacts=inputs,
    available_artifact_producers=artifact_producers_for_outputs(
        contract.artifact_outputs,
        groups=(None,),
        invocation_keys=(
            FunctionInvocationKey(
                "engineering_calibration_classification_fixture", DEFAULT_GROUP_KEY, 0
            ),
        ),
    ),
)
module = ModuleBlock(
    name="ClassifyObjectsSingleMeasurement",
    module_num=2,
    setting_records=[
        ModuleSetting("Select the object to be classified", labels.name),
        ModuleSetting("Select the measurement to classify by", "pixel_count"),
    ],
)
owner = ClassifyObjectsSingleMeasurementModule
assert owner.prior_measurement_feature_names(module) == ("pixel_count",)
object_refs, source_refs = owner.prior_measurement_lineage_refs(
    feature_name="pixel_count", direct_inputs=inputs, step_context=context
)
assert rows.measurement_feature_owner.owns_measurement_feature_name("pixel_count")
assert not source_refs
print("FEATURE_OWNER_ACCEPTS_PIXEL_COUNT=True")
print("CONSUMER_OBJECT_REFS=" + repr(object_refs))
print("PRODUCER_MEASUREMENT_RELATIONS=" + repr(rows.relations))
raw_match = any(relation.source in object_refs for relation in rows.relations)
projected_match = any(
    relation.source.for_plan_type(ArtifactInputPlan) in object_refs
    for relation in rows.relations
)
print("CURRENT_OBJECT_LINEAGE_MATCH=" + str(raw_match))
print("ORIGINAL_REF_OWNER_PROJECTED_MATCH=" + str(projected_match))
assert raw_match is False and projected_match is True
try:
    owner.prior_measurement_artifact_inputs(
        module, step_context=context, direct_inputs=inputs
    )
except ValueError as error:
    assert "cannot resolve prior measurement feature 'pixel_count'" in str(error)
    print("EXACT_ORIGINAL_FAILURE=" + str(error))
else:
    raise AssertionError("Original source defect did not reproduce")
print("NO_ENGINEERING_CALLABLE_OR_NATIVE_PROCESS_EXECUTED")
