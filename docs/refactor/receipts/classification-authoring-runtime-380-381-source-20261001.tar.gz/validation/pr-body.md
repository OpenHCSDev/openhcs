## Separate follow-up ownership

Fixes #380 and #381. Dewey owns this source-only follow-up; no competing parent patch. **Stacked on frozen PR372 head `683106068`**, not changes to #370 / PR372. Retarget to main normally after PR372 merges. Two production owners only; no overlap with merged #368/371 or parent evidence/installed trees.

## Original failures retained

- #380: exact original custom fixture `3157e246...` declares output-qualified object subject; feature owner accepts `pixel_count`, but the prior consumer compares it to an input-qualified selector. Exact source rejection reproduced 5.52s / 381.74MiB. This is a generic declaration-role interoperability defect, not a fixture mistake.
- #381: parent's original v4 native compile `7384d733` PASS 1.586s, then execution `dddef9dc-df32-4d7c-a1d5-137799b403dc` FAILED 7.74s after fixture/size success: `(0,) != ()`. Real source contract -> original store/adapter -> original scalar callable reproduces exactly (7.05s / 433.42MiB). No native run or original mutation replay by this worker.

## Owning repair and inheritance proof

Existing `PriorMeasurementArtifactInputModule` compares typed lineage using original `ArtifactSpecRef.for_plan_type`; exact names/types, both object/source constraints and group ambiguity checks remain. No producer subject rewrite or decoder/registry copy.

Original runtime-parameter leaves now extend one shared vector-binding ABC and supply small original feature-binding hooks. The scalar leaf composes a separate compiled-output-selector capability, cooperative `super()` restores both measurement vector and original named image. Pair-vector leaves do not inherit this capability. Generic selection derives from `CallableContract.runtime_bound_parameter_types`. Removed all three central vector/feature/zip rosters and old consumer procedure. Strict image-rule assertion and numerical engines unchanged; no omitted output, default-off path or compatibility facade.

New declaration/MI test adds its own decorated callable and leaf hooks, then executes through the unchanged shared consumer with both independently contributed values. Custom nominal feature owner + prior consumer declare only their own case. Rejection checks cover unknown feature, wrong subject/source/type, missing owner/subject, duplicate image, absent relation and wrong rule index. Latest NRA/refactor-audit review explicitly covers IMPL-1/3/4/5/6/12/13, MEMB-1/2, BOUND-2, IDEN-1.

## Source checkpoint

83 source cases PASS **7.79s / 423.72MiB**: complete new boundary, original artifact-declaration and invocation-provider suites. CPU0/one-thread pools/unchanged combined512MiB/60s, readonly parent dependencies, explicit own source, native-child guard. Ruff F/I and diff check PASS. Pinned original R0 and supplemental complete-suite/source fixture receipts in progress.

A combined conditional-image run hit the unchanged resource limit (512.56MiB at16.01s); original failure and all intermediate red receipts remain. No passing/waiver claim for that run. Separate bounded checks will be reported honestly.

Parent-installed next engineering acceptance remains required. Original full classification runtime is **FAILED**, not ready; no biological/frozen-snapshot/viewer/global FULL claim. No native/install/provider/science launch by this worker. Production source and evidence handoff: `docs/refactor/Classification-authoring-runtime-380-381.rst`.
