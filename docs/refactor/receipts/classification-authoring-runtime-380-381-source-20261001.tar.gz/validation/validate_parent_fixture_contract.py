"""Readonly original fixture declaration qualification; never call its science."""

import importlib.util
import sys

from openhcs.core.artifacts import ArtifactInputPlan, ArtifactSpecCollection, ImageArtifactType
from openhcs.core.callable_contract import CallableContract
from openhcs.core.function_patterns import DEFAULT_GROUP_KEY, FunctionInvocationKey
from openhcs.core.invocation_artifacts import ArtifactDeclarationStepContext
from openhcs.core.pipeline.artifact_planning import artifact_producers_for_outputs
from openhcs.processing.backends.cellprofiler.classification import (
    ClassifyObjectsSingleMeasurementModule, classify_objects_single_measurement,
)
from tests.unit.test_cellprofiler_conditional_analysis_images import _public_function_step_contract

fixture_path = (
    "/home/ts/wt/openhcs-issue-batch-20260929/"
    "calibration371-classification372-installed-20261001/engineering_fixture.py"
)
spec = importlib.util.spec_from_file_location("original_fixture_contract_380", fixture_path)
fixture = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = fixture
spec.loader.exec_module(fixture)
original = CallableContract.from_callable(fixture.engineering_calibration_classification_fixture)
context = ArtifactDeclarationStepContext(
    step_name="engineering_classification", step_index=1,
    available_artifacts=original.artifact_outputs,
    main_flow_artifacts=ArtifactSpecCollection((fixture.ENGINEERING_LABELS.for_plan_type(ArtifactInputPlan),)),
    available_artifact_producers=artifact_producers_for_outputs(
        original.artifact_outputs, groups=(None,),
        invocation_keys=(FunctionInvocationKey("engineering_fixture", DEFAULT_GROUP_KEY, 0),),
    ),
)
compiled = _public_function_step_contract(
    ClassifyObjectsSingleMeasurementModule, classify_objects_single_measurement,
    dict(select_the_object_to_be_classified="engineering_cells", measurement_feature="pixel_count",
         retained_image_name="engineering_class_rgb"), context,
)
selected = compiled.artifact_inputs.by_ref(fixture.ENGINEERING_ROWS.for_plan_type(ArtifactInputPlan).ref())
assert selected is not None
assert selected.measurement_feature_owner is fixture.EngineeringFeatureOwner
assert fixture.ENGINEERING_ROWS.relations[0].source == fixture.ENGINEERING_LABELS.ref()
assert tuple(output.name for output in compiled.artifact_outputs.of_artifact_type(ImageArtifactType)) == ("engineering_class_rgb",)
print("ORIGINAL_CUSTOM_FIXTURE_CONTRACT_PASS=" + repr(selected.ref()))
print("ORIGINAL_OUTPUT_QUALIFIED_SUBJECT_UNCHANGED=True")
print("DECLARED_RETAINED_IMAGE=engineering_class_rgb")
print("NO_FIXTURE_FUNCTION_EXECUTION_OR_NATIVE_PROCESS=True")
