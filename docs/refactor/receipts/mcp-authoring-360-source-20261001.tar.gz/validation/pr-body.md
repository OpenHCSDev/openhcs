## Working source checkpoint: MCP authoring roundtrip (#360)

Independent branch/worktree based on main `791650087e01c9d25766f12802a37296851f37cf`; no parent-tree edits, installs, engine/pin changes, scientific processing or mutation replays.

* Fix the real response-decoder NameError at the recursive JSON alias declaration. Original `python_introspect.dataclass_from_mapping` and declared DTO descent stay unchanged; no dictionary decoder or namespace/schema roster.
* Keep canonical `FunctionReference` authority in rendered source. The existing ABC composes `PythonSourceLiteral`; registry leaves supply exact-key lookup hooks, importable leaves retain declaration imports. Cooperative source-import collection and the original pycodify formatter handle the family; delete the lossy carrier and separate reference formatter. No skimage/library/type switch or compatibility facade.
* Add real dev-client structured/text receipt decoding and actual authoring → rendering → parsing → `FuncStepContractValidator` checks using the real wrapped SkimageRegistry declaration. New leaf and independent MI capability tests need no generic consumer edit.

Final source checkpoint: **131f824769ff95bf315958061db0e2f92876a747**. **39 passed**, **6.82 s / 372.93 MiB**, complete formatter + focused authoring + JSON projection suites, no deselection; one CPU, unchanged **512 MiB / 60 s**. Focused 15 cases include real cooperative MI/MRO import composition. Hard subprocess guards. Original PINNED R0 main791650 → source131f82476: **PASS**, **14.17 s / 82.58 MiB**, **5,176 measures, increased[]**. Ruff F/I and diff checks pass.

Guarded original production-source comparison: **9 failed / 3 passed**, 6.47 s / 254.75 MiB; raw external function still rejects missing memory decorator. Original transcripts and all failed local attempts retained, including an accidental custom-reconciliation preparation subprocess failure and a capped 514.36 MiB attempt. No installed/live acceptance claimed. Receipt archive: `docs/refactor/receipts/mcp-authoring-360-source-20261001.tar.gz`; subsequent delivery changes are docs/evidence only.

### Explicit remaining boundaries

Parent owns fresh installed MCP/native/user acceptance. Full global 85-detector NRA remains unqualified; focused proof is not FULL or installed GUI acceptance. Native/bootstrap/serialized lock are not claimed.

The linked GrayToColor compile-selector/default/ordinal witnesses remain **recorded/unfixed**, with this independent sidecar retaining authoring-boundary diagnosis ownership: signature-only admission disagrees with `CellProfilerModule.declared_setting_bindings` and declaration-time consumption. Named FITC(red)/DAPI(blue) selectors compile FITC,DAPI inputs, distinct from source-binding DAPI,FITC; numeric red1/blue0 swaps observed MCP full pixels, and omitting numeric kwargs fails exact module reconstruction. Parent tests red0/blue1 against compiled order and retains both original engineering sources. This does not authorize modifying scientific/native engines or replaying drafts. Issue360 stays open for the logical authoring group.

Parent's AUTO/PREPARED_WORKSPACE raw-override refusal is correct provenance behavior; no weakening. Parent's separately authored explicit SOURCE_BINDINGS synthetic artifact-plan success does not prove the original rendered source or advertised func selectors pass.

See `docs/refactor/MCP-authoring-roundtrip-360.rst` for owner/interface review, IMPL/BOUND patterns, original evidence and limitations. No hosted-CI wait or self-merge.
