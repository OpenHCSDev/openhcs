Issue360 / draft PR365 source evidence, 2026-10-01
==================================================

Production/tested checkpoint: 131f824769ff95bf315958061db0e2f92876a747.
Base: 791650087e01c9d25766f12802a37296851f37cf.

Each .json contains the exact command, exit/limit, elapsed wall time and
peak combined command-process-group RSS. Its same-name .log is full output.
All application checks use explicit own source plus read-only dependencies;
source commands are pinned to CPU0, bounded to 512 MiB / 60 s using the original
read-only PR359 run_bounded.py supervisor. No tool algorithm is copied here.

Authoritative passing receipts:

* formatter-full: all 39 formatter/authoring/JSON projection cases,
  6.82 s / 372.93 MiB; no deselection.
* roundtrip-polymorphic: 15 focused cases, 4.96 s / 245.26 MiB.
* r0-final: original PINNED R0 with actual Python3.14, source
  comms-ratchet-pinned-ui348/src and read-only BaSiCPy metaclass backing;
  main791650 -> source131f82476, 14.17 s / 82.58 MiB, 5176 measures,
  increased[]. StringSubscript -1; ForeignAbsenceProbe on pycodify -1.

Original real reproductions:

* decoder-original: real decoder descent into ConfigPatch hits JsonValue
  NameError, 0.51 s / 39.55 MiB. This first minimal hand-authored wire receipt
  also omitted config_type, but type-hint evaluation fails before construction;
  the guarded original comparison below uses fully declared valid receipts.
* roundtrip-original-guarded: original PR359 production source is identical
  under openhcs/ to main791650 (git diff --exit-code verified). New focused
  cases execute against that explicit source with actual decoder/formatters,
  recording 9 failures / 3 passes, 6.47 s / 254.75 MiB. Original raw callable
  still rejects the missing memory contract.

All other receipts preserve intermediate failures/setup mistakes, not waived
qualification: missing extension during collection, initially unregistered
formatter fixture, incorrect test config_type, 514.36 MiB cap termination,
unexpected custom-source reconciliation preparation child failure at missing
extension, clean-mode assertion that initially compared omitted defaults,
Popen guard type-alias setup error, and stale direct-import assertion.
Subsequent passing fixture hooks use the original registry metadata store and
prevent subprocess launches; they do not replace decoder/serializer/validator.

Parent original installed transcript and authoring/color witnesses remain
unmodified at openhcs-issue-batch-20260929/paired350-installed-20261001.
No original mutation is replayed. GrayToColor selector admission, ordinal/default
reconstruction and parent installed acceptance remain open. PREPARED_WORKSPACE
provenance rejection is correct. Global85 NRA FULL remains unqualified.
