MCP authoring-roundtrip defect owner, 2026-10-01
================================================

Independent owner: this Codex sidecar; issue 360. Persistent worktree
``/home/ts/wt/openhcs-mcp-inherited-dto-decoder-20261001``;
branch ``fix/mcp-inherited-dto-decoder-20261001``;
base ``791650087e01c9d25766f12802a37296851f37cf``.
Draft PR: https://github.com/OpenHCSDev/openhcs/pull/365.

Original installed ``3d58912`` mutation is reconciled: the step exists despite
client decoding failure. Do not replay. Original transcript remains untouched:
``/home/ts/wt/openhcs-issue-batch-20260929/paired350-installed-20261001/mcp.stdout``
and ``mcp.stdin``. Parent owns installed/native/viewer/MCP acceptance and lock.

Own tests/receipts are under ``validation/`` here, persistent and small.
No large scratch, installs, dependency edits, native processes, provider calls,
scientific processing, or changes to parent trees. Source commands run on one
CPU, bounded to 512 MiB combined command RSS / 60 s via the original read-only
PR359 supervisor. Failed attempts retained, never overwritten.

Decoder owner: recursive aliases in ``openhcs.serialization.json``; original
``python_introspect.dataclass_from_mapping`` already uses declared type hints.
Real original failure descends from FunctionStepSpec into ConfigPatch.values.
Fix alias recursion's module ownership, not a DTO/global namespace roster.

Rendering owner: FunctionReference ABC and concrete RegistryFunctionReference,
consumed by existing pycodify formatters. Preserve canonical key and use the
existing documented lookup instead of projecting only raw import identity.

Linked GrayToColor witness is not silently fixed/waived: authoring validator
``PipelineAuthoringService._function_spec_item / _validate_callable_kwargs``
permits only ordinary signature agent parameters; advertised compile selectors
belong to ``CellProfilerModule.declared_setting_bindings`` and are consumed by
``module_blocks_for_invocation`` and ``invocation_callable_contract``.
This sidecar owns recording/diagnosis; selector admission is an explicitly
remaining authoring/declaration follow-up, not numerical or runtime-engine work.
No draft replay or scientific-module changes are authorized by this witness.

Source checkpoint: 39 cases pass together, 6.82 s / 372.93 MiB; 15 focused
cases include cooperative-MRO/new-case behavior. Original source comparison:
9 failures / 3 passes, 6.47 s / 254.75 MiB. Original pinned R0 passed at
final source131f824769ff95bf315958061db0e2f92876a747,
14.17 s / 82.58 MiB, all5176 measures with no increases. Delivery commits after
that source checkpoint are docs/evidence only. All logs/commands and this
handoff are archived under docs/refactor/receipts/mcp-authoring-360-source-20261001.tar.gz.
An initial source test unexpectedly attempted registry preparation during
custom-source reconciliation and failed its child import; preserved receipts
name it. Subsequent source fixtures forbid launches and use existing selected
declaration metadata. No further native/live gate is owned or authorized here.

Parent provenance update: AUTO on an already prepared unaliased workspace
correctly rejects raw override. Do not weaken PREPARED_WORKSPACE. Parent's
separate explicit SOURCE_BINDINGS tiny plate succeeds; that is not acceptance
of original rendering/selector admission. Named GrayToColor selectors reorder
compiled inputs FITC,DAPI; numeric red1/blue0 swaps observed colors and omission
fails module reconstruction. Preserve both parent sources and the unresolved
selector/default/ordinal contract witness in issue360/docs.
