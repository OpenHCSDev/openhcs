Classification subject #370 / PR372 source receipts
===================================================

Owner: /home/ts/wt/openhcs-classification-measurement-subject-20261001.
Base: bcf5fa55a21d33126d0ca2c2e100c85e4f985960.
Qualified production/test source: a5a0972e481d9e5062aef8e9126806c356f25551.

original-main-provider: unchanged complete original suite, 25 passed/1 failed,
6.68s / 383.36MiB. Exact classification missing subject failure retained.
focused-subject-provider: fixture-constructor mistake, 8 failed/26 passed,
6.74s / 378.29MiB. Original compile test already passes; fixture subsequently
corrected to the actual ModuleBlock constructor. Failure is not overwritten.
focused-subject-provider-corrected-fixture: 34 passed, 6.47s / 377.82MiB.
declaration-regression: three complete suites, 76 passed, 7.85s / 383.39MiB.
pinned-r0: original tool, 15.07s / 85.25MiB, 5161 entries, no deltas.

Every JSON contains the exact command, exit, combined process-group RSS and
wall time. Matching logs retain full output. Source suites use one CPU,
one-thread pools, readonly parent dependencies and explicit own source, with
native subprocess launches guarded. Bounds stay 512MiB / 60s. No installation,
provider call, native/science/UI/MCP launch or heavy gate. Installed acceptance
remains parent-owned. No original mutation or frozen science trial replay.

Evidence is persistent and intentionally retained, not abandoned scratch.
Uncompressed validation directory is about 1.6MiB. No disposable large output
was generated. PR367 reviewed head and all parent worktrees remain untouched.
