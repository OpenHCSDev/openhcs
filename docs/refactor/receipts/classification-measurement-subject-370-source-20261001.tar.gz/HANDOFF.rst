Classification object subject ownership / #370 / PR372
======================================================

Working draft: https://github.com/OpenHCSDev/openhcs/pull/372
Issue: https://github.com/OpenHCSDev/openhcs/issues/370
Source checkpoint: a5a0972e481d9e5062aef8e9126806c356f25551
Base: merged PR365 main bcf5fa55a21d33126d0ca2c2e100c85e4f985960

Owning capability ObjectMeasurementArtifactOutputModule extends the original
MeasurementArtifactOutputModule. Existing ObjectMeasurementInputModule
inherits it, deleting the old duplicate location; classification composes it
with original input/prior-measurement/recording owners. One algorithm, real
cooperative MRO, no compiler switch, fallback or new registry. New declaration
test exercises original registry and generic output behavior without consumer
changes; missing and ambiguous subjects still reject. Both variants covered.

Original full provider suite 25 passed/1 failed preserved. Qualified complete
declaration/provider/new subject suites 76 passed, 7.85s / 383.39MiB. Original
pinned R0 passes 15.07s / 85.25MiB, no increases or decreases. All source-only,
oneCPU / 512MiB / 60s, no native or installs. Parent-installed acceptance next;
do not call this numerical, installed GUI or native classification acceptance.

No edits to Lorentz #368 function_patterns/metadata edge/runtime work or PR362
producer files. PR367 remains frozen at ec8761591862378794a3021543fa18e263717284
for parent installed acceptance; this sidecar does not block it or self-merge.
All exact receipts/logs in validation/ and tracked archive. Evidence about
1.6MiB retained deliberately; no disposable large scratch or process remains.
