#!/bin/bash
# Original repaired R1 consumer, complete context and unchanged resource bounds.
set -euo pipefail
unset PYTHONPATH
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export XDG_CACHE_HOME=/home/ts/.cache/agent-scratch/paired350-r1-20261001/cache
export TMPDIR=/home/ts/.cache/agent-scratch/paired350-r1-20261001
export GIT_CONFIG_COUNT=2
export GIT_CONFIG_KEY_0=core.packedGitWindowSize GIT_CONFIG_VALUE_0=8m
export GIT_CONFIG_KEY_1=core.packedGitLimit GIT_CONFIG_VALUE_1=128m
mkdir -p "$TMPDIR" "$XDG_CACHE_HOME"
# This unchanged worktree owns all eight exact recorded dependency clones.
cd /home/ts/wt/openhcs-ui-workflow-rendering-20261001
test "$(git -C /home/ts/wt/nra-bounded-full-audit-20260929 rev-parse HEAD)" = 673c062fc656e9c74f1eddcab30f036c9befbc1f
exec /home/ts/wt/openhcs-generated-inputs-installed-parent-20261001/.venv/bin/python -I -B -c \
  'import runpy,sys; from pathlib import Path; sys.path.insert(0,"/home/ts/wt/nra-bounded-full-audit-20260929"); import nominal_refactor_advisor; assert Path(nominal_refactor_advisor.__file__).is_relative_to(Path("/home/ts/wt/nra-bounded-full-audit-20260929")); runpy.run_path("/home/ts/wt/openhcs-r1-revision-staging-357-20261001/scripts/check_refactor_r1.py",run_name="__main__")' \
  --base 791650087e01c9d25766f12802a37296851f37cf \
  --head 3d58912d6e74e4b3dd4fa9e07a6b4a9d7dd9c7e4 \
  --scratch-root /home/ts/.cache/agent-scratch/paired350-r1-20261001/r1 \
  --budget-seconds 160
