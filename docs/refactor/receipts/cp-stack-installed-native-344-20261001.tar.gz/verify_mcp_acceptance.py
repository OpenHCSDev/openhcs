"""Verify recorded MCP payloads, never decode microscopy files directly."""
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
text = (root / "mcp.stdout").read_text()
decoder = json.JSONDecoder()
documents = []
for match in re.finditer(r"(?m)^\{", text):
    document, _ = decoder.raw_decode(text, match.start())
    documents.append(document)
payloads = {}
errors = []
for document in documents:
    errors.extend(document.get("errors", []))
    for result in document.get("results", []):
        assert result["mcp_error"] is False
        for payload in result["payloads"]:
            payloads.setdefault(result["tool"], []).append(payload)
            errors.extend(payload.get("errors", []))

health = payloads["openhcs_health_check"][-1]
assert health["status"] == "ok" and not health["restart_required"]
assert "openhcs-cp-stack-installed-parent-20261001/.venv" in health["server_source_path"]
plans = payloads["openhcs_inspect_pipeline_source_artifact_plan"]
assert len(plans) == 4 and len(errors) == 3
assert all(plan["errors"] for plan in plans[:3])
plan = plans[-1]
assert not plan["errors"] and plan["axes"] == ["A01"]
assert plan["step_count"] == 1 and plan["source_workspace"]["file_count"] == 4
files = plan["source_workspace"]["files"]
assert {(f["source_metadata"]["source_alias"], f["source_metadata"]["z_index"]) for f in files} == {
    ("EngineeringCH1", "1"), ("EngineeringCH1", "2"),
    ("EngineeringCH2", "1"), ("EngineeringCH2", "2"),
}
assert len({f["source_path"] for f in files}) == 4
for item in files:
    metadata = item["source_metadata"]
    assert metadata["site"] == "1" and metadata["well"] == "A01"
    assert metadata["OpenHCSSourceVoxelSpacingZYX"] == "4,0.5,0.5"
    assert metadata["OpenHCSSourceVoxelSpacingUnit"] == "micrometers"

jobs = payloads["openhcs_get_execution_status"]
assert len(jobs) == 2
assert {job["kind"] for job in jobs} == {"compile", "execute"}
for job in jobs:
    assert job["status"] == "complete" and not job["errors"]
    execution = job["response"]["execution"]
    assert execution["status"] == "complete" and execution["error"] is None
    assert execution["results_summary"]["wells"] == ["A01"]

samples = payloads["openhcs_sample_plate_image"]
assert len(samples) == 8
raw = samples[:4]
outputs = samples[4:]
def flatten(value):
    if isinstance(value, list):
        return [number for item in value for number in flatten(item)]
    return [value]
for sample in samples:
    assert not sample["errors"] and sample["sample_included"]
    assert sample["selected_resolution_index"] == 0
    assert sample["downsample_yx"] == [1, 1]
assert all(sample["shape"] == [32, 32] for sample in raw)
raw_by_plane = {(s["source_metadata"]["z_index"], s["source_metadata"]["channel"]): s for s in raw}
assert set(raw_by_plane) == {(1,1), (1,2), (2,1), (2,2)}
raw_values = [v for sample in raw for v in flatten(sample["sample_values"])]
low, high = min(raw_values), max(raw_values)
assert low < high
maximum_error = 0.0
comparison_count = 0
for sample in outputs:
    assert sample["shape"] == [2, 32, 32] and sample["dtype"] == "float32"
    metadata = sample["source_metadata"]
    assert metadata["OpenHCSSourceVoxelSpacingZYX"] == "4,0.5,0.5"
    assert metadata["OpenHCSSourceVoxelSpacingUnit"] == "micrometers"
    assert metadata["source_alias"] == "EngineeringCH1"
    assert metadata["channel"] == 1 and metadata["site"] == 1
    z = metadata["z_index"]
    for channel in (1, 2):
        input_pixels = flatten(raw_by_plane[(z, channel)]["sample_values"])
        output_pixels = flatten(sample["sample_values"][channel - 1])
        assert len(input_pixels) == len(output_pixels) == 1024
        for input_pixel, output_pixel in zip(input_pixels, output_pixels, strict=True):
            error = abs(output_pixel - (input_pixel - low) / (high - low))
            maximum_error = max(maximum_error, error)
            assert error <= 1e-6, (z, channel, input_pixel, output_pixel, error)
            comparison_count += 1
assert comparison_count == 8192
close = payloads["openhcs_close_owned_runtime"][-1]
assert close["outcome"]["process_exited"] is True
assert close["outcome"]["succeeded"] is True
assert close["handle"]["process_identity"] == {"pid":918063,"create_time":1790840817.41}
print(json.dumps({"status":"PASS", "recorded_admission_failures":len(errors),
    "compared_pixels":comparison_count,"maximum_absolute_error":maximum_error,
    "input_range":[low,high],"owned_runtime_exited":True}))
