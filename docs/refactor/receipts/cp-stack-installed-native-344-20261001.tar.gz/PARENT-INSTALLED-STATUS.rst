Parent installed checkpoint for PR344
====================================

Public source head 34203beb15a49da522b8719f08020e6fc9f2e9b9 plus normal merge
of current main 05c3cf288 produces candidate 21c0a460c73179aff60c207a0d3066abd87540a9.
Its three changed installed production files match source byte-for-byte.
Actual installed OpenHCS origin is the private candidate venv, version 0.8.7,
with existing paired PolyStore 0.3.0 dependency backing reused read-only.

Wheel SHA256 73c35787284c1eb8a0b3e604bc1e9cb6117f0ce11aac7b1133ae48f08ec2942b,
4175140 bytes. No downloads or global install. Build PASS 11.78s/250.36 MiB,
one CPU/512 MiB/60s supervisor, existing installed dependencies reused.

Installed source-family numeric tests: 15 PASS, 2.70s/269.26 MiB, same bounds,
installed Python -I --import-mode=importlib --noconftest -o addopts= -o pythonpath=.
The first invocation failed before collection because source addopts named a
tests.pytest_integration_options plugin unavailable under isolated Python.
It is retained; the corrected invocation disables that repository setup rather
than injecting source paths into the installed package. No assertion changed.

Additional installed external-argument boundary::

  from openhcs.core.runtime_slice_projection import RuntimeSliceProjection
  token = object()
  assert RuntimeSliceProjection.full_stack_kwargs({'options': token})['options'] is token

FAILED at original registered strategy_for_value lookup:
RuntimeSliceProjectionDeclarationError: Runtime-slice projection has no nominal
strategy for object. 0.58s/56.58 MiB. Exact original argv, output and exit 1 are
retained in owned cp-stack-installed-opaque-original supervisor receipts.
This is an actual discovered regression, not a timeout or successful gate.

Named source owner: Darwin, existing issue342/PR344. His active uncommitted
extension uses the existing optional nominal owner lookup for full-stack values,
preserving opaque arguments by identity while declared aligned image strategies
own materialization. It adds opaque callable-argument and calibrated nominal
new-case controls. These edits are not in this installed candidate and have
not been accepted. Parent must consume coherent published source, integrate
normally, rebuild and verify this regression plus the installed/native path.
No parent edits to Darwin's worktree or parallel implementation.

No native server, MCP, viewer, scientific execution or H003g retry launched
for this candidate. Native slot free. H003g remains frozen FAILED. Complete
NRA/R1 and biological acceptance are not established by these 15 tests.

Raw build/test receipts are currently under owned supervisor scratch
imagexpress-installed-20261001/cp-stack-*, purpose declared in OWNERSHIP.rst;
retain and archive before cleaning. Candidate remains unmerged.
