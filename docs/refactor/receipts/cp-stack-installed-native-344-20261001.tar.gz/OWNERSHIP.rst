PR344 installed/runtime engineering acceptance
=============================================

Owner: parent integration. Source base public PR344 head
34203beb15a49da522b8719f08020e6fc9f2e9b9, normal merge with main
05c3cf2883fb2ce75c14961264dabad633e639ee in detached private persistent WT.
Darwin retains independent source ownership; this gate does not edit his WT.

Private candidate: /home/ts/wt/openhcs-cp-stack-installed-parent-20261001.
Read-only dependency backing: isolated ImageXpress installed venv, which reuses
the paired frozen OpenHCS/PolyStore dependency store. Install --ignore-installed
into candidate only, no downloads or global package changes. Verify installed
OpenHCS origin and production byte equality before live claims.

Disposable runtime cache: /home/ts/.cache/agent-scratch/cp-stack-installed-20261001.
The already reviewed resource supervisor under imagexpress-installed-20261001
is reused for small build/source checks; its cp-stack-* logs belong to this gate
and will be archived here before scratch cleanup. One CPU/512 MiB/60s shards.
No heavy test or native runtime parallel with other gate; validation.lock owns
the live slot. Native startup allowed only through exposed MCP with exact handle
and owned local endpoint. Display91 protected/isolation only; desktop0/H002 and
foreign7777 are untouched. Preserve returned child incarnation on timeouts.

This is a new tiny engineering fixture, not H003g's source, inputs or scientific
parameters. No counted blind retry, held-out access, answer reference or biology
claim. Acceptance must use actual installed MCP/native declaration/runtime path
and preserve exact source identities/calibration with persisted output checks.
Keep source, installed numeric and native evidence distinct. Complete NRA/R1
and biological QA remain unqualified; successful engineering does not clear them.
