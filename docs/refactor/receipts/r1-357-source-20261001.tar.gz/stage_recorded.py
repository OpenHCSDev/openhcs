"""Read-only real Git staging check; does not run NRA analysis or a heavy gate."""

from pathlib import Path
from tempfile import TemporaryDirectory

from scripts.check_refactor_r1 import SourceRevision, StagedSourceRevision, git


REPO = Path("/home/ts/wt/openhcs-ui-workflow-rendering-20261001")
SCRATCH = Path("/home/ts/.cache/agent-scratch/openhcs-r1-357-20261001")
ROOTS = ("openhcs", "scripts", "benchmark")
BASE = "c81963475e6221961be5209c47c36f5f4c222521"
HEAD = "901e9a49a6e18f0b9c86574210568d1a3efbae67"


def membership(revision, prefix=Path("."), roots=()):
    revision.require_repository()
    sources = set()
    dependencies = []
    for entry in git(revision.repo, "ls-tree", "-r", "-z", revision.revision).split(b"\0"):
        if not entry:
            continue
        metadata, path_bytes = entry.split(b"\t", 1)
        mode, kind, object_id = metadata.decode().split()
        path = Path(path_bytes.decode())
        if mode == "160000":
            dependencies.append((prefix / path, object_id))
            nested_sources, nested_dependencies = membership(
                SourceRevision(revision.repo / path, object_id), prefix / path
            )
            sources.update(nested_sources)
            dependencies.extend(nested_dependencies)
        elif kind == "blob" and path.suffix == ".py":
            if not roots or any(path.is_relative_to(root) for root in roots):
                sources.add(prefix / path)
    return sources, dependencies


def main():
    with TemporaryDirectory(prefix="recorded-stage-", dir=SCRATCH) as work:
        snapshot = Path(work) / "source"
        retained_stat = {}
        retained_bytes = {}
        for commit in (BASE, HEAD):
            source = StagedSourceRevision(REPO, commit)
            expected, dependencies = membership(source, roots=ROOTS)
            actual = {path.relative_to(snapshot) for path in source.materialize(snapshot, ROOTS)}
            assert len(dependencies) == 8
            assert actual == expected == {path.relative_to(snapshot) for path in snapshot.rglob("*.py")}
            unchanged = 0
            for path in actual:
                file = snapshot / path
                content = file.read_bytes()
                if path in retained_bytes and content == retained_bytes[path]:
                    assert file.stat() == retained_stat[path]
                    unchanged += 1
                retained_bytes[path] = content
                retained_stat[path] = file.stat()
            print(f"revision={commit} Python_members={len(actual)} unchanged_stat_identities={unchanged}")
            for path, object_id in dependencies:
                print(f"recorded_gitlink={path} object={object_id}")
    print("PASS: original real Git corpus staged at one address; no NRA analysis performed")


if __name__ == "__main__":
    main()
