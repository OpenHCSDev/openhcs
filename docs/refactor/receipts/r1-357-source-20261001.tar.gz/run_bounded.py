"""Sidecar-only command supervisor; limits apply to the entire command group."""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=60)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    peak = 0
    reason = None
    with args.receipt.with_suffix(".log").open("w") as output:
        process = subprocess.Popen(args.command, stdout=output, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        while process.poll() is None:
            rss = 0
            for path in Path("/proc").glob("[0-9]*/stat"):
                try:
                    stat = path.read_text().rpartition(") ")[2].split()
                    if int(stat[2]) == process.pid:
                        rss += int(stat[21]) * os.sysconf("SC_PAGE_SIZE")
                except (OSError, ValueError, IndexError):
                    continue
            peak = max(peak, rss)
            if rss > 512 * 1024**2:
                reason = "512 MiB combined process-group RSS"
            elif time.monotonic() - started > args.seconds:
                reason = f"{args.seconds:g}s wall"
            if reason:
                os.killpg(process.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        result = process.wait()
    summary = dict(command=args.command, exit=result, limit=reason,
                   peak_rss_mib=round(peak / 1024**2, 2),
                   seconds=round(time.monotonic() - started, 2))
    args.receipt.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))
    print(args.receipt.with_suffix(".log").read_text()[-9000:])
    return result if result >= 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
