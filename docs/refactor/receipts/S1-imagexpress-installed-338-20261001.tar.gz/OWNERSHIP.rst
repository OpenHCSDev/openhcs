ImageXpress installed acceptance ownership
=========================================

Parent owns this engineering gate, source integration and sole live validation
slot. Arendt retains PR338 source ownership and works separately on339; Darwin
retains runtime342/344 source. No agent worktree edits or competing source PR.

Candidate source: detached persistent worktree
/home/ts/wt/openhcs-imagexpress-installed-parent-20261001, head
69af3be07962ba66cdb0d3186bcdaa5734e54fb9: normal integration of338 at2a4e6a103
with merged343/main7b0ec3f5. Five338 production files unchanged by integration.
Private installed venv under that worktree; existing paired dependencies only,
no global/frozen H003g environment/managed skill changes or package downloads.

Disposable scratch: /home/ts/.cache/agent-scratch/imagexpress-installed-20261001,
owner parent, purpose bounded wheel build, own XDG/cache/runtime and MCP launch
diagnostics. Archive all outcomes and close exact owned handles before removing
this scratch. Persistent output/fixture/session/launch/provenance stay here.

Authority: generate only a fresh raw ImageXpress plate below this owned root,
32x32 tiles, grid1x1, A01, two wavelengths/twoZ, bounded cells/sample count.
Actual MCP inspect/query human+JSON before any initialization; source TIFF/HTD
hashes and file list unchanged, no workspace metadata permitted by read-only
operations. Then real exposed artifact-plan/session initialization through MCP;
repeat actual inspection/query and compare exact source paths, well/site/time,
CH1/2 Z1/2 and HTD calibration. Only declared workspace metadata writes allowed.
No analytical processing, biological input/output/count claim or viewer required.

Use existing validation.lock nonblocking and same installed stdio process.
DISPLAY91; preserve desktop0/H00290/foreign7777/5991. One CPU/native pools1;
observe real live handles, never restart solely on timeout. Preflight21.6GiB RAM,
home15.5GiB/swap14.2GiB warnings, not20GB hard limit. No fleet expansion.
No startup permitted on occupied endpoints. Dispose exact original native child
through MCP if one is necessary; retain acknowledgement vs process exit facts.
