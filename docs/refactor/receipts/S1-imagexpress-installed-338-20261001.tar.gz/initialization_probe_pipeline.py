from openhcs.constants.constants import Microscope
from openhcs.core.config import PipelineConfig
pipeline_config = PipelineConfig(num_workers=1, microscope=Microscope.IMAGEXPRESS, use_threading=True)
pipeline_steps = []
