"""Check recorded MCP engineering evidence; never decode image pixels."""
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent
text = (root / "mcp.stdout").read_text()
decoder = json.JSONDecoder()
records = []
offset = 0
while offset < len(text):
    start = text.find('\n{', offset)
    if start < 0:
        break
    envelope, end = decoder.raw_decode(text, start + 1)
    records.extend(envelope.get("results", []))
    offset = end

failed = [record for record in records if record["mcp_error"]]
assert len(failed) == 1, failed
assert failed[0]["tool"] == "openhcs_describe_config_schema"
assert "Field required" in failed[0]["payloads"][0]["text"]
plate = root / "fixture-imagexpress-folder-axes"
inspections = [record["payloads"][0] for record in records
               if record["tool"] == "openhcs_inspect_plate_path"
               and record["payloads"][0]["plate_path"] == str(plate)]
before, after = inspections
assert before["detected_microscope_type"] == "imagexpress"
assert before["workspace_preparation"]["required_before_execution"]
assert after["detected_microscope_type"] == "openhcsdata"
assert not after["workspace_preparation"]["required_before_execution"]
expected = {(f"TimePoint_1/ZStep_{z}/A01_s001_w{channel}.tif",
             "A01", 1, channel, z, 1)
            for z in (1, 2) for channel in (1, 2)}

def identities(values):
    return {(str(Path(item["source_path"]).relative_to(plate)),
             item["metadata"]["well"], item["metadata"]["site"],
             item["metadata"]["channel"], item["metadata"]["z_index"],
             item["metadata"]["timepoint"]) for item in values}

for inspection in inspections:
    assert inspection["status"] == "ok" and not inspection["errors"]
    assert inspection["pixel_size"] == 0.65
    assert inspection["image_files"]["count"] == 4
    assert identities(inspection["image_files"]["sampled_records"]) == expected
queries = [record["payloads"][0] for record in records
           if record["tool"] == "openhcs_query_plate_files"
           and record["payloads"][0]["plate_path"] == str(plate)]
assert len(queries) == 2
for query in queries:
    assert query["total_count"] == query["returned_count"] == 4
    assert query["truncated_count"] == 0 and not query["errors"]
    assert identities(query["records"]) == expected
plan, = [record["payloads"][0] for record in records
         if record["tool"] == "openhcs_inspect_pipeline_source_artifact_plan"]
assert not plan["errors"] and plan["step_count"] == 0
workspace = plan["source_workspace"]
assert workspace["file_count"] == workspace["axis_file_counts"]["A01"] == 4
assert workspace["truncated_file_count"] == 0
assert {item["source_path"] for item in workspace["files"]} == {item[0] for item in expected}
for item in workspace["files"]:
    metadata = item["source_metadata"]
    assert metadata["OpenHCSSourceVoxelSpacingUnit"] == "micrometers"
    assert tuple(map(float, metadata["OpenHCSSourceVoxelSpacingZYX"].split(","))) == (0.65, 0.65)
assert len({item["virtual_path"] for item in workspace["files"]}) == 4
subprocess.run(["sha256sum", "-c", "folder-axes-original.sha256"], cwd=root, check=True)
print("PASS: raw and initialized MCP inventories preserve four source identities and XY calibration; six original files unchanged.")
print("LIMIT: initialization-only empty pipeline; no processing execution, viewer, biological QA or complete NRA certificate.")
print("RETAINED: one read-only schema input rejection, corrected before mutation; shell exit 1 records that failure.")
