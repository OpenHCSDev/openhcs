import time
import zipfile
from copy import copy
from multiprocessing import SimpleQueue
from pathlib import Path

import numpy as np
import tifffile
from objectstate import ObjectStateRegistry
from objectstate.lazy_factory import ensure_global_config_context

from openhcs.constants import AllComponents, GroupBy, Microscope, VariableComponents
from openhcs.constants.input_source import InputSource
from openhcs.core.callable_contract import CallableContract
from openhcs.core.artifacts import ArtifactViewerStreaming
from openhcs.core.config import GlobalPipelineConfig, LazyNapariStreamingConfig
from openhcs.core.function_patterns import get_core_callable
from openhcs.core.orchestrator.orchestrator import PipelineOrchestrator
from openhcs.core.progress import set_progress_queue
from openhcs.core.source_bindings import source_bindings_defaults_to_base
from openhcs.core.source_workspace_projection import (
    VirtualWorkspaceSourceProjectionAuthority,
)
from openhcs.microscopes.bioformats import BioFormatsHandler
from openhcs.processing.backends.analysis.neurite_outgrowth import (
    MetaXpressCellBodySettings,
    MetaXpressNuclearSettings,
    MetaXpressOutgrowthSettings,
    neurite_outgrowth_metaxpress,
)
from openhcs.processing.backends.processors.numpy_processor import (
    percentile_normalize_plane,
)
from openhcs.processing.presets.demo_contribution import PipelineDemoContribution
from openhcs.processing.presets.pipelines.neuroncyto_ii_crossover_neurite_outgrowth import (  # noqa: E501
    NeuronCytoIICrossoverInputs,
    build_neuroncyto_ii_crossover_demo,
    neuroncyto_ii_crossover_demo_contribution,
)
from polystore.base import ensure_storage_registry, storage_registry
from polystore.filemanager import FileManager


def _inputs(plate_path: Path, output_root: Path) -> NeuronCytoIICrossoverInputs:
    return NeuronCytoIICrossoverInputs(
        plate_path=plate_path,
        output_root=output_root,
        image_id="Image15",
        neurite_filename="15_w1.tif",
        soma_nuclei_filename="15_w2.tif",
        viewer_port=5999,
    )


def test_neuroncyto_demo_declares_exact_crossover_channel_semantics(
    tmp_path: Path,
) -> None:
    inputs = _inputs(tmp_path / "CrossOvers_Images", tmp_path / "output")
    pipeline_config, steps = build_neuroncyto_ii_crossover_demo(inputs)

    assert pipeline_config.microscope is Microscope.SOURCE_BINDINGS
    assert pipeline_config.well_filter_config.well_filter == "Image15"
    assert pipeline_config.path_planning_config.well_filter == 0
    assert pipeline_config.materialize_runtime_artifacts is True
    assert pipeline_config.materialization_results_path == (
        inputs.output_root.resolve() / "results"
    )

    bindings = pipeline_config.source_bindings_config.bindings
    assert [binding.alias for binding in bindings] == [
        "NeuriteCellSignal",
        "SomaNucleiSignal",
    ]
    assert [binding.selector.filters[0].value for binding in bindings] == [
        "15_w1.tif",
        "15_w2.tif",
    ]
    assert [
        next(
            selector.value
            for selector in binding.component_identity
            if selector.component is AllComponents.CHANNEL
        )
        for binding in bindings
    ] == ["1", "2"]

    assert len(steps) == 1
    step = steps[0]
    assert get_core_callable(step.func) is neurite_outgrowth_metaxpress
    assert step.processing_config.variable_components == [VariableComponents.CHANNEL]
    assert step.processing_config.group_by is GroupBy.NONE
    assert step.processing_config.input_source is InputSource.PIPELINE_START
    assert step.napari_streaming_config.enabled is True
    assert step.napari_streaming_config.persistent is True
    assert step.napari_streaming_config.port == 5999

    kwargs = step.func[1]
    assert kwargs["neurite_channel_index"] == 0
    assert kwargs["cell_body"] == MetaXpressCellBodySettings(
        approximate_max_width=36.0,
        minimum_area=45.0,
        intensity_above_local_background=20.0,
        channel_index=0,
    )
    assert kwargs["outgrowth"] == MetaXpressOutgrowthSettings(
        maximum_width=5.0,
        intensity_above_local_background=8.0,
        minimum_cell_growth_to_log_as_significant=8.0,
        candidate_threshold_correction_factor=0.22,
        candidate_hysteresis_seed_correction_factor=0.25,
    )
    assert kwargs["use_nuclear_stain"] is True
    assert kwargs["nuclear_stain"] == MetaXpressNuclearSettings(
        channel_index=1,
        approx_min_width=5.0,
        approx_max_width=32.0,
        intensity_above_local_background=24.0,
    )
    artifact_outputs = CallableContract.from_callable(
        neurite_outgrowth_metaxpress
    ).artifact_outputs
    assert artifact_outputs.names() == (
        "neurite_outgrowth_summary",
        "neurite_outgrowth_cells",
        "cell_bodies",
        "neurite_outgrowth",
        "neurons",
        "nuclei",
        "neurite_candidate_mask",
        "neurite_unrooted_residual",
        "neurite_secondary_ownership",
        "neurite_topology_dropped_trace",
        "neurite_topology_added_trace",
        "neurite_morphology",
    )
    assert {spec.name: spec.viewer_streaming for spec in artifact_outputs} == {
        "neurite_outgrowth_summary": ArtifactViewerStreaming.AUTOMATIC,
        "neurite_outgrowth_cells": ArtifactViewerStreaming.AUTOMATIC,
        "cell_bodies": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_outgrowth": ArtifactViewerStreaming.ON_DEMAND,
        "neurons": ArtifactViewerStreaming.AUTOMATIC,
        "nuclei": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_candidate_mask": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_unrooted_residual": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_secondary_ownership": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_topology_dropped_trace": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_topology_added_trace": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_morphology": ArtifactViewerStreaming.AUTOMATIC,
    }


def test_neuroncyto_demo_compiles_exact_loose_tiff_pair(tmp_path: Path) -> None:
    plate_path = tmp_path / "CrossOvers_Images"
    plate_path.mkdir()
    inputs = _inputs(plate_path, tmp_path / "output")
    tifffile.imwrite(plate_path / inputs.neurite_filename, np.ones((32, 32), np.uint8))
    tifffile.imwrite(
        plate_path / inputs.soma_nuclei_filename,
        np.ones((32, 32), np.uint8),
    )

    pipeline_config, steps = build_neuroncyto_ii_crossover_demo(inputs)
    ObjectStateRegistry.clear()
    set_progress_queue(SimpleQueue())
    try:
        ensure_global_config_context(
            GlobalPipelineConfig,
            GlobalPipelineConfig(num_workers=1),
        )
        orchestrator = PipelineOrchestrator(
            plate_path,
            pipeline_config=pipeline_config,
        ).initialize()
        compilation = orchestrator.compile_pipelines(
            pipeline_definition=steps,
            well_filter=[inputs.image_id],
            is_zmq_execution=True,
        )
    finally:
        set_progress_queue(None)

    context = compilation.runtime_contexts[inputs.image_id]
    plan = context.step_plans[0]
    assert plan.step_name == "NeuronCyto II Crossover Neurite Outgrowth"
    assert tuple(plan.variable_components) == (VariableComponents.CHANNEL,)
    assert plan.compiled_function_pattern is not None
    assert {
        output.name: output.viewer_streaming
        for output in plan.artifact_outputs.values()
    } == {
        "neurite_outgrowth_summary": ArtifactViewerStreaming.AUTOMATIC,
        "neurite_outgrowth_cells": ArtifactViewerStreaming.AUTOMATIC,
        "cell_bodies": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_outgrowth": ArtifactViewerStreaming.ON_DEMAND,
        "neurons": ArtifactViewerStreaming.AUTOMATIC,
        "nuclei": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_candidate_mask": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_unrooted_residual": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_secondary_ownership": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_topology_dropped_trace": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_topology_added_trace": ArtifactViewerStreaming.ON_DEMAND,
        "neurite_morphology": ArtifactViewerStreaming.AUTOMATIC,
    }


def test_neuroncyto_demo_executes_numeric_biological_well_identity(
    tmp_path: Path,
) -> None:
    plate_path = tmp_path / "CrossOvers_Images"
    plate_path.mkdir()
    inputs = NeuronCytoIICrossoverInputs(
        plate_path=plate_path,
        output_root=tmp_path / "output",
        image_id="1",
        neurite_filename="1_w1.tif",
        soma_nuclei_filename="1_w2.tif",
        viewer_port=5999,
    )
    tifffile.imwrite(
        plate_path / inputs.neurite_filename,
        np.ones((32, 32), np.uint16),
    )
    tifffile.imwrite(
        plate_path / inputs.soma_nuclei_filename,
        np.ones((32, 32), np.uint16),
    )

    pipeline_config, steps = build_neuroncyto_ii_crossover_demo(inputs)
    execution_step = copy(steps[0])
    execution_step.napari_streaming_config = LazyNapariStreamingConfig(enabled=False)
    steps = [execution_step]
    ObjectStateRegistry.clear()
    progress_queue = SimpleQueue()
    set_progress_queue(progress_queue)
    try:
        ensure_global_config_context(
            GlobalPipelineConfig,
            GlobalPipelineConfig(num_workers=1, use_threading=True),
        )
        orchestrator = PipelineOrchestrator(
            plate_path,
            pipeline_config=pipeline_config,
        ).initialize()
        compilation = orchestrator.compile_pipelines(
            pipeline_definition=steps,
            well_filter=[inputs.image_id],
            enable_visualizer_override=False,
        )
        results = orchestrator.execute_compiled_plate(
            execution_bundle=compilation,
            max_workers=1,
            progress_queue=progress_queue,
            progress_context={
                "execution_id": f"test::{time.time_ns()}",
                "plate_id": str(plate_path),
                "axis_id": "",
            },
        )
    finally:
        set_progress_queue(None)

    assert results[inputs.image_id].is_success(), results[inputs.image_id].error_message


def test_neuroncyto_declared_identity_replaces_loose_tiff_store_coordinates(
    tmp_path: Path,
) -> None:
    plate_path = tmp_path / "CrossOvers_Images"
    plate_path.mkdir()
    inputs = _inputs(plate_path, tmp_path / "output")
    tifffile.imwrite(plate_path / inputs.neurite_filename, np.ones((8, 8), np.uint8))
    tifffile.imwrite(
        plate_path / inputs.soma_nuclei_filename,
        np.ones((8, 8), np.uint8),
    )
    pipeline_config, _steps = build_neuroncyto_ii_crossover_demo(inputs)
    ensure_storage_registry()
    filemanager = FileManager(dict(storage_registry))
    handler = BioFormatsHandler.create(
        filemanager=filemanager,
        source_bindings_config=source_bindings_defaults_to_base(
            pipeline_config.source_bindings_config
        ),
    )

    handler.initialize_workspace(plate_path, filemanager)

    projection = VirtualWorkspaceSourceProjectionAuthority.from_plate_metadata(
        plate_path=plate_path,
        metadata_handler=handler.metadata_handler,
        filemanager=filemanager,
    ).projection_if_available()
    assert projection is not None
    source_projections = tuple(projection.source_projections_by_virtual_path.values())
    assert {
        source_projection.address.value_for(AllComponents.WELL)
        for source_projection in source_projections
    } == {inputs.image_id}
    assert {
        source_projection.address.value_for(AllComponents.CHANNEL)
        for source_projection in source_projections
    } == {"1", "2"}
    assert {
        source_projection.ref.backend_address
        for source_projection in source_projections
    } == {inputs.neurite_filename, inputs.soma_nuclei_filename}


def test_neuroncyto_demo_contributor_prepares_only_declared_pair(
    tmp_path: Path,
    monkeypatch,
) -> None:
    source_root = tmp_path / "source"
    source_root.mkdir()
    for filename in ("15_w1.tif", "15_w2.tif"):
        tifffile.imwrite(source_root / filename, np.ones((8, 8), np.uint8))
    archive_path = tmp_path / "Testing image.zip"
    with zipfile.ZipFile(archive_path, "w") as archive:
        for filename in ("15_w1.tif", "15_w2.tif"):
            archive.write(
                source_root / filename,
                f"Testing image/CrossOvers_Images/{filename}",
            )
        archive.writestr("Testing image/CrossOvers_Images/35_w1.tif", b"unused")
    monkeypatch.setenv("OPENHCS_NEURONCYTO_II_TEST_ARCHIVE", str(archive_path))

    contribution = neuroncyto_ii_crossover_demo_contribution(
        session_root=tmp_path / "session"
    )
    assert isinstance(contribution, PipelineDemoContribution)
    assert contribution.demo_id == "neuroncyto_ii_crossover_neurite_outgrowth"
    assert contribution.title == "NeuronCyto II crossover neurite morphology"
    assert contribution.plate_path.name == (
        "NeuronCyto II crossover neurite morphology"
    )
    assert len(contribution.pipeline_steps) == 2
    contrast_step, analysis_step = contribution.pipeline_steps
    assert get_core_callable(contrast_step.func) is percentile_normalize_plane
    assert contrast_step.processing_config.input_source is InputSource.PIPELINE_START
    assert get_core_callable(analysis_step.func) is neurite_outgrowth_metaxpress
    assert analysis_step.processing_config.input_source is InputSource.PREVIOUS_STEP
    assert contribution.presentation_identity.output_key == "neurite_morphology"
    assert contribution.presentation_identity.artifact_kind == "spatial_graph"
    assert contribution.presentation_identity.step_name == analysis_step.name
    assert len(contribution.supporting_presentation_identities) == 1
    supporting = contribution.supporting_presentation_identities[0]
    assert supporting.output_kind == "main"
    assert supporting.output_key == "main"
    assert supporting.step_name == contrast_step.name
    contrast_callable, contrast_kwargs = contrast_step.func
    assert contrast_callable.__name__ == "percentile_normalize_plane"
    assert contrast_kwargs == {
        "plane_index": 0,
        "low_percentile": 1.0,
        "high_percentile": 99.8,
        "target_max": 255.0,
    }
    assert contribution.prepare is not None

    contribution.prepare()

    assert sorted(path.name for path in contribution.plate_path.iterdir()) == [
        "15_w1.tif",
        "15_w2.tif",
    ]

    ObjectStateRegistry.clear()
    set_progress_queue(SimpleQueue())
    try:
        ensure_global_config_context(
            GlobalPipelineConfig,
            GlobalPipelineConfig(num_workers=1),
        )
        orchestrator = PipelineOrchestrator(
            contribution.plate_path,
            pipeline_config=contribution.pipeline_config,
        ).initialize()
        compilation = orchestrator.compile_pipelines(
            pipeline_definition=list(contribution.pipeline_steps),
            well_filter=["Image15"],
            is_zmq_execution=True,
        )
    finally:
        set_progress_queue(None)

    context = compilation.runtime_contexts["Image15"]
    assert [
        context.step_plans[index].step_name for index in range(len(context.step_plans))
    ] == [
        "Percentile-normalized neurite signal",
        "NeuronCyto II Crossover Neurite Outgrowth",
    ]


def test_neuroncyto_percentile_normalization_changes_only_declared_plane() -> None:
    image = np.array(
        [
            [[0, 16], [64, 255]],
            [[0, 16], [64, 255]],
        ],
        dtype=np.uint8,
    )

    enhanced = percentile_normalize_plane(
        image,
        plane_index=0,
        low_percentile=25.0,
        high_percentile=75.0,
        target_max=255.0,
    )

    assert enhanced.dtype == image.dtype
    assert np.array_equal(enhanced[1], image[1])
    assert not np.array_equal(enhanced[0], image[0])
