519 bounded source qualification commands and dispositions
=========================================================

Owned persistent branch investigate/selective-viewer-route-retirement-519-20261003
at /home/ts/wt/openhcs-ui-workflow-rendering-20261001. Production6c49bedd8;
basef7de9efad393bce83a3756a271f0cd4383783ea9. Foreign gitlinks/untracked503
ledgers not edited, installed environments/packages untouched. No scientific
data, native server, MCP process, viewer/author contact or runtime operation.

Each serial command uses systemd-run --user --wait --pipe --collect with unique
singer519 unit name, WorkingDirectory above, MemoryMax=536870912,
MemorySwapMax=0, CPUQuota=100%, AllowedCPUs=3, RuntimeMaxSec=60, TasksMax=48
(32 for original R0/AST), then /usr/bin/time elapsed/maxrss/exit. Output is
the named original stdout/stderr file; failures are never overwritten.

Pytest uses original existing paired3.12 interpreter
/home/ts/wt/basicpy-live-candidate-20260930/.venv/bin/python -B, source PYTHONPATH
equal this WT, PYTEST_DISABLE_PLUGIN_AUTOLOAD=1, QT_QPA_PLATFORM=offscreen,
NUMBA_DISABLE_JIT=1, OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1, MKL_NUM_THREADS=1.
validation/viewer-retirement-519/run_source_controls.py imports OpenHCS before
its original source dependency consumers and borrows existing clean paired
Qt checkout read-only. It invokes original pytest with --noconftest
--import-mode=importlib -p no:cacheprovider -o addopts= -q. No mocked product
canvas replaces the original fixture; retirement uses real ViewerModel/Qt
queue with overridden socket boundary, not an installed/native scene.

Final owner-controls10 arguments:

* tests/unit/test_napari_reset_transitions.py
* tests/unit/test_viewer_retirement_contract.py
* tests/unit/test_napari_streaming_handlers.py::test_napari_component_display_coordinator_purges_deleted_route_domain
* tests/unit/test_napari_streaming_handlers.py::test_napari_viewer_clear_state_resets_accumulated_axis_domains
* tests/unit/test_napari_streaming_handlers.py::test_clear_state_preserves_mounted_payload_and_domains_until_native_removal
* tests/unit/test_napari_streaming_handlers.py::test_napari_shutdown_cancels_pending_updates_before_scheduling_viewer_close

33PASS/terminal0/12.31s/maxRSS507976KiB/cgroup309006336B/Swap0/noOOM.
Earlier qt-controls06 has18PASS, contract-controls01 has6PASS; latest26
retirement+contract and7 original lifecycle controls supersede those source
strengths without overwriting originals. owner-controls09 has24PASS before
two geometry-family cases were added. owner-controls07 preserves collection
dataclass order failure; owner-controls08 preserves slotted-super3failures
and original mixedQt Vispy refusal (25PASS/4FAIL). snapshot-controls01 preserves
isolated hiddenVispy setup exit1 after three completed controls, no traceback.
No source/binding override or weakened snapshot assertion. Native receiving
remains required. Other original failure logs retain their original output.

Final original R0 command, using existing3.14 -I -B:

  validation/run_pinned_r0_419.py --root openhcs
  --base f7de9efad393bce83a3756a271f0cd4383783ea9 --head 6c49bedd8

The existing caller imports original detector modules from agent-comms Git
3b03785f45df2ef5dc62ba6aed99294192ecbb01, not copied/modified detector files.
pinned-r0-05 PASS29.51s/86936KiB/Swap0 includes all9 changed production files
and positive delta mapping empty. Earlier02RED/03PASS/01importfailure/04CLI
failure remain original; no omission/threshold waiver. Deferred-annotation
original detector source requires3.14; no namespace shim is injected.

Final AST commands use same existing3.14 -I -B:

  validation/viewer-retirement-519/source_family.py
  validation/viewer-retirement-519/source_family.py --dependency-details

Caller uses original refactor-audit ParsedModule/FunctionFacts/Repository at
/home/ts/code/projects/nominal-refactor-advisor/skills/refactor-audit/scripts.
source-family03 retains full704/669/258 parsed inventory, selected related
projections; dependency-details02 retains full258-module declarations/imports/
checks/constructor sites. Zero parse errors; no global detector completeness
or executed native proof claimed. The unchanged245 Qt/Vispy scene projections
and original census are in the historical source archive, not regenerated.

All units observed terminal, no interrupted/UNKNOWN source qualification call,
no running worker handle retained. Original native/scientific UNKNOWN journals
and other agents' saved viewers remain outside scope and untouched.
