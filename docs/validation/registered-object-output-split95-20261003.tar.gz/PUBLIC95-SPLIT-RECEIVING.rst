50395 independent public default/removed receiving documents
============================================================

Parent owns sole original PTY83658/native6014 process2355303, already READY/
catalog READY and existing config-1. No startup/health/catalog/config replay,
second client, installed patch, SCI input/contact or changed frozen packet.
Original5-module artifact-plan failed before session/compile/execute; original
pipeline.py/labels503.cppipe/hash and full mcp.stdout remain unchanged/preserved.
Concrete independent conflict #516 is filed and sent to Root394 shared owner:
https://github.com/OpenHCSDev/openhcs/issues/516
https://github.com/OpenHCSDev/openhcs/pull/394#issuecomment-5965875069

New files, all under the SAME existing writable output root:
engineering503/LABELS503_95/author-workspace/output.

* labels503-default01.cppipe + pipeline-default01.py:
  complete original importer/NamesAndTypes/ConvertImageToObjects/Shape/
  FilterObjects default document; output results-default01.
* labels503-removed01.cppipe + pipeline-removed01.py:
  complete original importer/NamesAndTypes/ConvertImageToObjects/Shape/
  FilterObjects removed-enabled document; output results-removed01.

Both use exact original same12x15uint16 input2/7, preserve labels, normal
PipelineDocument pipeline_steps/pipeline_config, source bindings1um/Z axis,
single channel, streaming disabled. No manual artifact/lineage binding, new
function/algorithm/export/sampler, compatibility facade or validator override.
Repeated config declarations are independently authored complete documents,
not two copies of a shared product procedure. No import/compile/test/runtime
was performed by Singer; parent actual public acceptance follows.

Next original retained-shell commands (NOT a new client)
-------------------------------------------------------

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-default01.py --global-config-id config-1 --json

On actual successful plan, use the already recorded public source-session/
compile/execute/observe owner with this exact source file and a NEW session/job
handle. New exclusive VALUES export runtime-values-default01.json. Do not replay
the original failed full document or invent a session/compile artifact ID.

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-removed01.py --global-config-id config-1 --json

On actual successful plan, independently use exact second source and NEW session/
compile/execute handles; VALUES runtime-values-removed01.json. Parent performs
the required original fresh all4 heavy-action admission; no extra owner here.
Results/default/removed paths and VALUES receipt paths remain distinct. Every
pending/failed/UNKNOWN original operation stays on its original handle.

Unchanged strict joins, declaration-derived module numbering
-----------------------------------------------------------

Each source/Objects mask: label2 rows0:2/cols2:5, area6; label7 rows6:10/cols8:13,
area20, background0. Shape native categorical key object_label (LABEL_ID),
AreaShape_Area6 for ID2,20 for ID7. Existing absent declared-domain rows follow
their original missing-value rules, never row-ordinal or count shortcuts.
Both kept1 masks occupy source7's exact20 pixels; removed1 occupies source2's
exact6 pixels. Complement and retained target1 are independent object domains.

Each independent CPPipe places its only filter at original module_num4.
Original ObjectRelationshipDeclaration.artifact_name derives these identities:

* default: module_4_parent_child_Objects_RetainedDefault_relationships,
  source_object Objects, target_object RetainedDefault, parent_id7/child_id1.
* removed-enabled kept: module_4_parent_child_Objects_RetainedEnabled_relationships,
  source_object Objects, target_object RetainedEnabled, parent_id7/child_id1.
* removed-enabled complement: module_4_parent_child_Objects_RemovedEnabled_relationships,
  source_object Objects, target_object RemovedEnabled, parent_id2/child_id1.

For each: relationship_type parent_child, source_role parent/target_role child,
producer_module_number4. Raw directed payload source_ids(7,)/target_ids(1,) or
source_ids(2,)/target_ids(1,), respectively. No removed artifact in default.
Enabled exact6-return/default exact4-return ABI/matcher remain required.
Only declared module ordinal changes from retained original5-module control;
no identity/area/lineage assertion is dropped. These are artifact identities,
not guessed filenames; obtain actual paths and VALUES shape from public reply.

Original frozen packet still hashes exactly. New source file SHA256:
default CPPipe e7696b2059cc3c2f2a716290cf276ebe26eebb263d7026965bb273485e65252f
removed CPPipe 84e20af15b5fda38e95834fecaeaa920bb1366382110616decd32a88f1e0b77f
default document a382fb3fdff82f4a066f15c01719ae4c7432b9abed5ed154ed788c5a988b55b2
removed document 3246b76965606ae3fdc9d4a095907bc143349d14cdda12bdca845896ce509b9e

Production/source/wheel/target02 remain unchanged. This is a parent-authorized
independent public qualification design, not a fix or closure of #516. Root
retains its original shared reconstruction/context/lineage family repair.
