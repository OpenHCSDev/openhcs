CellProfiler repeated FilterObjects conflicts with named object lineage
======================================================================

Actual ordinary installed PUBLIC MCP reproducer, independent tiny engineering
data only. Whole qualified503 target02 at sourcec0314a171 / productf9a15dcbd;
public native6014 READY/catalog READY, config-1 created. Original artifact-plan
of the retained complete pipeline.py rejects before source session/compile/
execution, with source Objects versus prior canonical RetainedDefault for
RetainedEnabled. No timeout, scientific pixels, session or job replay.

Original complete five-module CPPipe:
NamesAndTypes Labels; ConvertImageToObjects -> Objects (preserve labels);
MeasureObjectSizeShape Objects; FilterObjects Objects -> RetainedDefault,
removed default-off; FilterObjects Objects -> RetainedEnabled, removed-enabled
RemovedEnabled. Both filters explicitly select Objects. Source is12x15uint16
with border label2 area6 and interior label7 area20.

Original public error code pipeline_source_invalid_document:
FilterObjectsModule has conflicting dynamic artifact declarations for
occurrence1 of output object labels RetainedEnabled. One exact spec carries
SourceStackLineageSourceRelation(Objects); the other carries
SourceStackLineageSourceRelation(RetainedDefault).

Original frozen bytes and full reply remain in
engineering503/LABELS503_95/author-workspace/output/pipeline.py,
labels503.cppipe, runtime/mcp.stdout. Determining error currently line998.
The original5-module input and parent hash/freeze are NOT replaced.

Named shared integration owner: Root, existing PR394. Singer owns503 receiving
RCA/evidence and narrow released shape/optional return, NOT a competing patch
to CellProfiler reconstruction/contract/artifact/main-flow shared owners.
Current Root8e06a382e2d4b6d9d9b8ceb93c229717c328d538 and main236644e43b6c:
module_declarations.py, module_artifact_contracts.py,
module_artifact_declarations.py and pipeline_import.py byte-equal qualified
c031 at this checkpoint; optional-return leaf differs because503 is unmerged.
No existing issue with this concrete conflict was found in open/all search;
#495 (merged producer address queries) and #502 (return ABI) are distinct.

Source seam: CellProfilerModule.invocation_callable_contract reconstructs
numbered blocks and combines their exact metadata via combine_callable_contracts
(strictly rejects conflicting occurrences). Explicit FilterObjects plan emits
the output lineage from its named Objects input. Generic output relations and
reconstructed canonical main flow can provide RetainedDefault to the same
output identity. Root must resolve named object input versus primary main-flow
carrier at the existing declaration/context owner; do NOT weaken spec equality,
rename source lineage after the fact, fabricate source bindings, add a roster,
consumer FilterObjects switch or wrapper/compatibility contract.

Required source acceptance: original full CPPipe -> import -> normal complete
PipelineDocument artifact-plan/compile succeeds, both filters' declared input
remains original Objects; emitted directed relationships source Objects,
targets RetainedDefault/RetainedEnabled/RemovedEnabled. Preserve strict dynamic
declaration and ABI checks; genuine sequential RetainedDefault-input control
must instead derive RetainedDefault. New nominal leaf/hook control must need
no generic-consumer edits. Installed public original five-module receipt is
the final gate, separate from focused source controls/AST evidence.

Parent authorizes503 live acceptance with two independent complete ordinary
pipelines, one default and one removed-enabled, both same exact tiny source2/7.
This separates this unrelated cross-step conflict without changing501's pixel/
table/area/lineage checks. Parent owns sole live client83658/native6014 and
all public calls; Singer only prepares new distinct files/result paths after
publishing this issue. No installed source patch or scientific author contact.
