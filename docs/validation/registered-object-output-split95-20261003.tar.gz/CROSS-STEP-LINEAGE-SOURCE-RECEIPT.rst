516 named-object lineage versus reconstructed main flow
=======================================================

Actual public negative is retained in parent's original83658 mcp.stdout,
line998: identical RetainedEnabled output identity carries Objects versus
RetainedDefault SourceStackLineageSourceRelation. Before session/compile/
execute, not timed out. Original full5-module packet and SHA freeze unchanged.
Issue516 and Root394 integration comment5965875069 preceded new split files.
Root owns shared reconstruction/contract/context/artifact lineage; Singer
prepares source evidence and independent503 receiving documents only.

Pinned source family and actual owners
-------------------------------------

Qualifiedc0314a17163260b1b05071e0d405ee386fa6a2e0, currentmain
236644e43b6c88e56cbab0397668a9d4f3751233, Root394
8e06a382e2d4b6d9d9b8ceb93c229717c328d538.
All three shared module_declarations/module_artifact_contracts/
module_artifact_declarations/pipeline_import bodies byte-equal. Main and Root
lack503's optional-return union, but that is NOT this lineage disagreement.
Open/all issue searches distinguished merged495 address projection and502
return ABI; no prior concrete repeated-FilterObjects declaration conflict.

CellProfilerModule.combine_callable_contracts joins exact artifact occurrences
and correctly rejects unequal specs; weakening it would conceal the defect.
CellProfilerModule.invocation_callable_contract derives contracts from original
numbered reconstructed blocks, then calls that same combiner. The public importer
constructs its parsed target graph, projects the ordinary invocation chain and
reconstructs public blocks against advancing ArtifactDeclarationStepContext.
Named FilterObjects Plan.output_artifact_specs resolves output lineage from
its exact named source. Generic reconstruction input-row projection searches
scoped producer/main-flow inputs through _available_artifact_input_specs and
_artifact_input_record_groups_for_bindings. Advance_artifact_context publishes
the last canonical object flow while retaining earlier artifact producers.
These are different legitimate facts: original named input Objects and current
main-flow carrier RetainedDefault. The observed conflicting reconstructed
occurrences show they are not being kept distinct at the receiving boundary.
Source identifies the shared seam; it does not assert a fully executed internal
call path or choose a patch to Root's owner without its disposition.

Full-family AST evidence (not a product execution proof)
------------------------------------------------------

Existing validation/labels503_source_family.py orchestration and original
refactor-audit Repository/ParsedModule/FunctionFacts were reused. In-memory
projection changes only revision/context and related symbol selection, leaves
the original script/source untouched. All704 production Python per revision
parsed, not only grep hits; selected111/111/112 related modules respectively,
plus ALL6 existing metaclass_registry dependency Python files per source.
Declarations/bases/args/decorators/imports/load/store/calls and original function
facts retained; zero parse omissions. Dynamic qualified callees are not proved
from syntax; no product import, detector/R0/R1/behavioral pass claim.
Relevant names include CellProfilerModule, FilterObjectsModule, source-stack
lineage, ArtifactDeclarationStepContext/main_flow_artifacts, reconstructed input
bindings, primary-image policy, output spec construction and contract combination.

Original first source attempt failed before parsing because systemd's cwd was
not inherited: FileNotFoundError validation/labels503_source_family.py. Its raw
stdout/stderr unchanged. Corrected explicit existing WT WorkingDirectory,
new unique source observation02, one serial three-revision pass terminal0:
50.548s wall/36.726sCPU/45.4M peak/Swap0, oneCPU,512MiB/60s guard unchanged.
Raw02 stdout7533692bytes SHA256
6f2a74f1e1e06fb782d8b276af3513bc85e7b41ba9ba5b3dae9820de09d7cf4b;
stderr5aa1c047b87ff7e57eff379a74dcda1e7125fc3e4363b12d68c7f94283d56801.
First stderr87baa3ec6d9b507e68f8a683a1928fe6658d8d3f93822927d6f4dee0961c61e9.
Initial Git fetch recursively attempted two unavailable dependency refs; its
known failure was not a source change/install. Exact nonrecursive refs fetched
without checkout/submodule/env mutation. No audit bound raised or omission hidden.

Latest NRA and authoritative refactor-audit.skill SKILL/catalog reread:
IDEN-1 (named object source versus current main-flow identity), BOUND-2 (consume
the existing contract/source declaration), IMPL-5 (derive relation once instead
of parallel reconstructed decisions). These are review lenses, not an automated
finding count. Required Root fix belongs on original behavior-owning ancestor/
nominal binding hooks and its real cooperative MRO, no FilterObjects consumer
switch, copied importer, mirrored registry or compatibility facade.

Independent receiving documents and acceptance
----------------------------------------------

PUBLIC95-SPLIT-RECEIVING.rst gives parent original retained-shell commands,
all4 new file hashes, distinct results/VALUES paths and exact declared joins.
Default/removed-enabled are independent COMPLETE PipelineDocuments imported
by original CellProfiler owner; no manual bindings or copied algorithm. Native
module4 in each is the sole filter, so relationship producer_module_number4
in both. Objects2/7 -> AreaShape_Area6/20, kept7->1, removed2->complement1,
exact label masks, typed identities, strict4/6 ABI and directed endpoints remain.
Original full-five #516 control remains RED/frozen, not silently replaced.
Root's broader unbounded502 extension and516 are not gates on accepted501.

New files only at own existing output/results paths; AST syntax checked without
OpenHCS imports. Parent alone owns live83658/native6014 and every actual call.
No source/wheel/target/control-suite change, new WT/env/build/install/provider,
scientific input/read/control/hint, second client or native/helper mutation.
