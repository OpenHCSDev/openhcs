Actual public sparse-label and optional removed-output acceptance
===============================================================

Original sole parent PTY83658 and original qualified target02/native6014.
No alternative client, algorithm, installed patch, label remap or input change.
Health refreshed: PID2349805 target02/server.py current, packaged resources86
ready, no source drift. Original preparation and all01/02/03 failures retained.

04 complete documents use original CPPipe importer and existing typed source
binding declarations: primary Labels plus categorical Objects from the same
unchanged scalar12x15 TIFF; explicit SOURCE_BINDINGS, metadata matching and
physical source_stack_components=(). Processing Z/channel grouping retained.
This fixes authored acquisition selection/axis declarations, not a relaxed
validator. The earlier five-module lineage conflict516 remains separate.

Both public artifact plans succeeded with one A01 axis/two source roles/two
lowered steps and no errors. Producer identity derives module2 in this plan,
not the historical module4/5 CPPipe ordinal. New session3 compilejob3
8faad1c4-df98-4545-a835-5918e19b8fad and executejob4
82d3bd52-7fcd-4e91-96fd-56496bcd714a actually COMPLETE. New session4 compilejob5
4813e152-7020-47bf-9e77-38edc0a722d0 and executejob6
6e2d108f-51ce-4f0b-9df1-b5b7a731da3c actually COMPLETE. Exact public status
confirmed100percent progress/no execution error. Every compile/execute preceded
a unique passing original current-programme resource observation.

Public MCP full native12x15 persisted-label samples show RetainedDefault and
RetainedEnabled target1 exactly at y6:10,x8:13,20pixels; RemovedEnabled target1
exactly at y0:2,x2:5,6pixels. All other pixels zero, int32, no downsampling.
These are actual complete masks, not equal-count acceptance or private image
decoding. Default emits no removed object artifact.

The ordinary server-produced VALUES exports were read through the SAME
installed ZMQRuntimeExecutionObservationExport.read and require_valid_observation
owners, not a JSON/manual-pickle parser. Readonly512MiB/Swap0/oneCPU45s scopes
both terminated0. The full categorical shape rows have object_label2/Area6
and object_label7/Area20 in BOTH ordinary executions. Exact runtime label
arrays equal the expected full masks; no feature-row ordinal substitution.

Original ObjectRelationship.relationship_columns and raw payloads agree:
Objects(parent7) -> RetainedDefault(child1),
Objects(parent7) -> RetainedEnabled(child1),
Objects(parent2) -> RemovedEnabled(child1).
Each uses parent_child/source_role parent/target_role child, producer_module2,
source_ids7/2 and target_ids1, slice0/count1, separate named child domains.
Default has exactly4 canonical records; enabled has exactly6. No unbounded
additional-group502 assertion is made. This accepts the delivered shape-row
501 and optional-removed portion of502 at actual public/native strength.

Exact evidence SHA256
--------------------

default04-values.json4bfc28b2b17b8e1fef0be2f08b2c1e47773534eff1d0804fa600a2a4f558c0ec
removed04-values.json9ba434762fd5775f817f3cdccb365eaefffc8715c1953931108e3080b8cc4ca3
default04 Python cf15ecf7875d3940effd06676963b6ba3c52fe98a9e5523a873d64b283cce5a7
removed04 Python bf3e94150c4417a0993ff48b1b5a84565f4b8bc6abfeee7b4df89340677893bb
default04 CPPipe7bde88397b53638422c6ba6debe2f408ba95caa36d71c07b4c362663b2f37628
removed04 CPPipe7e2dab65974b915e876becfb83396c9244633ba452b38bb86dea5e7b1a433bfd
Both retained TIFFs0727265bd0ec4947538e838c4a06ab124f32d2f15498db90a0ce9123a3aa7750
Removed TIFFe2abb31e1f0231bd7283874da20bc0d0746d4b2b460003d4822d3135ced9e541

Native owned closure
--------------------

Original bootstrap handle native2355303/create1791003919.41 retained. Exactly
one public close_owned_runtime call returned acknowledged/endpoint_terminated/
process_exited/succeededtrue, no errors. Independent OS PID absence and all
four6014/6015/7014/7015 listener absence verified. No engineering viewer ever
started. Parent sent exit once to original client83658; client termination and
complete final journal hashes require separate actual terminal observation,
not inferred from native closure. Original inherited95 helpers untouched.
