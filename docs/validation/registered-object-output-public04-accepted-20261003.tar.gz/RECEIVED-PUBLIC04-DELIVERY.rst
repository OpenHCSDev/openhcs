503 final delivered checkpoint: public categorical/optional-output joins PASS
===========================================================================

Parent accepted the original installed public04 journey on qualified whole
target02/sourcec0314a17163260b1b05071e0d405ee386fa6a2e0. No product, installed
or raw input patch was required during receiving. Parent source report received
in full: PARENT-PUBLIC04-ACCEPTANCE.rst, SHA256
bf6a494855c74b0888d229e5e769062311def177fe868fa58bd35d54e219a22a.
Its final-client-status sentence is the earlier custody snapshot, superseded
by the actual original terminal journal below; the report is archived unchanged.

Actual accepted workflow
------------------------

One original parent PTY83658/native6014 child2355303, qualified whole package,
normal source/document/import/artifact-plan/session/compile/execute/inventory/
sample path. Both04 plans succeeded with A01/two source roles/two lowered steps.
Original NamesAndTypes declares primary Labels and categorical Objects from the
same unchanged scalar12x15 TIFF; explicit SOURCE_BINDINGS, declared Metadata
match, source_stack_components=(), processing Z/channel grouping retained.

session3: compile job3 /8faad1c4-df98-4545-a835-5918e19b8fad COMPLETE;
execute job4 /82d3bd52-7fcd-4e91-96fd-56496bcd714a COMPLETE.
session4: compile job5 /4813e152-7020-47bf-9e77-38edc0a722d0 COMPLETE;
execute job6 /6e2d108f-51ce-4f0b-9df1-b5b7a731da3c COMPLETE.
All heavy actions used original admission/current programme, no extra client.

Public full12x15 int32 persisted-label samples: default and enabled retained
target1 occupy exactly source7's20 pixels at y6:10/x8:13; removed target1 exactly
source2's6 pixels at y0:2/x2:5. All other pixels0; no downsampling/private decoder.
Parent read canonical VALUES through installed ZMQRuntimeExecutionObservationExport
and require_valid_observation: both readonly512MiB/Swap0/CPU1/45s scopes terminal0.
Exact A01 categorical shape object_label2/Area6 and7/Area20 in BOTH executions,
full runtime label masks equal expected. Four default/six enabled canonical
records; no default removed artifact. Count equality is not this acceptance.

Original ObjectRelationship.relationship_columns and raw source_ids/target_ids
agree: Objects parent7 -> RetainedDefault child1, parent7 -> RetainedEnabled
child1, parent2 -> RemovedEnabled child1. Each parent_child/source_role parent/
target_role child, actual public producer module2, slice0/count1, distinct named
child domains. Historical external/module3/4/5 numbering guesses are superseded
by the actual returned declaration, not relabelled after export.

This accepts501 and the default/optional-removed portion of502 at actual installed
public/native strength. Root's unbounded additional-object ABI and full-five
named-input conflict516 remain separate, not silently fixed by the split trials.

Original receiving failures preserved
------------------------------------

Full-five artifact-plan: named Objects versus canonical RetainedDefault output
lineage conflict516 before session/compile/execution.
Default01: technically COMPLETE but source2/7 converted to ALLZERO before Shape;
Grayscale image-intensity normalisation followed by preserve-label integer cast.
Removed01: session2 only; never compiled/executed after this known source error.
Default02: Objects-only/source selection scope failure, axes0/steps0, no session.
Default03: SOURCE_BINDINGS selected correctly but scalar12x15 file rejected
against incorrectly declared physical leading Z axis, no session.
04 corrected the authored categorical source/selection/physical-axis declarations
through existing owners, without raw remapping/reshaping, fake groups or relaxed
validators.01/02/03 source files/errors and all earlier archives remain original.
Actual04 PASS is not proof that artifact-only sources universally need a carrier
or that #521's initial resolver-defect hypothesis was demonstrated.

Current-main product-byte proof, not another test run
---------------------------------------------------

Latest normally fetched main e3dba241597ab6c584b8380e31edc015b258d3f0 is merged520.
From previously reviewed main236644e43b6c only canonical viewer-qa.md changed;
BOTH503 product leaves have zero intervening main change. Current-main-to503
scoped patch remains object_filtering9+/1- and shape9+/50-, the same accepted
18+/51- product change. No main merge/source editing by Singer at this checkpoint.

Qualifiedc031 and current delivery HEAD Git blobs are equal:
shape46a797c83dc04da94870dadd767c84498c263351,
object_filteringd6e964e103f7e2b5f3b7db092850e809d2cb86c9.
Source/installed target SHA256 also equal:
shape1ecd193454bf62479cd13fee34245b85bf83e846f5a39f8057037ade10065896,
object_filteringd80fab4019854fe51c9360c04f0256f42ff26486ce00814bbf7cd267a00aebd6.
git diff c031 HEAD -- openhcs tests is empty. Whole target retains its accepted
pin, not a claim it includes later514 readiness/520 guide bytes. No rebuild/
retest/R0 replay/dependency install or Root source mutation.

Existing ObjectFeatureValueTable.rows owns categorical measured-ID lookup; shape
leaf keeps vocabulary/missing hooks with cooperative super and original typed
dense label domain. Positional zipper/padded radius copies were deleted; genuine
ordinal owners retained. Previously accepted independent cooperative declaration/
hook controls and21 installed tests remain evidence, not rerun. Public04 confirms
the same source-ID/table/lineage relation end-to-end. Optional-return union stays
at its callable declaration; strict shared ABI validators/matcher unchanged.

Terminal custody and byte-exact evidence
---------------------------------------

Original public native close acknowledged, endpoint_terminated/process_exited/
succeededtrue; exact2355303/create1791003919.41. Parent verified PID and
6014/6015/7014/7015 listeners absent. No engineering viewer ever started.
Original mcp.stdout ends Script done2026-10-03 02:03:19-04:00 COMMAND_EXIT_CODE2;
original83658 actually terminal after one exit. Child numeric exit is unknown,
NOT recorded as0; known public native-exit receipt is preserved as returned.
Singer made no runtime/control call or helper cleanup. Original95 helpers remain
under their existing custody; no scientist/author input/contact/exposure occurred.

SHA256 of complete terminal public journals, authentic whitespace untouched:
mcp.stdin3667b682532a21f2a38a1bbb10165071f125bb103157a8efab643d819f23055a
mcp.stdout8cfba62def54b8ddc8f5a1023ad414dfc3304f74e5f55228b3ab6bd8cd8afcd9
default04-values.json4bfc28b2b17b8e1fef0be2f08b2c1e47773534eff1d0804fa600a2a4f558c0ec
removed04-values.json9ba434762fd5775f817f3cdccb365eaefffc8715c1953931108e3080b8cc4ca3
Both retained TIFFs0727265bd0ec4947538e838c4a06ab124f32d2f15498db90a0ce9123a3aa7750
Removed TIFFe2abb31e1f0231bd7283874da20bc0d0746d4b2b460003d4822d3135ced9e541
Raw TIFF1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e

Parent's independent full receipt supplies source/CPPipe hashes. The final archive
contains that original receipt, this receiving note, accepted04 documents/raw/
persisted masks/VALUES and the complete original terminal public journals. It
does not copy a scientific dataset, dependency environment or live process state.
Parent owns final head-match/current-main review and ordinary merge; no hosted
CI wait or further source work remains for this delivered scope.
