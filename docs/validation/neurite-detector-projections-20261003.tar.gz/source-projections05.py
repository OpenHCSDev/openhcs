"""Changed analysis family evidence via the original audit parser, not a scanner."""
import ast
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/ts/.codex/skills/refactor-audit/scripts")
from audit.findings import Package
from audit.repository import Repository

repo = Repository(Path("/home/ts/wt/openhcs-ui-workflow-rendering-20261001"))
revision = repo.git("rev-parse", "HEAD").strip()
package = Package.load(repo, revision, "openhcs/processing/backends/analysis")
print(json.dumps({"revision": revision, "parsed": len(package.modules),
                  "unparsed": package.unparsed}), flush=True)
assert not package.unparsed
for module in package.modules:
    if module.path.endswith(("/count_cells_simple.py", "/neurite_outgrowth.py")):
        print(json.dumps({"path": module.path,
                          "ast": ast.dump(module.tree, include_attributes=True)}))
print(json.dumps({"scope": "changed family closure; prior source-family04 retains dependencies",
                  "limit": "AST source evidence, not global R1 or behavior"}))
