"""Shared stream component semantics for image and artifact outputs."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import ClassVar, Iterable, TypeAlias

from metaclass_registry import AutoRegisterMeta
from polystore.exceptions import MetadataNotFoundError
from polystore.streaming.viewer_transport import (
    DisplayComponentToken,
    DisplayModeToken,
    IndexedViewerStreamSourceMetadata,
    PathMappedViewerStreamSourceMetadata,
    ViewerStreamBackendKwargs,
    ViewerStreamMessageContext,
    ViewerStreamProducer,
    ViewerStreamSourceIdentity,
    ViewerStreamSourceMetadata,
    ViewerDisplayConfigABC,
)
from zmqruntime.viewer_protocol import (
    ViewerComponentMetadataPayload,
    ViewerWireField,
    ViewerWireValue,
)

from openhcs.constants.constants import AllComponents, get_multiprocessing_axis
from openhcs.core.config import FijiDimensionMode, NapariDimensionMode
from openhcs.core.context.processing_context import ProcessingContext
from openhcs.core.runtime_image_values import ImagePayloadMetadata
from openhcs.core.runtime_plane_projection import RuntimePlaneAxisValueProjection
from openhcs.core.runtime_slice_projection import (
    RuntimeProjectionData,
    RuntimeProjectedPayloadItem,
    RuntimeProjectionSourceIdentityRequest,
    RuntimeProjectionSourceIdentityRequirement,
)

from openhcs.core.source_image_provenance import (
    SourceComponentMetadata,
    SourceImageIdentity,
    SourceImageProvenance,
)
from openhcs.core.source_matching import (
    source_component_metadata_raw_value,
    source_metadata_value,
)
from openhcs.core.streaming_config_factory import (
    StreamingViewerSurface,
)
from openhcs.runtime.viewer_component_system import (
    ComponentValue,
    ViewerComponentMetadataNormalizer,
    ViewerComponentValueParser,
    ViewerComponentAxisSemantics,
    ViewerComponentAxisSemanticsAuthority,
    ViewerComponentLayout,
    ViewerComponentValueDomainPayload,
    ViewerObjectDisplayConfigInput,
)

StreamComponentMetadata = SourceComponentMetadata | None
ComponentDisplayName: TypeAlias = str | int | float | bool | None
StreamComponentDomainMetadataItems: TypeAlias = tuple[dict[str, ComponentValue], ...]


class StreamImagePayloadMetadataProjector:
    """Project image-axis declarations into viewer batch-item fields."""

    @classmethod
    def payload_items_for_display(
        cls,
        payload: RuntimeProjectionData,
        *,
        metadata: ImagePayloadMetadata,
        plane_components: tuple[AllComponents, ...],
        component_modes: Mapping[str, str],
        source_description: str,
    ) -> tuple[RuntimeProjectedPayloadItem, ...]:
        """Project declared planes when their display requires scalar identities."""
        item_fields = cls.item_fields_for_plane_components(metadata, plane_components)
        component_values = item_fields.get(
            ViewerWireField.PLANE_COMPONENT_VALUES.value, {}
        )
        scalar_modes = (
            NapariDimensionMode.LAYER.value,
            FijiDimensionMode.WINDOW.value,
        )
        if not any(
            mode in scalar_modes
            for component, mode in component_modes.items()
            if component in component_values
        ):
            return (RuntimeProjectedPayloadItem(payload, source_description),)
        projection = RuntimePlaneAxisValueProjection.preserve(
            axis=metadata.plane_axis,
            axis_size=metadata.source_provenance.source_plane_count,
        )
        source_identity = (
            RuntimeProjectionSourceIdentityRequirement.REQUIRED_COMPONENT_METADATA
        )
        return source_identity.project_payload_items(
            RuntimeProjectionSourceIdentityRequest(
                value=metadata.attach_to(payload),
                source_description=source_description,
                variable_components=plane_components,
                plane_projection=projection,
            )
        )

    @classmethod
    def partition_indices(
        cls,
        metadata_items: Iterable[ImagePayloadMetadata | None],
        component_order: tuple[str, ...],
    ) -> tuple[tuple[int, ...], ...]:
        """Group ordered items by the metadata common to one wire batch."""
        partitions: list[tuple[dict[str, ViewerWireValue], list[int]]] = []
        for index, metadata in enumerate(metadata_items):
            item_fields = cls.item_fields(metadata, component_order)
            for partition_fields, indices in partitions:
                if partition_fields == item_fields:
                    indices.append(index)
                    break
            else:
                partitions.append((item_fields, [index]))
        return tuple(tuple(indices) for _fields, indices in partitions)

    @classmethod
    def item_fields(
        cls,
        metadata: ImagePayloadMetadata | None,
        component_order: tuple[str, ...],
    ) -> dict[str, ViewerWireValue]:
        """Project main-flow metadata through its existing component order."""

        return cls._item_fields(
            metadata,
            tuple(
                component
                for component_name in component_order
                if (component := AllComponents.from_value(component_name)) is not None
            ),
            project_singleton=False,
        )

    @classmethod
    def item_fields_for_plane_components(
        cls,
        metadata: ImagePayloadMetadata | None,
        plane_components: tuple[AllComponents, ...],
    ) -> dict[str, ViewerWireValue]:
        """Project retained image planes, with compiler-owned singleton identity."""

        return cls._item_fields(
            metadata,
            plane_components,
            project_singleton=True,
        )

    @classmethod
    def _item_fields(
        cls,
        metadata: ImagePayloadMetadata | None,
        plane_components: tuple[AllComponents, ...],
        *,
        project_singleton: bool,
    ) -> dict[str, ViewerWireValue]:
        if metadata is None:
            return {}
        item_fields = metadata.source_spatial_domain.to_viewer_wire_mapping()
        item_fields[ViewerWireField.IMAGE_METADATA.value] = (
            metadata.to_viewer_image_metadata()
        )
        if metadata.source_channel_axis is not None:
            item_fields[ViewerWireField.SOURCE_CHANNEL_AXIS.value] = (
                metadata.source_channel_axis
            )
        if metadata.plane_axis is None:
            return item_fields

        item_fields[ViewerWireField.PLANE_AXIS.value] = metadata.plane_axis.value
        plane_component_values = metadata.retained_plane_component_values()
        if (
            not plane_component_values
            and metadata.source_provenance.source_plane_count == 1
            and project_singleton
        ):
            plane_component_values = cls._singleton_plane_component_values(
                metadata,
                plane_components,
            )
        if len(plane_component_values) > 1:
            raise ValueError(
                "Viewer stream image plane axis declares multiple varying "
                "OpenHCS components; one leading plane axis requires exactly "
                f"one component projection, got {tuple(plane_component_values)!r}."
            )
        if plane_component_values:
            item_fields[ViewerWireField.PLANE_COMPONENT_VALUES.value] = (
                plane_component_values
            )
        return item_fields

    @staticmethod
    def _singleton_plane_component_values(
        metadata: ImagePayloadMetadata,
        plane_components: tuple[AllComponents, ...],
    ) -> dict[str, tuple[ComponentValue, ...]]:
        """Project one exact source plane onto its declared viewer component."""

        plane_metadata = metadata.source_provenance.for_source_plane(
            0
        ).source_component_metadata
        values = {
            component.value: (value,)
            for component in plane_components
            if (
                value := source_component_metadata_raw_value(
                    plane_metadata or {},
                    component,
                )
            )
            is not None
        }
        if len(values) != 1:
            raise ValueError(
                "Viewer stream singleton plane axis requires exactly one exact "
                "component value from the declared plane components; got "
                f"{tuple(values)!r} from {plane_components!r}."
            )
        return values


class StreamComponentNameMetadata(dict[str, dict[str, ComponentDisplayName]]):
    """Component value display names keyed by component then raw value."""


@dataclass(frozen=True, slots=True)
class StreamScopedDisplayConfig(ViewerDisplayConfigABC):
    """Display config restricted to components addressable by one stream request."""

    base: ViewerDisplayConfigABC
    component_order: tuple[str, ...]

    @classmethod
    def for_source_provenance(
        cls,
        base: ViewerDisplayConfigABC,
        provenance: SourceImageProvenance,
    ) -> ViewerDisplayConfigABC:
        """Consume the source owner's scalar-coordinate requirements."""
        order = tuple(str(component) for component in base.COMPONENT_ORDER)
        required = provenance.required_scalar_components(order)
        return base if required == order else cls(base, required)

    @property
    def COMPONENT_ORDER(self) -> tuple[str, ...]:
        return self.component_order

    def component_modes(
        self,
    ) -> Mapping[DisplayComponentToken, DisplayModeToken]:
        """Retain the complete typed display config across a scoped route.

        ``COMPONENT_ORDER`` controls which axes one stream request addresses.
        Component modes remain properties of the display config itself and
        must not be discarded merely because an axis is absent from this
        particular request.
        """

        return self.base.component_modes()

    def display_payload_extra(self) -> dict[str, ViewerWireValue]:
        """Retain backend-specific display fields while scoping component axes."""

        return dict(self.base.display_payload_extra())


@dataclass(frozen=True)
class StreamComponentMessageExtraPayload(ViewerComponentMetadataPayload):
    """Viewer wire payload declaring stream component domains and display names."""

    @classmethod
    def from_axis_semantics(
        cls,
        *,
        component_axis_semantics: ViewerComponentAxisSemantics,
        component_names_metadata: StreamComponentNameMetadata,
    ) -> "StreamComponentMessageExtraPayload":
        return cls(
            component_names_metadata=component_names_metadata,
            component_value_domain=component_axis_semantics.to_wire_mapping(),
        )


@dataclass(frozen=True, slots=True)
class StreamViewerComponentMetadataProjector:
    """Project source metadata onto the viewer's declared component axes."""

    component_order: tuple[str, ...]

    @classmethod
    def for_item_fields(
        cls,
        component_order: Iterable[str],
        item_fields: Mapping[str, ViewerWireValue],
    ) -> "StreamViewerComponentMetadataProjector":
        """Exclude components represented by a payload-local plane axis."""

        plane_component_values = item_fields.get(
            ViewerWireField.PLANE_COMPONENT_VALUES.value,
            {},
        )
        if not isinstance(plane_component_values, Mapping):
            raise TypeError("Viewer stream plane_component_values must be a mapping.")
        return cls(
            tuple(
                component
                for component in component_order
                if component not in plane_component_values
            )
        )

    def project_required(
        self,
        *,
        index: int,
        metadata: StreamComponentMetadata,
    ) -> dict[str, ComponentValue]:
        if metadata is None:
            raise ValueError(
                "Viewer streaming requires source component metadata for "
                f"item {index}."
            )
        projected = self.project(metadata)
        missing = tuple(
            component
            for component in self.component_order
            if component not in projected
        )
        if missing:
            raise ValueError(
                "Viewer streaming requires complete source component metadata "
                f"for item {index}; missing {missing!r}. "
                f"metadata={metadata!r}."
            )
        return projected

    def project(
        self,
        metadata: SourceComponentMetadata,
    ) -> dict[str, ComponentValue]:
        projected: dict[str, ComponentValue] = {}
        for component in self.component_order:
            value = self.component_value(metadata, component)
            if value is not None:
                projected[component] = value
        return ViewerComponentMetadataNormalizer().normalize(projected)

    def component_value(
        self,
        metadata: SourceComponentMetadata,
        component: str,
    ) -> ComponentValue:
        component_identity = AllComponents.from_value(component)
        if component_identity is None:
            value = metadata.get(component)
        else:
            value = source_component_metadata_raw_value(metadata, component_identity)
        if value is None:
            return None
        return ViewerComponentValueParser.parse(
            value,
            context=f"Viewer source metadata component {component!r}",
        )

    def indexed_source_metadata(
        self,
        values: tuple[StreamComponentMetadata, ...],
    ) -> ViewerStreamSourceMetadata:
        return IndexedViewerStreamSourceMetadata(
            metadata_by_index=tuple(
                self.project_required(index=index, metadata=metadata)
                for index, metadata in enumerate(values)
            )
        )

    def path_mapped_source_metadata(
        self,
        metadata_by_path: Mapping[str, StreamComponentMetadata],
    ) -> ViewerStreamSourceMetadata:
        return PathMappedViewerStreamSourceMetadata(
            metadata_by_path={
                path: self.project_required(index=index, metadata=metadata)
                for index, (path, metadata) in enumerate(metadata_by_path.items())
            }
        )


@dataclass(frozen=True, slots=True)
class StreamSourceComponentMetadataItems:
    """Source component metadata observed by one viewer streaming operation."""

    values: tuple[StreamComponentMetadata, ...]

    @classmethod
    def from_values(
        cls,
        values: Iterable[StreamComponentMetadata],
    ) -> "StreamSourceComponentMetadataItems":
        return cls(tuple(values))

    @classmethod
    def from_image_metadata(
        cls,
        metadata: ImagePayloadMetadata,
        *,
        fallback_source_identity: SourceImageIdentity | None = None,
    ) -> "StreamSourceComponentMetadataItems":
        """Observe exact retained planes, not only their common scalar address.

        These are domain observations, not one route address per emitted image.
        A collapsed image's contributor provenance must not recreate a pixel axis.
        """
        provenance = metadata.source_provenance
        identities = (
            tuple(
                provenance.for_source_plane(index).scalar_source_identity
                for index in range(provenance.source_plane_count)
            )
            if metadata.plane_axis is not None and provenance.source_plane_count
            else (provenance.scalar_source_identity,)
        )
        return cls.from_source_identities(
            identities,
            fallback_source_identity=fallback_source_identity,
        )

    @classmethod
    def from_source_identities(
        cls,
        identities: Iterable[SourceImageIdentity],
        *,
        fallback_source_identity: SourceImageIdentity | None = None,
    ) -> "StreamSourceComponentMetadataItems":
        return cls.from_values(
            (
                identity.with_missing_from(fallback_source_identity)
                if fallback_source_identity is not None
                else identity
            ).component_metadata
            for identity in identities
        )

    def domain_metadata_items(
        self,
        component_order: tuple[str, ...],
    ) -> StreamComponentDomainMetadataItems:
        projector = StreamViewerComponentMetadataProjector(component_order)
        return tuple(
            projector.project(metadata)
            for metadata in self.values
            if metadata is not None
        )

    def viewer_source_metadata(
        self,
        component_order: tuple[str, ...],
    ) -> ViewerStreamSourceMetadata:
        return StreamViewerComponentMetadataProjector(
            component_order
        ).indexed_source_metadata(self.values)

    def complete_component_order(
        self,
        component_order: Iterable[str],
    ) -> tuple[str, ...]:
        """Return components with concrete metadata in every streamed item."""
        order = tuple(str(component) for component in component_order)
        if not self.values:
            return order
        projector = StreamViewerComponentMetadataProjector(order)
        complete: list[str] = []
        for component in order:
            if all(
                metadata is not None
                and projector.component_value(metadata, component) is not None
                for metadata in self.values
            ):
                complete.append(component)
        return tuple(complete)

    def include_observed_values(
        self,
        name_map: "StreamComponentNameMap",
        component_order: tuple[str, ...],
    ) -> None:
        for metadata in self.values:
            if metadata is None:
                continue
            for component in component_order:
                value = source_metadata_value(metadata, component)
                if value is None:
                    continue
                name_map.include_observed_value(component, value)


class StreamComponentNameMap(StreamComponentNameMetadata):
    """Mutable builder for stream component display-name metadata."""

    def merge_component_values(
        self,
        component: str,
        values: dict[str, ComponentDisplayName],
    ) -> None:
        if not values:
            return
        if component not in self:
            self[component] = {}
        self[component].update(values)

    def include_observed_value(self, component: str, value: ComponentValue) -> None:
        if component not in self:
            self[component] = {}
        wire_value = str(value)
        if wire_value not in self[component]:
            self[component][wire_value] = None


@dataclass(frozen=True, slots=True)
class StreamMetadataRoot:
    """Metadata root that has a metadata document discoverable by the handler."""

    source: ViewerStreamSourceIdentity
    root: Path

    @classmethod
    def from_candidate(
        cls,
        source: ViewerStreamSourceIdentity,
        root: Path,
    ) -> "StreamMetadataRoot":
        source.microscope_handler.metadata_handler.find_metadata_file(root)
        return cls(source=source, root=root)

    def component_display_names(
        self,
        component: str,
    ) -> dict[str, ComponentDisplayName]:
        values = self.source.microscope_handler.metadata_handler.get_component_values(
            self.root,
            component,
        )
        if values is None:
            return {}
        return {str(value): name for value, name in dict(values).items()}

    def component_values(self, component: str) -> tuple[ComponentValue, ...]:
        values = self.source.microscope_handler.metadata_handler.get_component_values(
            self.root,
            component,
        )
        if values is None:
            return ()
        return tuple(str(value) for value in values)


@dataclass(frozen=True, slots=True)
class StreamMetadataRootAuthority:
    """Resolve unique metadata roots available to stream-output projection."""

    source: ViewerStreamSourceIdentity
    candidate_roots: tuple[Path, ...]

    @classmethod
    def from_context(cls, context: ProcessingContext) -> "StreamMetadataRootAuthority":
        roots = []
        for value in (
            context.plate_path,
            context.input_dir,
        ):
            if value is None:
                continue
            root = Path(value)
            if root not in roots:
                roots.append(root)
        return cls(
            source=ViewerStreamSourceIdentity(
                microscope_handler=context.microscope_handler,
                plate_path=context.plate_path,
            ),
            candidate_roots=tuple(roots),
        )

    @classmethod
    def from_source_identity(
        cls,
        source: ViewerStreamSourceIdentity,
    ) -> "StreamMetadataRootAuthority":
        roots = ()
        if source.plate_path is not None:
            roots = (Path(source.plate_path),)
        return cls(
            source=source,
            candidate_roots=roots,
        )

    def roots(self) -> tuple[StreamMetadataRoot, ...]:
        metadata_roots = []
        for root in self.candidate_roots:
            try:
                metadata_roots.append(
                    StreamMetadataRoot.from_candidate(
                        self.source,
                        root,
                    )
                )
            except (FileNotFoundError, MetadataNotFoundError, NotADirectoryError):
                continue
        return tuple(metadata_roots)


@dataclass(frozen=True, slots=True)
class StreamComponentDomainProvider(ABC, metaclass=AutoRegisterMeta):
    """Nominal provider for declared stream component values and display names."""

    __registry_key__ = "registry_key"
    __skip_if_no_key__ = True
    registry_key: ClassVar[str | None] = None

    component: str
    metadata_roots: tuple[StreamMetadataRoot, ...]

    @classmethod
    def for_component(
        cls,
        *,
        context: ProcessingContext,
        component: str,
        metadata_roots: tuple[StreamMetadataRoot, ...],
    ) -> "StreamComponentDomainProvider":
        for provider_type in cls.__registry__.values():
            if provider_type.supports(component):
                return provider_type.build_for_component(
                    context=context,
                    component=component,
                    metadata_roots=metadata_roots,
                )
        raise LookupError(
            f"No stream component domain provider registered for {component!r}."
        )

    @classmethod
    def build_for_component(
        cls,
        *,
        context: ProcessingContext,
        component: str,
        metadata_roots: tuple[StreamMetadataRoot, ...],
    ) -> "StreamComponentDomainProvider":
        del context
        return cls(
            component=component,
            metadata_roots=metadata_roots,
        )

    @classmethod
    @abstractmethod
    def supports(cls, component: str) -> bool:
        """Return whether this provider owns the component's declared domain."""

    @abstractmethod
    def domain_metadata_items(self) -> StreamComponentDomainMetadataItems:
        """Return metadata entries declaring this component's value domain."""

    def include_display_names(self, name_map: StreamComponentNameMap) -> None:
        for metadata_root in self.metadata_roots:
            name_map.merge_component_values(
                self.component,
                metadata_root.component_display_names(self.component),
            )


@dataclass(frozen=True, slots=True)
class StreamExecutionAxisDomainProvider(StreamComponentDomainProvider):
    """Declared domain provider for the execution multiprocessing axis."""

    registry_key: ClassVar[str] = "execution_axis"
    axis_component: ClassVar[str] = str(get_multiprocessing_axis().value)
    execution_axis_values: tuple[ComponentValue, ...] = ()

    @classmethod
    def build_for_component(
        cls,
        *,
        context: ProcessingContext,
        component: str,
        metadata_roots: tuple[StreamMetadataRoot, ...],
    ) -> "StreamExecutionAxisDomainProvider":
        if context.execution_runtime is None:
            raise RuntimeError(
                "Streaming component domain requires ProcessingContext.execution_runtime "
                "for the multiprocessing axis."
            )
        values = context.execution_runtime.execution_axis_values
        if not values:
            raise RuntimeError(
                "Streaming component domain requires at least one execution axis value."
            )
        return cls(
            component=component,
            metadata_roots=metadata_roots,
            execution_axis_values=values,
        )

    @classmethod
    def supports(cls, component: str) -> bool:
        return component == cls.axis_component

    def domain_metadata_items(self) -> StreamComponentDomainMetadataItems:
        return tuple({self.component: value} for value in self.execution_axis_values)


@dataclass(frozen=True, slots=True)
class StreamMetadataBackedComponentDomainProvider(StreamComponentDomainProvider):
    """Declared domain provider for components described by plate metadata roots."""

    registry_key: ClassVar[str] = "metadata"

    @classmethod
    def supports(cls, component: str) -> bool:
        return True

    def domain_metadata_items(self) -> StreamComponentDomainMetadataItems:
        items: list[dict[str, ComponentValue]] = []
        for metadata_root in self.metadata_roots:
            for value in metadata_root.component_values(self.component):
                items.append({self.component: value})
        return tuple(items)


@dataclass(frozen=True, slots=True)
class StreamComponentDomainProviders:
    """Ordered domain-provider set for one viewer component layout."""

    values: tuple[StreamComponentDomainProvider, ...]

    @classmethod
    def from_layout(
        cls,
        *,
        context: ProcessingContext,
        layout: ViewerComponentLayout,
        metadata_roots: tuple[StreamMetadataRoot, ...],
    ) -> "StreamComponentDomainProviders":
        return cls(
            tuple(
                StreamComponentDomainProvider.for_component(
                    context=context,
                    component=component,
                    metadata_roots=metadata_roots,
                )
                for component in layout.component_order
            )
        )

    def domain_metadata_items(self) -> StreamComponentDomainMetadataItems:
        return tuple(
            item
            for provider in self.values
            for item in provider.domain_metadata_items()
        )

    def include_display_names(self, name_map: StreamComponentNameMap) -> None:
        for provider in self.values:
            provider.include_display_names(name_map)


@dataclass(frozen=True, slots=True)
class StreamComponentMessageExtraAuthority:
    """Build viewer wire metadata that declares component domains and display names."""

    viewer_surface: StreamingViewerSurface
    source_metadata_items: StreamSourceComponentMetadataItems
    metadata_roots: tuple[StreamMetadataRoot, ...]
    domain_providers: StreamComponentDomainProviders

    @classmethod
    def from_context(
        cls,
        viewer_surface: StreamingViewerSurface,
        *,
        context: ProcessingContext,
        source_metadata_items: StreamSourceComponentMetadataItems,
    ) -> "StreamComponentMessageExtraAuthority":
        viewer_surface = cls._scope_to_complete_components(
            viewer_surface,
            source_metadata_items,
        )
        display_input = ViewerObjectDisplayConfigInput(viewer_surface.display_config)
        metadata_roots = StreamMetadataRootAuthority.from_context(context).roots()
        return cls(
            viewer_surface=viewer_surface,
            source_metadata_items=source_metadata_items,
            metadata_roots=metadata_roots,
            domain_providers=StreamComponentDomainProviders.from_layout(
                context=context,
                layout=display_input.layout(),
                metadata_roots=metadata_roots,
            ),
        )

    @classmethod
    def from_viewer_surface(
        cls,
        viewer_surface: StreamingViewerSurface,
        *,
        source_metadata_items: StreamSourceComponentMetadataItems,
    ) -> "StreamComponentMessageExtraAuthority":
        viewer_surface = cls._scope_to_complete_components(
            viewer_surface,
            source_metadata_items,
        )
        return cls(
            viewer_surface=viewer_surface,
            source_metadata_items=source_metadata_items,
            metadata_roots=StreamMetadataRootAuthority.from_source_identity(
                viewer_surface.source,
            ).roots(),
            domain_providers=StreamComponentDomainProviders(()),
        )

    @staticmethod
    def _scope_to_complete_components(
        viewer_surface: StreamingViewerSurface,
        source_metadata_items: StreamSourceComponentMetadataItems,
    ) -> StreamingViewerSurface:
        component_order = (
            ViewerObjectDisplayConfigInput(viewer_surface.display_config)
            .layout()
            .component_order
        )
        complete_component_order = source_metadata_items.complete_component_order(
            component_order
        )
        if complete_component_order == component_order:
            return viewer_surface
        return replace(
            viewer_surface,
            display_config=StreamScopedDisplayConfig(
                base=viewer_surface.display_config,
                component_order=complete_component_order,
            ),
        )

    @property
    def display_input(self) -> ViewerObjectDisplayConfigInput:
        return ViewerObjectDisplayConfigInput(self.viewer_surface.display_config)

    @property
    def layout(self) -> ViewerComponentLayout:
        return self.display_input.layout()

    @property
    def metadata_items(self) -> StreamComponentDomainMetadataItems:
        return (
            *self.domain_providers.domain_metadata_items(),
            *self.source_metadata_items.domain_metadata_items(
                self.layout.component_order
            ),
        )

    @property
    def component_axis_semantics(self) -> ViewerComponentAxisSemantics:
        return ViewerComponentAxisSemanticsAuthority.from_display_config(
            display_config=self.display_input,
            value_domain=ViewerComponentValueDomainPayload.from_component_metadata(
                component_layout=self.layout,
                metadata_items=self.metadata_items,
            ),
        )

    def component_names_metadata(
        self,
        component_order: tuple[str, ...],
    ) -> StreamComponentNameMetadata:
        metadata = StreamComponentNameMap()
        self.domain_providers.include_display_names(metadata)
        self.source_metadata_items.include_observed_values(
            metadata,
            component_order,
        )
        return metadata

    def payload(self) -> StreamComponentMessageExtraPayload:
        component_axis_semantics = self.component_axis_semantics
        return StreamComponentMessageExtraPayload.from_axis_semantics(
            component_axis_semantics=component_axis_semantics,
            component_names_metadata=self.component_names_metadata(
                component_axis_semantics.component_order,
            ),
        )

    def message_context(
        self,
        images_dir: str | None = None,
    ) -> ViewerStreamMessageContext:
        return ViewerStreamMessageContext(
            message_extra=self.payload().to_wire_mapping(),
            images_dir=images_dir,
        )

    def viewer_backend_kwargs(
        self,
        *,
        producer: ViewerStreamProducer,
        source_metadata: ViewerStreamSourceMetadata | None = None,
        images_dir: str | None = None,
    ) -> ViewerStreamBackendKwargs:
        if source_metadata is None:
            source_metadata = self.source_metadata_items.viewer_source_metadata(
                self.layout.component_order
            )
        return self.viewer_surface.viewer_backend_kwargs(
            producer=producer,
            source_metadata=source_metadata,
            message_context=self.message_context(images_dir=images_dir),
        )

    def path_mapped_source_metadata(
        self,
        metadata_by_path: Mapping[str, StreamComponentMetadata],
        *,
        item_fields: Mapping[str, ViewerWireValue] | None = None,
    ) -> ViewerStreamSourceMetadata:
        projector = StreamViewerComponentMetadataProjector(self.layout.component_order)
        if item_fields is not None:
            projector = StreamViewerComponentMetadataProjector.for_item_fields(
                self.layout.component_order,
                item_fields,
            )
        return projector.path_mapped_source_metadata(metadata_by_path)
