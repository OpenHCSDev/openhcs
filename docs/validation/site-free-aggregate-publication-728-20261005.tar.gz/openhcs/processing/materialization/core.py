"""Materialization core (writer-based, greenfield).

Key idea: the abstraction boundary is the output *format* (writers), not per-analysis handlers.
"""

from __future__ import annotations

import csv
import io
import json
import logging
import operator
import re
import string
from abc import ABC, abstractmethod
from collections.abc import Callable, Mapping, Sequence, Sized
from dataclasses import dataclass, field, is_dataclass, replace
from functools import lru_cache, singledispatch
from pathlib import Path, PurePosixPath, PureWindowsPath
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, TypeAlias

import numpy as np
import pandas as pd
from metaclass_registry import AutoRegisterMeta
from polystore.config import TiffConfig
from polystore.streaming.viewer_transport import (
    PathMappedViewerStreamSourceMetadata,
    ViewerStreamBackendKwargs,
    ViewerDisplayConfigABC,
)
from zmqruntime.viewer_protocol import ViewerWireValue

from openhcs.core.source_path_identity import source_path_identity
from openhcs.constants.constants import AllComponents, VariableComponents
from openhcs.core.artifacts import ArtifactMaterializationPayload
from openhcs.core.component_set import ComponentSet
from openhcs.core.components.parser_metaprogramming import FilenameParseResult
from openhcs.core.image_file_serialization import ImageFileFormat
from openhcs.core.registry_strategies import (
    AlwaysMatchesContextMixin,
    MostDerivedContextStrategyMixin,
)
from openhcs.core.runtime_array_values import runtime_array_operand
from openhcs.core.runtime_image_values import (
    ImagePayloadMetadata,
    ImagePayloadMetadataCompositionMode,
    image_payload_data,
    image_payload_metadata,
)
from openhcs.core.runtime_object_labels import (
    ObjectLabelValue,
)
from openhcs.core.runtime_slice_projection import (
    RuntimeProjectedPayloadItem,
    RuntimeProjectionPlaneMetadata,
    RuntimeProjectionSourceIdentityRequest,
    RuntimeProjectionSourceIdentityRequirement,
)
from openhcs.core.runtime_spatial_graph import SpatialGraph, SpatialGraphNode
from openhcs.core.runtime_tabular_values import (
    ColumnarRows,
    measurement_row_mapping,
    supports_measurement_row_mapping,
)
from openhcs.core.source_image_provenance import (
    SourceComponentMetadata,
    SourceImageIdentity,
    SourceImageProvenance,
    SourcePlaneIndexedMetadata,
    VariableComponentAxisProjection,
)
from openhcs.core.source_matching import (
    source_component_metadata_value,
    source_metadata_value,
)
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.core.source_spatial_domain import SourceSpatialDomain
from openhcs.core.steps.function_output_identity import (
    FunctionOutputIdentity,
)
from openhcs.core.steps.stream_component_semantics import (
    StreamImagePayloadMetadataProjector,
    StreamViewerComponentMetadataProjector,
    StreamScopedDisplayConfig,
)
from openhcs.processing.materialization.constants import (
    MaterializationFormat,
    WriteMode,
)
from openhcs.processing.materialization.options import (
    CsvOptions,
    FileBundleOptions,
    FileOutputOptions,
    ImageFileOptions,
    JsonOptions,
    MaterializedFilenameIdentity,
    PointROIOptions,
    ROIOptions,
    SourceOptions,
    SpatialGraphROIOptions,
    SWCOptions,
    TabularExtractionOptions,
    TextOptions,
    TiffStackOptions,
)

if TYPE_CHECKING:
    from polystore.filemanager import FileManager

    from openhcs.core.artifacts import ArtifactOutputPlan
    from openhcs.core.context.processing_context import ProcessingContext
    from openhcs.microscopes.microscope_interfaces import FilenameParser

logger = logging.getLogger(__name__)

MaterializationValue = (
    str
    | bytes
    | int
    | float
    | bool
    | list
    | tuple
    | dict
    | ColumnarRows
    | ObjectLabelValue
    | SpatialGraph
    | np.ndarray
    | pd.DataFrame
    | pd.Series
    | None
)
SourceComponentIdentity: TypeAlias = tuple[tuple[str, str], ...]


class BackendCallKwargs(ABC, metaclass=AutoRegisterMeta):
    """Nominal payload that knows how to build FileManager kwargs per output."""

    backend_kwargs_key_axis: ClassVar[str] = "backend_kwargs_kind"
    __registry_key__ = backend_kwargs_key_axis
    __skip_if_no_key__ = True
    stable_key_axis: ClassVar[str] = backend_kwargs_key_axis
    backend_kwargs_kind: ClassVar[str | None] = None

    @classmethod
    def registered_types(cls) -> tuple[type[BackendCallKwargs], ...]:
        return tuple(cls.__registry__.values())

    @abstractmethod
    def to_filemanager_kwargs(
        self,
        output: Output,
    ) -> dict:
        """Return kwargs for one FileManager save call."""

    @abstractmethod
    def filemanager_batches(
        self,
        outputs: Sequence[Output],
    ) -> tuple[tuple[tuple[Output, ...], dict], ...]:
        """Partition outputs into exact FileManager batch calls."""


@dataclass(frozen=True, slots=True)
class RawBackendKwargs(BackendCallKwargs, Mapping[str, MaterializationValue]):
    """Raw FileManager backend kwargs at the materialization adapter edge."""

    backend_kwargs_kind = "raw"
    values: Mapping[str, MaterializationValue] = field(default_factory=dict)
    tiff_config: TiffConfig | None = None

    def __getitem__(self, key: str) -> MaterializationValue:
        return self.values[key]

    def __iter__(self):
        return iter(self.values)

    def __len__(self) -> int:
        return len(self.values)

    def to_filemanager_kwargs(
        self,
        output: Output,
    ) -> dict:
        values = dict(self.values)
        if self.tiff_config is not None and self.tiff_config.applies_to_path(
            output.path
        ):
            values["tiff_config"] = self.tiff_config
        return values

    def filemanager_batches(
        self,
        outputs: Sequence[Output],
    ) -> tuple[tuple[tuple[Output, ...], dict], ...]:
        return tuple(
            (
                tuple(outputs[index] for index in indices),
                {
                    **self.values,
                    **({"tiff_config": config} if config is not None else {}),
                },
            )
            for indices, config in ImageFileFormat.storage_write_batches(
                tuple(
                    (
                        output.metadata.attach_to(output.content)
                        if output.metadata is not None
                        and ImageFileFormat.is_image_path(output.path)
                        else output.content
                    )
                    for output in outputs
                ),
                tuple(output.path for output in outputs),
                self.tiff_config,
            )
        )


class TabularRow(dict[str, MaterializationValue]):
    """Nominal row emitted by materialization tabular extraction."""


class TabularRows(list[TabularRow]):
    """Nominal row collection emitted by materialization tabular extraction."""


def tabular_row_from_payload(
    item: MaterializationValue,
    field_names: Sequence[str] | None = None,
) -> TabularRow:
    """Project one payload item into a canonical tabular row."""
    if supports_measurement_row_mapping(item):
        row = measurement_row_mapping(item)
        if field_names:
            return TabularRow(
                {
                    field_name: row[field_name]
                    for field_name in field_names
                    if field_name in row
                }
            )
        return TabularRow(dict(row))

    return TabularRow({"value": item})


def expanded_tabular_rows(
    array_data: Sequence[MaterializationValue],
    base_row: TabularRow,
    row_columns: Mapping[str, str],
) -> TabularRows:
    """Expand an explicitly declared nested row field into tabular rows."""
    array_rows = tuple(array_data)
    if not array_rows:
        return TabularRows((base_row,))

    rows = TabularRows()
    for elem in array_rows:
        if isinstance(elem, (list, tuple)):
            cols = {
                col: elem[int(idx)]
                for idx, col in row_columns.items()
                if str(idx).isdigit() and int(idx) < len(elem)
            }
        else:
            cols = {}
        rows.append(TabularRow({**base_row, **cols}))
    return rows


@dataclass(frozen=True, slots=True)
class BackendKwargsAbsent:
    """Default backend kwargs variant for callers that do not provide overrides."""


BACKEND_KWARGS_ABSENT = BackendKwargsAbsent()
BackendKwargsValue: TypeAlias = "BackendCallKwargs | Mapping[str, MaterializationValue]"
BackendKwargs: TypeAlias = dict[str, BackendKwargsValue]
NormalizedBackendKwargs: TypeAlias = dict[str, "BackendCallKwargs"]
BackendKwargsInput = BackendKwargs | BackendKwargsAbsent
PrimaryPathSelector = Callable[[list["Output"]], str]
CandidatePathSelector = Callable[[FileOutputOptions, str], tuple[str, ...]]


@dataclass(frozen=True)
class Output:
    path: str
    content: MaterializationValue
    metadata: ImagePayloadMetadata | None = None
    variable_components: tuple[AllComponents, ...] = ()

    @classmethod
    def from_metadata(
        cls,
        *,
        path: str,
        content: MaterializationValue,
        metadata: ImagePayloadMetadata | None,
    ) -> Output:
        return cls(
            path=path,
            content=content,
            metadata=metadata,
        )

    @property
    def source_identity(self) -> SourceImageIdentity | None:
        if self.metadata is None:
            return None
        return self.metadata.source_provenance.scalar_source_identity

    @property
    def source_component_metadata(self) -> SourceComponentMetadata | None:
        if self.source_identity is None:
            return None
        return self.source_identity.component_metadata

    @property
    def viewer_stream_requires_source_metadata(self) -> bool:
        return True

    def viewer_display_config(
        self, base: ViewerDisplayConfigABC
    ) -> ViewerDisplayConfigABC:
        """Project display scope from this output's own optional source payload."""
        if self.metadata is None:
            return base
        return StreamScopedDisplayConfig.for_source_provenance(
            base, self.metadata.source_provenance
        )

    def require_text_content(self) -> str:
        """Return declared text content or reject a non-text output."""

        raise TypeError(
            f"Materialization output {self.path!r} is not declared as text "
            f"({self.__class__.__name__})."
        )

    def with_source_identity_fallback(
        self,
        fallback: SourceImageIdentity | None,
    ) -> Output:
        if fallback is None:
            return self
        fallback_metadata = ImagePayloadMetadata(
            source_path=fallback.path,
            source_component_metadata=fallback.component_metadata,
        )
        metadata = (
            fallback_metadata
            if self.metadata is None
            else self.metadata.with_source_context_from(fallback_metadata)
        )
        return replace(
            self,
            metadata=metadata,
        )

    def with_variable_components(
        self,
        variable_components: Sequence[VariableComponents],
    ) -> Output:
        """Carry compiler-resolved runtime plane components to backend saving."""

        return replace(
            self,
            variable_components=ComponentSet.coerce(variable_components).as_tuple(),
        )


@dataclass(frozen=True)
class TextOutput(Output):
    """Materialization output whose canonical payload is text."""

    content: str

    @property
    def viewer_stream_requires_source_metadata(self) -> bool:
        return False

    def require_text_content(self) -> str:
        return self.content


@dataclass(frozen=True)
class Utf8TextOutput(Output):
    """Text output stored as UTF-8 bytes for file-bundle compatibility."""

    content: bytes

    @classmethod
    def from_text(cls, *, path: str, content: str) -> Utf8TextOutput:
        return cls(path=path, content=content.encode("utf-8"))

    @property
    def viewer_stream_requires_source_metadata(self) -> bool:
        return False

    def require_text_content(self) -> str:
        return self.content.decode("utf-8")


class SourceSegmentAuthority:
    """Resolve one source selector segment against mappings or named fields."""

    @staticmethod
    def resolve(value: MaterializationValue, segment: str) -> MaterializationValue:
        if isinstance(value, dict):
            return value[segment]
        return operator.attrgetter(segment)(value)


class MaterializationSourceProjection(ABC, metaclass=AutoRegisterMeta):
    """Projection strategy for writer source options."""

    __registry_key__ = "source_type"
    __skip_if_no_key__ = True
    source_type: ClassVar[type | None] = None
    __registry__: ClassVar[dict[type, type[MaterializationSourceProjection]]] = {}

    @classmethod
    def from_source(cls, source) -> MaterializationSourceProjection:
        source_type = source.__class__
        try:
            projection_type = cls.__registry__[source_type]
        except KeyError as exc:
            raise TypeError(
                "Unsupported materialization source selector type: "
                f"{source_type.__name__}"
            ) from exc
        return projection_type.build(source)

    @classmethod
    @abstractmethod
    def build(cls, source) -> MaterializationSourceProjection:
        """Build a projection from the declared source selector."""

    @abstractmethod
    def project(self, value: MaterializationValue) -> MaterializationValue:
        """Return the payload seen by materialization writers."""


class IdentityMaterializationSourceProjection(MaterializationSourceProjection):
    """No source option was declared; writers consume the payload directly."""

    source_type = type(None)

    @classmethod
    def build(cls, source: None) -> IdentityMaterializationSourceProjection:
        del source
        return cls()

    def project(self, value: MaterializationValue) -> MaterializationValue:
        return value


@dataclass(frozen=True, slots=True)
class SourcePathSegments:
    """Validated dotted source path segments."""

    segments: tuple[str, ...]

    @classmethod
    def from_text(cls, source: str) -> SourcePathSegments:
        segments = tuple(source.split("."))
        if "" in segments:
            raise ValueError("Materialization source path contains an empty segment.")
        return cls(segments)


@dataclass(frozen=True, slots=True)
class DottedMaterializationSourceProjection(MaterializationSourceProjection):
    """Source option declared as a dotted path into the input payload."""

    source_type = str
    source_path: SourcePathSegments

    @classmethod
    def build(cls, source: str) -> DottedMaterializationSourceProjection:
        return cls(SourcePathSegments.from_text(source))

    def project(self, value: MaterializationValue) -> MaterializationValue:
        projected = value
        for segment in self.source_path.segments:
            projected = SourceSegmentAuthority.resolve(projected, segment)
        return projected


def _materialization_sequence(
    value: MaterializationValue,
) -> tuple[MaterializationValue, ...]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple)):
        return tuple(value)
    return (value,)


def _materialization_sequence_type(value: MaterializationValue) -> type | None:
    if isinstance(value, (list, tuple)):
        return value.__class__
    return None


@singledispatch
def materialization_is_empty(value: MaterializationValue) -> bool:
    """Return whether a materialization payload carries no output data."""
    return False


@materialization_is_empty.register(type(None))
def none_materialization_is_empty(value: None) -> bool:
    return True


@materialization_is_empty.register(np.ndarray)
def numpy_materialization_is_empty(value: np.ndarray) -> bool:
    return value.size == 0


@materialization_is_empty.register(pd.DataFrame)
def dataframe_materialization_is_empty(value: pd.DataFrame) -> bool:
    return value.empty


@materialization_is_empty.register(pd.Series)
def series_materialization_is_empty(value: pd.Series) -> bool:
    return value.empty


@materialization_is_empty.register(ColumnarRows)
def columnar_rows_materialization_is_empty(value: ColumnarRows) -> bool:
    return value.row_count() == 0


@materialization_is_empty.register(list)
@materialization_is_empty.register(tuple)
@materialization_is_empty.register(dict)
@materialization_is_empty.register(str)
@materialization_is_empty.register(bytes)
def sized_materialization_is_empty(value: Sized) -> bool:
    return len(value) == 0


@dataclass(frozen=True, slots=True)
class MaterializationInputItem(RuntimeProjectedPayloadItem):
    """One materialization payload item with semantic metadata preserved."""

    @property
    def data(self) -> MaterializationValue:
        return runtime_array_operand(image_payload_data(self.value))

    @property
    def runtime_plane(self) -> RuntimeProjectionPlaneMetadata | None:
        """Return runtime display-plane identity for this materialized item."""
        return self.runtime_plane_metadata


class ROIMaterializationSourceSpatialDomain:
    """Resolve the source-spatial domain used by ROI extraction."""

    def domain_for_item(self, item: MaterializationInputItem) -> SourceSpatialDomain:
        metadata_domain = item.metadata.source_spatial_domain.with_value_name(
            "ROI materialization source image",
        )
        if metadata_domain.source_shape_yx is not None:
            return metadata_domain
        local_shape_yx = item.metadata.spatial_shape_yx(item.data)
        if local_shape_yx is None:
            return metadata_domain
        return SourceSpatialDomain(
            origin_yx=(
                metadata_domain.origin_yx
                if metadata_domain.origin_yx is not None
                else (0, 0)
            ),
            source_shape_yx=local_shape_yx,
            fill_value=metadata_domain.fill_value,
            value_name=metadata_domain.value_name,
        )

    def domain_for_target(
        self,
        target: ROIMaterializationTarget,
    ) -> SourceSpatialDomain:
        """Return the one exact source domain represented by an ROI archive."""

        domains = tuple(self.domain_for_item(item) for item in target.items)
        if not domains:
            return SourceSpatialDomain(value_name="ROI materialization source image")
        domain_keys = {(domain.origin_yx, domain.source_shape_yx) for domain in domains}
        if len(domain_keys) != 1:
            raise ValueError(
                f"ROI archive {target.archive.path!r} cannot represent conflicting "
                f"source-spatial domains {tuple(domain_keys)!r}."
            )
        return domains[0]


@dataclass(frozen=True, slots=True)
class SourcePlaneProjectionContract:
    """Source-plane provenance declared by the payload before slice projection."""

    plane_count_sources: tuple[int, ...] = ()

    @classmethod
    def from_payloads(
        cls,
        payloads: tuple[MaterializationValue, ...],
    ) -> SourcePlaneProjectionContract:
        return cls(
            tuple(
                plane_count_source
                for payload in payloads
                for plane_count_source in (
                    image_payload_metadata(
                        payload
                    ).source_provenance.plane_count_sources
                )
            )
        )

    @property
    def requires_source_identity(self) -> bool:
        return bool(self.plane_count_sources)


@dataclass(frozen=True, slots=True)
class SourceComponentMetadataStemAuthority:
    """Construct source stems from component metadata through the filename parser."""

    parser: FilenameParser

    def stem(self, metadata: SourceComponentMetadata) -> str:
        return Path(
            self.parser.construct_filename(
                self.parser.bind_component_values(
                    self.component_values(metadata),
                    extension=self.required_extension(metadata),
                )
            )
        ).stem

    @staticmethod
    def required_extension(metadata: SourceComponentMetadata) -> str:
        if "extension" not in metadata:
            raise ValueError(
                "Component-addressed ROI paths require source component metadata "
                "to include an extension."
            )
        return str(metadata["extension"])

    @staticmethod
    def component_values(
        metadata: Mapping[str, MaterializationValue],
    ) -> dict[str, MaterializationValue]:
        return {
            str(key): value
            for key, value in metadata.items()
            if str(key) != "extension"
        }


@dataclass(frozen=True, slots=True)
class SourceStemAuthoritySelection:
    """Available source-stem inputs for one materialization context."""

    parser: FilenameParser | None

    @classmethod
    def from_processing_context(
        cls,
        context: ProcessingContext | None,
    ) -> SourceStemAuthoritySelection:
        if context is None:
            return cls(parser=None)
        microscope_handler = context.microscope_handler
        if microscope_handler is None:
            return cls(parser=None)
        return cls(parser=microscope_handler.parser)

    def required_parser(self) -> FilenameParser:
        if self.parser is None:
            raise ValueError("Parser-backed source-stem authority requires a parser.")
        return self.parser


class SourceStemAuthority(
    MostDerivedContextStrategyMixin[SourceStemAuthoritySelection],
    ABC,
):
    """Resolve the stream/materialization source stem for ROI path ownership."""

    authority_key_axis: ClassVar[str] = "authority_key"
    __registry_key__ = authority_key_axis
    __skip_if_no_key__ = True
    stable_key_axis: ClassVar[str] = authority_key_axis

    authority_key: ClassVar[str | None] = None
    strategy_key_attr: ClassVar[str] = authority_key_axis

    @classmethod
    def from_processing_context(
        cls,
        context: ProcessingContext | None,
    ) -> SourceStemAuthority:
        return cls.for_context(
            SourceStemAuthoritySelection.from_processing_context(context),
            error_subject="source-stem authority selection",
        )

    @classmethod
    def build_for_context(
        cls,
        selection: SourceStemAuthoritySelection,
    ) -> SourceStemAuthority:
        """Build an authority after context selection."""
        del selection
        return cls()

    def required_source_stem(
        self,
        metadata: ImagePayloadMetadata,
        filename_identity: SourceImageIdentity | None = None,
    ) -> str:
        source_stem = SourceStemResolutionPolicy.for_context(
            metadata,
            error_subject="source-stem metadata resolution",
        ).source_stem(self, metadata, filename_identity)
        if source_stem is None:
            raise ValueError(
                "ROI source-stem path policy requires metadata.source_path or "
                "metadata.source_component_metadata."
            )
        return source_stem

    def source_replacement_suffix(
        self,
        path_name: str,
        metadata: ImagePayloadMetadata,
        reference_source_stem: str | None,
        reference_metadata: ImagePayloadMetadata | None,
    ) -> str | None:
        for source_stem in self.source_replacement_stems(
            path_name,
            metadata,
            reference_source_stem,
            reference_metadata,
        ):
            if path_name.startswith(source_stem):
                return path_name[len(source_stem) :]
        return None

    def source_replacement_stems(
        self,
        path_name: str,
        metadata: ImagePayloadMetadata,
        reference_source_stem: str | None,
        reference_metadata: ImagePayloadMetadata | None,
    ) -> tuple[str, ...]:
        del path_name, metadata, reference_metadata
        if reference_source_stem is None:
            return ()
        return (reference_source_stem,)

    @abstractmethod
    def source_component_metadata_stem(
        self,
        metadata: SourceComponentMetadata,
        filename_identity: SourceImageIdentity | None = None,
    ) -> str:
        """Return the source stem for component-addressed metadata."""


class SourceStemResolutionPolicy(
    MostDerivedContextStrategyMixin[ImagePayloadMetadata],
    ABC,
):
    """Resolve source-stem inputs through MRO precedence over payload metadata."""

    @abstractmethod
    def source_stem(
        self,
        authority: SourceStemAuthority,
        metadata: ImagePayloadMetadata,
        filename_identity: SourceImageIdentity | None,
    ) -> str | None:
        """Return this source-stem case's projection."""


class MissingSourceStemResolutionPolicy(
    AlwaysMatchesContextMixin[ImagePayloadMetadata],
    SourceStemResolutionPolicy,
):
    """No addressable source identity is present."""

    strategy_key = "missing"

    def source_stem(
        self,
        authority: SourceStemAuthority,
        metadata: ImagePayloadMetadata,
        filename_identity: SourceImageIdentity | None,
    ) -> str | None:
        del authority, metadata, filename_identity
        return None


class ComponentMetadataSourceStemResolutionPolicy(MissingSourceStemResolutionPolicy):
    """Component metadata is addressable through the selected source-stem authority."""

    strategy_key = "component_metadata"

    def matches(self, context: ImagePayloadMetadata) -> bool:
        return (
            context.source_provenance.scalar_source_identity.component_metadata
            is not None
        )

    def source_stem(
        self,
        authority: SourceStemAuthority,
        metadata: ImagePayloadMetadata,
        filename_identity: SourceImageIdentity | None,
    ) -> str:
        component_metadata = (
            metadata.source_provenance.scalar_source_identity.component_metadata
        )
        if component_metadata is None:
            raise ValueError(
                "Component metadata source-stem policy requires scalar "
                "source_component_metadata."
            )
        return authority.source_component_metadata_stem(
            component_metadata,
            filename_identity,
        )


class SourcePathSourceStemResolutionPolicy(ComponentMetadataSourceStemResolutionPolicy):
    """Source path identity has precedence over component-derived filenames."""

    strategy_key = "source_path"

    def matches(self, context: ImagePayloadMetadata) -> bool:
        return bool(context.source_provenance.scalar_source_identity.path)

    def source_stem(
        self,
        authority: SourceStemAuthority,
        metadata: ImagePayloadMetadata,
        filename_identity: SourceImageIdentity | None,
    ) -> str:
        del authority, filename_identity
        return source_path_identity(
            metadata.source_provenance.scalar_source_identity.path
        ).stem


@dataclass(frozen=True, slots=True)
class PathOnlySourceStemAuthority(
    AlwaysMatchesContextMixin[SourceStemAuthoritySelection],
    SourceStemAuthority,
):
    """Resolve ROI source stems when no filename parser exists in the context."""

    authority_key = "path_only"

    def source_component_metadata_stem(
        self,
        metadata: SourceComponentMetadata,
        filename_identity: SourceImageIdentity | None = None,
    ) -> str:
        del metadata, filename_identity
        raise ValueError(
            "Component-addressed ROI paths require a filename parser in the "
            "materialization context."
        )


@dataclass(frozen=True, slots=True)
class ParserBackedSourceStemAuthority(PathOnlySourceStemAuthority):
    """Resolve ROI source stems from paths or parser-readable component metadata."""

    authority_key = "parser_backed"
    parser: FilenameParser

    @classmethod
    def matches_context(
        cls,
        context: SourceStemAuthoritySelection,
    ) -> bool:
        return context.parser is not None

    @classmethod
    def build_for_context(
        cls,
        context: SourceStemAuthoritySelection,
    ) -> ParserBackedSourceStemAuthority:
        return cls(parser=context.required_parser())

    def source_replacement_stems(
        self,
        path_name: str,
        metadata: ImagePayloadMetadata,
        reference_source_stem: str | None,
        reference_metadata: ImagePayloadMetadata | None,
    ) -> tuple[str, ...]:
        prefix_metadata = metadata
        if reference_metadata is not None:
            prefix_metadata = reference_metadata

        return (
            *super(ParserBackedSourceStemAuthority, self).source_replacement_stems(
                path_name,
                metadata,
                reference_source_stem,
                reference_metadata,
            ),
            *self.path_component_prefix_stems(path_name, prefix_metadata),
        )

    def path_component_prefix_stems(
        self,
        path_name: str,
        metadata: ImagePayloadMetadata,
    ) -> tuple[str, ...]:
        component_metadata = (
            metadata.source_provenance.scalar_source_identity.component_metadata
        )
        if component_metadata is None:
            return ()

        return tuple(
            SourceComponentMetadataStemAuthority(self.parser).stem(
                parsed.wire_mapping()
            )
            for extension in self.path_parse_extensions(metadata)
            for parsed in (self.parser.parse_filename(f"{path_name}{extension}"),)
            if parsed is not None
            and self.parsed_components_match_metadata(parsed, component_metadata)
        )

    def path_parse_extensions(self, metadata: ImagePayloadMetadata) -> tuple[str, ...]:
        source_identity = metadata.source_provenance.scalar_source_identity
        extension = source_identity.filename_extension
        if extension is None:
            extension = source_identity.with_parsed_path_components(
                self.parser
            ).filename_extension
        return () if extension is None else (extension,)

    @staticmethod
    def parsed_components_match_metadata(
        parsed: FilenameParseResult,
        metadata: SourceComponentMetadata,
    ) -> bool:
        return all(
            component.value in metadata
            and ParserBackedSourceStemAuthority.component_values_match(
                parsed_value,
                metadata[component.value],
            )
            for component, parsed_value in parsed.declared_values()
        )

    @staticmethod
    def component_values_match(
        left: MaterializationValue,
        right: MaterializationValue,
    ) -> bool:
        return left == right or str(left) == str(right)

    def source_component_metadata_stem(
        self,
        metadata: SourceComponentMetadata,
        filename_identity: SourceImageIdentity | None = None,
    ) -> str:
        if filename_identity is not None:
            metadata = (
                SourceImageIdentity(
                    component_metadata=metadata,
                )
                .with_missing_from(filename_identity)
                .component_metadata
            )
            if metadata is None:
                raise RuntimeError(
                    "Filename identity resolution lost source component metadata."
                )
        return SourceComponentMetadataStemAuthority(self.parser).stem(
            metadata,
        )


@dataclass(frozen=True, slots=True)
class ROIMaterializationArchiveIdentity:
    """Archive path plus stream-visible source identity for one ROI output."""

    path: str
    source_identity: SourceImageIdentity | None = None

    @classmethod
    def from_metadata(
        cls,
        *,
        path: str,
        metadata: ImagePayloadMetadata | None,
    ) -> ROIMaterializationArchiveIdentity:
        return cls(
            path=path,
            source_identity=(
                None
                if metadata is None
                else metadata.source_provenance.scalar_source_identity
            ),
        )

    @property
    def component_address_identity(self) -> SourceComponentIdentity | None:
        if self.source_identity is None:
            return None
        return self.source_identity.identity[1]

    @property
    def source_stem_identity(self) -> str | None:
        if self.source_identity is None:
            return None
        if self.component_address_identity is not None:
            return None
        source_path = self.source_identity.path
        if source_path:
            return source_path_identity(source_path).stem
        return None

    @property
    def source_component_metadata(self) -> SourceComponentMetadata | None:
        if self.source_identity is None:
            return None
        return self.source_identity.component_metadata

    @property
    def source_identity_completeness(self) -> tuple[bool, bool]:
        """Rank stream identities by how much source identity they preserve."""
        return (
            self.source_identity is not None,
            self.component_address_identity is not None,
        )

    def compatible_with(
        self,
        other: ROIMaterializationArchiveIdentity,
    ) -> bool:
        if self.path != other.path:
            return False
        if self.source_identity is None or other.source_identity is None:
            return True
        if (
            self.component_address_identity is not None
            and other.component_address_identity is not None
        ):
            return self.component_address_identity == other.component_address_identity
        if (
            self.source_stem_identity is not None
            and other.source_stem_identity is not None
        ):
            return self.source_stem_identity == other.source_stem_identity
        return True

    def merge_with(
        self,
        other: ROIMaterializationArchiveIdentity,
    ) -> ROIMaterializationArchiveIdentity:
        self._require_compatible(other)
        return max(
            (self, other),
            key=lambda identity: identity.source_identity_completeness,
        )

    def _require_compatible(
        self,
        other: ROIMaterializationArchiveIdentity,
    ) -> None:
        if self.compatible_with(other):
            return
        raise ValueError(
            "ROI materialization produced conflicting stream identities for "
            f"archive path {self.path!r}."
        )


@dataclass(frozen=True, slots=True)
class ROIMaterializationTarget:
    """One ROI archive output with the label planes it owns."""

    archive: ROIMaterializationArchiveIdentity
    items: tuple[MaterializationInputItem, ...]

    def with_archive_source_identity(
        self,
        source_identity: SourceImageIdentity,
    ) -> ROIMaterializationTarget:
        return type(self)(
            archive=ROIMaterializationArchiveIdentity(
                path=self.archive.path,
                source_identity=source_identity,
            ),
            items=self.items,
        )

    def merge_with(
        self,
        other: ROIMaterializationTarget,
    ) -> ROIMaterializationTarget:
        return ROIMaterializationTarget(
            archive=self.archive.merge_with(other.archive),
            items=self.items + other.items,
        )


ROIMaterializationTargets = tuple[ROIMaterializationTarget, ...]


@dataclass(frozen=True, slots=True)
class ROIPathAuthority:
    """Name addressable ROI archives from source metadata."""

    source_stem_authority: SourceStemAuthority

    @classmethod
    def from_processing_context(
        cls,
        context: ProcessingContext | None,
    ) -> ROIPathAuthority:
        return cls(SourceStemAuthority.from_processing_context(context))

    def path(
        self,
        *,
        paths: PathHelper,
        options: ROIOptions,
        metadata: ImagePayloadMetadata,
        filename_identity: SourceImageIdentity | None,
        reference_source_stem: str | None,
        reference_metadata: ImagePayloadMetadata | None,
    ) -> str:
        source_stem = self.source_stem_authority.required_source_stem(
            metadata,
            filename_identity,
        )
        suffix = self.source_stem_authority.source_replacement_suffix(
            paths.name,
            metadata,
            reference_source_stem,
            reference_metadata,
        )
        if suffix is not None:
            path = str(paths.parent / f"{source_stem}{suffix}{options.roi_suffix}")
        else:
            path = str(paths.parent / f"{paths.name}_{source_stem}{options.roi_suffix}")
        if not path:
            raise RuntimeError("ROI path authority produced an empty path.")
        return path


@dataclass(frozen=True, slots=True)
class ROIRequestBase(ROIPathAuthority):
    """Shared ROI materialization request facts."""

    paths: PathHelper
    options: ROIOptions


@dataclass(frozen=True, slots=True)
class ROIMaterializationTargetRequest(ROIRequestBase):
    """Input facts needed to derive ROI archive targets."""

    materialization_input: MaterializationInput
    artifact_source_identity: SourceImageIdentity | None = None
    artifact_filename_identity: SourceImageIdentity | None = None
    output_plan: ArtifactOutputPlan | None = None
    pipeline_position: int | None = None

    @classmethod
    def from_context(
        cls,
        data: MaterializationValue,
        options: ROIOptions,
        context: MaterializationContext,
    ) -> ROIMaterializationTargetRequest:
        return cls(
            paths=context.paths(options),
            options=options,
            source_stem_authority=SourceStemAuthority.from_processing_context(
                context.context
            ),
            materialization_input=MaterializationInput.from_runtime_slice_projected_value(
                data, options
            ),
            artifact_source_identity=context.artifact_source_identity,
            artifact_filename_identity=context.artifact_filename_identity,
            output_plan=context.output_plan,
            pipeline_position=context.pipeline_position,
        )

    @property
    def summary_path(self) -> str:
        return self.paths.related_output_path(self.options, self.options.summary_suffix)

    def projected_path(
        self,
        *,
        metadata: ImagePayloadMetadata,
        reference_source_stem: str | None,
        reference_metadata: ImagePayloadMetadata | None,
    ) -> str:
        """Name one projected plane from its source and compiled artifact identity."""

        if self.output_plan is None or self.pipeline_position is None:
            return self.path(
                paths=self.paths,
                options=self.options,
                metadata=metadata,
                filename_identity=self.artifact_filename_identity,
                reference_source_stem=reference_source_stem,
                reference_metadata=reference_metadata,
            )
        source_stem = self.source_stem_authority.required_source_stem(
            metadata,
            self.artifact_filename_identity,
        )
        return str(
            self.paths.parent
            / (
                f"{source_stem}_{self.output_plan.name}"
                f"_step{self.pipeline_position}{self.options.roi_suffix}"
            )
        )

    @property
    def source_identity_set(self) -> ROIPlaneSourceIdentitySet:
        return ROIPlaneSourceIdentitySet(self.materialization_input)

    @property
    def requires_projected_targeting(self) -> bool:
        return self.source_identity_set.requires_projected_targeting


@dataclass(frozen=True, slots=True)
class MaterializationInput:
    """Normalized writer input with data and metadata from one authority."""

    items: tuple[MaterializationInputItem, ...]
    unprojected_items: tuple[MaterializationInputItem, ...] = ()
    sequence_type: type | None = None
    source_plane_projection: SourcePlaneProjectionContract = field(
        default_factory=SourcePlaneProjectionContract
    )

    @classmethod
    def from_value(
        cls,
        value: MaterializationValue,
        options: SourceOptions,
    ) -> MaterializationInput:
        projected = MaterializationSourceProjection.from_source(options.source).project(
            value
        )
        source_payloads = _materialization_sequence(projected)
        items = tuple(
            MaterializationInputItem(
                value=item,
                source_description="materialization payload",
            )
            for item in source_payloads
        )
        return cls(
            items=items,
            unprojected_items=items,
            sequence_type=_materialization_sequence_type(projected),
        )

    @classmethod
    def from_runtime_slice_projected_value(
        cls,
        value: MaterializationValue,
        options: SourceOptions,
    ) -> MaterializationInput:
        projected = MaterializationSourceProjection.from_source(options.source).project(
            value
        )
        source_payloads = _materialization_sequence(projected)
        return cls(
            items=tuple(
                MaterializationInputItem(
                    value=item.value,
                    source_description=item.source_description,
                    runtime_plane_metadata=item.runtime_plane_metadata,
                )
                for source_payload in source_payloads
                for item in (
                    RuntimeProjectionSourceIdentityRequirement.OPTIONAL
                ).project_payload_items(
                    RuntimeProjectionSourceIdentityRequest(
                        value=source_payload,
                        source_description="materialization payload",
                        plane_projection=(
                            source_payload.declared_plane_projection()
                            if isinstance(source_payload, ObjectLabelValue)
                            else None
                        ),
                    )
                )
            ),
            unprojected_items=tuple(
                MaterializationInputItem(
                    value=source_payload,
                    source_description="materialization payload",
                )
                for source_payload in source_payloads
            ),
            sequence_type=_materialization_sequence_type(projected),
            source_plane_projection=SourcePlaneProjectionContract.from_payloads(
                source_payloads
            ),
        )

    @classmethod
    def from_image_value(
        cls,
        value: MaterializationValue,
        options: SourceOptions,
    ) -> "MaterializationInput":
        """Preserve intrinsic images while projecting ordinary runtime planes."""
        unprojected = cls.from_value(value, options)
        items = []
        for image in unprojected.items:
            if image.metadata.persists_whole_image():
                items.append(image)
            else:
                items.extend(
                    MaterializationInputItem(
                        value=item.value,
                        source_description=item.source_description,
                        runtime_plane_metadata=item.runtime_plane_metadata,
                    )
                    for item in (
                        RuntimeProjectionSourceIdentityRequirement.OPTIONAL
                    ).project_payload_items(
                        RuntimeProjectionSourceIdentityRequest(
                            value=image.value,
                            source_description=image.source_description,
                            plane_projection=(
                                image.value.declared_plane_projection()
                                if isinstance(image.value, ObjectLabelValue)
                                else None
                            ),
                        )
                    )
                )
        return replace(
            unprojected,
            items=tuple(items),
            source_plane_projection=SourcePlaneProjectionContract.from_payloads(
                tuple(item.value for item in unprojected.items)
            ),
        )

    @property
    def data(self) -> MaterializationValue:
        data_items = [item.data for item in self.items]
        if self.sequence_type is None:
            if not data_items:
                return None
            return data_items[0]
        return self.sequence_type(data_items)


class PathSuffixes:
    """Filename suffixes recognized by materialization path normalization."""

    ROI_ZIP: ClassVar[str] = ".roi.zip"
    ROI: ClassVar[str] = ".roi"
    PKL: ClassVar[str] = ".pkl"


class PathHelper:
    """Path helper parameterized by output options."""

    def __init__(self, base_path: str, options: FileOutputOptions):
        self.base_path = self._strip_path(base_path, options)
        self.parent = self.base_path.parent
        self.name = self.base_path.name

    @staticmethod
    def _strip_path(path: str, options: FileOutputOptions) -> Path:
        return Path(
            _cached_stripped_materialization_path(
                path,
                options.strip_pkl,
                options.strip_roi_suffix,
            )
        )

    def with_suffix(self, suffix: str) -> str:
        return str(self.parent / f"{self.name}{suffix}")

    def source_identity_base_path(self, options: FileOutputOptions) -> Path | None:
        """Return the source-identity base path when it already names this output."""
        suffix = options.primary_output_suffix
        if (
            options.filename_identity is MaterializedFilenameIdentity.SOURCE_IDENTITY
            and suffix
            and self.base_path.name.endswith(suffix)
        ):
            return self.base_path
        return None

    def primary_output_path(self, options: FileOutputOptions) -> str:
        """Return a writer output path, preserving matching source-identity paths."""
        source_path = self.source_identity_base_path(options)
        if source_path is not None:
            return str(source_path)
        return self.with_suffix(options.primary_output_suffix)

    def primary_output_basename(self, options: FileOutputOptions) -> str:
        """Return basename for derived outputs from the same writer."""
        source_path = self.source_identity_base_path(options)
        if source_path is None:
            return self.name
        return source_path.name[: -len(options.primary_output_suffix)]

    def related_output_path(
        self,
        options: FileOutputOptions,
        related_suffix: str,
    ) -> str:
        """Return a side output path sharing the primary output basename."""
        return str(
            self.parent / f"{self.primary_output_basename(options)}{related_suffix}"
        )

    def patterned_output_path(
        self,
        options: FileOutputOptions,
        pattern: str,
        *,
        index: int,
        preserve_single_source_output: bool = False,
    ) -> str:
        """Return an indexed output path using this writer's primary basename."""
        source_path = self.source_identity_base_path(options)
        if preserve_single_source_output and source_path is not None:
            return str(source_path)
        return str(
            self.parent
            / f"{self.primary_output_basename(options)}{pattern.format(index=index)}"
        )


@lru_cache(maxsize=65536)
def _cached_stripped_materialization_path(
    path: str,
    strip_pkl: bool,
    strip_roi_suffix: bool,
) -> str:
    """Return a materialization base path stripped according to writer flags."""
    p = Path(path)
    name = p.name

    name = name.removesuffix(PathSuffixes.ROI_ZIP)

    if strip_pkl and name.endswith(PathSuffixes.PKL):
        name = name[: -len(PathSuffixes.PKL)]
    if strip_roi_suffix and name.endswith(PathSuffixes.ROI):
        name = name[: -len(PathSuffixes.ROI)]

    return str(p.with_name(name))


class MaterializationCandidatePathAuthority:
    """Project writer options to the output paths a backend may see."""

    @staticmethod
    def single_output(options: FileOutputOptions, base_path: str) -> tuple[str, ...]:
        paths = PathHelper(base_path, options)
        return (paths.primary_output_path(options),)


class ROICandidatePathAuthority:
    """Candidate paths emitted by ROI materialization."""

    @staticmethod
    def paths(options: FileOutputOptions, base_path: str) -> tuple[str, ...]:
        if not isinstance(options, ROIOptions):
            raise TypeError(
                "ROICandidatePathAuthority requires ROIOptions, "
                f"got {options.__class__.__name__}."
            )
        paths = PathHelper(base_path, options)
        return (
            paths.primary_output_path(options),
            paths.related_output_path(options, options.summary_suffix),
        )


class TiffStackCandidatePathAuthority:
    """Candidate paths emitted by TIFF stack materialization."""

    @staticmethod
    def paths(options: FileOutputOptions, base_path: str) -> tuple[str, ...]:
        if not isinstance(options, TiffStackOptions):
            raise TypeError(
                "TiffStackCandidatePathAuthority requires TiffStackOptions, "
                f"got {options.__class__.__name__}."
            )
        paths = PathHelper(base_path, options)
        return (
            paths.patterned_output_path(
                options,
                options.slice_pattern,
                index=0,
                preserve_single_source_output=True,
            ),
            paths.related_output_path(options, options.summary_suffix),
        )


def _tiff_stack_slice_path(
    paths: PathHelper,
    options: TiffStackOptions,
    *,
    index: int,
    slice_count: int,
) -> str:
    return paths.patterned_output_path(
        options,
        options.slice_pattern,
        index=index,
        preserve_single_source_output=slice_count == 1,
    )


def _tiff_stack_summary_path(paths: PathHelper, options: TiffStackOptions) -> str:
    return paths.related_output_path(options, options.summary_suffix)


class WriteModePathPolicy(ABC, metaclass=AutoRegisterMeta):
    """Apply existing-path policy for one write mode."""

    __registry_key__ = "write_mode"
    __skip_if_no_key__ = True

    write_mode: ClassVar[WriteMode | None] = None

    @abstractmethod
    def prepare_existing_path(
        self, saver: BackendSaver, backend: str, path: str
    ) -> None:
        """Prepare an already-existing backend path before saving."""


class OverwritePathPolicy(WriteModePathPolicy):
    write_mode = WriteMode.OVERWRITE

    def prepare_existing_path(
        self, saver: BackendSaver, backend: str, path: str
    ) -> None:
        saver.filemanager.delete(path, backend)


class ErrorPathPolicy(WriteModePathPolicy):
    write_mode = WriteMode.ERROR

    def prepare_existing_path(
        self, saver: BackendSaver, backend: str, path: str
    ) -> None:
        raise FileExistsError(
            f"Refusing to overwrite existing path: {path} ({backend})"
        )


@dataclass(frozen=True, slots=True)
class ViewerStreamBackendCallKwargs(BackendCallKwargs):
    """Viewer stream kwargs with per-output component metadata applied in-band."""

    backend_kwargs_kind = "viewer_stream"
    values: ViewerStreamBackendKwargs

    def to_filemanager_kwargs(
        self,
        output: Output,
    ) -> dict:
        projected_outputs = self.projected_outputs((output,))
        if len(projected_outputs) != 1 or projected_outputs[0] is not output:
            raise ValueError("Projected viewer materialization requires batch saving.")
        output_fields = self._output_fields(projected_outputs[0])
        if output_fields is None:
            return self.values.to_kwargs()
        component_metadata, item_fields, display_config = output_fields
        return self._stream_kwargs(display_config, item_fields).with_single_item_source(
            component_metadata,
            item_fields,
        ).to_kwargs()

    def _stream_kwargs(
        self,
        display_config: ViewerDisplayConfigABC,
        item_fields: Mapping[str, ViewerWireValue],
    ) -> ViewerStreamBackendKwargs:
        """Apply one source-owned display scope to the original typed request."""
        request = self.values.with_item_fields(item_fields).stream_request
        return ViewerStreamBackendKwargs(replace(request, display_config=display_config))

    def filemanager_batches(
        self,
        outputs: Sequence[Output],
    ) -> tuple[tuple[tuple[Output, ...], dict], ...]:
        grouped: list[
            tuple[
                dict[str, ViewerWireValue],
                ViewerDisplayConfigABC,
                list[Output],
                list[dict[str, MaterializationValue]],
            ]
        ] = []
        unprojected_outputs: list[Output] = []
        for output in self.projected_outputs(outputs):
            output_fields = self._output_fields(output)
            if output_fields is None:
                unprojected_outputs.append(output)
                continue
            component_metadata, item_fields, display_config = output_fields
            group = next(
                (candidate for candidate in grouped
                 if candidate[0] == item_fields and candidate[1] == display_config),
                None,
            )
            if group is None:
                group = (item_fields, display_config, [], [])
                grouped.append(group)
            group[2].append(output)
            group[3].append(component_metadata)

        batches: list[tuple[tuple[Output, ...], dict]] = []
        if unprojected_outputs:
            batches.append((tuple(unprojected_outputs), self.values.to_kwargs()))
        for item_fields, display_config, batch_outputs, component_metadata in grouped:
            metadata_by_path = dict(
                zip(
                    (output.path for output in batch_outputs),
                    component_metadata,
                    strict=True,
                )
            )
            if len(metadata_by_path) != len(batch_outputs):
                raise ValueError(
                    "Viewer materialization batch requires unique output paths."
                )
            stream_request = self._stream_kwargs(display_config, item_fields).stream_request
            stream_request = replace(
                stream_request,
                source=replace(
                    stream_request.source,
                    metadata=PathMappedViewerStreamSourceMetadata(
                        metadata_by_path=metadata_by_path
                    ),
                ),
            )
            batches.append(
                (
                    tuple(batch_outputs),
                    ViewerStreamBackendKwargs(stream_request).to_kwargs(),
                )
            )
        return tuple(batches)

    def projected_outputs(self, outputs: Sequence[Output]) -> tuple[Output, ...]:
        """Derive stream items without changing persisted aggregate outputs."""
        result: list[Output] = []
        display_semantics = self.values.stream_request.display_semantics
        parser = self.values.stream_request.source.identity.microscope_handler.parser
        for output in outputs:
            if output.metadata is None:
                result.append(output)
                continue
            items = StreamImagePayloadMetadataProjector.payload_items_for_display(
                output.content,
                metadata=output.metadata,
                plane_components=output.variable_components,
                component_modes=display_semantics.component_modes,
                source_description=output.path,
            )
            if len(items) == 1 and items[0].value is output.content:
                result.append(output)
                continue
            output_path = Path(output.path)
            for item in items:
                identity = FunctionOutputIdentity.from_metadata(
                    parser,
                    item.metadata,
                    fallback_identity_path=output.path,
                )
                if identity is None:
                    raise ValueError("Projected viewer output requires a filename identity.")
                identity = replace(identity, extension=output_path.suffix)
                filename = identity.with_filename_qualifier(output_path.stem).filename(parser)
                result.append(
                    replace(
                        output,
                        path=str(output_path.parent / filename),
                        content=item.data,
                        metadata=item.metadata,
                    )
                )
        return tuple(result)

    def _output_fields(
        self,
        output: Output,
    ) -> tuple[
        dict[str, MaterializationValue],
        dict[str, ViewerWireValue],
        ViewerDisplayConfigABC,
    ] | None:
        source_identity = output.source_identity
        if source_identity is not None:
            source_identity = source_identity.with_parsed_path_components(
                self.values.stream_request.source.identity.microscope_handler.parser
            )
        component_metadata = (
            source_identity.component_metadata if source_identity is not None else None
        )
        if component_metadata is None:
            if not output.viewer_stream_requires_source_metadata:
                return None
            raise ValueError(
                "Viewer stream materialization requires output metadata with "
                "source_component_metadata."
            )
        item_fields = (
            StreamImagePayloadMetadataProjector.item_fields_for_plane_components(
                output.metadata,
                output.variable_components,
            )
        )
        display_config = output.viewer_display_config(
            self.values.stream_request.display_config
        )
        projected_metadata = StreamViewerComponentMetadataProjector.for_item_fields(
            display_config.COMPONENT_ORDER,
            item_fields,
        ).project_required(index=0, metadata=component_metadata)
        return projected_metadata, item_fields, display_config


EMPTY_BACKEND_CALL_KWARGS = RawBackendKwargs()


class BackendSaver:
    """Centralized multi-backend saving."""

    def __init__(
        self,
        backends: list[str],
        filemanager: FileManager,
        backend_kwargs: NormalizedBackendKwargs,
        *,
        write_mode: WriteMode,
    ):
        self.backends = backends
        self.filemanager = filemanager
        self.backend_kwargs = backend_kwargs
        self.write_mode = write_mode

    def save_all(
        self,
        outputs: Sequence[Output],
    ) -> Mapping[str, tuple[Output, ...]]:
        saved_outputs: dict[str, tuple[Output, ...]] = {}
        for backend in self.backends:
            backend_instance = self.filemanager._get_backend(backend)
            output_acceptance = tuple(
                (
                    output,
                    backend_instance.accepts_payload(output.content, output.path),
                )
                for output in outputs
            )
            supported_outputs = tuple(
                output for output, accepted in output_acceptance if accepted
            )
            skipped_outputs = tuple(
                output for output, accepted in output_acceptance if not accepted
            )
            for output in skipped_outputs:
                logger.info(
                    "Skipping backend %s for unsupported materialization path %s",
                    backend,
                    output.path,
                )
            for output in supported_outputs:
                self._prepare_path(backend, backend_instance, output.path)
            if not supported_outputs:
                continue
            if backend in self.backend_kwargs:
                kwargs_payload = self.backend_kwargs[backend]
            else:
                kwargs_payload = EMPTY_BACKEND_CALL_KWARGS
            written_outputs: list[Output] = []
            for batch_outputs, kwargs in kwargs_payload.filemanager_batches(
                supported_outputs
            ):
                self.filemanager.save_batch(
                    [output.content for output in batch_outputs],
                    [output.path for output in batch_outputs],
                    backend,
                    **kwargs,
                )
                written_outputs.extend(batch_outputs)
            saved_outputs[backend] = tuple(written_outputs)
        return saved_outputs

    def _prepare_path(self, backend: str, backend_instance, path: str) -> None:
        if not backend_instance.requires_filesystem_validation:
            return

        self.filemanager.ensure_directory(
            str(source_path_identity(path).parent), backend
        )

        if not self.filemanager.exists(path, backend):
            return

        WriteModePathPolicy.__registry__[self.write_mode]().prepare_existing_path(
            self,
            backend,
            path,
        )


@dataclass(frozen=True)
class MaterializationContext:
    base_path: str
    backends: list[str]
    backend_kwargs: NormalizedBackendKwargs
    filemanager: FileManager
    extra_inputs: dict
    context: ProcessingContext | None = None
    artifact_source_identity: SourceImageIdentity | None = None
    artifact_filename_identity: SourceImageIdentity | None = None
    variable_components: Sequence[VariableComponents] = field(default_factory=tuple)
    write_mode: WriteMode = WriteMode.OVERWRITE
    source_paths: tuple[str, ...] = ()
    pipeline_position: int | None = None
    output_plan: ArtifactOutputPlan | None = None
    materialization_spec: MaterializationSpec | None = None

    def named_source_filename(
        self, metadata: ImagePayloadMetadata, extension: str,
    ) -> str | None:
        """Name a retained image from the actual rendering purpose and role."""
        if self.materialization_spec is None:
            return None
        qualifier = self.materialization_spec.filename_qualifier(self.output_plan)
        if qualifier is None:
            return None
        parser = SourceStemAuthoritySelection.from_processing_context(self.context).required_parser()
        identity = FunctionOutputIdentity.from_filename_metadata(parser, metadata)
        if identity is None:
            raise ValueError("Retained image output has no addressable source filename identity.")
        identity = self.materialization_spec.filename_identity_for_output(
            replace(identity, extension=extension), self.output_plan,
        )
        return identity.filename(parser)

    def paths(self, options: FileOutputOptions) -> PathHelper:
        return PathHelper(self.base_path, options)

    @property
    def saver(self) -> BackendSaver:
        return BackendSaver(
            self.backends,
            self.filemanager,
            self.backend_kwargs,
            write_mode=self.write_mode,
        )


OutputPathProjection: TypeAlias = Callable[
    [MaterializationValue, FileOutputOptions, MaterializationContext], tuple[str, ...]
]


@dataclass(frozen=True)
class WriterSpec:
    format: MaterializationFormat
    options_type: type
    write: WriterFunction
    primary_path: PrimaryPathSelector
    candidate_paths: CandidatePathSelector
    output_path_projection: OutputPathProjection | None = None

    def outputs(
        self,
        data: MaterializationValue,
        options: FileOutputOptions,
        context: MaterializationContext,
        output_path_filter: Callable[[Path], bool] | None,
    ) -> tuple[Output, ...]:
        """Skip rendering only when declared runtime paths prove it unnecessary."""
        if (
            output_path_filter is not None
            and self.output_path_projection is not None
            and not any(
                output_path_filter(Path(path))
                for path in self.output_path_projection(data, options, context)
            )
        ):
            return ()
        return tuple(
            output
            for output in self.write(data, options, context)
            if output_path_filter is None or output_path_filter(Path(output.path))
        )


WriterFunction = Callable
_WRITERS_BY_OPTIONS: dict[type, WriterSpec] = {}


def registered_materialization_option_types() -> tuple[type[FileOutputOptions], ...]:
    """Return writer option declarations from the authoritative writer registry."""

    return tuple(_WRITERS_BY_OPTIONS)


class PrimaryPathAuthority:
    """Resolve the primary materialized path for writer outputs."""

    @staticmethod
    def first_output_path(outs: list[Output]) -> str:
        if outs:
            return outs[0].path
        return ""


class BackendKwargsAuthority:
    """Normalize absent/present backend kwargs variants."""

    @staticmethod
    def normalize(backend_kwargs: BackendKwargsInput) -> NormalizedBackendKwargs:
        if isinstance(backend_kwargs, BackendKwargsAbsent):
            return {}
        return {
            backend: BackendKwargsAuthority.normalize_value(value)
            for backend, value in backend_kwargs.items()
        }

    @staticmethod
    def normalize_value(value: BackendKwargsValue) -> BackendCallKwargs:
        if isinstance(value, BackendCallKwargs):
            return value
        return RawBackendKwargs(dict(value))


def writer_for(
    options_type: type,
    fmt: MaterializationFormat,
    *,
    primary_path: PrimaryPathSelector | None = None,
    candidate_paths: CandidatePathSelector | None = None,
    output_path_projection: OutputPathProjection | None = None,
):
    """Register a writer for a given options type.

    This is intentionally metaprogramming-friendly: adding a new format is
    defining one options dataclass and one function.
    """

    def decorator(fn: WriterFunction):
        if options_type in _WRITERS_BY_OPTIONS:
            raise ValueError(
                f"Writer already registered for options type {options_type.__name__}"
            )
        selected_primary_path = primary_path
        if selected_primary_path is None:
            selected_primary_path = PrimaryPathAuthority.first_output_path
        selected_candidate_paths = candidate_paths
        if selected_candidate_paths is None:
            selected_candidate_paths = (
                MaterializationCandidatePathAuthority.single_output
            )
        _WRITERS_BY_OPTIONS[options_type] = WriterSpec(
            format=fmt,
            options_type=options_type,
            write=fn,
            primary_path=selected_primary_path,
            candidate_paths=selected_candidate_paths,
            output_path_projection=output_path_projection,
        )
        return fn

    return decorator


@singledispatch
def tabular_rows_from_payload(
    data: MaterializationValue,
    options: TabularExtractionOptions,
) -> TabularRows | None:
    del data, options
    return None


@tabular_rows_from_payload.register(pd.DataFrame)
def dataframe_tabular_rows(
    data: pd.DataFrame,
    options: TabularExtractionOptions,
) -> TabularRows:
    del options
    return TabularRows(TabularRow(dict(row)) for row in data.to_dict(orient="records"))


@tabular_rows_from_payload.register(pd.Series)
def series_tabular_rows(
    data: pd.Series,
    options: TabularExtractionOptions,
) -> TabularRows:
    del options
    return TabularRows((TabularRow(dict(data.to_dict())),))


@tabular_rows_from_payload.register(ColumnarRows)
def columnar_rows_tabular_rows(
    data: ColumnarRows,
    options: TabularExtractionOptions,
) -> TabularRows:
    del options
    return TabularRows(TabularRow(dict(row)) for row in data.row_mappings())


def _mapping_column_length(value: MaterializationValue) -> int | None:
    """Return row count for a mapping value that behaves like a table column."""
    if isinstance(value, Mapping):
        return None
    if isinstance(value, (str, bytes, bytearray)):
        return None
    shape = getattr(value, "shape", None)
    if shape:
        return int(shape[0])
    if isinstance(value, Sequence):
        return len(value)
    try:
        return len(value)  # type: ignore[arg-type]
    except TypeError:
        return None


def _mapping_column_value(
    value: MaterializationValue,
    row_index: int,
) -> MaterializationValue:
    """Return one row value from a column-like mapping value."""
    length = _mapping_column_length(value)
    if length is None:
        return value
    if row_index >= length:
        return value
    return value[row_index]  # type: ignore[index]


@tabular_rows_from_payload.register(Mapping)
def mapping_tabular_rows(
    data: Mapping,
    options: TabularExtractionOptions,
) -> TabularRows:
    """Project mapping-of-columns payloads into row mappings."""
    columns = {str(column): value for column, value in data.items()}
    field_names = tuple(options.fields) if options.fields else tuple(columns)
    column_lengths = tuple(
        length
        for field_name in field_names
        if field_name in columns
        for length in (_mapping_column_length(columns[field_name]),)
        if length is not None
    )
    row_count = max(column_lengths) if column_lengths else 1
    rows = TabularRows()
    for row_index in range(row_count):
        row = TabularRow(
            {
                field_name: _mapping_column_value(columns[field_name], row_index)
                for field_name in field_names
                if field_name in columns
            }
        )
        if TabularRowsAuthority.should_add_slice_index(row, options.fields):
            row[TabularRowsAuthority.SLICE_INDEX_FIELD] = row_index
        rows.append(row)
    return rows


class TabularRowsAuthority:
    """Build canonical tabular rows for CSV and JSON materialization."""

    SLICE_INDEX_FIELD: ClassVar[str] = "slice_index"

    @staticmethod
    def requested(options: TabularExtractionOptions) -> bool:
        return bool(
            options.fields
            or options.row_field
            or options.row_unpacker
            or options.row_columns
        )

    @classmethod
    def build(
        cls,
        data: MaterializationValue,
        options: TabularExtractionOptions,
    ) -> TabularRows:
        direct_rows = tabular_rows_from_payload(data, options)
        if direct_rows is not None:
            return direct_rows

        rows = TabularRows()
        for idx, item in enumerate(_materialization_sequence(data)):
            base_row = cls.base_row(item, idx, options)

            if options.row_unpacker:
                for exp_row in options.row_unpacker(item):
                    rows.append(TabularRow({**base_row, **exp_row}))
                continue

            if options.row_field:
                array_data = FieldValueAuthority.value(item, options.row_field)
                rows.extend(
                    expanded_tabular_rows(array_data, base_row, options.row_columns)
                )
                continue

            rows.append(base_row)
        return rows

    @classmethod
    def base_row(
        cls,
        item: MaterializationValue,
        index: int,
        options: TabularExtractionOptions,
    ) -> TabularRow:
        field_names = options.fields
        base_row = tabular_row_from_payload(item, field_names)
        if cls.should_add_slice_index(base_row, field_names):
            base_row[cls.SLICE_INDEX_FIELD] = index
        return base_row

    @classmethod
    def should_add_slice_index(
        cls,
        base_row: Mapping,
        field_names: Sequence[str] | None,
    ) -> bool:
        return cls.SLICE_INDEX_FIELD not in base_row and (
            not field_names or cls.SLICE_INDEX_FIELD in field_names
        )


class FieldValueAuthority:
    """Resolve declared row fields through the shared materialization extractor."""

    @staticmethod
    def value(item: MaterializationValue, field_name: str) -> MaterializationValue:
        field_values = tabular_row_from_payload(item, (field_name,))
        if field_name in field_values:
            return field_values[field_name]
        return SourceSegmentAuthority.resolve(item, field_name)


def _render_csv(data: MaterializationValue, options: CsvOptions) -> str:
    if isinstance(data, pd.DataFrame):
        return data.to_csv(index=False)
    if isinstance(data, ColumnarRows):
        return _render_csv_rows(
            data.row_mappings(),
            tuple(field.name for field in data.fields),
        )

    if direct_rows := _direct_csv_mapping_rows(data, options):
        rows, fieldnames = direct_rows
        return _render_csv_rows(rows, fieldnames)
    if direct_object_rows := _direct_csv_object_rows(data, options):
        rows, fieldnames = direct_object_rows
        return _render_csv_object_rows(rows, fieldnames)

    rows = TabularRowsAuthority.build(data, options)
    if not rows and options.fields:
        return _render_csv_rows((), tuple(options.fields))
    if not rows:
        return pd.DataFrame(rows).to_csv(index=False)
    return _render_csv_rows(
        rows,
        CsvFieldnamesAuthority.fieldnames(rows, options.fields),
    )


def _direct_csv_mapping_rows(
    data: MaterializationValue,
    options: CsvOptions,
) -> tuple[Sequence[Mapping], tuple[str, ...]] | None:
    """Return existing mapping rows when generic extraction would be a no-op."""
    if options.row_unpacker is not None or options.row_field is not None:
        return None
    if not isinstance(data, (list, tuple)):
        return None
    if not data:
        if options.fields:
            return data, tuple(options.fields)
        return None
    first_row = data[0]
    if not isinstance(first_row, Mapping):
        return None

    fieldnames = CsvFieldnamesAuthority.fieldnames(data, options.fields)
    if (
        TabularRowsAuthority.SLICE_INDEX_FIELD in fieldnames
        and TabularRowsAuthority.SLICE_INDEX_FIELD not in first_row
    ):
        return None
    return data, fieldnames


def _direct_csv_object_rows(
    data: MaterializationValue,
    options: CsvOptions,
) -> tuple[Sequence, tuple[str, ...]] | None:
    """Return object rows when declared fields let us avoid dict materialization."""
    if (
        options.row_unpacker is not None
        or options.row_field is not None
        or not options.fields
        or not isinstance(data, (list, tuple))
    ):
        return None
    if not data:
        return data, tuple(options.fields)
    first_row = data[0]
    if isinstance(first_row, Mapping):
        return None
    if not CsvObjectRowAuthority.accepts(first_row):
        return None
    return data, tuple(options.fields)


def _render_csv_rows(
    rows: Sequence[Mapping],
    fieldnames: Sequence[str],
) -> str:
    output = io.StringIO()
    ordered_fieldnames = tuple(fieldnames)
    writer = csv.writer(output)
    writer.writerow(ordered_fieldnames)
    writer.writerows(
        tuple(row.get(fieldname) for fieldname in ordered_fieldnames) for row in rows
    )
    return output.getvalue()


def _render_csv_object_rows(
    rows: Sequence,
    fieldnames: Sequence[str],
) -> str:
    output = io.StringIO()
    ordered_fieldnames = tuple(fieldnames)
    writer = csv.writer(output)
    writer.writerow(ordered_fieldnames)
    writer.writerows(
        CsvObjectRowAuthority.values(row, ordered_fieldnames) for row in rows
    )
    return output.getvalue()


class CsvObjectRowAuthority:
    """Read declared fields from object rows without structural probing at write time."""

    @staticmethod
    def accepts(row: MaterializationValue) -> bool:
        return is_dataclass(row)

    @staticmethod
    def values(row: MaterializationValue, fieldnames: Sequence[str]) -> tuple:
        fields = tabular_row_from_payload(row, fieldnames)
        return tuple(
            CsvObjectRowAuthority.field_value(fields, fieldname)
            for fieldname in fieldnames
        )

    @staticmethod
    def field_value(fields: Mapping, fieldname: str) -> MaterializationValue:
        if fieldname in fields:
            return fields[fieldname]
        return None


class CsvFieldnamesAuthority:
    """Own CSV field order for direct and extracted row materialization."""

    @staticmethod
    def fieldnames(
        rows: Sequence[Mapping],
        declared_fields: Sequence[str] | None,
    ) -> tuple[str, ...]:
        if declared_fields is not None:
            return tuple(declared_fields)
        fieldnames: list[str] = []
        seen: set[str] = set()
        for row in rows:
            for fieldname in row:
                if fieldname in seen:
                    continue
                seen.add(fieldname)
                fieldnames.append(fieldname)
        return tuple(fieldnames)


def _render_json(data: MaterializationValue, options: JsonOptions) -> str:
    payload: MaterializationValue
    if TabularRowsAuthority.requested(options):
        payload = TabularRowsAuthority.build(data, options)
    else:
        payload = data

    if options.wrap_list and isinstance(payload, list):
        payload = {"total_items": len(payload), "results": payload}

    return json.dumps(JsonPayloadAuthority.jsonable(payload), indent=options.indent)


class JsonPayloadAuthority:
    """Convert materialized payloads into JSON-native values before encoding."""

    @classmethod
    def jsonable(cls, value: MaterializationValue) -> MaterializationValue:
        return json_payload_value(value)


@singledispatch
def json_payload_value(value: MaterializationValue) -> MaterializationValue:
    if supports_measurement_row_mapping(value):
        return {
            key: JsonPayloadAuthority.jsonable(item)
            for key, item in measurement_row_mapping(value).items()
        }
    return value


@json_payload_value.register(dict)
def json_payload_mapping(value: dict) -> dict:
    return {key: JsonPayloadAuthority.jsonable(item) for key, item in value.items()}


@json_payload_value.register(ColumnarRows)
def json_payload_columnar_rows(value: ColumnarRows) -> list[dict]:
    return [
        {key: JsonPayloadAuthority.jsonable(item) for key, item in row.items()}
        for row in value.iter_row_mappings()
    ]


@json_payload_value.register(list)
def json_payload_list(value: list) -> list:
    return [JsonPayloadAuthority.jsonable(item) for item in value]


@json_payload_value.register(tuple)
def json_payload_tuple(value: tuple) -> tuple:
    return tuple(JsonPayloadAuthority.jsonable(item) for item in value)


@json_payload_value.register(pd.DataFrame)
def json_payload_dataframe(value: pd.DataFrame) -> TabularRows:
    return TabularRows(TabularRow(dict(row)) for row in value.to_dict(orient="records"))


@json_payload_value.register(pd.Series)
def json_payload_series(value: pd.Series) -> dict:
    return value.to_dict()


@json_payload_value.register(np.generic)
def json_payload_numpy_scalar(value: np.generic) -> MaterializationValue:
    return value.item()


@json_payload_value.register(np.ndarray)
def json_payload_numpy_array(value: np.ndarray) -> list:
    return value.tolist()


class SingleFileWriterAuthority:
    """Create writers for formats that produce one file from one payload."""

    @staticmethod
    def writer(
        render: Callable,
        *,
        validate_payload: Callable | None = None,
    ) -> Callable:
        def write(
            data: MaterializationValue, options, ctx: MaterializationContext
        ) -> list[Output]:
            materialization_input = MaterializationInput.from_value(data, options)
            payload = materialization_input.data
            if validate_payload is not None:
                validate_payload(payload, options)
            return [
                TextOutput(
                    path=ctx.paths(options).primary_output_path(options),
                    content=render(payload, options),
                )
            ]

        return write


def register_single_file_writer(
    options_type: type,
    fmt: MaterializationFormat,
    *,
    render: Callable,
    validate_payload: Callable | None = None,
    primary_path: PrimaryPathSelector | None = None,
) -> None:
    writer_for(options_type, fmt, primary_path=primary_path)(
        SingleFileWriterAuthority.writer(render, validate_payload=validate_payload)
    )


register_single_file_writer(CsvOptions, MaterializationFormat.CSV, render=_render_csv)
register_single_file_writer(
    JsonOptions, MaterializationFormat.JSON, render=_render_json
)


class TextPayloadAuthority:
    """Validate text materialization payloads."""

    @staticmethod
    def validate(payload: MaterializationValue, options: TextOptions) -> None:
        del options
        if not isinstance(payload, str):
            raise TypeError(
                f"TextOptions expects a str payload, got {payload.__class__.__name__}"
            )


register_single_file_writer(
    TextOptions,
    MaterializationFormat.TEXT,
    render=lambda payload, _options: payload,
    validate_payload=TextPayloadAuthority.validate,
)


_NAMED_PATH_BACKREFERENCE = re.compile(r"\\g<(?P<name>[^>]+)>")
_PATH_TEMPLATE_FORMATTER = string.Formatter()


def _normalized_relative_materialization_path(value: object) -> PurePosixPath:
    """Validate and normalize one platform-neutral relative output path."""
    if not isinstance(value, str):
        raise TypeError("Materialization relative path must be a string.")
    if not value:
        raise ValueError("Materialization relative path cannot be empty.")
    if PurePosixPath(value).is_absolute() or PureWindowsPath(value).is_absolute():
        raise ValueError(f"Materialization path must be relative: {value!r}.")
    normalized = PurePosixPath(value.replace("\\", "/"))
    if ".." in normalized.parts:
        raise ValueError(
            f"Materialization relative path cannot traverse parents: {value!r}."
        )
    if str(normalized) in {"", "."}:
        raise ValueError("Materialization relative path cannot be empty.")
    return normalized


def _relative_materialization_output_path(
    base_path: str,
    relative_path: PurePosixPath,
) -> str:
    return str(Path(base_path).parent.joinpath(*relative_path.parts))


def _image_template_candidate_path(template: str) -> PurePosixPath:
    candidate = _NAMED_PATH_BACKREFERENCE.sub(
        lambda match: match.group("name"),
        template,
    )
    candidate = _format_image_sequence_index(candidate, 1)
    return _normalized_relative_materialization_path(candidate)


def _image_template_uses_source_metadata(template: str | None) -> bool:
    """Return whether one image path template requires per-item source metadata."""

    return (
        template is not None and _NAMED_PATH_BACKREFERENCE.search(template) is not None
    )


def _image_template_uses_sequence_index(template: str | None) -> bool:
    """Return whether one image path template declares per-item numbering."""

    if template is None:
        return False
    return any(
        field_name == "index"
        for _literal, field_name, _format_spec, _conversion in (
            _PATH_TEMPLATE_FORMATTER.parse(template)
        )
        if field_name is not None
    )


def _format_image_sequence_index(template: str, sequence_index: int) -> str:
    """Expand the sole generic per-item field accepted by image templates."""

    field_names = tuple(
        field_name
        for _literal, field_name, _format_spec, _conversion in (
            _PATH_TEMPLATE_FORMATTER.parse(template)
        )
        if field_name is not None
    )
    unsupported = tuple(
        field_name for field_name in field_names if field_name != "index"
    )
    if unsupported:
        raise ValueError(
            "Image materialization path template contains unsupported format "
            f"fields: {unsupported!r}."
        )
    return template.format(index=sequence_index)


def _image_relative_output_path(
    data: MaterializationValue,
    options: ImageFileOptions,
    context: MaterializationContext,
    *,
    sequence_index: int,
) -> str:
    if options.relative_path_template is None:
        return context.paths(options).primary_output_path(options)

    metadata = image_payload_metadata(data)
    source_identity = metadata.source_provenance.scalar_source_identity
    component_metadata = source_identity.component_metadata

    def replace_backreference(match: re.Match[str]) -> str:
        if component_metadata is None:
            raise ValueError(
                "Image materialization path template requires source component "
                f"metadata for {match.group('name')!r}."
            )
        value = source_metadata_value(component_metadata, match.group("name"))
        if value is None:
            raise ValueError(
                "Image materialization path template references undeclared source "
                f"metadata {match.group('name')!r}; available fields are "
                f"{tuple(component_metadata)!r}."
            )
        return value

    expanded = _NAMED_PATH_BACKREFERENCE.sub(
        replace_backreference,
        options.relative_path_template,
    )
    expanded = _format_image_sequence_index(expanded, sequence_index)
    relative_path = _normalized_relative_materialization_path(expanded)
    scoped_relative_path = options.relative_path_scope.project(
        relative_path,
        context.context,
    )
    return _relative_materialization_output_path(
        context.base_path,
        _normalized_relative_materialization_path(str(scoped_relative_path)),
    )


class ImageFileCandidatePathAuthority:
    """Project image-file options to their compile-time backend-routing path."""

    @staticmethod
    def paths(options: FileOutputOptions, base_path: str) -> tuple[str, ...]:
        if not isinstance(options, ImageFileOptions):
            raise TypeError(
                "ImageFileCandidatePathAuthority requires ImageFileOptions."
            )
        if options.relative_path_template is None:
            candidate = PathHelper(base_path, options).primary_output_path(options)
        else:
            candidate = _relative_materialization_output_path(
                base_path,
                _image_template_candidate_path(options.relative_path_template),
            )
        ImageFileFormat.require_path(candidate)
        return (candidate,)


@writer_for(
    ImageFileOptions,
    MaterializationFormat.IMAGE_FILE,
    candidate_paths=ImageFileCandidatePathAuthority.paths,
)
def write_image_file(
    data: MaterializationValue,
    options: ImageFileOptions,
    context: MaterializationContext,
) -> list[Output]:
    """Write image payloads through the nominal image serialization format."""
    materialization_input = MaterializationInput.from_image_value(
        data,
        options,
    )
    metadata_projection = RuntimePlaneStackAxisMetadataProjection(
        context.variable_components,
        context.artifact_source_identity,
    )
    projected_items = tuple(
        replace(
            item,
            value=metadata_projection.metadata_for_item(item).attach_to(item.value),
        )
        for item in materialization_input.items
    )
    if len(projected_items) > 1 and not materialization_emits_variable_component_planes(
        options, data
    ):
        projected_items = (
            MaterializationInputItem(
                value=data,
                source_description="materialization payload",
            ),
        )

    paths = context.paths(options)
    source_stem_authority = SourceStemAuthority.from_processing_context(context.context)
    preserves_planned_path = (
        options.filename_identity is MaterializedFilenameIdentity.ARTIFACT_NAME
        or paths.source_identity_base_path(options) is not None
    )
    outputs = []
    for sequence_index, item in enumerate(projected_items, start=1):
        if options.relative_path_template is not None:
            path = _image_relative_output_path(
                item.value, options, context, sequence_index=sequence_index,
            )
        elif preserves_planned_path:
            path = paths.primary_output_path(options)
        else:
            filename = context.named_source_filename(item.metadata, options.primary_output_suffix)
            if filename is None:
                filename = (
                    source_stem_authority.required_source_stem(
                        item.metadata, context.artifact_filename_identity,
                    )
                    + options.primary_output_suffix
                )
            path = str(paths.parent / filename)
        outputs.append((path, item))
    output_paths = tuple(path for path, _item in outputs)
    if len(set(output_paths)) != len(output_paths):
        raise ValueError(
            "Image materialization source identities produced duplicate paths: "
            f"{output_paths!r}."
        )
    return [
        Output.from_metadata(
            path=path,
            content=ImageFileFormat.require_path(path).prepare(item.value),
            metadata=item.metadata,
        )
        for path, item in outputs
    ]


def _file_bundle_outputs(
    data: MaterializationValue,
    context: MaterializationContext,
) -> list[Output]:
    if type(data) is not dict:
        raise TypeError("File bundle payload must be a built-in dict.")

    outputs: list[Output] = []
    normalized_paths: set[PurePosixPath] = set()
    for relative_value, content in data.items():
        relative_path = _normalized_relative_materialization_path(relative_value)
        if relative_path in normalized_paths:
            raise ValueError(
                f"File bundle contains duplicate normalized path {relative_path!s}."
            )
        normalized_paths.add(relative_path)
        output_path = _relative_materialization_output_path(
            context.base_path,
            relative_path,
        )
        if isinstance(content, str):
            output = Utf8TextOutput.from_text(
                path=output_path,
                content=content,
            )
        elif isinstance(content, bytes):
            output = Output(path=output_path, content=content)
        else:
            raise TypeError("File bundle values must be str or bytes.")
        outputs.append(output)
    return outputs


@writer_for(FileBundleOptions, MaterializationFormat.FILE_BUNDLE)
def write_file_bundle(
    data: MaterializationValue,
    options: FileBundleOptions,
    context: MaterializationContext,
) -> list[Output]:
    """Write a validated insertion-ordered bundle beneath the artifact directory."""
    del options
    return _file_bundle_outputs(data, context)


class ROIPrimaryPathAuthority:
    """Resolve the user-visible primary path for ROI materialization outputs."""

    @staticmethod
    def primary_path(outs: list[Output]) -> str:
        for out in outs:
            if out.path.endswith(PathSuffixes.ROI_ZIP):
                return out.path
        return PrimaryPathAuthority.first_output_path(outs)


class ROIMaterializationTargetPolicy(
    MostDerivedContextStrategyMixin[ROIMaterializationTargetRequest],
    ABC,
):
    """Registered target selection policy for ROI materialization."""

    @abstractmethod
    def targets(
        self,
        request: ROIMaterializationTargetRequest,
    ) -> ROIMaterializationTargets:
        """Return ROI archive targets for the request."""


@dataclass(frozen=True, slots=True)
class ROIPlaneSourceIdentitySet:
    """Source identities available for a runtime-slice-projected ROI plane set."""

    materialization_input: MaterializationInput

    @property
    def items(self) -> tuple[MaterializationInputItem, ...]:
        return self.materialization_input.items

    @property
    def identities(self) -> tuple:
        return tuple(
            item.metadata.source_provenance.scalar_source_identity.identity
            for item in self.items
        )

    @property
    def missing_indices(self) -> tuple[int, ...]:
        return tuple(
            index
            for index, identity in enumerate(self.identities)
            if identity == (None, None)
        )

    @property
    def has_addressable_identity(self) -> bool:
        return any(identity != (None, None) for identity in self.identities)

    @property
    def has_single_component_address(self) -> bool:
        if len(self.items) != 1:
            return False
        return (
            self.items[
                0
            ].metadata.source_provenance.scalar_source_identity.component_metadata
            is not None
        )

    @property
    def requires_source_identity(self) -> bool:
        return (
            self.materialization_input.source_plane_projection.requires_source_identity
        )

    @property
    def requires_projected_targeting(self) -> bool:
        return len(self.items) > 1 and (
            self.has_addressable_identity or self.requires_source_identity
        )

    def validate_projected_targeting(self) -> None:
        if not self.missing_indices:
            return
        if self.has_addressable_identity or self.requires_source_identity:
            raise ValueError(
                "Projected ROI planes require per-plane source identity; planes "
                f"{self.missing_indices!r} have neither source_path nor "
                "source_component_metadata."
            )


@dataclass(frozen=True, slots=True)
class ROIMaterializationPathContext:
    """Path-selection facts derived from the projected ROI plane set."""

    source_stems: tuple[str, ...]
    metadata_items: tuple[ImagePayloadMetadata, ...]

    @property
    def reference_source_stem(self) -> str | None:
        return self.source_stems[0]

    @property
    def reference_metadata(self) -> ImagePayloadMetadata | None:
        return self.metadata_items[0]


class CombinedROIMaterializationTargetPolicy(
    AlwaysMatchesContextMixin[ROIMaterializationTargetRequest],
    ROIMaterializationTargetPolicy,
):
    """Single archive behavior for ROI payloads without addressable planes."""

    strategy_key = "combined"

    def targets(
        self,
        request: ROIMaterializationTargetRequest,
    ) -> ROIMaterializationTargets:
        return (
            ROIMaterializationTarget(
                archive=ROIMaterializationArchiveIdentity(
                    request.paths.primary_output_path(request.options)
                ),
                items=request.materialization_input.unprojected_items,
            ),
        )


class ComponentAddressedCombinedROIMaterializationTargetPolicy(
    CombinedROIMaterializationTargetPolicy
):
    """Single archive behavior that preserves stream component identity."""

    strategy_key = "component_addressed_combined"

    def matches(self, request: ROIMaterializationTargetRequest) -> bool:
        return request.source_identity_set.has_single_component_address

    def targets(
        self,
        request: ROIMaterializationTargetRequest,
    ) -> ROIMaterializationTargets:
        item = request.materialization_input.items[0]
        return (
            ROIMaterializationTarget(
                archive=ROIMaterializationArchiveIdentity.from_metadata(
                    path=request.paths.primary_output_path(request.options),
                    metadata=item.metadata,
                ),
                items=(item,),
            ),
        )


class ProjectedROIMaterializationTargetPolicy(CombinedROIMaterializationTargetPolicy):
    """Use one archive per runtime-slice-projected ROI plane."""

    strategy_key = "projected"

    def matches(self, request: ROIMaterializationTargetRequest) -> bool:
        return request.requires_projected_targeting

    def targets(
        self,
        request: ROIMaterializationTargetRequest,
    ) -> ROIMaterializationTargets:
        items = request.materialization_input.items
        request.source_identity_set.validate_projected_targeting()
        path_context = ROIMaterializationPathContext(
            source_stems=tuple(
                request.source_stem_authority.required_source_stem(
                    item.metadata,
                    request.artifact_filename_identity,
                )
                for item in items
            ),
            metadata_items=tuple(item.metadata for item in items),
        )
        return tuple(
            ROIMaterializationTarget(
                archive=ROIMaterializationArchiveIdentity.from_metadata(
                    path=request.projected_path(
                        metadata=item.metadata,
                        reference_source_stem=path_context.reference_source_stem,
                        reference_metadata=path_context.reference_metadata,
                    ),
                    metadata=item.metadata,
                ),
                items=(item,),
            )
            for item in items
        )


class ROIMaterializationTargetCoalescer:
    """Coalesce repeated ROI targets without allowing path identity conflicts."""

    def coalesce(
        self,
        targets: ROIMaterializationTargets,
        *,
        common_source_identity: SourceImageIdentity | None = None,
    ) -> ROIMaterializationTargets:
        targets_by_path: dict[str, ROIMaterializationTarget] = {}

        for target in targets:
            path = target.archive.path
            if path in targets_by_path:
                existing = targets_by_path[path]
                if (
                    common_source_identity is not None
                    and not existing.archive.compatible_with(target.archive)
                ):
                    existing = existing.with_archive_source_identity(
                        common_source_identity
                    )
                    target = target.with_archive_source_identity(common_source_identity)
                targets_by_path[path] = existing.merge_with(target)
                continue
            targets_by_path[path] = target

        coalesced = tuple(targets_by_path.values())
        if len(coalesced) != len(targets):
            logger.info(
                "ROI materialization coalesced %d target(s) into %d archive(s)",
                len(targets),
                len(coalesced),
            )
        return coalesced


class ROIMaterializationTargetAuthority:
    """Resolve ROI archive targets through registered cardinality policies."""

    def __init__(self) -> None:
        self._coalescer = ROIMaterializationTargetCoalescer()

    def targets(
        self,
        request: ROIMaterializationTargetRequest,
    ) -> ROIMaterializationTargets:
        policy = ROIMaterializationTargetPolicy.for_context(
            request,
            error_subject="ROI materialization target",
        )
        targets = self._coalescer.coalesce(
            policy.targets(request),
            common_source_identity=request.artifact_source_identity,
        )
        self._log_targets(targets)
        return targets

    @staticmethod
    def _log_targets(targets: ROIMaterializationTargets) -> None:
        if len(targets) <= 1:
            return
        logger.info(
            "ROI materialization split into %d addressable archive(s): %s",
            len(targets),
            [
                {
                    "path": target.archive.path,
                    "component_metadata": target.archive.source_component_metadata,
                }
                for target in targets
            ],
        )


_ROI_MATERIALIZATION_TARGETS = ROIMaterializationTargetAuthority()


class ROIMaterializationPlaneMetadataAuthority:
    """Declare ROI-local plane metadata from the compiled output plane domain."""

    @staticmethod
    def metadata_for_target(
        target: ROIMaterializationTarget,
        variable_components: Sequence[VariableComponents],
        metadata: ImagePayloadMetadata,
    ) -> ImagePayloadMetadata:
        components = ComponentSet.coerce(variable_components).as_tuple()
        if not components:
            return metadata
        if len(target.items) != 1:
            if any(np.ndim(item.data) > 2 for item in target.items):
                raise ValueError(
                    "ROI output plane components require one unprojected stack "
                    "per materialization target."
                )
            return metadata

        item = target.items[0]
        local_plane_shape = tuple(int(size) for size in np.shape(item.data)[:-2])
        if not local_plane_shape:
            return metadata
        if len(local_plane_shape) != len(components):
            raise ValueError(
                "ROI output plane component rank does not match the materialized "
                f"label stack: {components!r} for {local_plane_shape!r}."
            )

        local_plane_count = 1
        for extent in local_plane_shape:
            local_plane_count *= extent
        source_plane_count = metadata.source_provenance.source_plane_count
        if source_plane_count not in (0, local_plane_count):
            raise ValueError(
                "ROI output source-plane provenance does not match its materialized "
                f"label stack: {source_plane_count} != {local_plane_count}."
            )
        if local_plane_count > 1 and source_plane_count == 0:
            raise ValueError(
                "Multi-plane ROI output requires exact source-plane provenance for "
                f"its declared components {components!r}."
            )

        return ImagePayloadMetadata.compose(
            (item.value,),
            mode=ImagePayloadMetadataCompositionMode.STACK,
            source_metadata=(metadata,),
        )


def _roi_output_path_projection(
    data: MaterializationValue,
    options: ROIOptions,
    context: MaterializationContext,
) -> tuple[str, ...]:
    """Derive possible runtime ROI outputs from the writer's target authority."""
    request = ROIMaterializationTargetRequest.from_context(data, options, context)
    if materialization_is_empty(request.materialization_input.data):
        return (request.summary_path,)
    return (
        *(
            target.archive.path
            for target in _ROI_MATERIALIZATION_TARGETS.targets(request)
        ),
        request.summary_path,
    )


@writer_for(
    ROIOptions,
    MaterializationFormat.ROI_ZIP,
    primary_path=ROIPrimaryPathAuthority.primary_path,
    candidate_paths=ROICandidatePathAuthority.paths,
    output_path_projection=_roi_output_path_projection,
)
def _write_roi_zip(
    data: MaterializationValue,
    options: ROIOptions,
    ctx: MaterializationContext,
) -> list[Output]:
    from polystore.roi import extract_rois_from_labeled_mask
    from openhcs.core.roi_source_metadata import ROIArchiveSourceMetadata

    request = ROIMaterializationTargetRequest.from_context(data, options, ctx)
    materialization_input = request.materialization_input
    payload = materialization_input.data
    summary_path = request.summary_path

    if materialization_is_empty(payload):
        return [
            TextOutput(
                path=summary_path,
                content="No segmentation masks generated (empty data)\n",
            )
        ]

    targets = _ROI_MATERIALIZATION_TARGETS.targets(request)
    outs: list[Output] = []
    total_roi_count = 0
    roi_paths: list[str] = []
    source_domain_authority = ROIMaterializationSourceSpatialDomain()
    for target in targets:
        target_rois: list = []
        for item in target.items:
            source_domain = source_domain_authority.domain_for_item(item)
            rois = extract_rois_from_labeled_mask(
                item.data,
                min_area=options.min_area,
                extract_contours=options.extract_contours,
                spatial_origin_yx=source_domain.origin_yx,
                source_spatial_shape_yx=source_domain.source_shape_yx,
            )
            if ctx.output_plan is not None:
                object_subject_binding = ctx.output_plan.object_subject_binding()
                if object_subject_binding is not None:
                    rois = [
                        replace(
                            roi,
                            metadata={
                                **roi.metadata,
                                **object_subject_binding.feature_metadata(
                                    roi.metadata,
                                    producer_step_scope_id=(
                                        ctx.output_plan.producer_step_scope_id
                                    ),
                                    producer_step_index=(
                                        ctx.output_plan.producer_step_index
                                    ),
                                ),
                            },
                        )
                        for roi in rois
                    ]
            target_rois.extend(rois)

        total_roi_count += len(target_rois)
        if target_rois:
            roi_paths.append(target.archive.path)
            item_metadata = target.items[0].metadata
            item_metadata = item_metadata.with_source_provenance(
                item_metadata.source_provenance.with_common_scalar_identity_from_planes()
            )
            item_metadata = (
                ROIMaterializationPlaneMetadataAuthority.metadata_for_target(
                    target,
                    ctx.variable_components,
                    item_metadata,
                )
            )
            source_identity = target.archive.source_identity
            if source_identity is not None:
                item_metadata = item_metadata.with_source_provenance(
                    SourceImageProvenance(
                        source_path=source_identity.path,
                        source_component_metadata=source_identity.component_metadata,
                    ).with_missing_from(item_metadata.source_provenance)
                )
            item_metadata = item_metadata.replace_fields(
                source_spatial_domain=source_domain_authority.domain_for_target(target)
            )
            outs.append(
                Output(
                    path=target.archive.path,
                    content=ROIArchiveSourceMetadata.bind(target_rois, item_metadata),
                    metadata=item_metadata,
                )
            )

    summary = (
        f"Segmentation ROIs: {total_roi_count} parent labels\n"
        "Spatial dimensions: 2D\n"
        f"Projected source planes: {len(materialization_input.items)}\n"
    )
    if roi_paths:
        summary += "ROI files:\n"
        for roi_path in roi_paths:
            summary += f"- {roi_path}\n"
    else:
        summary += "No ROIs extracted (all regions below min_area threshold)\n"
    outs.append(TextOutput(path=summary_path, content=summary))
    return outs


def _swc_xyz(
    coordinates: Sequence[float],
    spacing: Sequence[float],
) -> tuple[float, float, float]:
    """Project array-order coordinates into physical SWC x/y/z coordinates."""

    physical = tuple(
        float(coordinate) * float(axis_spacing)
        for coordinate, axis_spacing in zip(coordinates, spacing, strict=True)
    )
    if len(physical) == 2:
        y, x = physical
        return x, y, 0.0
    z, y, x = physical
    return x, y, z


def _swc_sample_type(node: SpatialGraphNode, default: int) -> int:
    """Return an imported sample type or the projection's declared default."""

    features = node.feature_mapping()
    if SpatialGraph.SWC_TYPE_FEATURE not in features:
        return default
    sample_type = features[SpatialGraph.SWC_TYPE_FEATURE]
    if isinstance(sample_type, bool) or not isinstance(
        sample_type,
        (int, np.integer),
    ):
        raise TypeError(
            f"SpatialGraphNode {node.node_id} "
            f"{SpatialGraph.SWC_TYPE_FEATURE!r} must be an "
            "integer."
        )
    if sample_type < 0:
        raise ValueError(
            f"SpatialGraphNode {node.node_id} "
            f"{SpatialGraph.SWC_TYPE_FEATURE!r} cannot be negative."
        )
    return int(sample_type)


@writer_for(
    SWCOptions,
    MaterializationFormat.SWC,
)
def _write_spatial_graph_swc(
    data: MaterializationValue,
    options: SWCOptions,
    ctx: MaterializationContext,
) -> list[Output]:
    """Write a directed spatial forest as standard SWC sample rows."""

    materialization_input = MaterializationInput.from_value(data, options)
    graph = materialization_input.data
    if not isinstance(graph, SpatialGraph):
        raise TypeError(
            "SWCOptions expects a SpatialGraph payload, " f"got {type(graph).__name__}."
        )
    graph.require_directed_forest()

    outgoing = {node.node_id: [] for node in graph.nodes}
    for edge in graph.edges:
        outgoing[edge.source.node_id].append(edge)
    for edges in outgoing.values():
        edges.sort(key=lambda edge: edge.edge_id)

    rows: list[str] = []
    next_sample_id = 1

    def append_sample(
        coordinates: Sequence[float],
        *,
        sample_type: int,
        radius: float,
        parent_sample_id: int,
    ) -> int:
        nonlocal next_sample_id
        sample_id = next_sample_id
        next_sample_id += 1
        x, y, z = _swc_xyz(coordinates, graph.coordinate_spacing)
        rows.append(
            f"{sample_id} {sample_type} {x:.9g} {y:.9g} {z:.9g} "
            f"{radius:.9g} {parent_sample_id}"
        )
        return sample_id

    def append_descendants(node, parent_sample_id: int) -> None:
        pending = [
            (edge, parent_sample_id) for edge in reversed(outgoing[node.node_id])
        ]
        while pending:
            edge, source_sample_id = pending.pop()
            edge_parent_id = source_sample_id
            for coordinates in edge.coordinates[1:]:
                edge_parent_id = append_sample(
                    coordinates,
                    sample_type=_swc_sample_type(
                        edge.target,
                        options.process_type,
                    ),
                    radius=edge.target.radius,
                    parent_sample_id=edge_parent_id,
                )
            pending.extend(
                (child_edge, edge_parent_id)
                for child_edge in reversed(outgoing[edge.target.node_id])
            )

    for root in graph.roots():
        root_sample_id = append_sample(
            root.coordinates,
            sample_type=_swc_sample_type(root, options.root_type),
            radius=root.radius,
            parent_sample_id=-1,
        )
        append_descendants(root, root_sample_id)

    content = (
        f"# OpenHCS spatial graph: {graph.name}\n"
        "# id type x y z radius parent\n" + ("\n".join(rows) + "\n" if rows else "")
    )
    return [
        TextOutput(
            path=ctx.paths(options).primary_output_path(options),
            content=content,
        )
    ]


@writer_for(PointROIOptions, MaterializationFormat.ROI_ZIP)
def _write_point_roi_zip(
    data: MaterializationValue,
    options: PointROIOptions,
    ctx: MaterializationContext,
) -> list[Output]:
    """Write 3D measurement centres through the native ROI ZIP backend."""
    from math import isfinite
    from polystore.roi import PointShape, ROI
    from openhcs.core.roi_point_metadata import ROIFractionalZ
    from openhcs.core.roi_source_metadata import ROIArchiveSourceMetadata
    from openhcs.core.runtime_measurements import MeasurementTable

    payload = MaterializationInput.from_value(data, options).data
    if not isinstance(payload, MeasurementTable):
        raise TypeError("PointROIOptions requires a MeasurementTable payload.")
    id_field = payload.subject.object_id_field
    if id_field is None:
        raise ValueError("PointROIOptions requires an object-measurement subject.")
    features = (options.z_feature, options.y_feature, options.x_feature)
    if payload.measurement_feature_owner is not None:
        foreign = [
            feature.value
            for feature in features
            if not payload.measurement_feature_owner.owns_measurement_feature_name(
                feature.value
            )
        ]
        if foreign:
            raise ValueError(
                f"Point coordinate features are not owned by the table: {foreign!r}."
            )
    coordinate_fields = tuple(
        feature.measurement_row_field_name for feature in features
    )
    missing = {id_field, *coordinate_fields} - {field.name for field in payload.fields}
    if missing:
        raise ValueError(f"Point measurement fields are missing: {sorted(missing)!r}.")
    provenance = payload.source_provenance.with_common_scalar_identity_from_planes()
    source_planes = provenance.source_image_provenance_planes
    if provenance.source_path is None and (
        not source_planes.has_values
        or any(path is None for path in source_planes.paths)
    ):
        raise ValueError(
            "Point ROI ZIP requires a source-image path or exact paths for every "
            "source plane."
        )
    rois: list[ROI] = []
    seen_labels: set[int] = set()
    for row in payload.iter_row_mappings():
        label = row[id_field]
        if (
            isinstance(label, bool)
            or not isinstance(label, (int, np.integer))
            or label <= 0
        ):
            raise ValueError("Point ROI object labels must be positive integers.")
        if int(label) in seen_labels:
            raise ValueError(f"Duplicate point ROI object label: {label!r}.")
        seen_labels.add(int(label))
        coordinates: list[float] = []
        for field_name in coordinate_fields:
            value = row[field_name]
            if isinstance(value, bool) or not isinstance(
                value, (int, float, np.number)
            ):
                raise ValueError(f"Point coordinate {field_name!r} must be numeric.")
            coordinate = float(value)
            if not isfinite(coordinate):
                raise ValueError(f"Point coordinate {field_name!r} must be finite.")
            coordinates.append(coordinate)
        z, y, x = coordinates
        rois.append(
            ROIFractionalZ(z).bind(
                ROI(
                    shapes=[PointShape(y=y, x=x)],
                    metadata={**row, "label": int(label)},
                )
            )
        )
    if not rois:
        raise ValueError("Point ROI ZIP requires at least one measured object.")
    metadata = ImagePayloadMetadata(source_provenance=provenance)
    ROIFractionalZ.source_component_domain(rois, metadata)
    return [
        Output(
            path=ctx.paths(options).primary_output_path(options),
            content=ROIArchiveSourceMetadata.bind(rois, metadata),
            metadata=metadata,
        )
    ]


@writer_for(
    SpatialGraphROIOptions,
    MaterializationFormat.ROI_ZIP,
)
def _write_spatial_graph_roi_zip(
    data: MaterializationValue,
    options: SpatialGraphROIOptions,
    ctx: MaterializationContext,
) -> list[Output]:
    """Write graph edges as feature-bearing polyline ROIs."""

    from polystore.roi import ROI, PolylineShape

    from openhcs.core.roi_source_metadata import ROIArchiveSourceMetadata

    materialization_input = MaterializationInput.from_value(data, options)
    graph = materialization_input.data
    if not isinstance(graph, SpatialGraph):
        raise TypeError(
            "SpatialGraphROIOptions expects a SpatialGraph payload, "
            f"got {type(graph).__name__}."
        )

    source_metadata = ImagePayloadMetadata(
        source_provenance=graph.source_provenance,
        source_voxel_spacing=SourceVoxelSpacing(graph.coordinate_spacing),
    )
    rois = []
    for edge in graph.edges:
        coordinates = np.asarray(edge.coordinates, dtype=float)
        if coordinates.shape[1] != 2:
            raise ValueError(
                "SpatialGraphROIOptions requires 2D edge coordinates because "
                "ImageJ polyline ROI archives are 2D. Use SWCOptions for 3D graphs."
            )
        segment_lengths = np.linalg.norm(np.diff(coordinates, axis=0), axis=1)
        edge_features = edge.feature_mapping()
        object_subject_metadata: Mapping[str, object] = {}
        if ctx.output_plan is not None:
            object_subject_binding = ctx.output_plan.object_subject_binding()
            if object_subject_binding is not None:
                object_subject_metadata = object_subject_binding.feature_metadata(
                    edge_features,
                    producer_step_scope_id=ctx.output_plan.producer_step_scope_id,
                    producer_step_index=ctx.output_plan.producer_step_index,
                )
        metadata = {
            "label": edge.edge_id,
            "area": 0.0,
            "perimeter": float(np.sum(segment_lengths)),
            "centroid": tuple(float(value) for value in coordinates.mean(axis=0)),
            "graph": graph.name,
            "edge_id": edge.edge_id,
            "source_node_id": edge.source_node_id,
            "target_node_id": edge.target_node_id,
            **edge_features,
            **object_subject_metadata,
        }
        rois.append(
            ROI(
                shapes=[PolylineShape(coordinates=coordinates)],
                metadata=metadata,
            )
        )

    return [
        Output(
            path=ctx.paths(options).primary_output_path(options),
            content=ROIArchiveSourceMetadata.bind(rois, source_metadata),
            metadata=source_metadata,
        )
    ]


class TiffStackSlicePayloadAuthority:
    """Own how TIFF stack materialization expands payloads into saved slices."""

    @staticmethod
    def slices(
        materialization_input: MaterializationInput,
    ) -> tuple[MaterializationValue, ...]:
        if materialization_input.sequence_type is not None:
            return tuple(item.data for item in materialization_input.items)
        if len(materialization_input.items) != 1:
            raise ValueError(
                "TIFF stack materialization requires exactly one payload or an "
                "explicit payload sequence."
            )
        item = materialization_input.items[0]
        if item.metadata.plane_axis is None:
            return (item.data,)
        data = np.asarray(item.data)
        if data.ndim < 3 or data.shape[0] <= 0:
            raise ValueError(
                "TIFF stack payload storage does not match its declared leading "
                f"plane axis: shape {data.shape!r}."
            )
        return tuple(data[index] for index in range(data.shape[0]))


@singledispatch
def materialization_emits_variable_component_planes(
    options: FileOutputOptions,
    data: MaterializationValue,
) -> bool:
    """Return whether one writer emits source-stack identity as separate outputs."""
    del options, data
    return False


@materialization_emits_variable_component_planes.register(TiffStackOptions)
def tiff_stack_emits_variable_component_planes(
    options: TiffStackOptions,
    data: MaterializationValue,
) -> bool:
    materialization_input = MaterializationInput.from_value(data, options)
    metadata_input = MaterializationInput.from_runtime_slice_projected_value(
        data,
        options,
    )
    slices = TiffStackSlicePayloadAuthority.slices(materialization_input)
    return len(slices) > 1 and len(metadata_input.items) == len(slices)


@materialization_emits_variable_component_planes.register(ImageFileOptions)
def image_file_emits_variable_component_planes(
    options: ImageFileOptions,
    data: MaterializationValue,
) -> bool:
    if not (
        options.filename_identity is MaterializedFilenameIdentity.SOURCE_IDENTITY
        or _image_template_uses_source_metadata(options.relative_path_template)
        or _image_template_uses_sequence_index(options.relative_path_template)
    ):
        return False
    return len(MaterializationInput.from_image_value(data, options).items) > 1


@materialization_emits_variable_component_planes.register(ROIOptions)
def roi_emits_variable_component_planes(
    options: ROIOptions,
    data: MaterializationValue,
) -> bool:
    materialization_input = MaterializationInput.from_runtime_slice_projected_value(
        data,
        options,
    )
    return materialization_input.source_plane_projection.requires_source_identity


@singledispatch
def materialization_uses_filename_source_identity(
    options: FileOutputOptions,
    data: MaterializationValue,
) -> bool:
    """Return whether stream identity should follow the materialized filename."""
    del options, data
    return False


@materialization_uses_filename_source_identity.register(TiffStackOptions)
def tiff_stack_uses_filename_source_identity(
    options: TiffStackOptions,
    data: MaterializationValue,
) -> bool:
    return not materialization_emits_variable_component_planes(options, data)


@materialization_uses_filename_source_identity.register(ImageFileOptions)
def image_file_uses_filename_source_identity(
    options: ImageFileOptions,
    data: MaterializationValue,
) -> bool:
    del data
    return options.filename_identity is MaterializedFilenameIdentity.SOURCE_IDENTITY


@writer_for(
    TiffStackOptions,
    MaterializationFormat.TIFF_STACK,
    candidate_paths=TiffStackCandidatePathAuthority.paths,
)
def _write_tiff_stack(
    data: MaterializationValue,
    options: TiffStackOptions,
    ctx: MaterializationContext,
) -> list[Output]:
    materialization_input = MaterializationInput.from_value(data, options)
    metadata_input = MaterializationInput.from_runtime_slice_projected_value(
        data,
        options,
    )
    data = materialization_input.data
    paths = ctx.paths(options)

    if materialization_is_empty(data):
        summary_path = _tiff_stack_summary_path(paths, options)
        return [TextOutput(path=summary_path, content=options.empty_summary)]

    slices = TiffStackSlicePayloadAuthority.slices(materialization_input)

    slice_metadata = _TIFF_STACK_SLICE_METADATA.metadata_for_slices(
        metadata_input,
        len(slices),
        variable_components=ctx.variable_components,
        artifact_source_identity=ctx.artifact_source_identity,
    )

    outs: list[Output] = []
    for i, arr in enumerate(slices):
        filename = _tiff_stack_slice_path(
            paths,
            options,
            index=i,
            slice_count=len(slices),
        )
        out_arr = TiffArrayAuthority.output_array(arr, options)
        outs.append(
            Output.from_metadata(
                path=filename,
                content=out_arr,
                metadata=slice_metadata[i],
            )
        )

    summary_path = _tiff_stack_summary_path(paths, options)
    first = None
    if slices:
        first = slices[0]
    source_path = paths.source_identity_base_path(options)
    if source_path is not None:
        base_filename_pattern = (
            source_path.name
            if len(slices) == 1
            else f"{paths.primary_output_basename(options)}" f"{options.slice_pattern}"
        )
    else:
        base_filename_pattern = f"{paths.name}{options.slice_pattern}"
    summary_content = (
        f"Images saved: {len(slices)} files\n"
        f"Base filename pattern: {base_filename_pattern}\n"
        f"Image dtype: {TiffArrayAuthority.dtype_name(first)}\n"
        f"Image shape: {TiffArrayAuthority.shape_text(first)}\n"
    )
    outs.append(TextOutput(path=summary_path, content=summary_content))
    return outs


class TiffArrayAuthority:
    """Own array inspection and normalization for TIFF stack materialization."""

    UINT8_DTYPE: ClassVar[np.dtype] = np.dtype("uint8")

    @classmethod
    def output_array(
        cls,
        value: MaterializationValue,
        options: TiffStackOptions,
    ) -> MaterializationValue:
        if not options.normalize_uint8:
            return value
        array = np.asarray(value)
        if array.dtype == cls.UINT8_DTYPE:
            return value
        max_val = cls.max_value(array)
        if max_val <= 1.0:
            return (array * 255).astype(cls.UINT8_DTYPE)
        return array.astype(cls.UINT8_DTYPE)

    @staticmethod
    def max_value(array: np.ndarray) -> float:
        if array.size == 0:
            return 0.0
        return float(np.max(array))

    @staticmethod
    def dtype_name(value: MaterializationValue) -> str:
        if value is None:
            return "unknown"
        return str(np.asarray(value).dtype)

    @staticmethod
    def shape_text(value: MaterializationValue) -> str:
        if value is None:
            return "unknown"
        return str(np.shape(value))


@dataclass(frozen=True, slots=True)
class RuntimePlaneStackAxisMetadataProjection:
    """Project scalar source identity across variable component runtime planes."""

    variable_components: Sequence[VariableComponents]
    artifact_source_identity: SourceImageIdentity | None = None

    def metadata_for_item(
        self,
        item: MaterializationInputItem,
    ) -> ImagePayloadMetadata:
        metadata = self.metadata_with_artifact_source_identity(item.metadata)
        runtime_plane = item.runtime_plane
        if runtime_plane is None or not self.variable_components:
            return metadata
        if runtime_plane.carries_source_plane_identity:
            return metadata

        axes = self.ordered_axes()
        if len(axes) != len(runtime_plane.plane_indices):
            raise ValueError(
                "TIFF stack output uses variable components "
                f"{axes!r}, but runtime plane metadata has "
                f"{len(runtime_plane.plane_indices)} coordinate(s)."
            )

        component_metadata = metadata.source_component_metadata
        if component_metadata is None:
            raise ValueError(
                "TIFF stack output uses variable components "
                f"{axes!r}, but slice metadata has no scalar "
                "source_component_metadata."
            )

        projected_metadata = VariableComponentAxisProjection(
            frozenset(axes)
        ).project_component_metadata(
            component_metadata,
            runtime_plane.plane_indices,
        )

        return metadata.with_source_provenance(
            metadata.source_provenance.with_source_component_metadata(
                projected_metadata,
            )
        )

    def metadata_with_artifact_source_identity(
        self,
        metadata: ImagePayloadMetadata,
    ) -> ImagePayloadMetadata:
        if self.artifact_source_identity is None:
            return metadata
        artifact_provenance = SourceImageProvenance(
            source_path=self.artifact_source_identity.path,
            source_component_metadata=self.artifact_source_identity.component_metadata,
        )
        return metadata.with_source_context_from(
            ImagePayloadMetadata(source_provenance=artifact_provenance)
        )

    def ordered_axes(self) -> tuple[str, ...]:
        return VariableComponentAxisProjection(
            frozenset(
                component.value
                for component in self.variable_components
                if component.value is not None
            )
        ).ordered_axes()


@dataclass(frozen=True, slots=True)
class RuntimePlaneStackAxesProjectionSelection:
    """Select variable component axes that still need runtime-plane projection."""

    variable_components: Sequence[VariableComponents]
    items: tuple[MaterializationInputItem, ...]
    artifact_source_identity: SourceImageIdentity | None = None

    def axes(self) -> frozenset[str]:
        ordered_axes = RuntimePlaneStackAxisMetadataProjection(
            self.variable_components
        ).ordered_axes()
        if not ordered_axes:
            return frozenset()
        runtime_rank = self.runtime_plane_rank()
        if runtime_rank == 0:
            return frozenset()
        if any(self.axis_varies(axis) for axis in ordered_axes):
            return frozenset()
        indexed_source_plane_axis = self.indexed_source_plane_axis(ordered_axes)
        if indexed_source_plane_axis is not None:
            return frozenset((indexed_source_plane_axis,))
        if runtime_rank != len(ordered_axes):
            raise ValueError(
                "TIFF stack output cannot map runtime plane metadata with "
                f"rank {runtime_rank} onto variable component axes "
                f"{ordered_axes!r}; slice metadata does not already vary across "
                "any variable component axis."
            )
        return frozenset(ordered_axes)

    def runtime_plane_rank(self) -> int:
        ranks = tuple(
            len(item.runtime_plane.plane_indices)
            for item in self.items
            if item.runtime_plane is not None
        )
        if not ranks:
            return 0
        first = ranks[0]
        if any(rank != first for rank in ranks):
            raise ValueError(
                "TIFF stack materialization received inconsistent runtime "
                f"plane metadata ranks: {ranks!r}."
            )
        return first

    def runtime_plane_shape(self) -> tuple[int, ...]:
        shapes = tuple(
            item.runtime_plane.plane_shape
            for item in self.items
            if item.runtime_plane is not None
        )
        if not shapes:
            return ()
        first = shapes[0]
        if any(shape != first for shape in shapes):
            raise ValueError(
                "TIFF stack materialization received inconsistent runtime "
                f"plane metadata shapes: {shapes!r}."
            )
        return first

    def runtime_planes_carry_source_identity(self) -> bool:
        states = tuple(
            item.runtime_plane.carries_source_plane_identity
            for item in self.items
            if item.runtime_plane is not None
        )
        if not states:
            return False
        if any(state != states[0] for state in states):
            raise ValueError(
                "TIFF stack materialization received mixed source-plane "
                f"runtime metadata states: {states!r}."
            )
        return states[0]

    def axis_varies(self, axis: str) -> bool:
        component = VariableComponentAxisProjection.component_for_axis(axis)
        values = tuple(
            source_component_metadata_value(metadata, component)
            for metadata in self.item_component_metadata()
        )
        return len(frozenset(values)) > 1

    def indexed_source_plane_axis(
        self,
        ordered_axes: tuple[str, ...],
    ) -> str | None:
        runtime_shape = self.runtime_plane_shape()
        if len(runtime_shape) != 1:
            return None
        source_plane_axis = SourcePlaneIndexedMetadata.projected_component().value
        if source_plane_axis not in ordered_axes:
            return None
        metadata_values = self.item_component_metadata()
        if not metadata_values:
            return None
        for metadata in metadata_values:
            indexed_metadata = SourcePlaneIndexedMetadata.from_metadata(
                metadata,
                expected_plane_count=runtime_shape[0],
            )
            if indexed_metadata is None:
                indexed_metadata = (
                    SourcePlaneIndexedMetadata.from_declared_runtime_stack_origin(
                        metadata,
                        source_plane_count=runtime_shape[0],
                    )
                )
            if indexed_metadata is None:
                return None
        return source_plane_axis

    def item_component_metadata(self) -> tuple[SourceComponentMetadata, ...]:
        metadata_values = tuple(
            self.effective_item_metadata(item).source_component_metadata
            for item in self.items
        )
        if any(metadata is None for metadata in metadata_values):
            return ()
        return tuple(metadata for metadata in metadata_values if metadata is not None)

    def effective_item_metadata(
        self,
        item: MaterializationInputItem,
    ) -> ImagePayloadMetadata:
        return RuntimePlaneStackAxisMetadataProjection(
            frozenset(),
            self.artifact_source_identity,
        ).metadata_with_artifact_source_identity(item.metadata)


@dataclass(frozen=True, slots=True)
class TiffStackSliceMetadataRequest:
    """Input facts needed to align metadata to emitted TIFF slices."""

    materialization_input: MaterializationInput
    slice_count: int
    variable_components: Sequence[VariableComponents] = field(default_factory=tuple)
    artifact_source_identity: SourceImageIdentity | None = None

    @property
    def input_item_count(self) -> int:
        return len(self.materialization_input.items)

    @property
    def has_empty_slice_set(self) -> bool:
        return self.slice_count <= 0

    @property
    def has_presliced_payloads(self) -> bool:
        return self.input_item_count == self.slice_count

    @property
    def has_single_payload(self) -> bool:
        return self.input_item_count == 1

    @property
    def has_single_presliced_payload(self) -> bool:
        return self.has_single_payload and self.has_presliced_payloads


class TiffStackSliceMetadataPolicy(
    MostDerivedContextStrategyMixin[TiffStackSliceMetadataRequest],
    ABC,
):
    """One cardinality policy for TIFF slice metadata projection."""

    @abstractmethod
    def metadata_for_slices(
        self,
        request: TiffStackSliceMetadataRequest,
    ) -> tuple[ImagePayloadMetadata, ...]:
        """Return one metadata record for each emitted TIFF slice."""


class UnknownTiffStackSliceMetadataPolicy(
    AlwaysMatchesContextMixin[TiffStackSliceMetadataRequest],
    TiffStackSliceMetadataPolicy,
):
    """Ambiguous cardinality gets empty metadata rather than invented identity."""

    strategy_key = "unknown"

    def metadata_for_slices(
        self,
        request: TiffStackSliceMetadataRequest,
    ) -> tuple[ImagePayloadMetadata, ...]:
        return tuple(ImagePayloadMetadata() for _index in range(request.slice_count))


class PreslicedTiffStackSliceMetadataPolicy(UnknownTiffStackSliceMetadataPolicy):
    """Input items already correspond one-to-one with emitted TIFF slices."""

    strategy_key = "presliced"

    def matches(self, request: TiffStackSliceMetadataRequest) -> bool:
        return request.has_presliced_payloads

    def metadata_for_slices(
        self,
        request: TiffStackSliceMetadataRequest,
    ) -> tuple[ImagePayloadMetadata, ...]:
        selected_variable_components = RuntimePlaneStackAxesProjectionSelection(
            request.variable_components,
            request.materialization_input.items,
            request.artifact_source_identity,
        ).axes()
        projector = RuntimePlaneStackAxisMetadataProjection(
            tuple(
                component
                for component in request.variable_components
                if component.value in selected_variable_components
            ),
            request.artifact_source_identity,
        )
        return tuple(
            projector.metadata_for_item(item)
            for item in request.materialization_input.items
        )


class SinglePayloadTiffStackSliceMetadataPolicy(UnknownTiffStackSliceMetadataPolicy):
    """One stacked payload is being split into emitted TIFF slices."""

    strategy_key = "single_payload"

    def matches(self, request: TiffStackSliceMetadataRequest) -> bool:
        return request.has_single_payload

    def metadata_for_slices(
        self,
        request: TiffStackSliceMetadataRequest,
    ) -> tuple[ImagePayloadMetadata, ...]:
        metadata = request.materialization_input.items[0].metadata
        return tuple(
            metadata.for_source_plane(index) for index in range(request.slice_count)
        )


class SinglePreslicedTiffStackSliceMetadataPolicy(
    PreslicedTiffStackSliceMetadataPolicy,
    SinglePayloadTiffStackSliceMetadataPolicy,
):
    """One input item already represents the one emitted TIFF slice."""

    strategy_key = "single_presliced"

    def matches(self, request: TiffStackSliceMetadataRequest) -> bool:
        return request.has_single_presliced_payload


class EmptyTiffStackSliceMetadataPolicy(
    PreslicedTiffStackSliceMetadataPolicy,
    SinglePayloadTiffStackSliceMetadataPolicy,
):
    """No emitted slices means no metadata records."""

    strategy_key = "empty"

    def matches(self, request: TiffStackSliceMetadataRequest) -> bool:
        return request.has_empty_slice_set

    def metadata_for_slices(
        self,
        request: TiffStackSliceMetadataRequest,
    ) -> tuple[ImagePayloadMetadata, ...]:
        return ()


class TiffStackSliceMetadataAuthority:
    """Owns metadata alignment for TIFF slices emitted from runtime payloads."""

    def metadata_for_slices(
        self,
        materialization_input: MaterializationInput,
        slice_count: int,
        *,
        variable_components: Sequence[VariableComponents] = (),
        artifact_source_identity: SourceImageIdentity | None = None,
    ) -> tuple[ImagePayloadMetadata, ...]:
        request = TiffStackSliceMetadataRequest(
            materialization_input=materialization_input,
            slice_count=slice_count,
            variable_components=tuple(variable_components),
            artifact_source_identity=artifact_source_identity,
        )
        policy = TiffStackSliceMetadataPolicy.for_context(
            request,
            error_subject="TIFF stack slice metadata",
        )
        return policy.metadata_for_slices(request)


_TIFF_STACK_SLICE_METADATA = TiffStackSliceMetadataAuthority()


@dataclass(init=False)
class MaterializationSpec(ArtifactMaterializationPayload):
    """Declarative materialization spec.

    The spec is a list of *writer options* objects. Writer dispatch is inferred
    from the option type.
    """

    outputs: tuple[FileOutputOptions, ...]
    allowed_backends: list[str] | None
    primary: int
    write_mode: WriteMode

    def __init__(
        self,
        *outputs: FileOutputOptions | Sequence[FileOutputOptions],
        allowed_backends: list[str] | None = None,
        primary: int = 0,
        write_mode: WriteMode = WriteMode.OVERWRITE,
    ):
        if len(outputs) == 1 and isinstance(outputs[0], (list, tuple)):
            outputs = tuple(outputs[0])

        if not outputs:
            raise ValueError(
                "MaterializationSpec requires at least one output options object"
            )

        for opt in outputs:
            if isinstance(opt, dict):
                raise TypeError("dict-based materialization options are not supported")
            option_type = opt.__class__
            if option_type not in _WRITERS_BY_OPTIONS:
                raise ValueError(
                    f"No writer registered for options type {option_type.__name__}. "
                    f"Registered: {[t.__name__ for t in _WRITERS_BY_OPTIONS]}"
                )

        if primary < 0 or primary >= len(outputs):
            raise IndexError("MaterializationSpec.primary out of range")
        if not isinstance(write_mode, WriteMode):
            raise TypeError(
                "MaterializationSpec.write_mode must be a WriteMode, "
                f"got {type(write_mode).__name__}."
            )

        self.outputs = tuple(outputs)
        self.allowed_backends = allowed_backends
        self.primary = primary
        self.write_mode = write_mode

    @classmethod
    def __objectstate_rebuild__(
        cls,
        *,
        outputs: tuple[FileOutputOptions, ...],
        allowed_backends: list[str] | None = None,
        primary: int = 0,
        write_mode: WriteMode = WriteMode.OVERWRITE,
    ) -> MaterializationSpec:
        # Rebuild via the normal constructor to keep validation behavior.
        return cls(
            *outputs,
            allowed_backends=allowed_backends,
            primary=primary,
            write_mode=write_mode,
        )

    def participates_in_runtime_export_observation(self) -> bool:
        """Explicit materialization specs are externally observed exports."""
        return True

    def filename_qualifier(self, output_plan: ArtifactOutputPlan | None) -> str | None:
        """Preserve the source filenames authored by an explicit export."""
        return None

    def participates_in_persistent_materialization(self) -> bool:
        """Explicit materialization specs write to configured persistent targets."""
        return True

    def tabular_field_names(self) -> tuple[str, ...]:
        """Return declared tabular field names from the primary writer first."""
        return tabular_field_names_from_options(self.outputs, primary=self.primary)

    def candidate_paths(self, base_path: str) -> tuple[str, ...]:
        """Return representative declaration-time paths for previews and routing.

        Runtime payload and source metadata can refine names and add outputs.
        """
        return tuple(
            path
            for output_options in self.outputs
            for path in _WRITERS_BY_OPTIONS[output_options.__class__].candidate_paths(
                output_options, base_path
            )
        )

    def shared_output_stem(self, base_path: str) -> str:
        """Return the writer-normalized stem shared by candidate outputs."""

        return str(PathHelper(base_path, self.outputs[self.primary]).base_path)

    def emits_variable_component_planes(self, data: MaterializationValue) -> bool:
        """Return whether any writer emits variable-component planes."""
        return any(
            materialization_emits_variable_component_planes(output_options, data)
            for output_options in self.outputs
        )

    def emitted_source_identities(
        self,
        data: MaterializationValue,
    ) -> tuple[SourceImageIdentity, ...]:
        """Return source identities for writers that emit projected planes."""
        for output_options in self.outputs:
            if not materialization_emits_variable_component_planes(
                output_options,
                data,
            ):
                continue
            materialization_input = (
                MaterializationInput.from_runtime_slice_projected_value(
                    data,
                    output_options,
                )
            )
            if len(materialization_input.items) == 1:
                provenance = materialization_input.items[0].metadata.source_provenance
                if provenance.source_plane_count > 1:
                    return tuple(
                        provenance.for_source_plane(index).scalar_source_identity
                        for index in range(provenance.source_plane_count)
                    )
            return tuple(
                item.metadata.source_provenance.scalar_source_identity
                for item in materialization_input.items
            )
        return ()

    def uses_filename_source_identity(self, data: MaterializationValue) -> bool:
        """Return whether any writer routes stream identity by materialized filename."""
        return any(
            materialization_uses_filename_source_identity(output_options, data)
            for output_options in self.outputs
        )

    def uses_source_identity_filename(self) -> bool:
        """Return whether this spec materializes files by source identity."""
        return any(
            output_options.filename_identity
            is MaterializedFilenameIdentity.SOURCE_IDENTITY
            for output_options in self.outputs
        )


def tabular_field_names_from_options(
    options: Sequence[FileOutputOptions],
    *,
    primary: int = 0,
) -> tuple[str, ...]:
    """Return declared tabular fields from writer options, primary first."""
    if not options:
        return ()
    output_tuple = tuple(options)
    ordered_options = (
        output_tuple[primary : primary + 1]
        + output_tuple[:primary]
        + output_tuple[primary + 1 :]
    )
    for output_options in ordered_options:
        if (
            isinstance(output_options, TabularExtractionOptions)
            and output_options.fields
        ):
            return tuple(output_options.fields)
    return ()


def tabular_field_names_from_materialization(materialization) -> tuple[str, ...]:
    """Return declared tabular fields from a materialization spec."""
    if not isinstance(materialization, MaterializationSpec):
        return ()
    return materialization.tabular_field_names()


class BackendSequenceAuthority:
    """Normalize materialization backend declarations."""

    @staticmethod
    def normalize(backends: Sequence[str] | str) -> list[str]:
        if isinstance(backends, str):
            return [backends]
        return list(backends)


class AllowedBackendsAuthority:
    """Validate materialization backends against the spec allow-list."""

    @staticmethod
    def validate(spec: MaterializationSpec, backends: list[str]) -> None:
        if not spec.allowed_backends:
            return
        invalid = [b for b in backends if b not in spec.allowed_backends]
        if invalid:
            raise ValueError(
                f"Backend(s) {invalid} not in allowed backends for this spec: "
                f"{spec.allowed_backends}"
            )


@dataclass(frozen=True)
class SavedMaterializationOutputs:
    """Backend-indexed outputs from completed saves, independent of artifact kind."""

    outputs_by_backend: Mapping[str, tuple[Output, ...]]

    def outputs_for_backend(self, backend: str) -> tuple[Output, ...]:
        return self.outputs_by_backend.get(backend, ())


@dataclass(frozen=True)
class MaterializationBatch:
    """One rendered writer batch shared by saving and immediate publication."""

    context: MaterializationContext
    output_groups: tuple[tuple[WriterSpec, tuple[Output, ...]], ...]
    primary: int

    @classmethod
    def render(
        cls,
        spec: MaterializationSpec,
        data: MaterializationValue,
        context: MaterializationContext,
        *,
        output_path_filter: Callable[[Path], bool] | None = None,
    ) -> MaterializationBatch:
        context = replace(context, materialization_spec=spec)
        groups = tuple(
            (
                writer,
                tuple(
                    output.with_source_identity_fallback(
                        context.artifact_source_identity
                    ).with_variable_components(context.variable_components)
                    for output in writer.outputs(
                        data, options, context, output_path_filter
                    )
                ),
            )
            for options in spec.outputs
            for writer in (_WRITERS_BY_OPTIONS[options.__class__],)
        )
        return cls(context=context, output_groups=groups, primary=spec.primary)

    @property
    def outputs(self) -> tuple[Output, ...]:
        return tuple(
            output for _writer, outputs in self.output_groups for output in outputs
        )

    @property
    def primary_path(self) -> str:
        writer, outputs = self.output_groups[self.primary]
        return writer.primary_path(list(outputs))

    def save(self) -> SavedMaterializationOutputs:
        """Return only outputs accepted and successfully saved by each backend."""
        saved: dict[str, tuple[Output, ...]] = {}
        saver = self.context.saver
        for _writer, outputs in self.output_groups:
            for backend, saved_outputs in saver.save_all(outputs).items():
                saved[backend] = (*saved.get(backend, ()), *saved_outputs)
        return SavedMaterializationOutputs(MappingProxyType(saved))


def materialization_outputs(
    spec: MaterializationSpec,
    data: MaterializationValue,
    path: str,
    filemanager: FileManager,
    context: ProcessingContext | None = None,
    extra_inputs: dict | None = None,
    *,
    artifact_source_identity: SourceImageIdentity | None = None,
    artifact_filename_identity: SourceImageIdentity | None = None,
    variable_components: Sequence[VariableComponents] = (),
    source_paths: Sequence[str] = (),
    pipeline_position: int | None = None,
    output_plan: ArtifactOutputPlan | None = None,
    output_path_filter: Callable[[Path], bool] | None = None,
) -> tuple[Output, ...]:
    """Derive selected writer outputs without saving.

    Runtime path projections can skip writers with no matching outputs. Writers
    without a projection render before their actual output paths are filtered.
    """

    materialization_context = MaterializationContext(
        base_path=path,
        backends=[],
        backend_kwargs={},
        filemanager=filemanager,
        extra_inputs={} if extra_inputs is None else extra_inputs,
        context=context,
        artifact_source_identity=artifact_source_identity,
        artifact_filename_identity=artifact_filename_identity,
        variable_components=tuple(variable_components),
        write_mode=spec.write_mode,
        source_paths=tuple(str(p) for p in source_paths),
        pipeline_position=pipeline_position,
        output_plan=output_plan,
    )
    return MaterializationBatch.render(
        spec,
        data,
        materialization_context,
        output_path_filter=output_path_filter,
    ).outputs


def prepare_materialization(
    spec: MaterializationSpec,
    data: MaterializationValue,
    path: str,
    filemanager: FileManager,
    backends: Sequence[str] | str,
    backend_kwargs: BackendKwargsInput = BACKEND_KWARGS_ABSENT,
    context: ProcessingContext | None = None,
    extra_inputs: dict | None = None,
    *,
    artifact_source_identity: SourceImageIdentity | None = None,
    artifact_filename_identity: SourceImageIdentity | None = None,
    variable_components: Sequence[VariableComponents] = (),
    source_paths: Sequence[str] = (),
    pipeline_position: int | None = None,
    output_plan: ArtifactOutputPlan | None = None,
) -> MaterializationBatch:
    """Prepare one exact batch for saving and immediate publication."""

    normalized_backends = BackendSequenceAuthority.normalize(backends)
    AllowedBackendsAuthority.validate(spec, normalized_backends)
    effective_backend_kwargs = BackendKwargsAuthority.normalize(backend_kwargs)
    if extra_inputs is None:
        effective_extra_inputs = {}
    else:
        effective_extra_inputs = extra_inputs

    ctx = MaterializationContext(
        base_path=path,
        backends=normalized_backends,
        backend_kwargs=effective_backend_kwargs,
        filemanager=filemanager,
        extra_inputs=effective_extra_inputs,
        context=context,
        artifact_source_identity=artifact_source_identity,
        artifact_filename_identity=artifact_filename_identity,
        variable_components=tuple(variable_components),
        write_mode=spec.write_mode,
        source_paths=tuple(str(p) for p in source_paths),
        pipeline_position=pipeline_position,
        output_plan=output_plan,
    )

    return MaterializationBatch.render(spec, data, ctx)


def materialize(
    spec: MaterializationSpec,
    data: MaterializationValue,
    path: str,
    filemanager: FileManager,
    backends: Sequence[str] | str,
    backend_kwargs: BackendKwargsInput = BACKEND_KWARGS_ABSENT,
    context: ProcessingContext | None = None,
    extra_inputs: dict | None = None,
    *,
    artifact_source_identity: SourceImageIdentity | None = None,
    artifact_filename_identity: SourceImageIdentity | None = None,
    variable_components: Sequence[VariableComponents] = (),
    source_paths: Sequence[str] = (),
    pipeline_position: int | None = None,
    output_plan: ArtifactOutputPlan | None = None,
) -> str:
    """Materialize data and return the primary path derived from its writer batch."""
    batch = prepare_materialization(
        spec,
        data,
        path,
        filemanager,
        backends,
        backend_kwargs,
        context=context,
        extra_inputs=extra_inputs,
        artifact_source_identity=artifact_source_identity,
        artifact_filename_identity=artifact_filename_identity,
        variable_components=variable_components,
        source_paths=source_paths,
        pipeline_position=pipeline_position,
        output_plan=output_plan,
    )
    batch.save()
    return batch.primary_path
