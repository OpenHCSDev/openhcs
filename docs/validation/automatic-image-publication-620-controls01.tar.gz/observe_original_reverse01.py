"""Observe original writer operands through its unchanged registered CP runtime.

Synthetic retained engineering inputs only. No native process, viewer, MCP,
product patch or copied admission algorithm. Every original input stays intact.
"""
from dataclasses import fields, replace
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
import threading

root = Path(__file__).resolve().parent
run = root / "original-observation01"
target = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/package02/target')
original = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/public-packet01')
run.mkdir(exist_ok=False)
os.environ.update(
    OPENHCS_HEADLESS='true', OPENHCS_CPU_ONLY='true',
    POLYSTORE_IMAGEJ_ALLOW_DOWNLOAD='false', QT_QPA_PLATFORM='offscreen',
    XDG_CACHE_HOME=str(run / 'scratch/cache'),
    XDG_DATA_HOME=str(run / 'scratch/data'),
    XDG_CONFIG_HOME=str(run / 'scratch/config'),
    NUMBA_CACHE_DIR=str(run / 'scratch/numba'),
    MPLCONFIGDIR=str(run / 'scratch/matplotlib'),
    OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1',
)
sys.path.insert(0, str(target))

import openhcs
from openhcs.agent.services.execution_session_service import (
    AgentProgressQueue, CompileInspectionInput, InProcessCompileInspectionGateway,
)
from openhcs.constants import GroupBy, Microscope, VariableComponents
from openhcs.core.config import GlobalPipelineConfig, LazyPathPlanningConfig, LazyProcessingConfig, LazyNapariStreamingConfig
from openhcs.core.orchestrator.execution_result import RuntimeObservationMode
from openhcs.core.orchestrator.orchestrator import PipelineOrchestrator
from openhcs.core.pipeline_document import PipelineDocumentAuthority
from openhcs.core.source_bindings import MetadataExtractionRule, MetadataSource
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.core.steps.function_outputs import OpenHCSMetadataWriter
from openhcs.interop.cellprofiler.pipeline_import import import_cellprofiler_pipeline
from openhcs.serialization.json import to_jsonable

assert Path(openhcs.__file__).is_relative_to(target)
print('ORIGINAL_INSTALLED_ORIGIN', openhcs.__file__, flush=True)
for filename in ('openhcs/core/steps/function_outputs.py',
                 'openhcs/core/steps/function_runtime.py',
                 'openhcs/interop/cellprofiler/runtime/output_recording.py'):
    print('OWNER_SOURCE_SHA256', filename, sha256((target / filename).read_bytes()).hexdigest(), flush=True)

source = run / 'input'
source.mkdir()
inputs = []
for image in sorted((original / 'acquisition').glob('*.tif')):
    inputs.append((image, sha256(image.read_bytes()).hexdigest()))
    shutil.copy2(image, source / image.name)
assert len(inputs) == 2, inputs
steps, imported = import_cellprofiler_pipeline(original / 'intensity600.cppipe')
config = replace(
    imported, microscope=Microscope.SOURCE_BINDINGS,
    processing_config=LazyProcessingConfig(
        variable_components=[VariableComponents.Z_INDEX], group_by=GroupBy.CHANNEL),
    path_planning_config=LazyPathPlanningConfig(global_output_folder=run / 'results'),
    source_bindings_config=replace(imported.source_bindings_config,
        metadata_rules=(MetadataExtractionRule(source=MetadataSource.FILE_NAME,
            pattern=r'(?P<well>[A-H]\d{2})_s(?P<site>\d+)_w(?P<channel>\d+)_z(?P<z_index>\d+)_t(?P<timepoint>\d+)_(?:Gray|Color)\.tif'),),
        source_stack_components=(), source_voxel_spacing=SourceVoxelSpacing((0.5, 0.5))),
    napari_streaming_config=LazyNapariStreamingConfig(enabled=False),
)
document = PipelineDocumentAuthority.from_values(pipeline_config=config, pipeline_steps=steps)
bundle = InProcessCompileInspectionGateway().compile(CompileInspectionInput(
    plate=source, pipeline_document=document, axis_filter=('A01',),
    global_pipeline_config=GlobalPipelineConfig(num_workers=1, use_threading=True),
    progress_queue=AgentProgressQueue(),
)).execution_bundle
print('COMPILED_STEP_INDICES', tuple(bundle.runtime_contexts['A01'].step_plans), flush=True)

original_code = OpenHCSMetadataWriter.OutputTarget.project_runtime_artifacts.__code__
observed = []
def observe(frame, event, argument):
    if frame.f_code is not original_code:
        return None
    if event == 'exception':
        _exception_type, error, _traceback = argument
        if isinstance(error, ValueError):
            local = frame.f_locals
            projection = local['projection']
            metadata = local['metadata']
            differing = {
                member.name: {
                    'automatic': to_jsonable(getattr(projection.image_metadata, member.name)),
                    'named': to_jsonable(getattr(metadata, member.name)),
                }
                for member in fields(metadata)
                if getattr(projection.image_metadata, member.name) != getattr(metadata, member.name)
            }
            witness = {'error': str(error), 'destination': local['destination'],
                'automatic_address': to_jsonable(projection.address),
                'named_address': to_jsonable(local['address']),
                'automatic_metadata': to_jsonable(projection.image_metadata),
                'named_metadata': to_jsonable(metadata), 'differing_fields': differing,
                'automatic_record': to_jsonable(local['record']),
                'named_scope': to_jsonable(local['materialization'].record.key.scope),
                'projection_scope': to_jsonable(projection.execution_scope)}
            observed.append(witness)
            print('ORIGINAL_REJECTED_OPERANDS', json.dumps(witness, sort_keys=True), flush=True)
    return observe

orchestrator = PipelineOrchestrator(source, pipeline_config=config).initialize()
sys.settrace(observe)
threading.settrace(observe)
try:
    outcomes = orchestrator.execute_compiled_plate(
        execution_bundle=bundle, max_workers=1,
        runtime_observation_mode=RuntimeObservationMode.MERGE_INTO_PARENT,
        progress_queue=AgentProgressQueue(),
        progress_context={'execution_id': 'engineering620-original-observation01',
                          'plate_id': str(source), 'axis_id': ''},
    )
finally:
    sys.settrace(None)
    threading.settrace(None)
print('ORIGINAL_OUTCOMES', {key: value.error_message for key, value in outcomes.items()}, flush=True)
print('GUARD_OBSERVATIONS', len(observed), flush=True)
for image, digest in inputs:
    assert sha256(image.read_bytes()).hexdigest() == digest
print('ORIGINAL_INPUTS_UNCHANGED', flush=True)
