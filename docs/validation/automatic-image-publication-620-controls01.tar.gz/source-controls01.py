"""Run the existing source qualification bootstrap with this build's native ABI."""
from pathlib import Path
import runpy
import sys

checkout = Path('/home/ts/wt/openhcs-ui-workflow-rendering-20261001')
sys.path.insert(0, str(checkout))
import openhcs
from openhcs._source_dependencies import ensure_source_checkout_external_paths
ensure_source_checkout_external_paths(Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/source-runtime'))
import openhcs.core
openhcs.core.__path__.insert(0, str(checkout / 'build/lib.linux-x86_64-cpython-312/openhcs/core'))
import openhcs.core._tabular_native as native
assert Path(native.__file__) == checkout / 'build/lib.linux-x86_64-cpython-312/openhcs/core/_tabular_native.abi3.so'
openhcs.core.__path__.pop(0)
print('SOURCE_NATIVE_ORIGIN', native.__file__, flush=True)
sys.argv = [str(checkout / 'validation/mixed-carrier-intensity-domain-599/run_source.py'), *sys.argv[1:]]
runpy.run_path(sys.argv[0], run_name='__main__')
