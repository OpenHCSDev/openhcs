Acquisition positions obsolete metadata consumer
================================================

Read-only source checkpoint:600 c63af64a and main634875dd.
SourceImageProvenanceFields and ImagePayloadMetadata are unchanged for this relation.

The registered acquisition_tile_positions calls source_plane_metadata_records(),
which is not declared anywhere in production. The same absent call appears in
the paired stitched-mosaic consumer in tests/unit/test_source_tile_geometry.py.
Existing ImagePayloadMetadata.source_metadata_by_payload() already returns ordered
scalar ImagePayloadMetadata using source_plane_metadata_count and for_source_plane.
Those records preserve exact source_provenance and contributors. No additional
store, alias or duck-typed fallback is needed. Proposed repair migrates both
callers to this existing capability; its provenance ancestor remains the owner
of source identity/projection, composed through existing metadata MI.

Original retained public record:
/home/ts/wt/openhcs-issue-batch-20260929/next-ownp001-nine88-after604-20261004/P001_FRESH9SITE604_88/author-workspace/output/runtime/mcp.stdout
lines33514,33553 and33558 show job-4 execution_failed before position emission.
Original execution fd76397b-cfb7-41cf-8b88-5cdb49b0d5b3 is not replayed.

Required acceptance: registered positions over a tiny nine-site/two-channel
synthetic source domain, exact ordered embedded positions and shared canvas,
paired assembly analysis retaining represented source IDs/calibration, ordinary
whole-installed public artifact inspection. Original source test includes a
nine-site paired channel/native execution family; inspect before qualification.
This is distinct from600 intensity receiving. Current science unchanged.
