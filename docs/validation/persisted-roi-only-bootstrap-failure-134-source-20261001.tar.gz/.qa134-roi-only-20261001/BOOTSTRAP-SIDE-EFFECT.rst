Bounded harness side effect, retained 2026-10-01
================================================

Projected source check run-p2521341-i15080811.scope exited 124 at 60.03s,
maximum process RSS 304412 KiB; kernel 512MiB/no-swap/one CPU unchanged.
The public service's default PlateInspectionFileManagerFactory.create calls
ensure_storage_registry, selecting the optional ImageJ backend and bootstrap.
This source-only test failed to inject its already-existing disk-only manager.
Owned scratch cache contained an incomplete .imagej-download.shqrh3px.zip of
704712995 bytes and .fiji-20260718-0417-linux_x86_64-eb5d70b3ffb6.wfd69upf
extraction. These are disposable tool dependencies, not microscopy outputs or
uncertain scientific inputs. Original timeout log and test input are preserved.
Exact completed source PID2521345 absent at read-only check. No viewer startup,
installed package edit or parent endpoint control occurred. Do not claim this
attempt was download-free. Later tests must inject the original disk-only
manager through the service's factory boundary and forbid backend bootstrap.
