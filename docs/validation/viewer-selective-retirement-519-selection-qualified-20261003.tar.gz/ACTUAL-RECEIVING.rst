Actual public receiving, retirement and native review, 2026-10-03
================================================================

Parent operated ONE retained MCP shell63937 on target06/d92 qualified package,
original scopee1f0119dfeb6498eb219233d819db025, isolated95. Original source
metadata/archive were namespace-read-only; failed compilejob9292 was NOT replayed.
Actual healthy first-use/workflow/viewer contexts and full reflected schemas
preceded receiving. Full unabridged calls/results are runtime/mcp.stdin/stdout.

One raw stream mounted all4 original5x7 planes, orderedZ0,1,2,3, seven native
axes site/channel/z_index/timepoint/well/y/x, ZYXscale2/.65/.65 micrometers.
Complete140 exactrawvalues read through MCP: planes0/3zero,1/2 have the same
2x2 foreground atY1..2/X2..3. Native raw window0..1/gamma1 throughout review.

One saved989B ZIP stream mounted native Points with complete sourceZdomain0..3,
same transform, one feature row. Public shape payload has object_label7,
center_z1.5/center_y1.5/center_x2.5 and original four source-plane provenance.
Native data_index0 selection returned selected_data_indices[0]. Selection moved
integer slice toZ2/world4; that is NOT the exact fractional point coordinate.
The persisted point's calibrated coordinate isZ3/Y.975/X1.625 micrometers;
cross-section native review below independently checks rendered alignment.

Selective retirement used the current point route's complete9field original
producer identity, including invocation_key:null. ACK observed/appliedtrue,
errors[], retired exactly that Points route, remaining exactly the raw route.
Subsequent state showed raw payload summaries identical, Zdomain0..3, calibration
and camera unchanged. This exercises a raw survivor; it DOES NOT demonstrate
native selected_data preservation for a surviving feature-bearing layer.
No unsupported lower-RSS claim is made for released route buffers.

After definitive retirement, a separately recorded NEW manual transaction
reopened the same original ZIP on the SAME native process. Source domain,
transform, row count and route/producers matched original manual identities;
manual projection has no invented per-invocation identity. Native row0 selection
again returned[0]. Original metadata and ZIP SHA256 verified unchanged after.

Nine native1440x950 window PNGs captured via MCP render_complete, each personally
opened by parent. For each raw/point/combined triplet, full viewer state preceded
each capture: identical dimensions/order/world point/canvas962x448/camera,
numeric raw window, raw mounted even when invisible; no planar Shapes mounted.
XY atZ1: raw2x2 white square; point centred over it, point-only has black canvas.
XZ atY2: raw vertically extended two-plane rectangle; fractional point centred
between source planes1/2 in combined view. YZ atX3: same calibrated alignment.
Point display footprint exceeds the tiny fixture: acceptance is point coordinate
and cross-section alignment, not mask area or a biological segmentation claim.

Known native geometry800x600 rejection is retained unchanged. Empty presentation
read back CURRENT1440x950, not the Qt dynamic minimum. No X/mouse input or Qt
bypass was used. PARENT-GEOMETRY-ADMISSION.rst records same64Mi total reallocation
56Mi retained/8Mi scratch before captures;9actual PNGs total730733B. Actual
whole case5144576B/scratch3899392B before final receipts. Common3GiB/Swap0
scope peak969527296B observed; no parent source/build/install/helper changes.

Typed close ACK acknowledged/succeeded/process_exited/endpoint_terminatedtrue,
exact nativePID3457301/create_time1791021595.84/start49723584. Independent
ps/socket checks then proved viewer3457301 and MCP3414484 absent,6015/7015
unbound, original scope inactive. Original client63937 is TERMINAL1 at10:08:33.
This is the CLI aggregate error result, NOT failed close: dev_client.py
_run_persistent_shell retains max(execution.returncode), including the earlier
known geometry rejection. No persistent-session-failed text occurred.

Original journals are now closed, frozen SHA256:
stdin62acff2fa4e5dbaf4c7a213c8fa8a93c7554fab3e7940e85f1bfac6a6a1288ef
stdout1acda7973aee96bcd1bdc3fb6f86c5930a7ca16ff05b270f35ec4474a29340ae
timing15e702b268f021d2c30816e85b0eda905250bc5993e5e47450905e90f81bbf36
Original metadata f0f1c48a2a9a9e2e4449a5d4355f30433e3add1097976ffbdabdcca808cb7407
Original ZIP fd0a372f3100c73da9533b308d44c2f85fa7a86b733e2608ae986135cb4e401a

Limits: this proves public saved-archive receiving and positive selective route
retirement on this engineering fixture, not Root435 automatic execution stream,
wrong-producer negative control, surviving-point selection restoration, complete
fresh native catalog511 verification, or any biological analysis accuracy.
Scientific authors94/96 were never contacted or coached; their original
frozen skills/package and saved evidence remain unchanged.
