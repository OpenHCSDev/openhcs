"""Source-only caller of existing audit AST facts; no product imports or scanner copy."""

import ast
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/ts/code/projects/nominal-refactor-advisor/skills/refactor-audit/scripts")
from audit.findings import FunctionFacts, ParsedModule
from audit.repository import Repository

repo = Repository(Path.cwd())
revision = repo.git("rev-parse", "HEAD").strip()
root_revision = repo.git("rev-parse", "openhcsdev/perf/shared-runtime-plumbing-20261001").strip()
symbols = frozenset((
    "NapariComponentAwareDisplayCoordinator", "NapariLayerRouteStateStore",
    "NapariLayerSettlementState", "NapariPendingLayerUpdate", "NapariLayerDisplayPipeline",
    "NapariLayerDisplayRequest", "NapariLayerDisplayWork", "NapariShapesLayerDisplayWork",
    "NapariLayerDisplayHandler", "NapariLayerUpdateAuthority", "NapariLayerSelectionAuthority",
    "NapariComponentGroupStore", "NapariBatchProcessorStore", "NapariBatchProcessor",
    "ViewerRouteComponentValueTracker", "ViewerComponentValueDomain", "NapariStreamLayerItem",
    "NapariLayerRoute", "StreamProducerIdentity", "StreamRouteKeyAuthority", "NapariBatchDisplayRequest",
    "NapariControlMessageAction", "NapariMountedRouteControlMessageAction",
    "NapariSettleControlMessageAction", "NapariLayerIsolationControlMessageAction",
    "NapariAcceptedControlRequest", "NapariViewerStateProjection", "NapariViewerPayloadProjection",
    "ViewerWindowGatewayABC", "ZMQViewerWindowGateway", "ViewerWindowService",
    "ViewerWindowControlRequest", "ViewerWindowLayerIsolationRequest",
    "ViewerLayerIsolationControlOptions", "ViewerWindowLayerIsolationResult",
    "ViewerWindowCliConnectionCapability", "IsolateViewerWindowLayersCapability",
    "AgentViewerWindowRequestServiceInvocation", "ViewerSettleProgress", "ViewerSettlePhase",
    "ViewerStreamingDataTypeHandler", "ViewerStreamingDataTypeHandlerMeta",
    "clear_accumulated_stream_state", "_reconcile_deleted_layer", "_reconcile_deleted_layers",
    "layer_route_state", "component_groups", "component_values", "batch_processors",
    "_display_work_by_route", "layer_settlement", "layer_pending_updates",
    "purge_route", "cancel_pending_update", "drain_pending_updates", "reset_settlement",
    "reconcile_mounted_axis_projections", "settle_viewer_state", "route_for_layer",
    "retire_layers", "mutation_boundary", "require_retirement_boundary", "require_terminal",
    "purge_display_work", "producer_identities_for", "preserve_native_presentation",
    "NapariRematerializationRequest", "NapariImagePresentationRetention",
    "NapariLayerRetirementControlMessageAction", "ViewerLayerRetirementControlOptions",
    "ViewerWindowLayerRetirementRequest", "ViewerWindowLayerRetirementResult",
    "ViewerLayerRetirementReceipt", "RetireViewerWindowLayersCapability", "RetireViewerCommandSpec",
    "ViewerWindowPresentationRequest", "ViewerWindowPresentationResult", "ViewerNativePresentationCapability",
    "presentation_control", "from_snapshot", "admit_request", "retained_callback", "require_viewer",
    "NapariResultElementSelectionState", "NapariResultElementSelectionAuthority",
    "NapariResultSelectionController", "NapariResultSelectionGroupAuthority",
    "NapariResultSelectionGroupBinding", "NapariResultSelectionGroupIndex",
    "ObjectArtifactSubjectBinding", "NapariShapeLayerPayload", "NapariShapeFeatureColumns",
    "selected_data", "features", "bind_result_selection_layer", "_build_nd_points",
    "_queue_selection", "_synchronize_linked_group", "_apply_selection",
    "NapariSelectablePresentationRetention", "preserve_selection", "element_identity",
))
dependencies = (
    Path("external/zmqruntime/src/zmqruntime"),
    Path("external/metaclass-registry/src/metaclass_registry"),
    Path("external/pyqt-reactive/src/pyqt_reactive/services"),
    Path("/home/ts/wt/pyqt-reactive-render-complete-snapshot-20261001/src/pyqt_reactive/services"),
    Path("external/PolyStore/src/polystore/streaming"),
    Path("/home/ts/wt/basicpy-live-candidate-20260930/.venv/lib/python3.12/site-packages/polystore/streaming"),
    Path("/home/ts/code/projects/openhcs/.venv/lib/python3.12/site-packages/napari/components"),
    Path("/home/ts/code/projects/openhcs/.venv/lib/python3.12/site-packages/napari/utils/events"),
    Path("/home/ts/code/projects/openhcs/.venv/lib/python3.12/site-packages/napari/layers"),
)
dependency_details = "--dependency-details" in sys.argv
if "--scene-details" in sys.argv:
    dependency_details = True
    dependencies = (
        Path("/home/ts/code/projects/openhcs/.venv/lib/python3.12/site-packages/napari/_vispy"),
        Path("/home/ts/code/projects/openhcs/.venv/lib/python3.12/site-packages/napari/_qt"),
    )
failures = []
counts = {"production": 0, "tests": 0, "dependency": 0}
selected = {key: 0 for key in counts}
for category, paths in (
    ("production", () if dependency_details else repo.python_files(revision, "openhcs")),
    ("tests", () if dependency_details else repo.python_files(revision, "tests")),
    ("dependency", tuple(str(path) for root in dependencies for path in sorted(root.rglob("*.py")))),
):
    for path in paths:
        source = repo.source(revision, path) if category != "dependency" else Path(path).read_text()
        try:
            module = ParsedModule(path, source, ast.parse(source, path), path[:-3].replace("/", "."))
        except SyntaxError as error:
            failures.append((path, str(error)))
            continue
        counts[category] += 1
        references = [
            {"line": node.lineno, "expression": ast.unparse(node), "context": type(node.ctx).__name__}
            for node in ast.walk(module.tree)
            if (isinstance(node, ast.Name) and node.id in symbols)
            or (isinstance(node, ast.Attribute) and node.attr in symbols)
        ]
        if not references and not dependency_details:
            continue
        selected[category] += 1
        declarations = []
        for node in ast.walk(module.tree):
            if isinstance(node, ast.ClassDef):
                declarations.append({"line": node.lineno, "class": node.name,
                                     "bases": [ast.unparse(base) for base in node.bases]})
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                facts = FunctionFacts(node.name, node.end_lineno - node.lineno + 1)
                facts.visit(node)
                declarations.append({"line": node.lineno, "function": node.name,
                                     "args": ast.unparse(node.args),
                                     "return": ast.unparse(node.returns) if node.returns else None,
                                     "decorators": [ast.unparse(item) for item in node.decorator_list],
                                     "dispatch": {key: sorted(value) for key, value in facts.dispatch.items()},
                                     "keys": {key: sorted(value) for key, value in facts.keys.items()},
                                     "checks": facts.type_checks,
                                     "constructed": sorted(facts.constructed)})
        root_equal = source == repo.source(root_revision, path) if category == "production" else None
        print(json.dumps({"category": category, "path": path,
                          "sha256": hashlib.sha256(source.encode()).hexdigest(),
                          "root_equal": root_equal, "references": references,
                          "imports": [ast.unparse(node) for node in ast.walk(module.tree)
                                      if isinstance(node, (ast.Import, ast.ImportFrom))],
                          "declarations": declarations}), flush=True)
print(json.dumps({"revision": revision, "root_revision": root_revision,
                  "parsed": counts, "selected": selected, "failures": failures,
                  "dependency_roots": [str(path) for path in dependencies],
                  "limits": "static source facts; not a whole NRA detector result or executed lifecycle proof"}), flush=True)
raise SystemExit(bool(failures) or any(not root.is_dir() for root in dependencies))
