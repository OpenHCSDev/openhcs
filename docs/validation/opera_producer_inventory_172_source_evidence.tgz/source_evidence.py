"""Disposable focused evidence; not a product gate or replacement detector."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = "b31807d9de067e18d212bdf9353d05099757fc74"
FILES = (
    "openhcs/demo/synthetic_data.py",
    "openhcs/core/components/parser_metaprogramming.py",
    "openhcs/microscopes/imagexpress.py",
    "openhcs/microscopes/opera_phenix.py",
)

if sys.argv[1] == "baseline":
    from openhcs.demo.synthetic_data import SyntheticMicroscopyGenerator
    from openhcs.microscopes.microscope_interfaces import FilenameParser
    import openhcs.demo.synthetic_data as source
    assert Path(source.__file__).resolve() == Path.cwd() / FILES[0]
    plate = Path(__file__).parent / "original-base-plate"
    generator = SyntheticMicroscopyGenerator(
        str(plate), format="OperaPhenix", grid_size=(1, 1), tile_size=(32, 32),
        overlap_percent=0, stage_error_px=0, wavelengths=1, z_stack_levels=1,
        num_cells=4, wells=["A01"], random_seed=7, openhcs_format=True,
    )
    generator.generate_dataset()
    document = json.loads((plate / "openhcs_metadata.json").read_text())
    metadata = document["subdirectories"]["Images"]
    parser = FilenameParser.__registry__[metadata["source_filename_parser_name"]]()
    from openhcs.constants.constants import AllComponents
    persisted = set(metadata["wells"])
    parsed = {parser.parse_filename(path.name).value_for(AllComponents.WELL)
              for path in plate.rglob("*.tiff")}
    print(json.dumps(dict(source=source.__file__, persisted=sorted(persisted),
                          parsed=sorted(parsed), combined_count=len(persisted | parsed))))
    assert persisted == parsed, "Original producer/filename well identities disagree"
elif sys.argv[1] == "imports":
    import importlib
    modules = {}
    for path in FILES:
        module = importlib.import_module(path[:-3].replace("/", "."))
        origin = Path(module.__file__).resolve()
        assert origin == Path.cwd() / path
        modules[module.__name__] = str(origin)
    for name in ("polystore", "arraybridge", "metaclass_registry"):
        modules[name] = importlib.import_module(name).__file__
    assert Path(modules["polystore"]).is_relative_to(
        "/home/ts/wt/polystore-metadata-namespace-327-20261001/src")
    print(json.dumps(dict(interpreter=sys.executable, modules=modules), indent=2))
else:
    sources = {}
    for path in FILES:
        before = subprocess.check_output(["git", "show", f"{BASE}:{path}"], text=True)
        after = Path(path).read_text()
        sources[path] = dict(sha256=hashlib.sha256(after.encode()).hexdigest(),
                             before_lines=len(before.splitlines()),
                             after_lines=len(after.splitlines()))
        ast.parse(before)
        ast.parse(after)
    generator_tree = ast.parse(Path(FILES[0]).read_text())
    generator = next(node for node in generator_tree.body if isinstance(node, ast.ClassDef))
    methods = {node.name: node for node in generator.body if isinstance(node, ast.FunctionDef)}
    assert "imagexpress_filename" not in methods
    metadata = methods["generate_openhcs_metadata"]
    assert not any(isinstance(node, (ast.If, ast.IfExp)) for node in ast.walk(metadata))
    called = {node.attr for node in ast.walk(metadata) if isinstance(node, ast.Attribute)}
    assert {"metadata_dict", "replace_subdirectory_metadata"} <= called
    assert {"source_voxel_spacing", "require_physical_pixel_size", "merge_into"} <= called
    assert [argument.arg for argument in metadata.args.args] == ["self", "sub_dir"]
    for name in ("_write_plane", "_plane_components", "generate_openhcs_metadata"):
        assert not any(isinstance(node, ast.Attribute) and node.attr == "format"
                       for node in ast.walk(methods[name]))
    leaf_methods = {}
    for path in FILES[1:]:
        tree = ast.parse(Path(path).read_text())
        leaf_methods[path] = [node.name for node in ast.walk(tree)
                              if isinstance(node, ast.FunctionDef)
                              and node.name == "construct_acquisition_filename"]
        assert len(leaf_methods[path]) == 1
    print(json.dumps(dict(base=BASE, sources=sources, acquisition_owners=leaf_methods,
                          parsed_files=len(FILES), generator_metadata_format_switches=0,
                          calibration_owner="MetadataHandler.source_voxel_spacing / SourceVoxelSpacing",
                          proof="focused AST, not NRA schema/descent certificates"), indent=2))
