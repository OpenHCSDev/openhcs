Refs #172 and #335; keep both open until parent-owned installed producer acceptance. Builds on merged #206/#16 and normally integrated #329/main `2cbfc4a0` (frozen XML parser unchanged).

## Working source checkpoint

- Existing registered handler/parser declarations own acquisition spelling; `GenericFilenameParser` supplies the shared nominal operation. No new production classes, type/string dispatch roster, well formatter or consumer alias.
- Actual saved `SourcePlaneProjection` addresses feed the existing serializer: all five catalogs, source metadata, projection entries and exact physical refs stay coherent. Fixes Opera A01/R01C01 disagreement and ImageXpress Z-folder basename/ref collisions; deleted replaced generator paths.
- Calibration now comes from the selected acquisition metadata handler's existing typed `SourceVoxelSpacing`, decoded from actual HTD/XML. Native scalar and every persisted source coordinate share that authority. Deleted the independent 0.65 override/argument and migrated its fixture caller; raw calibration declarations unchanged.

## Inheritance/new-case evidence

Two independent test capabilities (acquisition recording and physical name scoping) derive from the real owning ABC, call `super()`, and compose with the existing ImageXpress leaf in both cooperative diamond orders. Each executes once, the common ancestor appears once, its canonical behavior preserves all axes, and automatic declaration registries admit new parser and handler leaves with zero consumer/registry edits. The unchanged plane writer, serializer and fresh real disk metadata reader handle the new case. No claim of arbitrary new-format HTD/layout support.

25 real-source contract methods pass, including raw/native format, Z, token, sparse-site, scalar Bio-Formats, XML URL, exact-ref/reopen, MRO, paired calibration/pixel parity and fail-closed missing acquisition controls. The 34-method existing regression shard passes after calibration. Original unchanged R0 passes (only generator GodClassExcess -131); focused current-archive census has zero unparsed files. Original R1 fails before analysis because recorded submodules are uninitialized; no global R1/NRA pass or waiver is claimed. Original errors and qualified evidence are retained in the freshly verified archive alongside the RST.

Full ownership/pattern witnesses, commands, resource evidence, original failures and precise proof limits: [RST receipt](docs/validation/opera_producer_inventory_172.rst).

Parent owns merge/integration/install and first-class raw/native MCP initialize, inspect, sample, persisted reopen and combined inventory acceptance. No compiler #331, runtime #326, renderer #334, installed/frozen files, original fixtures, science/native/JVM/MCP slot or dependency downloads were touched. One CPU, bounded 512 MiB RSS/60-second shards, scratch below 256 MiB.
