Synthetic Opera raw/native calibration disagreement
==================================================

Active source owner: Averroes, existing synthetic producer PR333.
Parent owns integration and installed MCP qualification; no competing patch.
This predates PR333, and is not attributed to its identity fix or PR329.

Exact source witness: PR333 reviewed source6d81dfd9f420970172d4e379d7cbed34c3d9fa01,
openhcs/demo/synthetic_data.py:630 sets Opera pixel_size_meters to
1.1867525298988041e-6 for ImageResolutionX/Y; :988 instead passes0.65
micrometers to generate_openhcs_metadata. :1050 publishes that independent
value through the existing source projection metadata serializer.
Original main has the same two conflicting declarations.

Parent installed real MCP raw Opera fixture from PR329:
generate one64x64 field/well/channel/Z, zero overlap/stage error, seed7;
inspect and empty-document initialization expose pixel_size1.1867525298988042
and source voxel spacing1.1867525298988042,1.1867525298988042.
Original outputs are retained in opera-installed-20261001/installed-live.stdout.
No openhcs-format native variant was run by parent for this issue yet; source
shows that variant emits0.65. This is confirmed conflicting source authority
plus live raw-route evidence, not a claimed paired live comparison.

Acceptance: raw and OpenHCS-format generation of the same seeded acquisition
must retain identical calibration units/XY values through persisted metadata,
fresh initialize/inspect/reopen and bounded MCP sampling. Derive values from
the actual acquisition owner, not another format switch/constant, new metadata
store or viewer-only scale correction. Exercise existing ImageXpress too.
Retain explicit pixel-only/unverified status where physical calibration is
absent; never substitute fixture calibration for scientific validation.

Source unit/control tests plus parent installed paired-route check required.
Frozen blind fixtures/outputs and historical failing fixtures remain untouched.
Source fixes are parallel; installed/native checks follow scientific slot
closure. CI is deferred, not local or live qualification.
