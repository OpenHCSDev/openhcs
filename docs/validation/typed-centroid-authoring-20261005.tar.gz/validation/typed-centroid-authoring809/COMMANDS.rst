Read-only contract and knowledge qualification
=============================================

Use existing ``scripts/run_installed_tests.py`` and the paired interpreter,
with read-only receiving14 backing. No install, build, native/viewer, catalogue,
provider or live managed-skill mutation. Fixture source is this checkout.
``--noconftest`` and disabled pytest autoload avoid unrelated UI/science plugins.
The existing package projection and isolated managed-sync test own those checks.

The first stdlib AST pass parsed/compiled both new canonical named blocks.
Current source and backing are byte-identical for artifacts, callable contract,
runtime measurements, aligned image payloads, PointROIOptions and tabular CPP.
CPP SHA256:15acc82b8ab64268bd1ea4f83fa7a68f527bf317f002e9f39e15be321e03b28e.
Qualified receiving14 native SHA256:
a2109a4ca25a1a4b0a88a340136ed4a0c8c44843aa638a1d48f276e97e22bc5e.
The backing writer additionally contains unmerged #748 PointROIOutput/source
geometry; no claim is made that current main has that automatic streaming hook.

Fresh resource check: available RAM11.3GiB, existing swap14.8GiB, home9.5GiB.
Warnings are retained, not a blanket veto. Memory PSI some/full avg10/60/300
all0.00. One serial docs/contract batch, CPU thread settings1, ordinary60s
outer bound, no invented hard memory/swap caps; time reports actual usage.

Exact command is retained in the terminal invocation and complete raw stdout/
stderr; original failures, if any, are kept unchanged as numbered attempts.
