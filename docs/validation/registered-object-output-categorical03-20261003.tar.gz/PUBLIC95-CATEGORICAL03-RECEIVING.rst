50395 dual-role source receiving03: original public negative preserved
====================================================================

Parent sole PTY83658/native6014 PID2355303 remains assigned/ready. Default02
artifact-plan failed compile_inspection_failed before new session/compile/
execution, axes0/steps0: MeasureObjectSizeShape cannot resolve ObjectLabels
Objects group scope. Original mcp.stdout4839..4842 contains the exact error.
No unchanged replay. All02 files stay unchanged; the earlier02 packet/archive
is historical prepared intent, NOT a successful public route. Removed01/session2
must NOT compile/execute. Default01 original ALLZERO/shape-empty failure stays.

Issue521 / Root394 contact5966037153 identify the original typed group-resolver
seam, not a competing production patch. Root latest observedb312148855b6 owns
the shared source/compilation integration. No proof of a product defect under
an explicitly selected source-binding handler is claimed at this checkpoint.

Determining source evidence and supported03 declaration
------------------------------------------------------

Observed input/openhcs_metadata.json still contains only original primary Labels,
microscope_handler_name bioformats / parser BioFormatsFilenameParser, no Objects
source artifact. Byte-exact observed copy default02-input-metadata-observed.json
SHA2567b895ddc1710748d46e46d644e9df7384d25958a57eb62176e5cfdc0d60b46ca.
The original metadata file was NOT edited. This is receiving metadata evidence,
not a capture of the failed resolver's internal state or selected handler.

PathPlannerExecutionGroups.artifact_owned_execution_scope uses exact declared/
context producer or source bindings, then original component_group_keys_for_
artifact_specs with CompilationSession.realized_source_metadata. Binding values
derive from declared selectors/identity or alias-matching realized metadata.
SourceProjectionSet explicitly supports artifact-only anchors; existing public
Objects-only CombineObjects fixture exists. Therefore artifact-only support is
intended, but the02 public failure alone does not establish where it was lost.

Crucial existing selection contract: OpenHCSMicroscopeHandler is PREPARED_WORKSPACE;
MicroscopeSourceSelectionRole.bindings_may_select_handler deliberately prevents
new declarations silently replacing a prepared receipt under AUTO. Config's
existing ``microscope`` field permits exact SOURCE_BINDINGS for arbitrary ordinary
files. Orchestrator.initialize_microscope_handler consumes that field and the
original source config; SourceBindingsHandler.initialize_workspace rebuilds
physical sources via SourceBindingWorkspaceProjector, rather than pretending a
persisted Labels-only projection already contains Objects. Generated public
pipeline source fixture already exercises explicit SOURCE_BINDINGS (read only).
This suggests a source-selection/configuration mismatch, not a license to patch
the resolver or override prepared-receipt guards. Actual failed handler identity
was not observed.03 explicitly declares the intended original source owner.

Both NEW03 documents use ``microscope=Microscope.SOURCE_BINDINGS`` through the
ordinary PipelineConfig field, not an environment/installed edit/private loader.
They declare two typed views of the SAME physical TIFF:

* Grayscale Labels: ImageArtifactType / PRIMARY_PLANE, ordinary image carrier.
* Objects: ObjectLabelsArtifactType / SOURCE_ARTIFACT, categorical IDs.

Source proof: NamesAndTypesModule consumes the two declarations; its existing
Match metadata decoder produces SourceBindingMatchDimension/Field declarations.
MetadataSourceSetAssembler joins candidates separately per alias on well, site,
channel, z_index, timepoint from the SAME original filename rule. It does not
reject shared physical refs. OrderSourceSetAssembler WOULD reject identical
alias source universes, so03 uses declared Metadata matching, not ORDER bypass.
SourceBindingProjectionStrategy dispatches each declared role; primary Labels
and namespaced _source/Objects virtual projections can refer to the same original
backend address without duplicate physical data. Serializer validates unique
virtual paths; no manually authored metadata/group keys/bindings.

ObjectLabelsArtifactType/its runtime strategy keep scalar IDs through original
VFS/workspace loader and SourceImageObjectLabelBuildRequest. Normalizing the
separate image carrier cannot be used as the categorical label argument.
Source/raw unchanged, no ConvertImageToObjects numeric intensity casting.
Metadata matching and explicit source owner are supported contracts, NOT an
installed03 PASS claim. The dual-role declaration also does not prove a primary
carrier is universally required for artifact-only pipelines.

New files and sole-parent commands
---------------------------------

Original output root:
/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output

labels503-default03.cppipe + pipeline-default03.py -> results-default03
labels503-removed03.cppipe + pipeline-removed03.py -> results-removed03

Complete original importer documents, one Shape Objects and one FilterObjects
default/removed-enabled respectively; normal Z/channel grouping,1um source
spacing and streaming disabled. No source session/compile/execution by Singer.

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-default03.py --global-config-id config-1 --json

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-removed03.py --global-config-id config-1 --json

Parent existing shell ONLY, actual fresh admission/normal public contracts.
On returned successful plan, NEW sessions/jobs and exclusive default03-values.json
/ removed03-values.json; no old session2/failed source replay. Explicit source
preparation may normally rewrite engineering workspace metadata; source TIFF and
all earlier failed result/export/documents must remain intact. If03 fails, retain
its first reply and report the determining original owner; no guessing group keys.

Unchanged acceptance: source12x15uint16 IDs2/7, exact areas6/20; shape rows
object_label/LABEL_ID, AreaShape_Area; retained7->target1 on exact20 pixels,
removed2->separatetarget1 on exact6 pixels. Typed Objects parent -> named target
child domain, actual public producer identity and parent_id/child_id plus raw
source_ids/target_ids agree. Default4/enabled6 ABI and no default removed artifact.
Do not reuse guessed filenames/module numbers; actual returned contract owns them.
Raw SHA1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e.

VALUES suffix .json remains gzip/pickle; original
ZMQRuntimeExecutionObservationExport.read(Path(path)) and .observation() own
decoding. No JSON mirror/manual unpickling by Singer. Existing source/wheel/
target02 and all accepted21 installed controls unchanged, no repeat qualification.
Only new03 Python AST syntax checked; public receiving remains parent-owned.
NRA IDEN-1/BOUND-2 keep primary image/categorical artifact/source-owner facts
distinct; no switches, duplicate authority, new algorithm/registry or shared edit.

SHA256:
default CPPipe7bde88397b53638422c6ba6debe2f408ba95caa36d71c07b4c362663b2f37628
removed CPPipe7e2dab65974b915e876becfb83396c9244633ba452b38bb86dea5e7b1a433bfd
default Python54f4a47ca4397b610bacdc7e38ca14da6bc3e717ce73a907b8e79f9b60120d14
removed Python5c5110ec31681de0f56cfd834f0a6c0027be4a03907dc11a26cec1ddc74fadf7
