Artifact-only public NamesAndTypes Objects cannot resolve typed group scope
==========================================================================

Receiving refinement: observed persisted input metadata remains Labels-only
BioFormats receipt. Existing AUTO prepared-workspace selection deliberately
does not replace receipts with new bindings. Failed exact handler identity is
unobserved. New03 explicitly selects SOURCE_BINDINGS and declares dual roles
through original metadata matcher. Treat source-selection/config mismatch as
a determining candidate; no demonstrated defect under the explicitly selected
handler, no speculative resolver patch. See PUBLIC95-CATEGORICAL03-RECEIVING.rst.

Actual ordinary installed public artifact-plan of pipeline-default02.py fails
compile_inspection_failed / ValueError before any new source session/compile/
execution. Original mcp.stdout determining error currently4839..4842:
Artifact-owned FunctionStep 'MeasureObjectSizeShape' cannot resolve group scope
for ArtifactSpecRef(plan_type=ArtifactInputPlan,
artifact_type=ObjectLabelsArtifactType, name='Objects'). Axes0/steps0.

Exact original source packet: engineering503/LABELS503_95/author-workspace/output/
labels503-default02.cppipe and pipeline-default02.py. NamesAndTypes Objects only,
one categorical12x15uint16 source IDs2/7, MeasureObjectSizeShape then one default
FilterObjects. Z variable/channel group; normal filename metadata/1um spacing,
streaming off. Raw source hash1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e.
Whole qualified sourcec031/target02, native6014 ready. Parent sole original
PTY83658/PID2355303. Original02 error/input/hash remains preserved/no replay.
Default01's upstream intensity-domain ALLZERO is separate and also preserved.

Named integration owner: Root394, currentb312148855b6. Singer503 receiving only,
no competing patch to source bindings/workspace/compilation/path planner.

Source support and exact receiving seam
--------------------------------------

SourceProjectionSet.execution_anchor_projections explicitly returns typed
artifacts when there are no primary planes. SourceBindingsHandler projects
declared source workspaces. Existing artifact-only source workspace fixture
and public CombineObjects NamesAndTypes Objects compilation fixture establish
intended source support (read only here, not requalified).

PathPlannerExecutionGroups.artifact_owned_execution_scope resolves declared/
context producers, then exact source bindings and component_group_keys_for_
artifact_specs with CompilationSession.realized_source_metadata. It rejects
absent source lineage or ungrouped source scope under CHANNEL. The exact public
error does not distinguish those two identical-message branches; no assertion
of captured internal binding/metadata values. NamedSourceBinding.component_values
uses declaration identity/selectors first, otherwise alias-matching realized
source metadata. CompilationSession derives that metadata from the axis-scoped
VirtualWorkspaceSourceProjection, not a private parallel catalog.

This route is intended, not explicitly documented unsupported. Root should
resolve whether public reconstruction loses the binding or the original source
projection loses realized alias/component scope. Preserve strict exact-artifact
and group-scope validation, not fake group keys/GroupBy.NONE/counterfeit bindings.

Required acceptance
-------------------

Original default02 complete document -> original public artifact-plan has one
actual source axis and both steps; then normal execution preserves Objects IDs2/7
and joins shape6/20, retained7->1. Source-only control must use actual imported
public callable/typed source/context; no stub hardcoded component scope. Existing
artifact-only multi-source fixture and independent declared source family remain
supported. Final installed public route stays parent-owned.

Independent receiving03 is a separately authored supported dual-role declaration,
NOT proof this artifact-only failure is fixed: Grayscale Labels primary carrier
plus Objects categorical SOURCE_ARTIFACT, same acquisition through declared
METADATA matching; no copied data/numeric remap/private loader. ORDER would
correctly reject identical alias source universes, so do not bypass that check.
