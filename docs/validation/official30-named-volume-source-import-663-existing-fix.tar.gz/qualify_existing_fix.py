"""Qualify the already-merged dependency source against the original recipe.

This is source-qualified import, not a replaced installation or live MCP run.
"""
import hashlib
import json
from pathlib import Path
import sys

target = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering-pre-first-routing-20261004/receiving03/target')
dependency = Path('/home/ts/wt/objectstate-nested-config-declaration-20261004/src')
sys.path[:0] = [str(dependency), str(target)]
import objectstate
assert Path(objectstate.__file__).is_relative_to(dependency)
print(json.dumps({'dependency_source': objectstate.__file__,
    'version': objectstate.__version__,
    'context_sha256': hashlib.sha256((dependency / 'objectstate/context_manager.py').read_bytes()).hexdigest()}), flush=True)

from openhcs.interop.cellprofiler.pipeline_import import import_cellprofiler_pipeline
from openhcs.core.pipeline_document import PipelineDocumentAuthority
from openhcs.core.source_spatial_domain import VolumeSourceSpatialDomain

recipe = target / 'openhcs/agent/resources/knowledge/benchmark/manifests/official30_portable_axis1.sources/dataset_cache/CellProfiler_tutorials/data/3d_monolayer/3d_monolayer_final.cppipe'
steps, config = import_cellprofiler_pipeline(recipe, source_root=recipe.parent / 'images')
assert tuple(b.alias for b in config.source_bindings_config.binding_declarations) == (
    'origDNA', 'origMito', 'origMemb')
assert isinstance(config.source_bindings_config.source_spatial_domain, VolumeSourceSpatialDomain)
document = PipelineDocumentAuthority.from_values(pipeline_config=config, pipeline_steps=steps)
source = PipelineDocumentAuthority.render(document)
print(json.dumps({'steps': len(steps), 'aliases': [b.alias for b in config.source_bindings_config.binding_declarations],
    'domain': type(config.source_bindings_config.source_spatial_domain).__name__,
    'public_source_chars': len(source), 'public_source_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'tier': 'existing merged dependency source + unchanged installed OpenHCS importer; no live or parity proof'}), flush=True)
