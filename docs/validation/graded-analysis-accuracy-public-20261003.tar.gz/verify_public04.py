"""Read the closed original public journal through existing typed DTO owners."""
import hashlib
import json
from pathlib import Path

import openhcs  # Activate original source dependency owners before their consumers.
from python_introspect import dataclass_from_mapping
from openhcs.agent.dto.authoring import AuthoringContext
from openhcs.agent.dto.knowledge import KnowledgeBaseDocument
from openhcs.agent.image_analysis_qa import ImageAnalysisQaPolicy
from openhcs.agent.services.llm_context_service import AgentAuthoringContextService

case = Path(__file__).resolve().parent
root = case / "public04/source"
raw = (case / "public04/mcp.stdout").read_text()
decoder = json.JSONDecoder()
replies = []
for offset in range(len(raw)):
    if raw[offset] != "{" or (offset and raw[offset - 1] != "\n"):
        continue
    reply, _ = decoder.raw_decode(raw[offset:])
    assert not reply["errors"]
    replies.extend(reply["results"])
assert [reply["tool"] for reply in replies] == [
    "openhcs_health_check", "openhcs_get_authoring_context",
    "openhcs_get_authoring_context", "openhcs_get_knowledge_document",
]
assert all(not reply["mcp_error"] for reply in replies)
health = replies[0]["payloads"][0]
assert health["status"] == "ok" and not health["errors"]
assert health["server_source_path"] == str(root / "openhcs/mcp/server.py")
assert not health["server_source_changed_since_import"]
service = AgentAuthoringContextService()
contexts = []
for reply in replies[1:3]:
    delivered = dataclass_from_mapping(AuthoringContext, reply["payloads"][0])
    assert delivered == service.get_authoring_context(delivered.kind)
    assert len(delivered.content) <= 16000
    contexts.append({"kind": delivered.kind, "chars": len(delivered.content),
                     "sha256": hashlib.sha256(delivered.content.encode()).hexdigest()})
document = dataclass_from_mapping(KnowledgeBaseDocument, replies[3]["payloads"][0])
target = ImageAnalysisQaPolicy.claim_scope_target
assert not document.errors and not document.truncated
assert document.selected_section_id == target.section_id
source = root / document.document.source_path
section = target.find_section(document.sections)
assert document.content.strip() == "\n".join(section.span.line_slice(
    tuple(source.read_text().splitlines())
)).strip()
synced = case / "public03/isolated-skills/use-openhcs"
canonical = root / "packaging/codex/openhcs/skills/use-openhcs"
members = tuple(path for path in canonical.rglob("*") if path.is_file())
assert all((synced / path.relative_to(canonical)).read_bytes() == path.read_bytes()
           for path in members)
print(json.dumps({"status": "PASS", "source": str(root), "server_pid": health["server_process_id"],
                  "contexts": contexts, "selected_section": document.selected_section_id,
                  "section_sha256": hashlib.sha256(document.content.encode()).hexdigest(),
                  "skill_members_byte_equal": len(members),
                  "health_missing_unextracted_recipe_sources": health["missing_packaged_resource_paths"]}, indent=2))
