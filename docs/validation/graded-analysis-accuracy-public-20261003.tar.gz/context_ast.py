"""Thin caller of original audit Package/FunctionFacts, not another scanner."""
import ast
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/ts/code/projects/nominal-refactor-advisor/skills/refactor-audit/scripts")
from audit.findings import Package
from audit.repository import Repository

repo = Repository(Path.cwd())
revision = repo.git("rev-parse", "HEAD").strip()
paths = frozenset((
    "openhcs/agent/image_analysis_qa.py", "openhcs/agent/authoring_contexts.py",
    "openhcs/agent/services/llm_context_service.py", "openhcs/agent/dto/knowledge.py",
    "openhcs/agent/capabilities.py", "openhcs/agent/services/knowledge_base_service.py",
    "openhcs/mcp/context.py", "openhcs/mcp/dev_client_commands/knowledge_pipeline.py",
))
for scope in ("openhcs/agent", "openhcs/mcp"):
    package = Package.load(repo, revision, scope)
    assert not package.unparsed
    print(json.dumps({"revision": revision, "scope": scope,
                      "parsed": len(package.modules), "unparsed": package.unparsed}))
    for module in package.modules:
        if module.path in paths:
            print(json.dumps({"path": module.path,
                              "ast": ast.dump(module.tree, include_attributes=True)}))
print(json.dumps({"limit": "AST declaration/import/Store/Load/base evidence; not global NRA/R1 or runtime MRO proof"}))
