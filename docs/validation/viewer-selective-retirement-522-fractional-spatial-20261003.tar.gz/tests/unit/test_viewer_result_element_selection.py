"""Native viewer result-element navigation and projection contracts."""

from __future__ import annotations

import asyncio
import importlib.util
import inspect
from types import SimpleNamespace

import numpy as np
import pytest
from polystore.streaming.identity import StreamProducerIdentity
from polystore.streaming_constants import StreamingDataType
from zmqruntime.viewer_protocol import ViewerComponentMode

from openhcs.agent.dto.execution import ExecutionConnectionSpec
from openhcs.agent.dto.viewer import (
    ViewerWindowLayerIsolationRequest,
    ViewerWindowNavigationRequest,
)
from openhcs.agent.services.viewer_window_service import (
    ViewerWindowGatewayABC,
    ViewerWindowService,
)
from openhcs.runtime.napari_streaming_handlers import (
    NapariAxisPresentation,
    NapariComponentGroupStore,
    NapariDimensionLayerState,
    NapariLayerRouteStateStore,
    NapariStreamLayerAddress,
    NapariStreamLayerItem,
)
from openhcs.core.runtime_image_values import ImagePayloadMetadata
from openhcs.runtime.napari_viewer_server import (
    NapariLayerIsolationControlMessageAction,
    NapariNavigationControlMessageAction,
    NapariResultElementSelectionAuthority,
    NapariResultSelectionController,
    NapariResultSelectionGroupBinding,
    NapariResultSelectionSurface,
    NapariViewerServer,
)
from openhcs.runtime.viewer_controls import (
    ViewerPointCoordinateAuthority,
    ViewerLayerIsolationControlOptions,
    ViewerNavigationControlOptions,
    ViewerResultElementCoordinateAuthority,
)
from openhcs.runtime.viewer_component_system import (
    ViewerComponentAxisSemanticsAuthority,
    ViewerComponentLayout,
    ViewerLayerAxisProjection,
    ViewerComponentValueDomainPayload,
)
from openhcs.runtime.viewer_protocol import (
    ViewerControlResponseField,
    ViewerLayerIsolationField,
)


class _NavigationResponseGateway(ViewerWindowGatewayABC):
    def close_window(self, request):
        raise AssertionError(request)

    def presentation_control(self, request):
        raise AssertionError(request)

    def image_intensity(self, request):
        raise AssertionError(request)

    def __init__(self, response: dict[str, object]) -> None:
        self.response = response

    def snapshot_window(self, request):
        raise AssertionError(request)

    def window_state(self, request):
        raise AssertionError(request)

    def window_payloads(self, request):
        raise AssertionError(request)

    def navigate_window(self, request):
        return self.response

    def isolate_layers(self, request):
        del request
        return self.response


class _DimensionLabelOverlay:
    def __init__(self) -> None:
        self.refresh_count = 0

    def refresh(self) -> None:
        self.refresh_count += 1


class _QtWindow:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def isMinimized(self) -> bool:
        self.calls.append("is_minimized")
        return True

    def showNormal(self) -> None:
        self.calls.append("show_normal")

    def show(self) -> None:
        self.calls.append("show")

    def raise_(self) -> None:
        self.calls.append("raise")

    def activateWindow(self) -> None:
        self.calls.append("activate")


class _ResultSelectionDock:
    def __init__(self, window: _QtWindow) -> None:
        self.qt_window = window
        self.calls: list[str] = []

    def show(self) -> None:
        self.calls.append("show")

    def raise_(self) -> None:
        self.calls.append("raise")

    def window(self) -> _QtWindow:
        self.calls.append("window")
        return self.qt_window


class _ViewerServerHarness(SimpleNamespace):
    def require_result_selection_surface(self) -> NapariResultSelectionSurface:
        return self.result_selection_surface

    def raise_result_selection_surface(self) -> None:
        NapariViewerServer.raise_result_selection_surface(self)


def _viewer_server(viewer, layer, route_key: str = "result-rois", group_binding=None):
    route_state = NapariLayerRouteStateStore.empty()
    route_state.set_title(route_key, "Result ROIs")
    route_state.set_layer(route_key, layer)
    overlay = _DimensionLabelOverlay()
    qt_window = _QtWindow()
    result_selection_dock = _ResultSelectionDock(qt_window)
    server = _ViewerServerHarness(
        viewer=viewer,
        layer_route_state=route_state,
        component_groups=NapariComponentGroupStore(),
        display_pipeline=SimpleNamespace(dimension_label_overlay=overlay),
        napari_window_title="OpenHCS Napari Viewer",
        result_selection_surface=NapariResultSelectionSurface(
            dock=result_selection_dock,
            manager=SimpleNamespace(),
        ),
    )
    server.result_selection_controller = NapariResultSelectionController(server)
    if NapariResultElementSelectionAuthority.state(layer).supported:
        from napari.layers import Points

        server.component_groups.items_for(route_key).append(
            NapariStreamLayerItem(
                data=layer.data,
                producer=StreamProducerIdentity(
                    origin="manual", output_kind="fixture", output_key=route_key,
                    projection_key=route_key,
                ),
                address=NapariStreamLayerAddress(
                    components={}, path=f"fixture/{route_key}",
                    stream_layer_data_type=(
                        StreamingDataType.POINTS if isinstance(layer, Points)
                        else StreamingDataType.SHAPES
                    ),
                ),
                image_metadata=ImagePayloadMetadata(),
                plane_component_domain=ViewerComponentValueDomainPayload(()),
            )
        )
        server.result_selection_controller.bind(layer, group_binding=group_binding)
    return server, overlay, result_selection_dock, qt_window


def test_native_navigation_acknowledges_exact_bound_linked_selection(qtbot):
    from napari.components import ViewerModel

    viewer = ViewerModel()
    paths = [np.asarray([[i, i], [i + 1, i + 1]], dtype=float) for i in range(3)]
    layer = viewer.add_shapes(paths, shape_type="path", features={"owner": [8, 8, 9]})
    linked = viewer.add_shapes(paths[:2], shape_type="path", features={"owner": [8, 9]})
    # This is an explicitly bound semantic subject, not a hardcoded neuron feature.
    binding = NapariResultSelectionGroupBinding("native-test-subject", "owner")
    server, _, _, _ = _viewer_server(viewer, layer, group_binding=binding)
    server.result_selection_controller.bind(linked, group_binding=binding)
    original_data = [coordinates.copy() for coordinates in layer.data]
    response = NapariNavigationControlMessageAction().handle(
        server,
        {
            "payload": ViewerNavigationControlOptions(
                route_key="result-rois", data_index=1, visible=True, selected=True
            )
        },
    )
    assert response["status"] == "success", response
    assert response["layers"][0]["selected_data_indices"] == (0, 1)
    assert layer.selected_data == {0, 1}
    assert linked.selected_data == {0}
    for before, after in zip(original_data, layer.data, strict=True):
        np.testing.assert_array_equal(before, after)


def test_singleton_selection_stays_strict_with_bound_group(qtbot):
    from napari.components import ViewerModel

    viewer = ViewerModel()
    paths = [np.asarray([[i, i], [i + 1, i + 1]], dtype=float) for i in range(3)]
    layer = viewer.add_shapes(paths, shape_type="path", features={"owner": [8, 8, 9]})
    binding = NapariResultSelectionGroupBinding("native-test-subject", "owner")
    _viewer_server(viewer, layer, group_binding=binding)
    with pytest.raises(RuntimeError, match="requested native data selection"):
        NapariResultElementSelectionAuthority.select(layer, 1)
    assert layer.selected_data == {0, 1}


def test_bound_selection_rejects_unrelated_native_members(qtbot):
    from napari.components import ViewerModel

    viewer = ViewerModel()
    paths = [np.asarray([[i, i], [i + 1, i + 1]], dtype=float) for i in range(3)]
    layer = viewer.add_shapes(paths, shape_type="path", features={"owner": [8, 8, 9]})
    binding = NapariResultSelectionGroupBinding("native-test-subject", "owner")
    server, _, _, _ = _viewer_server(viewer, layer, group_binding=binding)
    mutating = False

    def add_unrelated_member(_event):
        nonlocal mutating
        if mutating:
            return
        mutating = True
        try:
            layer.selected_data = {0, 1, 2}
        finally:
            mutating = False

    layer.events.highlight.connect(add_unrelated_member)
    with pytest.raises(RuntimeError, match="canonical linked result selection"):
        server.result_selection_controller.select(layer, 1)


@pytest.mark.parametrize("invalid_index", (True, "1", -1))
def test_viewer_navigation_rejects_invalid_data_index(invalid_index: object) -> None:
    error_type = TypeError if invalid_index in (True, "1") else ValueError

    with pytest.raises(error_type, match="data_index"):
        ViewerNavigationControlOptions(
            route_key="result-rois",
            data_index=invalid_index,  # type: ignore[arg-type]
        )


@pytest.mark.parametrize(
    ("state_override", "message"),
    (({"visible": False}, "hidden layer"), ({"selected": False}, "deselected layer")),
)
def test_viewer_navigation_rejects_data_index_without_visible_selection(
    state_override: dict[str, bool],
    message: str,
) -> None:
    with pytest.raises(ValueError, match=message):
        ViewerNavigationControlOptions(
            route_key="result-rois",
            data_index=0,
            **state_override,
        )


def test_napari_navigation_selects_native_feature_row_and_projects_evidence(qtbot):
    from napari.components import ViewerModel
    from openhcs.napari_roi_manager import QRoiManager

    viewer = ViewerModel()
    layer = viewer.add_shapes(
        [
            np.array([[0, 0], [0, 2], [2, 2]], dtype=float),
            np.array([[4, 4], [4, 6], [6, 6]], dtype=float),
        ],
        shape_type=["polygon", "polygon"],
        features={"label": [11, 12], "area": [3.0, 4.0]},
        name="Result ROIs",
    )
    roi_manager = QRoiManager(viewer)
    roi_manager.connect_layer(layer)
    qtbot.addWidget(roi_manager)
    layer.visible = False
    viewer.layers.selection.active = None
    server, overlay, result_selection_dock, qt_window = _viewer_server(viewer, layer)
    request = ViewerNavigationControlOptions.from_overrides(
        route_key="result-rois",
        visible=True,
        selected=True,
        data_index=1,
    )

    response = NapariNavigationControlMessageAction().handle(
        server,
        {ViewerControlResponseField.PAYLOAD.value: request},
    )
    qtbot.wait(0)

    assert response["status"] == "success"
    assert layer.visible is True
    assert viewer.layers.selection.active is layer
    assert layer.selected_data == {1}
    assert roi_manager._roilist.rowCount() == 2
    assert [
        index.row() for index in roi_manager._roilist.selectionModel().selectedRows()
    ] == [1]
    assert overlay.refresh_count == 1
    assert result_selection_dock.calls == ["show", "raise", "window"]
    assert qt_window.calls == [
        "is_minimized",
        "show_normal",
        "show",
        "raise",
        "activate",
    ]
    projected_layer = response["layers"][0]
    assert projected_layer["visible"] is True
    assert projected_layer["selected"] is True
    assert projected_layer["feature_row_count"] == 2
    assert projected_layer["selected_data_indices"] == (1,)

    result = ViewerWindowService(
        gateway=_NavigationResponseGateway(response)
    ).navigate_window(
        ViewerWindowNavigationRequest(
            connection=ExecutionConnectionSpec(port=5900),
            navigation=request,
        )
    )
    assert result.observed is True
    assert result.route_key == "result-rois"
    assert result.visible is True
    assert result.selected is True
    assert result.data_index == 1
    assert result.feature_row_count == 2
    assert result.selected_data_indices == (1,)


def test_napari_layer_isolation_applies_all_routes_in_one_control_action() -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    selected_layer = viewer.add_image(np.zeros((8, 8), dtype=np.uint8), name="Keep")
    hidden_layer = viewer.add_image(np.ones((8, 8), dtype=np.uint8), name="Hide")
    server, overlay, _result_selection_dock, _qt_window = _viewer_server(
        viewer,
        selected_layer,
        route_key="keep",
    )
    server.layer_route_state.set_title("hide", "Hide")
    server.layer_route_state.set_layer("hide", hidden_layer)
    request = ViewerLayerIsolationControlOptions.from_overrides(
        visible_route_keys=("keep",),
        selected_route_key="keep",
    )

    response = NapariLayerIsolationControlMessageAction().handle(
        server,
        {ViewerControlResponseField.PAYLOAD.value: request},
    )

    assert response[ViewerLayerIsolationField.APPLIED.value] is True
    assert response[ViewerLayerIsolationField.CHANGED_ROUTE_COUNT.value] == 2
    assert response[ViewerLayerIsolationField.MISSING_ROUTE_KEYS.value] == ()
    assert selected_layer.visible is True
    assert hidden_layer.visible is False
    assert viewer.layers.selection.active is selected_layer
    assert overlay.refresh_count == 1

    result = ViewerWindowService(
        gateway=_NavigationResponseGateway(response)
    ).isolate_layers(
        ViewerWindowLayerIsolationRequest.from_fields(
            connection=ExecutionConnectionSpec(port=5900),
            visible_route_keys=("keep",),
            selected_route_key="keep",
        )
    )
    assert result.applied is True
    assert result.visible_route_keys == ("keep",)
    assert result.hidden_route_keys == ("hide",)
    assert result.changed_route_count == 2


def test_napari_layer_isolation_rejects_missing_routes_before_mutation() -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    layer = viewer.add_image(np.zeros((8, 8), dtype=np.uint8), name="Keep")
    server, overlay, _result_selection_dock, _qt_window = _viewer_server(
        viewer,
        layer,
        route_key="keep",
    )
    request = ViewerLayerIsolationControlOptions.from_overrides(
        visible_route_keys=("missing",),
    )

    response = NapariLayerIsolationControlMessageAction().handle(
        server,
        {ViewerControlResponseField.PAYLOAD.value: request},
    )

    assert response[ViewerLayerIsolationField.APPLIED.value] is False
    assert response[ViewerLayerIsolationField.CHANGED_ROUTE_COUNT.value] == 0
    assert response[ViewerLayerIsolationField.MISSING_ROUTE_KEYS.value] == ("missing",)
    assert layer.visible is True
    assert overlay.refresh_count == 0


def test_napari_layer_isolation_preflights_navigation_before_mutation() -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    hidden_layer = viewer.add_image(np.ones((8, 8), dtype=np.uint8), name="Hide")
    selected_layer = viewer.add_image(np.zeros((8, 8), dtype=np.uint8), name="Keep")
    server, overlay, _result_selection_dock, _qt_window = _viewer_server(
        viewer,
        selected_layer,
        route_key="keep",
    )
    server.layer_route_state.set_title("hide", "Hide")
    server.layer_route_state.set_layer("hide", hidden_layer)
    viewer.layers.selection.active = hidden_layer
    request = ViewerLayerIsolationControlOptions.from_overrides(
        visible_route_keys=("keep",),
        selected_route_key="keep",
        axis_indices={"channel": 0},
    )

    response = NapariLayerIsolationControlMessageAction().handle(
        server,
        {ViewerControlResponseField.PAYLOAD.value: request},
    )

    assert response["status"] == "error"
    assert "no semantic axis labels" in response["message"]
    assert hidden_layer.visible is True
    assert selected_layer.visible is True
    assert viewer.layers.selection.active is hidden_layer
    assert overlay.refresh_count == 0


def test_napari_navigation_moves_to_selected_roi_component_slice(qtbot) -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    viewer.add_image(
        np.zeros((3, 4, 8, 8), dtype=np.uint8),
        name="Reference image",
    )
    layer = viewer.add_shapes(
        [
            np.array(
                [[0, 1, 0, 0], [0, 1, 0, 2], [0, 1, 2, 2]],
                dtype=float,
            ),
            np.array(
                [[2, 3, 4, 4], [2, 3, 4, 6], [2, 3, 6, 6]],
                dtype=float,
            ),
        ],
        shape_type=["polygon", "polygon"],
        features={"label": [11, 12], "area": [3.0, 4.0]},
        ndim=4,
        name="Result ROIs",
    )
    server, _overlay, _result_selection_dock, _qt_window = _viewer_server(
        viewer,
        layer,
    )
    projection = ViewerLayerAxisProjection(
        projected_axis_components=("channel", "z"),
        component_values={"channel": [0, 1, 2], "z": [0, 1, 2, 3]},
        routed_component_values={"channel": [0, 2], "z": [1, 3]},
        axis_offsets=(0, 0),
    )
    semantics = ViewerComponentAxisSemanticsAuthority.empty()
    server.layer_route_state.set_dimension_state(
        "result-rois",
        NapariDimensionLayerState(
            labels={
                "channel": ("Ch0", "Ch1", "Ch2"),
                "z": ("Z0", "Z1", "Z2", "Z3"),
            },
            presentation=NapariAxisPresentation(
                entries=semantics.entries,
                layout=ViewerComponentLayout.from_parts(
                    component_modes={
                        "channel": ViewerComponentMode.STACK,
                        "z": ViewerComponentMode.STACK,
                    },
                    component_order=("channel", "z"),
                ),
                route_key="result-rois",
                projection=projection,
            ),
        ),
    )
    viewer.dims.current_step = (0, 1, 0, 0)

    response = NapariNavigationControlMessageAction().handle(
        server,
        {
            ViewerControlResponseField.PAYLOAD.value: ViewerNavigationControlOptions.from_overrides(
                route_key="result-rois",
                visible=True,
                selected=True,
                data_index=1,
            )
        },
    )

    assert response["status"] == "success"
    assert viewer.dims.current_step[:2] == (2, 3)
    assert layer.selected_data == {1}

    conflicting_response = NapariNavigationControlMessageAction().handle(
        server,
        {
            ViewerControlResponseField.PAYLOAD.value: ViewerNavigationControlOptions.from_overrides(
                route_key="result-rois",
                axis_indices={"z": 1},
                visible=True,
                selected=True,
                data_index=1,
            )
        },
    )

    assert conflicting_response["status"] == "error"
    assert "conflict with explicit axis_indices" in conflicting_response["message"]
    assert viewer.dims.current_step[:2] == (2, 3)
    assert layer.selected_data == {1}


def test_result_element_coordinate_authority_derives_native_slice_indices() -> None:
    coordinates = np.array(
        [[2, 3, 4, 4], [2, 3, 4, 6], [2, 3, 6, 6]],
        dtype=float,
    )

    assert ViewerResultElementCoordinateAuthority.axis_indices(
        coordinates=coordinates,
        axis_labels=("channel", "z", "y", "x"),
        displayed_axis_indices=(2, 3),
        spatial_axis_labels=("y", "x"),
    ) == {"channel": 2, "z": 3}
    assert (
        ViewerResultElementCoordinateAuthority.axis_indices(
            coordinates=(4, 5),
            axis_labels=("y", "x"),
            displayed_axis_indices=(0, 1),
            spatial_axis_labels=("y", "x"),
        )
        == {}
    )


def test_result_element_coordinate_authority_rejects_cross_slice_geometry() -> None:
    with pytest.raises(ValueError, match="spans multiple 'z' slices"):
        ViewerResultElementCoordinateAuthority.axis_indices(
            coordinates=((2, 3, 4, 4), (2, 4, 4, 6), (2, 3, 6, 6)),
            axis_labels=("channel", "z", "y", "x"),
            displayed_axis_indices=(2, 3),
            spatial_axis_labels=("y", "x"),
        )


def test_fractional_z_point_navigation_chooses_slice_without_rounding_geometry() -> (
    None
):
    assert ViewerPointCoordinateAuthority.axis_indices(
        coordinates=(2.375, 1.25, 3.5),
        axis_labels=("z_index", "y", "x"),
        displayed_axis_indices=(1, 2),
        spatial_axis_labels=("z_index", "y", "x"),
    ) == {"z_index": 2}
    with pytest.raises(ValueError, match="integral slice"):
        ViewerResultElementCoordinateAuthority.axis_indices(
            coordinates=(2.375, 1.25, 3.5),
            axis_labels=("z_index", "y", "x"),
            displayed_axis_indices=(1, 2),
            spatial_axis_labels=("z_index", "y", "x"),
        )


@pytest.mark.parametrize("coordinate", [1.5, float("nan"), float("inf")])
def test_point_coordinate_owner_preserves_strict_acquisition_admission(coordinate):
    with pytest.raises(ValueError):
        ViewerPointCoordinateAuthority.axis_indices(
            coordinates=(coordinate, 1.5, 2.5, 3.5),
            axis_labels=("channel", "z_index", "y", "x"),
            displayed_axis_indices=(2, 3),
            spatial_axis_labels=("z_index", "y", "x"),
        )


@pytest.mark.parametrize("displayed", [(1, 2), (0, 2), (0, 1)])
def test_shapes_coordinate_owner_stays_strict_for_hidden_spatial_axes(displayed):
    with pytest.raises(ValueError, match="integral slice"):
        ViewerResultElementCoordinateAuthority.axis_indices(
            coordinates=((1.5, 2.5, 3.5),), axis_labels=("z_index", "y", "x"),
            displayed_axis_indices=displayed, spatial_axis_labels=("z_index", "y", "x"),
        )


def test_napari_navigation_selects_fractional_z_point_feature(qtbot) -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    viewer.add_image(np.zeros((4, 8, 8), dtype=np.uint8), name="Source planes")
    layer = viewer.add_points(
        np.array([[2.375, 1.25, 3.5]], dtype=float),
        features={"response": [4.75]},
        name="Centres",
    )
    server, _overlay, _dock, _window = _viewer_server(viewer, layer, "centres")
    projection = ViewerLayerAxisProjection(
        projected_axis_components=("z_index",),
        component_values={"z_index": [0, 1, 2, 3]},
        routed_component_values={"z_index": [0, 1, 2, 3]},
        axis_offsets=(0,),
    )
    semantics = ViewerComponentAxisSemanticsAuthority.empty()
    server.layer_route_state.set_dimension_state(
        "centres",
        NapariDimensionLayerState(
            labels={"z_index": ("Z 0", "Z 1", "Z 2", "Z 3")},
            presentation=NapariAxisPresentation(
                entries=semantics.entries,
                layout=ViewerComponentLayout.from_parts(
                    component_modes={"z_index": ViewerComponentMode.STACK},
                    component_order=("z_index",),
                ),
                route_key="centres",
                projection=projection,
            ),
        ),
    )

    response = NapariNavigationControlMessageAction().handle(
        server,
        {
            ViewerControlResponseField.PAYLOAD.value: ViewerNavigationControlOptions.from_overrides(
                route_key="centres", visible=True, selected=True, data_index=0
            )
        },
    )

    assert response["status"] == "success", response
    assert layer.selected_data == {0}
    assert viewer.dims.current_step[0] == 2
    assert layer.data[0, 0] == 2.375
    assert layer.features.loc[0, "response"] == 4.75


def test_napari_navigation_rejects_out_of_range_data_index(qtbot) -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    layer = viewer.add_points(
        np.array([[1, 2]], dtype=float),
        features={"score": [0.75]},
        name="Result Points",
    )
    server, _overlay, _result_selection_dock, _qt_window = _viewer_server(
        viewer,
        layer,
        "result-points",
    )

    response = NapariNavigationControlMessageAction().handle(
        server,
        {
            ViewerControlResponseField.PAYLOAD.value: ViewerNavigationControlOptions.from_overrides(
                route_key="result-points",
                data_index=1,
            )
        },
    )

    assert response["status"] == "error"
    assert "outside 1 populated feature row" in response["message"]


def test_napari_navigation_rejects_layer_without_native_data_selection(qtbot) -> None:
    from napari.components import ViewerModel

    viewer = ViewerModel()
    layer = viewer.add_image(np.zeros((4, 4), dtype=np.uint8), name="Image")
    server, _overlay, _result_selection_dock, _qt_window = _viewer_server(
        viewer,
        layer,
        "result-image",
    )

    response = NapariNavigationControlMessageAction().handle(
        server,
        {
            ViewerControlResponseField.PAYLOAD.value: ViewerNavigationControlOptions.from_overrides(
                route_key="result-image",
                data_index=0,
            )
        },
    )

    assert response["status"] == "error"
    assert "native feature-bearing data selection" in response["message"]


def test_navigate_viewer_cli_projects_data_index() -> None:
    import openhcs.mcp.dev_client as dev_client

    args = dev_client._build_parser().parse_args(
        ("navigate-viewer", "5900", "result-rois", "--data-index", "3")
    )

    call = dev_client._calls_from_args(args)[0]
    assert call.name == "openhcs_navigate_viewer_window"
    assert call.arguments["data_index"] == 3


def test_navigate_viewer_cli_rejects_hidden_data_index_before_mcp_call() -> None:
    import openhcs.mcp.dev_client as dev_client

    args = dev_client._build_parser().parse_args(
        (
            "navigate-viewer",
            "5900",
            "result-rois",
            "--data-index",
            "0",
            "--hidden",
            "--selected",
        )
    )

    with pytest.raises(dev_client.McpDevCliUsageError, match="hidden layer"):
        dev_client._calls_from_args(args)


def test_mcp_navigation_schema_explains_linked_result_selection() -> None:
    if importlib.util.find_spec("mcp") is None:
        return

    from openhcs.mcp import server

    built = server.build_server()
    listed_tools = built.list_tools()
    tools = (
        asyncio.run(listed_tools) if inspect.isawaitable(listed_tools) else listed_tools
    )
    navigation = next(
        tool for tool in tools if tool.name == "openhcs_navigate_viewer_window"
    )

    assert "data_index" in navigation.inputSchema["properties"]
    assert "native feature-bearing result layer" in navigation.description
    assert "selected_data_indices" in navigation.description
    assert "requires the target layer to remain visible and selected" in (
        navigation.description
    )
