"""Original source bootstrap and pytest, borrowing the existing paired Qt owner."""
import hashlib
import json
from pathlib import Path
import sys

import openhcs  # Activate original source dependencies before their consumers.

paired = Path('/home/ts/wt/pyqt-reactive-render-complete-snapshot-20261001/src')
sys.path.insert(0, str(paired))
import pyqt_reactive.services.window_snapshot as snapshot
assert Path(snapshot.__file__).is_relative_to(paired)
assert snapshot.WindowSnapshotFrameCondition.RENDER_COMPLETE
print(json.dumps({"openhcs": openhcs.__file__, "paired_snapshot": snapshot.__file__,
                  "paired_snapshot_sha256": hashlib.sha256(Path(snapshot.__file__).read_bytes()).hexdigest(),
                  "mode": "source fixtures only; no server/installed change"}), flush=True)
import pytest
status = pytest.main(['--noconftest', '--import-mode=importlib', '-p', 'no:cacheprovider',
                      '-o', 'addopts=', '-q', *sys.argv[1:]])
cgroup = Path('/sys/fs/cgroup' + Path('/proc/self/cgroup').read_text().strip().split(':', 2)[2])
for field in ('memory.max', 'memory.peak', 'memory.swap.max', 'memory.swap.peak', 'memory.events', 'cpu.max'):
    print(field + ': ' + (cgroup / field).read_text().replace('\n', ' '), flush=True)
raise SystemExit(status)
