"""
Napari-based real-time visualization module.

This module provides the NapariStreamVisualizer class for real-time
visualization of tensors during pipeline execution.
"""

from __future__ import annotations

import logging
import os
import pickle
import queue
import sys
import threading
import weakref
from abc import ABC, abstractmethod
from collections.abc import Callable, Hashable, Iterable, Mapping
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from enum import Enum
from functools import partial
from itertools import product
from math import ceil
from numbers import Integral
from types import MappingProxyType
from typing import TYPE_CHECKING, ClassVar, Generic, Sequence, TypeAlias, TypeVar, cast

import numpy as np
import zmq
from metaclass_registry import AutoRegisterMeta
from polystore.streaming import StreamingSharedMemoryAuthority
from polystore.streaming.identity import (
    FixedStreamProducerIdentityKind,
    StreamProducerDisplayNameAuthority,
    StreamProducerIdentity,
    StreamRouteKeyAuthority,
)
from polystore.streaming.receivers.napari import build_route_key
from polystore.streaming.receivers.napari.layer_inspection import (
    NapariNativeLayerTransformInspection,
)
from polystore.streaming.receivers.napari.image_presentation import (
    NapariNativeImageIntensityPresentation,
)
from polystore.streaming.receivers.napari.viewport_presentation import (
    NapariNativeViewportPresentation,
)
from polystore.streaming_constants import StreamingDataType
from qtpy.QtCore import Qt, QTimer
from qtpy.QtWidgets import QDockWidget
from napari.layers import Image
from napari.layers.base._base_constants import Blending
from napari.utils.colormaps import ensure_colormap
from zmqruntime.config import TransportMode
from zmqruntime.messages import (
    ImageTransferIdentity,
    ControlMessageType,
    EndpointControlCapability,
    ResponseType,
)
from zmqruntime.streaming import StreamingVisualizerServer
from zmqruntime.transport import remove_ipc_socket
from zmqruntime.viewer_protocol import (
    ViewerComponentMode,
    ViewerWireField,
    ViewerNativeLayerTransform,
    ViewerImageIntensityControlOptions,
    ViewerNativeViewportPresentation,
    ViewerSourceSpatialDomainPayload,
)

from openhcs.constants import AllComponents
from openhcs.agent.dto.viewer import (
    ViewerWindowDescriptor, ViewerWindowLayerRetirementRequest,
)
from openhcs.runtime.viewer_snapshot import (
    ViewerWindowSnapshotFailureReply,
    ViewerWindowSnapshotService,
)
from openhcs.core.roi_point_metadata import ROIFractionalZ
from openhcs.core.roi_source_metadata import ROIArchiveSourceMetadata
from openhcs.core.artifacts import ObjectArtifactSubjectBinding
from openhcs.core.config import (
    NapariDisplayConfig,
    NapariVariableSizeHandling,
)
from openhcs.core.registry_strategies import EnumKeyedStrategyMixin
from openhcs.core.runtime_image_values import (
    ImagePayloadMetadata,
)
from openhcs.core.source_spatial_domain import SourceSpatialDomain
from openhcs.core.streaming_config_declarations import ViewerType
from openhcs.core.streaming_config_factory import ViewerProcessLaunchConfig
from openhcs.runtime.napari_streaming_handlers import (
    DimensionLabelMap,
    LayerData,
    LayerKwargValue,
    NapariAggregateAxisBindingAuthority,
    NapariAggregateAxisBindingSet,
    NapariAxisPresentation,
    NapariBatchProcessorStore,
    NapariComponentGroupStore,
    NapariDimensionLayerState,
    NapariImageLayerPresentationPolicy,
    NapariImagePayloadAxisLabelPolicy,
    NapariNativeWindowPresentation,
    NapariLayerBatchDebouncePolicy,
    NapariLayerHandle,
    NapariLayerRouteStateStore,
    NapariLayerSettlementState,
    NapariLayerUpdateAuthority,
    NapariPendingLayerUpdate,
    NapariShapeColorProjection,
    NapariShapeLayerPayload,
    NapariShapesLayerHandle,
    NapariStreamLayerAddress,
    NapariStreamLayerItem,
    NapariViewerLayerCreator,
    VisualMetadataField,
)
from openhcs.runtime.viewer_component_system import (
    ComponentMap,
    ComponentValue,
    ComponentValues,
    ViewerBatchPayloadFields,
    ViewerComponentAxisSemantics,
    ViewerComponentAxisSemanticsAuthority,
    ViewerComponentCoordinateAuthority,
    ViewerComponentLayout,
    ViewerComponentMetadataNormalizer,
    ViewerComponentMetadataPayload,
    ViewerComponentNameMetadata,
    ViewerComponentValueDomainPayload,
    ViewerDisplayBatchContext,
    ViewerLayerAxisProjection,
    ViewerLayerAxisProjectionRequestAuthority,
    ViewerLayerAxisProjector,
    ViewerMappingDisplayConfigInput,
    ViewerObjectDisplayConfigInput,
    ViewerRouteComponentValueTracker,
    ViewerStreamingDataTypeHandler,
    ViewerStreamingDataTypeHandlerMeta,
)
from openhcs.runtime.viewer_controls import (
    ViewerFeatureMeasurementControlOptions,
    ViewerMeasurementCoordinates,
    ViewerPolylineControlOptions,
    ViewerRegionControlOptions,
    ViewerRoutedImageControlOptions,
    ViewerPointCoordinateAuthority,
    ViewerIntensityWindowControlOptions,
    ViewerNativeDimensions,
    ViewerResultElementCoordinateAuthority,
)
from openhcs.runtime.viewer_measurements import (
    NativeImageMeasurement,
)
from openhcs.serialization.json import to_jsonable
from openhcs.runtime.viewer_protocol import (
    NapariLayerKind,
    NapariViewerServerRequest,
    OpenHCSViewerServerABC,
    OpenHCSViewerControlMessageType,
    ViewerBatchMessageType,
    ViewerBatchWireField,
    ViewerComponentValueOrdering,
    ViewerControlField,
    ViewerImageColorControlOptions,
    ViewerNativeImageColorPresentation,
    ViewerNativeWindowControlOptions,
    ViewerDeclaredWireValue,
    ViewerControlMessageType,
    ViewerControlReplyHeader,
    ViewerControlReplyPayload,
    ViewerControlResponseField,
    ViewerIntensityWindowField,
    ViewerDescriptorField,
    ViewerLayerField,
    ViewerLayerIsolationControlOptions,
    ViewerLayerIsolationField,
    ViewerLayerRetirementReceipt,
    ViewerNavigationControlOptions,
    ViewerPayloadField,
    ViewerPayloadProjectionOptions,
    ViewerPayloadSummaryField,
    ViewerPayloadSummary,
    ViewerArrayValueSummary,
    ViewerPayloadRecord,
    ViewerProtocolStatus,
    ViewerQtEnvironmentPolicy,
    ViewerSettlePhase,
    ViewerSettleProgress,
    ViewerStateControlOptions,
)
from openhcs.runtime.zmq_application import OPENHCS_ENDPOINT_APPLICATION
from openhcs.runtime.zmq_config import OPENHCS_ZMQ_CONFIG

if TYPE_CHECKING:
    from openhcs.napari_roi_manager import QRoiManager

# Optional napari import - this module should only be imported if napari is available
try:
    import napari
except ImportError:
    napari = None

if napari is None:
    raise ImportError(
        "napari is required for NapariStreamVisualizer. "
        "Install it with: pip install 'openhcs[viz]' or pip install napari"
    )


logger = logging.getLogger(__name__)
_NAPARI_LAYER_UPDATES = NapariLayerUpdateAuthority()
DEFAULT_DIRECT_IMAGE_PATH = "<direct_napari_image>"
DEFAULT_IMAGE_DATA_TYPE = "image"
_DEFAULT_WINDOW_SCREEN_FRACTION = 0.9
_FEATURE_TABLE_HEIGHT_FRACTION = 0.32
_DEFAULT_RESULT_SELECTION_HIGHLIGHT_THICKNESS = 4
_NAPARI_STOCK_HIGHLIGHT_COLOR = (0.0, 0.6, 1.0, 1.0)
_DEFAULT_RESULT_SELECTION_HIGHLIGHT_COLOR = (1.0, 0.82, 0.0, 1.0)

NapariWireValue: TypeAlias = (
    str | int | float | bool | np.ndarray | np.dtype | tuple | list | dict | None
)
NapariBatchImagePayloads: TypeAlias = list[Mapping[str, NapariWireValue]]
NapariComponentModeMap: TypeAlias = dict[str, str]
NapariComponentGroups: TypeAlias = dict[str, list[NapariStreamLayerItem]]
NapariViewerProjectionRequestT = TypeVar("NapariViewerProjectionRequestT")


@dataclass(frozen=True)
class NapariResultSelectionSurface:
    """The one dock/widget pair bound to native Napari result state."""

    dock: QDockWidget
    manager: "QRoiManager"


def _apply_default_window_layout(viewer, result_selection_dock) -> None:
    """Give the image canvas and authoritative ROI table useful space."""

    qt_window = result_selection_dock.window()
    available_geometry = qt_window.screen().availableGeometry()
    target_width = min(
        available_geometry.width(),
        max(
            qt_window.width(),
            round(available_geometry.width() * _DEFAULT_WINDOW_SCREEN_FRACTION),
        ),
    )
    target_height = min(
        available_geometry.height(),
        max(
            qt_window.height(),
            round(available_geometry.height() * _DEFAULT_WINDOW_SCREEN_FRACTION),
        ),
    )

    bottom_area = Qt.DockWidgetArea.BottomDockWidgetArea
    qt_window.setCorner(Qt.Corner.BottomLeftCorner, bottom_area)
    qt_window.setCorner(Qt.Corner.BottomRightCorner, bottom_area)
    qt_window.addDockWidget(bottom_area, result_selection_dock)
    qt_window.showNormal()
    qt_window.resize(target_width, target_height)
    qt_window.resizeDocks(
        [result_selection_dock],
        [round(target_height * _FEATURE_TABLE_HEIGHT_FRACTION)],
        Qt.Orientation.Vertical,
    )


def _apply_scope_accent_styling(result_selection_dock, scope_accent_color: str) -> None:
    """Mark one viewer with the exact accent projected by its owning UI scope."""

    from qtpy.QtGui import QColor

    accent = QColor(scope_accent_color)
    if not accent.isValid():
        raise ValueError(f"Invalid scope accent color: {scope_accent_color!r}")
    canonical_color = accent.name().lower()
    qt_window = result_selection_dock.window()
    qt_window.setProperty("openhcs_scope_accent_color", canonical_color)
    existing_style = qt_window.styleSheet()
    scope_style = f"QMainWindow {{ border: 6px solid {canonical_color}; }}"
    qt_window.setStyleSheet(f"{existing_style}\n{scope_style}".strip())


class NapariWireField(str, Enum):
    """Wire keys used by Napari stream and ROI payloads."""

    CENTER = "center"
    COORDINATES = "coordinates"
    RADII = "radii"


@dataclass(frozen=True)
class PayloadMap:
    """Typed accessor for one JSON-derived payload mapping."""

    payload: Mapping[str, NapariWireValue]
    context: str

    def required(
        self,
        field: NapariWireField | ViewerBatchWireField,
    ) -> NapariWireValue:
        if field.value not in self.payload:
            raise ValueError(
                f"{self.context} missing required payload field '{field.value}'"
            )
        return self.payload[field.value]

    def optional(
        self,
        field: NapariWireField | ViewerBatchWireField,
    ) -> NapariWireValue | None:
        if field.value in self.payload:
            return self.payload[field.value]
        return None

    def required_mapping(
        self,
        field: NapariWireField | ViewerBatchWireField,
    ) -> Mapping[str, NapariWireValue]:
        return self._mapping(field, self.required(field))

    def optional_mapping(
        self,
        field: NapariWireField | ViewerBatchWireField,
    ) -> Mapping[str, NapariWireValue]:
        if field.value not in self.payload:
            return {}
        return self._mapping(field, self.payload[field.value])

    def _mapping(
        self,
        field: NapariWireField | ViewerBatchWireField,
        value: NapariWireValue,
    ) -> Mapping[str, NapariWireValue]:
        if not isinstance(value, dict):
            raise TypeError(
                f"{self.context} field '{field.value}' must be a dict, "
                f"got {type(value).__name__}"
            )
        return value


def _napari_wire_str_mapping(
    payload: Mapping[str, NapariWireValue],
    field: NapariWireField,
    context: str,
) -> Mapping[str, str]:
    result: dict[str, str] = {}
    for key, value in payload.items():
        if not isinstance(key, str):
            raise TypeError(
                f"{context} field '{field.value}' must use string keys, "
                f"got {type(key).__name__}"
            )
        if not isinstance(value, str):
            raise TypeError(
                f"{context} field '{field.value}' values must be strings, "
                f"got {type(value).__name__}"
            )
        result[key] = value
    return result


@dataclass(frozen=True)
class ShapePayload:
    """Typed view of one Napari ROI shape payload."""

    payload: Mapping[str, NapariWireValue]

    @property
    def shape_type(self) -> str:
        return str(
            PayloadMap(self.payload, "Napari shape payload").required(
                ViewerBatchWireField.TYPE
            )
        )

    @property
    def coordinates(self) -> LayerData:
        return PayloadMap(self.payload, "Napari shape payload").required(
            NapariWireField.COORDINATES
        )

    @property
    def metadata(self) -> "VisualMetadata":
        return VisualMetadata(
            PayloadMap(self.payload, "Napari shape payload").optional_mapping(
                ViewerWireField.METADATA
            )
        )


@dataclass(frozen=True)
class VisualMetadata:
    """Optional display metadata attached to one shape payload."""

    metadata: Mapping[str, NapariWireValue]

    def value(
        self,
        field: VisualMetadataField,
        default: NapariWireValue,
    ) -> NapariWireValue:
        if field.value in self.metadata:
            return self.metadata[field.value]
        return default


@dataclass(frozen=True)
class NapariBatchPayload(ViewerDisplayBatchContext[NapariDisplayConfig]):
    """Typed view of an incoming batch message."""

    images: NapariBatchImagePayloads
    msg_type: ViewerBatchMessageType

    @classmethod
    def from_json_payload(
        cls,
        data: Mapping[str, NapariWireValue],
    ) -> "NapariBatchPayload":
        fields = ViewerBatchPayloadFields(data, "Napari batch message")
        display_config_payload = fields.required_mapping(
            ViewerBatchWireField.DISPLAY_CONFIG
        )
        component_axis_semantics = fields.component_axis_semantics(
            ViewerMappingDisplayConfigInput(display_config_payload),
            context="Napari component value domain",
        )
        component_names_metadata = fields.optional_component_names_metadata(
            context="Napari component-name metadata",
        )
        return cls(
            msg_type=fields.message_type(),
            images=fields.required_mapping_items(ViewerBatchWireField.IMAGES),
            viewer_display_config=NapariDisplayConfig.from_display_payload(
                display_config_payload
            ),
            store=component_names_metadata.store,
            entries=component_axis_semantics.entries,
            layout=component_axis_semantics.layout,
        )


@dataclass(frozen=True)
class NapariAcceptedStreamItem:
    """One stream item after receiver-owned payload materialization."""

    payload: "NapariImagePayload"
    data: LayerData


@dataclass(frozen=True)
class NapariAcceptedStreamBatch:
    """Immutable transport-to-Qt handoff for one accepted stream batch."""

    payload: NapariBatchPayload
    items: tuple[NapariAcceptedStreamItem, ...]

    def dispatch_to(self, server: "NapariViewerServer") -> None:
        """Apply copied payloads to viewer state on the Qt thread."""

        if self.payload.store:
            server.component_name_metadata.merge(self.payload)
            logger.info(
                "🔬 NAPARI PROCESS: Updated component metadata: %s",
                list(self.payload),
            )

        for item in self.items:
            server._process_loaded_image(item)


@dataclass(frozen=True, slots=True)
class NapariAcceptedControlRequest:
    """Qt-bound control request received by the socket-owning pump."""

    message: Mapping[str, object]
    response_queue: queue.Queue[bytes]


@dataclass(frozen=True)
class NapariStreamMessageReply:
    """Reply sent on the Napari REP socket for one stream message."""

    status: ViewerProtocolStatus
    msg_type: ViewerBatchMessageType | None
    error: str | None = None

    @classmethod
    def success(
        cls,
        msg_type: ViewerBatchMessageType | None,
    ) -> "NapariStreamMessageReply":
        return cls(ViewerProtocolStatus.SUCCESS, msg_type)

    @classmethod
    def failure(
        cls,
        msg_type: ViewerBatchMessageType | None,
        error: str,
    ) -> "NapariStreamMessageReply":
        return cls(ViewerProtocolStatus.ERROR, msg_type, error)

    def to_wire_mapping(self) -> dict[str, NapariWireValue]:
        reply: dict[str, NapariWireValue] = {
            ViewerControlResponseField.STATUS.value: self.status.value,
            ViewerBatchWireField.TYPE.value: (
                self.msg_type.value if self.msg_type is not None else None
            ),
        }
        if self.error is not None:
            reply[ViewerControlResponseField.MESSAGE.value] = self.error
        return reply


@dataclass(frozen=True)
class NapariStreamLayerContext(ViewerComponentAxisSemantics):
    """Wire-derived routing facts for one streamed Napari payload."""

    producer: StreamProducerIdentity
    address: NapariStreamLayerAddress
    image_metadata: ImagePayloadMetadata
    plane_component_domain: ViewerComponentValueDomainPayload
    display_config: NapariDisplayConfig

    @classmethod
    def from_payload_map(
        cls,
        payload: PayloadMap,
        layer_axis_projection_semantics: ViewerComponentAxisSemantics,
        display_config: NapariDisplayConfig,
    ) -> "NapariStreamLayerContext":
        data_type_value = payload.optional(ViewerWireField.DATA_TYPE)
        if data_type_value is None:
            data_type_value = DEFAULT_IMAGE_DATA_TYPE
        source_channel_axis = payload.optional(ViewerWireField.SOURCE_CHANNEL_AXIS)
        plane_axis = payload.optional(ViewerWireField.PLANE_AXIS)
        return cls(
            entries=layer_axis_projection_semantics.entries,
            layout=layer_axis_projection_semantics.layout,
            producer=StreamProducerIdentity.from_payload(
                payload.required(ViewerWireField.PRODUCER_IDENTITY)
            ),
            address=NapariStreamLayerAddress(
                components=ViewerComponentMetadataPayload.component_map(
                    payload.optional_mapping(ViewerWireField.METADATA),
                    context="Napari image component metadata",
                ),
                path=str(payload.required(ViewerWireField.PATH)),
                stream_layer_data_type=StreamingDataType(str(data_type_value)),
            ),
            image_metadata=(
                ImagePayloadMetadata.from_viewer_image_metadata(
                    payload.payload[ViewerWireField.IMAGE_METADATA.value]
                )
                if ViewerWireField.IMAGE_METADATA.value in payload.payload
                else ImagePayloadMetadata(
                    source_channel_axis=source_channel_axis,
                    plane_axis=plane_axis,
                    source_spatial_domain=SourceSpatialDomain.from_viewer_wire_mapping(
                        payload.payload,
                        source_label="Napari image payload",
                        value_name="Napari image payload",
                    ),
                )
            ),
            plane_component_domain=ViewerComponentValueDomainPayload.from_ordered_wire_mapping(
                payload.optional_mapping(ViewerWireField.PLANE_COMPONENT_VALUES),
                context="Napari image plane component values",
            ),
            display_config=display_config,
        )

    def layer_route(
        self,
        *,
        payload_layout_role: "NapariImagePayloadLayoutRole | None",
        layer_route_state: "NapariLayerRouteStateStore",
    ) -> "NapariLayerRoute":
        component_info = _COMPONENT_METADATA_NORMALIZER.normalize(
            self.address.components
        )
        component_layout = self.layout
        base_layer_key = build_route_key(
            producer_identity=self.producer,
            component_info=component_info,
            display_layout=component_layout,
            data_type=self.address.stream_layer_data_type,
        )
        layer_key = (
            base_layer_key
            if payload_layout_role is None
            else payload_layout_role.route_key(base_layer_key)
        )
        layer_title = NapariLayerTitleAuthority.disambiguate(
            title=NapariLayerTitleAuthority.title(
                producer=self.producer,
                stream_layer_data_type=self.address.stream_layer_data_type,
                component_info=component_info,
                component_layout=component_layout,
                payload_layout_role=payload_layout_role,
            ),
            producer=self.producer,
            route_key=layer_key,
            layer_route_state=layer_route_state,
        )
        return NapariLayerRoute(
            entries=self.entries,
            layout=self.layout,
            producer=self.producer,
            route_key=layer_key,
            layer_title=layer_title,
            component_info=component_info,
            item_address=self.address.with_components(component_info),
            payload_layout_role=payload_layout_role,
            image_metadata=self.image_metadata,
            plane_component_domain=self.plane_component_domain,
            display_config=self.display_config,
        )


@dataclass(frozen=True)
class NapariImagePayload(NapariStreamLayerContext):
    """Typed view of one image/shapes message."""

    raw: Mapping[str, NapariWireValue]
    transfer: ImageTransferIdentity | None

    @property
    def image_id(self) -> str | None:
        return None if self.transfer is None else self.transfer.image_id

    def __post_init__(self) -> None:
        if not self.address.components:
            raise ValueError(
                f"No component metadata available for path: {self.address.path}"
            )

    @classmethod
    def from_payload(
        cls,
        image_info: Mapping[str, NapariWireValue],
        layer_axis_projection_semantics: ViewerComponentAxisSemantics,
        display_config: NapariDisplayConfig,
    ) -> "NapariImagePayload":
        payload = PayloadMap(image_info, "Napari image message")
        stream_layer_context = NapariStreamLayerContext.from_payload_map(
            payload,
            layer_axis_projection_semantics,
            display_config,
        )
        return cls(
            raw=image_info,
            transfer=ImageTransferIdentity.from_item(image_info),
            entries=stream_layer_context.entries,
            layout=stream_layer_context.layout,
            producer=stream_layer_context.producer,
            address=stream_layer_context.address,
            image_metadata=stream_layer_context.image_metadata,
            plane_component_domain=stream_layer_context.plane_component_domain,
            display_config=stream_layer_context.display_config,
        )

    @property
    def shapes(self) -> LayerData:
        return PayloadMap(self.raw, "Napari shapes/points message").required(
            ViewerWireField.SHAPES
        )

    @property
    def image_shape(self) -> tuple[int, ...]:
        shape = PayloadMap(self.raw, "Napari image message").required(
            ViewerWireField.SHAPE
        )
        if isinstance(shape, tuple):
            return tuple(int(dimension) for dimension in shape)
        if isinstance(shape, list):
            return tuple(int(dimension) for dimension in shape)
        raise TypeError(
            "Napari image message field 'shape' must be a sequence, "
            f"got {type(shape).__name__}"
        )

    @property
    def dtype(self) -> str | np.dtype:
        return PayloadMap(self.raw, "Napari image message").required(
            ViewerWireField.DTYPE
        )

    @property
    def shm_name(self) -> str | None:
        shm_name = PayloadMap(self.raw, "Napari image message").optional(
            ViewerWireField.SHM_NAME
        )
        if shm_name is None:
            return None
        return str(shm_name)

    @property
    def direct_data(self) -> LayerData:
        return PayloadMap(self.raw, "Napari image message").optional(
            ViewerWireField.DATA
        )


_COMPONENT_METADATA_NORMALIZER = ViewerComponentMetadataNormalizer()
_ACK_ERROR = ViewerProtocolStatus.ERROR.value
_ACK_SUCCESS = ViewerProtocolStatus.SUCCESS.value
NAPARI_SETTLEMENT_UPDATE_YIELD_MS = 10


class NapariImagePayloadLayoutRole(str, Enum):
    """Declared image layouts that cannot share one Napari layer."""

    SCALAR_PLANE = ("scalar_plane", "", True)
    SCALAR_STACK = ("scalar_stack", "image stack", False)
    COLOR_PLANE = ("color_plane", "source channels", False)
    COLOR_STACK = ("color_stack", "source-channel stack", False)

    def __new__(cls, value: str, title_suffix: str, is_default_route: bool):
        member = str.__new__(cls, value)
        member._value_ = value
        member.title_suffix = title_suffix
        member.is_default_route = is_default_route
        return member

    @classmethod
    def for_stream_layer_context(
        cls,
        stream_layer_context: NapariStreamLayerContext,
    ) -> "NapariImagePayloadLayoutRole | None":
        if (
            stream_layer_context.address.stream_layer_data_type
            is not StreamingDataType.IMAGE
        ):
            return None
        metadata = stream_layer_context.image_metadata
        has_channel_axis = metadata.source_channel_axis is not None
        has_plane_axis = metadata.plane_axis is not None
        if has_channel_axis:
            return cls.COLOR_STACK if has_plane_axis else cls.COLOR_PLANE
        return cls.SCALAR_STACK if has_plane_axis else cls.SCALAR_PLANE

    @property
    def route_suffix(self) -> str:
        return self.value

    def route_key(self, base_route_key: str) -> str:
        if self.is_default_route:
            return base_route_key
        return StreamRouteKeyAuthority.join([base_route_key, self.route_suffix])

    def title(self, base_title: str) -> str:
        if not self.title_suffix:
            return base_title
        return f"{base_title} {self.title_suffix}"


class NapariPayloadDataLoader:
    """Load payload data by streaming data kind."""

    SHAPE_LIKE_DATA_TYPES = frozenset(
        {StreamingDataType.SHAPES, StreamingDataType.POINTS}
    )

    def load(self, payload: NapariImagePayload) -> LayerData:
        data_type = payload.address.stream_layer_data_type
        if data_type in self.SHAPE_LIKE_DATA_TYPES:
            return payload.shapes
        return self._image_data(payload)

    def _image_data(self, payload: NapariImagePayload) -> np.ndarray:
        if payload.shm_name:
            return self._shared_memory_image(payload)
        if payload.direct_data is not None:
            return np.array(payload.direct_data, dtype=payload.dtype).reshape(
                payload.image_shape
            )
        raise ValueError("No image data in message")

    def _shared_memory_image(self, payload: NapariImagePayload) -> np.ndarray:
        try:
            return StreamingSharedMemoryAuthority.copy_sender_owned_array(
                name=payload.shm_name,
                shape=payload.image_shape,
                dtype=payload.dtype,
            )
        except FileNotFoundError as exc:
            raise FileNotFoundError(
                f"Shared memory {payload.shm_name} not found"
            ) from exc


@dataclass(frozen=True)
class NapariLayerRoute(ViewerComponentAxisSemantics):
    """Resolved route identity for one component-aware display item."""

    producer: StreamProducerIdentity
    route_key: str
    layer_title: str
    component_info: ComponentMap
    item_address: NapariStreamLayerAddress
    display_config: NapariDisplayConfig
    payload_layout_role: NapariImagePayloadLayoutRole | None = None
    image_metadata: ImagePayloadMetadata = field(default_factory=ImagePayloadMetadata)
    plane_component_domain: ViewerComponentValueDomainPayload = field(
        default_factory=lambda: ViewerComponentValueDomainPayload(())
    )


class NapariVariableSizeDisplayStrategy(
    EnumKeyedStrategyMixin[NapariVariableSizeHandling],
    ABC,
    metaclass=AutoRegisterMeta,
):
    """Apply one declared variable-size policy at routing and display time."""

    __enum_member_attr__ = "variable_size_handling"

    variable_size_handling: ClassVar[NapariVariableSizeHandling]

    def routing_context(
        self,
        context: NapariStreamLayerContext,
    ) -> NapariStreamLayerContext:
        """Return the effective route context for one streamed payload."""

        return context

    @abstractmethod
    def materialize_layer_items(
        self,
        layer_items: list[NapariStreamLayerItem],
        *,
        route_key: str,
    ) -> list[NapariStreamLayerItem]:
        """Return image items that can share one native Napari layer."""


class NapariPadToMaxDisplayStrategy(NapariVariableSizeDisplayStrategy):
    """Keep one component route and pad its images to a common shape."""

    variable_size_handling = NapariVariableSizeHandling.PAD_TO_MAX

    def materialize_layer_items(
        self,
        layer_items: list[NapariStreamLayerItem],
        *,
        route_key: str,
    ) -> list[NapariStreamLayerItem]:
        shapes = {item.data.shape for item in layer_items}
        if len(shapes) > 1:
            logger.info(
                "🔬 NAPARI PROCESS: Images in layer %s have different shapes - "
                "padding to max size",
                route_key,
            )
            max_shape = tuple(
                max(shape[axis] for shape in shapes)
                for axis in range(len(layer_items[0].data.shape))
            )
            for item_index, item in enumerate(layer_items):
                if item.data.shape == max_shape:
                    continue
                pad_width = tuple(
                    (0, maximum - current)
                    for current, maximum in zip(
                        item.data.shape,
                        max_shape,
                        strict=True,
                    )
                )
                layer_items[item_index] = replace(
                    item,
                    data=np.pad(
                        item.data,
                        pad_width,
                        mode="constant",
                        constant_values=0,
                    ),
                )
                logger.debug(
                    "🔬 NAPARI PROCESS: Padded image from %s to %s",
                    item.data.shape,
                    max_shape,
                )
        return layer_items


class NapariSeparateLayersDisplayStrategy(NapariVariableSizeDisplayStrategy):
    """Project the well axis into distinct routes and preserve native shapes."""

    variable_size_handling = NapariVariableSizeHandling.SEPARATE_LAYERS

    def routing_context(
        self,
        context: NapariStreamLayerContext,
    ) -> NapariStreamLayerContext:
        if context.address.stream_layer_data_type is not StreamingDataType.IMAGE:
            return context

        well_component = AllComponents.WELL.value
        ViewerComponentCoordinateAuthority.required_value(
            context.address.components,
            well_component,
            context="Napari separate-layer routing",
        )
        if well_component in context.layout.components_for_mode(
            ViewerComponentMode.LAYER
        ):
            return context

        component_modes = dict(context.layout.component_modes)
        component_modes[well_component] = ViewerComponentMode.LAYER.value
        return replace(
            context,
            layout=ViewerComponentLayout.from_parts(
                component_modes=component_modes,
                component_order=context.layout.component_order,
            ),
        )

    def materialize_layer_items(
        self,
        layer_items: list[NapariStreamLayerItem],
        *,
        route_key: str,
    ) -> list[NapariStreamLayerItem]:
        shapes = {item.data.shape for item in layer_items}
        if len(shapes) > 1:
            raise ValueError(
                "Napari separate-layer route "
                f"{route_key!r} still contains mixed image shapes: "
                f"{sorted(shapes)!r}."
            )
        return layer_items


class NapariComponentAwareDisplayCoordinator:
    """Route loaded payload data into debounced Napari layer updates."""

    def display(
        self,
        *,
        data: LayerData,
        stream_layer_context: NapariStreamLayerContext,
        server: "NapariViewerServer",
    ) -> None:
        routed_data = data
        self._reconcile_deleted_layers(server)
        route = self._route(
            data=routed_data,
            stream_layer_context=stream_layer_context,
            server=server,
        )
        self._log_route(route)
        group = self._group_for(server, route.route_key)
        self._upsert_item(
            data=routed_data,
            route=route,
            group=group,
        )
        logger.info(
            "🔬 NAPARI PROCESS: Scheduling debounced update for %s (data_type=%s)",
            route.route_key,
            route.item_address.stream_layer_data_type,
        )
        server.display_pipeline.schedule_layer_update(
            route.route_key,
            route.item_address.stream_layer_data_type,
            route,
            group,
        )

    @staticmethod
    def _route(
        *,
        data: LayerData,
        stream_layer_context: NapariStreamLayerContext,
        server: "NapariViewerServer",
    ) -> NapariLayerRoute:
        effective_context = NapariVariableSizeDisplayStrategy.for_enum_member(
            stream_layer_context.display_config.variable_size_handling
        ).routing_context(stream_layer_context)
        payload_layout_role = NapariImagePayloadLayoutRole.for_stream_layer_context(
            effective_context,
        )
        route = effective_context.layer_route(
            payload_layout_role=payload_layout_role,
            layer_route_state=server.layer_route_state,
        )
        server.layer_route_state.set_title(route.route_key, route.layer_title)
        return route

    @staticmethod
    def _log_route(
        route: NapariLayerRoute,
    ) -> None:
        logger.info(
            "🔍 NAPARI PROCESS: component_modes=%s, layout_role=%s, layer_key='%s'",
            route.layout.component_modes,
            route.payload_layout_role,
            route.route_key,
        )
        logger.info(
            "🔍 NAPARI PROCESS: layer_key='%s', component_info=%s",
            route.route_key,
            route.component_info,
        )

    @staticmethod
    def _reconcile_deleted_layers(
        server: "NapariViewerServer",
    ) -> None:
        """Purge every route whose native layer was removed from the viewer."""

        for layer_key in tuple(server.layer_route_state.layers):
            NapariComponentAwareDisplayCoordinator._reconcile_deleted_layer(
                server,
                layer_key,
            )

    @staticmethod
    def _reconcile_deleted_layer(
        server: "NapariViewerServer",
        layer_key: str,
    ) -> None:
        if (
            layer_key in server.layer_route_state.layers
            and server.layer_route_state.layers[layer_key] not in server.viewer.layers
        ):
            num_items = server.component_groups.item_count(layer_key)
            NapariComponentAwareDisplayCoordinator.purge_route(server, layer_key)
            logger.info(
                "🔬 NAPARI PROCESS: Reconciling state — '%s' was deleted from viewer; "
                "purged stale caches (had %d items in component_groups)",
                layer_key,
                num_items,
            )

    @staticmethod
    def purge_route(server: "NapariViewerServer", route_key: str) -> None:
        """The one route-release recipe, for native deletion and explicit retirement."""
        server.layer_route_state.purge_route(route_key)
        server.display_pipeline.purge_display_work(route_key)
        server.component_groups.purge(route_key)
        server.component_values.purge(route_key)
        server.batch_processors.purge(route_key)

    def retire_layers(
        self, server: "NapariViewerServer", request: ViewerWindowLayerRetirementRequest,
    ) -> tuple[str, ...]:
        """Validate the whole observed set before any ordinary native removal."""
        with server.layer_route_state.mutation_boundary():
            viewer = server.require_viewer()
            request.control_deadline().remaining_seconds()
            server.layer_route_state.require_retirement_boundary()
            server.display_pipeline.require_retirement_boundary()
            if not server.accepted_stream_batches.empty():
                raise RuntimeError("Cannot retire layers with accepted intake; settle first.")
            routes = tuple(request.retirement.expected_producers)
            for route, expected in request.retirement.expected_producers.items():
                if not server.layer_route_state.has_layer(route):
                    raise ValueError(f"Retirement route {route!r} is not mounted.")
                layer = server.layer_route_state.layer(route)
                if layer not in viewer.layers:
                    raise ValueError(f"Retirement route {route!r} is already deleted.")
                actual = server.component_groups.producer_identities_for(route)
                if actual != frozenset(expected):
                    raise ValueError(f"Retirement producer incarnation changed for {route!r}.")
            viewport = NapariNativeViewportPresentation.for_viewer(viewer)
            presentation = viewport.snapshot() if viewport is not None else None
            request.control_deadline().remaining_seconds()
            for route in routes:
                viewer.layers.remove(server.layer_route_state.layer(route))
                self.purge_route(server, route)
            server.display_pipeline.reconcile_mounted_axis_projections(rematerialize=True)
            if viewport is not None:
                viewport.apply(presentation)
            return routes

    @staticmethod
    def _group_for(
        server: "NapariViewerServer",
        layer_key: str,
    ) -> list[NapariStreamLayerItem]:
        """Stage intake on its pending generation, never overwrite mounted facts."""
        if server.replace_layers:
            return []
        pending = server.layer_route_state.pending_update_for(layer_key)
        if pending is not None:
            return list(pending.items)
        return list(server.component_groups.existing_items_for(layer_key) or ())

    def _upsert_item(
        self,
        *,
        data: LayerData,
        route: NapariLayerRoute,
        group: list[NapariStreamLayerItem],
    ) -> None:
        new_item = NapariStreamLayerItem(
            data=data,
            producer=route.producer,
            address=route.item_address,
            image_metadata=route.image_metadata,
            plane_component_domain=route.plane_component_domain,
        )
        existing_index = None
        for index, item in enumerate(group):
            if item.address.same_layer_slot(route.item_address):
                existing_index = index
                break
        if existing_index is None:
            group.append(new_item)
            logger.info(
                "🔬 NAPARI PROCESS: Added %s to component_groups[%s], now has %d items",
                route.item_address.stream_layer_data_type,
                route.route_key,
                len(group),
            )
            return

        old_data_type = group[existing_index].address.stream_layer_data_type
        group[existing_index] = new_item
        logger.info(
            "🔬 NAPARI PROCESS: Replaced %s item in component_groups[%s] at index %d, "
            "total items: %d",
            old_data_type,
            route.route_key,
            existing_index,
            len(group),
        )


_NAPARI_PAYLOAD_DATA_LOADER = NapariPayloadDataLoader()
_NAPARI_COMPONENT_DISPLAY_COORDINATOR = NapariComponentAwareDisplayCoordinator()

# ZMQ connection delay (ms)
ZMQ_CONNECTION_DELAY_MS = 100  # Brief delay for ZMQ connection to establish


def _build_nd_points(
    layer_items: list[NapariStreamLayerItem],
    axis_projection: ViewerLayerAxisProjection,
):
    """
    Build nD points by prepending stack component indices to 2D point coordinates.

    Args:
        layer_items: List of items with 'data' (list of point coordinate arrays) and 'components'
        axis_projection: Projected component axes and their value domains.

    Returns:
        Tuple of (all_points_nd, all_properties)
    """
    all_points_nd = []
    all_properties = {
        "label": [], "component": [], NapariStreamLayerItem.ELEMENT_IDENTITY_FEATURE: [],
    }
    point_metadata: list[Mapping[str, NapariWireValue]] = []

    for item in layer_items:
        points_data = item.data
        prepend_dims = list(
            axis_projection.coordinate_index(
                item.address.components,
                context="Napari points item",
            )
        )

        for member_index, shape_dict in enumerate(points_data):
            shape_payload = ShapePayload(shape_dict)
            if shape_payload.shape_type != "points":
                continue

            coordinates = shape_payload.coordinates
            metadata = shape_payload.metadata
            fractional_z = ROIFractionalZ.decode(metadata.metadata)
            z_axis_index = None
            if fractional_z is not None:
                try:
                    z_axis_index = axis_projection.projected_axis_components.index(
                        AllComponents.Z_INDEX.value
                    )
                except ValueError as exc:
                    raise ValueError(
                        "Fractional-Z point ROI requires a projected z_index axis."
                    ) from exc

            for coordinate_index, coord in enumerate(coordinates):
                point_dims = prepend_dims.copy()
                if z_axis_index is not None and fractional_z is not None:
                    point_dims[z_axis_index] += fractional_z.value
                nd_coord = point_dims + list(coord)
                all_points_nd.append(nd_coord)

                all_properties["label"].append(
                    metadata.value(VisualMetadataField.LABEL, "")
                )
                all_properties["component"].append(
                    metadata.value(VisualMetadataField.COMPONENT, 0)
                )
                point_metadata.append(
                    ROIArchiveSourceMetadata.feature_metadata(metadata.metadata)
                )
                all_properties[NapariStreamLayerItem.ELEMENT_IDENTITY_FEATURE].append(
                    item.element_identity(member_index, coordinate_index)
                )

    excluded = {
        "label",
        "component",
        ROIFractionalZ.FIELD,
        NapariStreamLayerItem.ELEMENT_IDENTITY_FEATURE,
    }
    feature_fields = {
        key
        for values in point_metadata
        for key, value in values.items()
        if key not in excluded and isinstance(value, (str, int, float, bool))
    }
    for field in sorted(feature_fields):
        if all(
            field in values and isinstance(values[field], (str, int, float, bool))
            for values in point_metadata
        ):
            all_properties[field] = [values[field] for values in point_metadata]

    points_array = np.empty((0, 2 + len(axis_projection.projected_axis_components)))
    if all_points_nd:
        points_array = np.array(all_points_nd)
    return points_array, all_properties


def _build_nd_image_array(
    layer_items: list[NapariStreamLayerItem],
    axis_projection: ViewerLayerAxisProjection,
    aggregate_axis_bindings: NapariAggregateAxisBindingSet | None = None,
):
    """
    Build nD image array by stacking images along stack component dimensions.

    Args:
        layer_items: List of items with 'data' (image arrays) and 'components'
        axis_projection: Projected component axes and their value domains.

    Returns:
        np.ndarray: Stacked image array
    """
    projected_axis_components = axis_projection.projected_axis_components
    component_values = axis_projection.component_values
    if aggregate_axis_bindings is None:
        aggregate_axis_bindings = NapariAggregateAxisBindingSet()
    logger.info(
        f"🔬 NAPARI PROCESS: Building nD array with axis_components={projected_axis_components}, component_values={component_values}"
    )

    first_img = layer_items[0].data
    payload_shape = tuple(int(axis) for axis in first_img.shape)
    residual_payload_shape = tuple(
        extent
        for index, extent in enumerate(payload_shape)
        if index not in aggregate_axis_bindings.payload_axes
    )
    stack_shape = axis_projection.axis_shape() + residual_payload_shape
    stacked_array = np.zeros(stack_shape, dtype=first_img.dtype)
    occupied_indices: set[tuple[int, ...]] = set()
    logger.info(
        f"🔬 NAPARI PROCESS: Created nD array with shape {stack_shape} from {len(layer_items)} items"
    )

    for img in layer_items:
        for payload_indices in product(
            *(range(binding.extent) for binding in aggregate_axis_bindings.bindings)
        ):
            components = aggregate_axis_bindings.item_component_values(
                img,
                payload_indices,
            )
            indices = axis_projection.coordinate_index(
                components,
                context="Napari image item",
            )
            if indices in occupied_indices:
                raise ValueError(
                    "Duplicate Napari image item for projected coordinate "
                    f"{indices!r} on axes {projected_axis_components!r}."
                )
            occupied_indices.add(indices)
            logger.debug(
                "🔬 NAPARI PROCESS: Placing image at indices %s, components=%s",
                indices,
                components,
            )
            if payload_indices:
                stacked_array[indices] = img.data[payload_indices]
            else:
                stacked_array[indices] = img.data

    missing_indices = axis_projection.expected_indices() - occupied_indices
    if missing_indices:
        raise ValueError(
            "Napari image stack missing routed image(s) for projected coordinate(s) "
            f"{sorted(missing_indices)!r} on axes {projected_axis_components!r}."
        )
    logger.info(
        "🔬 NAPARI PROCESS: Image route coverage complete for axes=%s positions=%d gaps=%d",
        projected_axis_components,
        len(occupied_indices),
        len(missing_indices),
    )
    return stacked_array


class NapariLayerTitleAuthority:
    """Build visible titles from producer identity and layer-routed components."""

    @classmethod
    def title(
        cls,
        *,
        producer: StreamProducerIdentity,
        stream_layer_data_type: StreamingDataType,
        component_info: ComponentMap,
        component_layout: ViewerComponentLayout,
        payload_layout_role: NapariImagePayloadLayoutRole | None = None,
    ) -> str:
        parts = [StreamProducerDisplayNameAuthority.output_label(producer)]
        for component in component_layout.components_for_mode(
            ViewerComponentMode.LAYER
        ):
            value = ViewerComponentCoordinateAuthority.required_value(
                component_info,
                component,
                context="Napari layer title",
            )
            parts.append(f"{component} {value}")
        suffix = NapariLayerDisplayHandler.for_data_type(
            stream_layer_data_type
        ).title_suffix
        if suffix:
            parts.append(suffix)
        title = " ".join(str(part) for part in parts if part)
        if payload_layout_role is None:
            return title
        return payload_layout_role.title(title)

    @staticmethod
    def disambiguate(
        *,
        title: str,
        producer: StreamProducerIdentity,
        route_key: str,
        layer_route_state: NapariLayerRouteStateStore,
    ) -> str:
        if not layer_route_state.title_collides(route_key, title):
            return title
        return f"{title} [{StreamProducerDisplayNameAuthority.disambiguation_label(producer)}]"


class NapariDimensionLabelRouteSource(str, Enum):
    """Provenance for the dimension-label route currently applied to Napari."""

    SELECTED_OPENHCS_LAYER = "selected_openhcs_layer"
    UPDATED_OPENHCS_LAYER = "updated_openhcs_layer"
    ACTIVE_STREAM_ROUTE = "active_stream_layer_context"
    COMPATIBLE_STREAM_ROUTE = "compatible_stream_layer_context"
    ACTIVE_NON_OPENHCS_LAYER = "active_non_openhcs_layer"
    MISSING = "missing"


@dataclass(frozen=True)
class NapariDimensionLabelRouteResolution:
    """Resolved dimension-label route plus the reason it was selected."""

    route_key: str | None
    source: NapariDimensionLabelRouteSource


class NapariDimensionLabelStore:
    """Store semantic axis labels for one streamed layer route."""

    def __init__(self, server: "NapariViewerServer") -> None:
        self.server = server

    def apply(
        self,
        presentation: NapariAxisPresentation,
        *,
        display_config: NapariDisplayConfig | None = None,
    ) -> tuple[str, ...] | None:
        self._validate_payload_axis_labels(presentation.payload_axis_labels)
        axis_projection = presentation.projection
        self._validate_axis_offsets(axis_projection.axis_offsets)
        axis_labels = presentation.axis_labels
        scalar_labels = self.server.component_name_metadata.scalar_labels(
            axis_projection.scalar_component_values
        )
        if display_config is None:
            display_config = self.server.layer_route_state.dimension_state_for(
                presentation.route_key
            ).display_config
        if not axis_projection.projected_axis_components:
            self.server.layer_route_state.set_dimension_state(
                presentation.route_key,
                NapariDimensionLayerState(
                    labels={},
                    scalar_labels=scalar_labels,
                    presentation=presentation,
                    display_config=display_config,
                ),
            )
            return axis_labels

        logger.info(
            "🔬 NAPARI PROCESS: Built axis_labels=%s for projected_axis_components=%s",
            axis_labels,
            axis_projection.projected_axis_components,
        )
        self.server.layer_route_state.set_dimension_state(
            presentation.route_key,
            NapariDimensionLayerState(
                labels=self._dimension_labels(
                    axis_projection.projected_axis_components,
                    axis_projection.component_values,
                    self.server.component_name_metadata,
                ),
                scalar_labels=scalar_labels,
                presentation=presentation,
                display_config=display_config,
            ),
        )
        return axis_labels

    @staticmethod
    def _validate_payload_axis_labels(payload_axis_labels: tuple[str, ...]) -> None:
        invalid_labels = [
            label for label in payload_axis_labels if not isinstance(label, str)
        ]
        if invalid_labels:
            raise TypeError(
                "payload_axis_labels must contain semantic axis-name strings; "
                f"got {invalid_labels!r}."
            )

    @staticmethod
    def _validate_axis_offsets(axis_offsets: tuple[int, ...]) -> None:
        invalid_offsets = [
            offset for offset in axis_offsets if not isinstance(offset, int)
        ]
        if invalid_offsets:
            raise TypeError(
                "axis_offsets must contain integer coordinate offsets; "
                f"got {invalid_offsets!r}."
            )

    def _dimension_labels(
        self,
        active_projected_axis_components: tuple[str, ...],
        active_component_values: ComponentValues,
        component_names_metadata: ViewerComponentNameMetadata,
    ) -> DimensionLabelMap:
        dimension_labels = {}
        for component in active_projected_axis_components:
            values = active_component_values[component]
            dimension_labels[component] = component_names_metadata.axis_labels(
                component,
                values,
            )
        return dimension_labels


class NapariDimensionLabelRouteResolver:
    """Resolve which route currently owns Napari dimension labels."""

    def __init__(self, server: "NapariViewerServer") -> None:
        self.server = server

    def resolve(
        self,
        updated_route_key: str | None = None,
    ) -> NapariDimensionLabelRouteResolution:
        viewer_ndim = self._viewer_ndim()
        current_step = self._viewer_current_step()
        selected_route_key = None
        active_layer = self.server.viewer.layers.selection.active
        if active_layer is not None:
            selected_route_key = self._route_key_for_layer(active_layer)
            if selected_route_key is None:
                return NapariDimensionLabelRouteResolution(
                    route_key=None,
                    source=NapariDimensionLabelRouteSource.ACTIVE_NON_OPENHCS_LAYER,
                )

        if self._route_matches_viewer_context(
            updated_route_key,
            viewer_ndim,
            current_step,
        ):
            return NapariDimensionLabelRouteResolution(
                route_key=updated_route_key,
                source=NapariDimensionLabelRouteSource.UPDATED_OPENHCS_LAYER,
            )

        if selected_route_key is not None:
            if self._route_matches_viewer_context(
                selected_route_key,
                viewer_ndim,
                current_step,
            ):
                return NapariDimensionLabelRouteResolution(
                    route_key=selected_route_key,
                    source=NapariDimensionLabelRouteSource.SELECTED_OPENHCS_LAYER,
                )

        route_key = self.server.layer_route_state.active_dimension_label_route
        if self._route_matches_viewer_context(route_key, viewer_ndim, current_step):
            return NapariDimensionLabelRouteResolution(
                route_key=route_key,
                source=NapariDimensionLabelRouteSource.ACTIVE_STREAM_ROUTE,
            )

        route_key = self._latest_compatible_route(viewer_ndim, current_step)
        if route_key is not None:
            return NapariDimensionLabelRouteResolution(
                route_key=route_key,
                source=NapariDimensionLabelRouteSource.COMPATIBLE_STREAM_ROUTE,
            )

        return NapariDimensionLabelRouteResolution(
            route_key=None,
            source=NapariDimensionLabelRouteSource.MISSING,
        )

    def _route_key_for_layer(self, active_layer: NapariLayerHandle) -> str | None:
        for layer_key, layer in self.server.layer_route_state.layers.items():
            if layer is active_layer:
                return layer_key
        return None

    def _route_matches_viewer_context(
        self,
        route_key: str | None,
        viewer_ndim: int,
        current_step: tuple[int, ...],
    ) -> bool:
        if route_key is None:
            return False
        state = self.server.layer_route_state.dimension_state_for(route_key)
        axis_labels = state.axis_labels
        viewer_axis_origins = self.server.layer_route_state.axis_origins_for(
            axis_labels
        )
        return (
            bool(axis_labels)
            and len(axis_labels) == viewer_ndim
            and state.describes_current_step(
                current_step,
                viewer_axis_origins,
            )
        )

    def _latest_compatible_route(
        self,
        viewer_ndim: int,
        current_step: tuple[int, ...],
    ) -> str | None:
        route_keys = tuple(self.server.layer_route_state.layer_dimension_states)
        for route_key in reversed(route_keys):
            if self._route_matches_viewer_context(
                route_key,
                viewer_ndim,
                current_step,
            ):
                return route_key
        return None

    def _viewer_ndim(self) -> int:
        ndim = self.server.viewer.dims.ndim
        try:
            return int(ndim)
        except (TypeError, ValueError):
            raise TypeError(f"Napari viewer dims.ndim must be int-like, got {ndim!r}.")

    def _viewer_current_step(self) -> tuple[int, ...]:
        return tuple(int(step) for step in self.server.viewer.dims.current_step)


class NapariDimensionLabelOverlayController:
    """Apply resolved dimension labels and overlay text to the viewer."""

    def __init__(
        self,
        server: "NapariViewerServer",
        route_resolver: NapariDimensionLabelRouteResolver,
    ) -> None:
        self.server = server
        self.route_resolver = route_resolver
        self._dimension_label_handler_connected = False
        self._layer_selection_handler_connected = False

    def setup_for_layer(self, layer_key: str) -> None:
        if not self.server.viewer:
            return

        if not self.server.layer_route_state.dimension_state_for(layer_key).axis_labels:
            return

        self._connect_handlers()
        resolution = self.route_resolver.resolve(layer_key)
        if resolution.source is NapariDimensionLabelRouteSource.MISSING:
            state = self.server.layer_route_state.dimension_state_for(layer_key)
            if self._apply_axis_labels(layer_key, state):
                self.server.layer_route_state.set_active_dimension_label_route(
                    layer_key
                )
                self.server.viewer.text_overlay.text = self._dimension_label_text(state)
                logger.info(
                    "🔬 NAPARI PROCESS: Applied route-local axis labels for %s "
                    "without a current value-label overlay.",
                    layer_key,
                )
            return
        self._apply_resolution(resolution)
        logger.info(
            "🔬 NAPARI PROCESS: Active dimension label route resolved to %s (%s)",
            resolution.route_key,
            resolution.source.value,
        )

    def _connect_handlers(self) -> None:
        self._connect_dimension_label_handler()
        self._connect_layer_selection_handler()

    def _connect_dimension_label_handler(self) -> None:
        if self._dimension_label_handler_connected:
            return

        try:
            current_step_event = self.server.viewer.dims.events.current_step
            current_step_event.connect(self._update_overlay)
            self._dimension_label_handler_connected = True
        except Exception as e:
            logger.warning(
                f"🔬 NAPARI PROCESS: Failed to setup dimension label handler: {e}"
            )

    def _connect_layer_selection_handler(self) -> None:
        if self._layer_selection_handler_connected:
            return

        try:
            active_layer_event = self.server.viewer.layers.selection.events.active
            active_layer_event.connect(self._update_overlay)
            self._layer_selection_handler_connected = True
        except Exception as e:
            logger.debug(
                f"🔬 NAPARI PROCESS: Failed to setup active-layer label handler: {e}"
            )

    def _update_overlay(self, event=None) -> None:
        del event
        try:
            self.refresh()
        except Exception as e:
            logger.debug(f"🔬 NAPARI PROCESS: Error updating dimension label: {e}")

    def refresh(self) -> None:
        """Resolve labels from the viewer's current selection and dimensions."""
        if not self.server.viewer:
            return
        self._connect_handlers()
        self._apply_resolution(self.route_resolver.resolve())

    def _apply_resolution(
        self,
        resolution: NapariDimensionLabelRouteResolution,
    ) -> None:
        route_key = resolution.route_key
        self.server.layer_route_state.set_active_dimension_label_route(route_key)
        overlay_text = ""
        if route_key is not None:
            state = self.server.layer_route_state.dimension_state_for(route_key)
            self._apply_axis_labels(route_key, state)
            overlay_text = self._dimension_label_text(state)
        self.server.viewer.text_overlay.text = overlay_text

    def _apply_axis_labels(
        self,
        layer_key: str,
        state: NapariDimensionLayerState,
    ) -> bool:
        axis_labels = state.axis_labels
        if not axis_labels:
            return False
        ndim = self._viewer_ndim()
        if len(axis_labels) != ndim:
            logger.warning(
                "🔬 NAPARI PROCESS: Refusing axis_labels=%s for route %s because "
                "active viewer ndim is %s.",
                axis_labels,
                layer_key,
                ndim,
            )
            return False
        self.server.viewer.dims.axis_labels = axis_labels
        return True

    def _viewer_ndim(self) -> int:
        ndim = self.server.viewer.dims.ndim
        try:
            return int(ndim)
        except (TypeError, ValueError):
            raise TypeError(f"Napari viewer dims.ndim must be int-like, got {ndim!r}.")

    def _dimension_label_text(self, state: NapariDimensionLayerState) -> str:
        current_step = tuple(int(step) for step in self.server.viewer.dims.current_step)
        label_parts = state.label_parts_for_current_step(
            current_step,
            self.server.layer_route_state.axis_origins_for(state.axis_labels),
        )
        if label_parts is None:
            return ""
        return " | ".join(label_parts)


@dataclass(frozen=True, slots=True)
class NapariLayerDisplayRequest:
    """Typed request for displaying one Napari route with one stream data type."""

    pipeline: "NapariLayerDisplayPipeline"
    items: list[NapariStreamLayerItem]
    presentation: NapariAxisPresentation
    display_config: NapariDisplayConfig

    def create_or_update_layer(
        self,
        *,
        layer_kind: NapariLayerKind,
        data: LayerData,
        layer_kwargs: Mapping[str, LayerKwargValue],
    ) -> NapariLayerHandle:
        """Create or replace the concrete Napari layer for this display request."""
        route_key = self.presentation.route_key
        layer_route_state = self.pipeline.server.layer_route_state
        layer = _NAPARI_LAYER_UPDATES.create_or_update(
            layer_kind=layer_kind,
            viewer=self.pipeline.server.viewer,
            layers=layer_route_state.layers,
            route_key=route_key,
            layer_name=layer_route_state.title_for(route_key),
            data=data,
            layer_kwargs=layer_kwargs,
        )
        self.publish()
        return layer

    def mount_layer(self, layer: NapariLayerHandle) -> None:
        """Publish only a complete native candidate through the route owner."""
        server = self.pipeline.server
        _NAPARI_LAYER_UPDATES.mount(
            viewer=server.viewer,
            layers=server.layer_route_state.layers,
            route_key=self.presentation.route_key,
            layer=layer,
        )
        self.publish()

    def publish(self) -> None:
        """Move accepted items and their declared domain to mounted ownership."""
        route_key = self.presentation.route_key
        self.pipeline.server.component_groups.groups[route_key] = self.items
        self.pipeline.display_axis_projection(
            route_key,
            self.presentation.axis_projection_semantics(),
            self.items,
            self.presentation.aggregate_axis_bindings,
        )
        self.pipeline.dimension_label_store.apply(
            self.presentation,
            display_config=self.display_config,
        )
        self.reconcile_peers()

    def reconcile_peers(self) -> None:
        self.pipeline.reconcile_mounted_axis_projections(
            updated_route_key=self.presentation.route_key,
        )


@dataclass(frozen=True, slots=True)
class NapariRematerializationRequest(NapariLayerDisplayRequest):
    """The original reconciliation traversal already owns every survivor."""

    def reconcile_peers(self) -> None:
        pass


class NapariLayerDisplayWork(ABC):
    """One handler-owned display operation advanced in bounded Qt work units."""

    @abstractmethod
    def advance(self) -> bool:
        """Execute one bounded unit and return whether the operation is complete."""


@dataclass(slots=True)
class NapariImmediateLayerDisplayWork(NapariLayerDisplayWork):
    """Adapt an existing atomic display handler to the bounded-work contract."""

    callback: Callable[[], None]
    complete: bool = False

    def advance(self) -> bool:
        if not self.complete:
            self.callback()
            self.complete = True
        return True


class NapariLayerDisplayHandler(
    ViewerStreamingDataTypeHandler[NapariLayerDisplayRequest],
    metaclass=ViewerStreamingDataTypeHandlerMeta,
):
    """Executable display handler for one Napari stream data type."""

    title_suffix: ClassVar[str] = ""
    result_coordinate_authority: ClassVar[type[ViewerResultElementCoordinateAuthority]] = (
        ViewerResultElementCoordinateAuthority
    )

    @contextmanager
    def preserve_native_presentation(self, request: NapariLayerDisplayRequest):
        """Shared native properties survive domain pruning and remounting."""
        state = request.pipeline.server.layer_route_state
        route = request.presentation.route_key
        layer = state.layer(route)
        visible, opacity, blending = layer.visible, layer.opacity, layer.blending
        yield
        layer = state.layer(route)
        layer.visible, layer.opacity, layer.blending = visible, opacity, blending

    def rematerialize(self, request: NapariLayerDisplayRequest) -> None:
        with self.preserve_native_presentation(request):
            self.handle(request)

    def geometric_component_values(
        self,
        items: Sequence[NapariStreamLayerItem],
        component_axis_semantics: ViewerComponentAxisSemantics,
    ) -> ComponentValues:
        """Return component values occupied by geometry beyond item anchors."""
        return {}

    def display_work(
        self,
        request: NapariLayerDisplayRequest,
    ) -> NapariLayerDisplayWork:
        """Return the handler-owned work needed to display one route."""

        return NapariImmediateLayerDisplayWork(lambda: self.handle(request))


class NapariImagePresentationRetention:
    """Independent image presentation capability, cooperating through the MRO."""

    @contextmanager
    def preserve_native_presentation(self, request: NapariLayerDisplayRequest):
        state = request.pipeline.server.layer_route_state
        route = request.presentation.route_key
        layer = state.layer(route)
        control = NapariNativeImageIntensityPresentation.for_layer(layer)
        intensity = control.snapshot()
        colormap, interpolation = layer.colormap, layer.interpolation2d
        with super().preserve_native_presentation(request):
            yield
        layer = state.layer(route)
        NapariNativeImageIntensityPresentation.for_layer(layer).apply(intensity)
        layer.colormap, layer.interpolation2d = colormap, interpolation


class NapariSelectablePresentationRetention:
    """Independent feature-row selection capability, composing through the MRO."""

    @contextmanager
    def preserve_native_presentation(self, request: NapariLayerDisplayRequest):
        with request.pipeline.server.result_selection_controller.preserve_selection(
            request.presentation.route_key,
        ):
            with super().preserve_native_presentation(request):
                yield


@dataclass(frozen=True, slots=True)
class NapariImageLayerDisplayHandler(
    NapariImagePresentationRetention, NapariLayerDisplayHandler,
):
    """Build or update a Napari image layer from routed image payloads."""

    streaming_data_type: ClassVar[StreamingDataType] = StreamingDataType.IMAGE

    def handle(self, request: NapariLayerDisplayRequest) -> None:
        layer_items = self._materialize_source_domains(request.items)
        presentation = request.presentation
        shapes = [item.data.shape for item in layer_items]
        shape_ranks = {len(shape) for shape in shapes}
        if len(shape_ranks) > 1:
            raise ValueError(
                f"Layer {presentation.route_key} contains mixed-rank image payloads: "
                f"{sorted(set(shapes))}"
            )
        layer_items = NapariVariableSizeDisplayStrategy.for_enum_member(
            request.display_config.variable_size_handling
        ).materialize_layer_items(
            layer_items,
            route_key=presentation.route_key,
        )
        logger.info(
            "🔬 NAPARI PROCESS: Building nD data for %s from %d items",
            presentation.route_key,
            len(layer_items),
        )
        stacked_data = _build_nd_image_array(
            layer_items,
            presentation.projection,
            presentation.aggregate_axis_bindings,
        )
        stacked_data = presentation.align_array(stacked_data)
        pipeline = request.pipeline
        image_presentation = NapariImageLayerPresentationPolicy.for_payload(
            layer_items[0].data,
            layer_items[0].image_metadata,
        )
        payload_axis_labels = (
            *pipeline.payload_axis_policy.axis_labels(
                layer_items[0].data,
                layer_items[0].image_metadata,
                presentation.aggregate_axis_bindings.payload_axes,
            ),
            *image_presentation.payload_axis_labels,
        )
        stacked_data = image_presentation.present_data(stacked_data)
        presentation = replace(
            presentation,
            payload_axis_labels=payload_axis_labels,
        )
        request = replace(request, presentation=presentation)
        axis_labels = presentation.axis_labels

        layer_kwargs = image_presentation.layer_kwargs(request.display_config.colormap)
        if axis_labels is not None:
            layer_kwargs["axis_labels"] = axis_labels
        layer_kwargs.update(
            presentation.spatial_layer_kwargs(layer_items, payload_axis_labels)
        )

        request.create_or_update_layer(
            layer_kind=NapariLayerKind.IMAGE,
            data=stacked_data,
            layer_kwargs=layer_kwargs,
        )
        if axis_labels is not None:
            logger.info(
                "🔬 NAPARI PROCESS: Route %s carries layer-local axis_labels=%s",
                presentation.route_key,
                axis_labels,
            )

        pipeline.dimension_label_overlay.setup_for_layer(presentation.route_key)

    @staticmethod
    def _materialize_source_domains(
        layer_items: list[NapariStreamLayerItem],
    ) -> list[NapariStreamLayerItem]:
        """Place images in their declared source-image coordinate domains."""

        materialized_items: list[NapariStreamLayerItem] = []
        for item in layer_items:
            spatial_axes = item.image_metadata.spatial_axes_yx(item.data)
            source_domain = item.image_metadata.source_spatial_domain
            if spatial_axes is None or not source_domain.has_values:
                materialized_items.append(item)
                continue
            materialized_data = source_domain.materialize(
                item.data,
                spatial_axes_yx=spatial_axes,
            )
            materialized_items.append(
                replace(item, data=materialized_data)
                if materialized_data is not item.data
                else item
            )
        return materialized_items


@dataclass(slots=True)
class NapariShapesLayerDisplayWork(NapariLayerDisplayWork):
    """Incrementally materialize one native Shapes layer without starving Qt."""

    request: NapariLayerDisplayRequest
    payload: NapariShapeLayerPayload
    chunks: tuple[NapariShapeLayerPayload, ...]
    color_projection: NapariShapeColorProjection
    common_layer_kwargs: dict[str, LayerKwargValue]
    next_chunk_index: int = 0
    next_member_index: int = 0
    layer: NapariShapesLayerHandle | None = None

    def advance(self) -> bool:
        if self.next_chunk_index >= len(self.chunks):
            return True

        chunk = self.chunks[self.next_chunk_index]
        next_member_index = self.next_member_index + len(chunk.data)
        member_colors = self.color_projection.member_colors[
            self.next_member_index : next_member_index
        ]
        if self.layer is None:
            from napari.layers import Shapes

            layer_kwargs = dict(self.common_layer_kwargs)
            layer_kwargs.update(
                {
                    "shape_type": chunk.shape_types,
                    "features": chunk.features,
                    "edge_color": VisualMetadataField.LABEL.value,
                    "face_color": VisualMetadataField.LABEL.value,
                }
            )
            self.layer = cast(
                NapariShapesLayerHandle,
                Shapes(
                    chunk.data,
                    name=self.request.pipeline.server.layer_route_state.title_for(
                        self.request.presentation.route_key
                    ),
                    **layer_kwargs,
                ),
            )
        else:
            self.layer.add(
                chunk.data,
                shape_type=chunk.shape_types,
                edge_color=member_colors,
                face_color=member_colors,
            )

        self.next_member_index = next_member_index
        self.next_chunk_index += 1
        if self.next_chunk_index < len(self.chunks):
            logger.debug(
                "🔬 NAPARI PROCESS: Materialized ROI chunk %d/%d for %s",
                self.next_chunk_index,
                len(self.chunks),
                self.request.presentation.route_key,
            )
            return False

        if self.layer is None:
            raise RuntimeError("Napari Shapes display completed without a layer.")
        self.layer.features = self.payload.features
        self.layer.edge_color_cycle = self.color_projection.cycle
        self.layer.face_color_cycle = self.color_projection.cycle
        if self.layer.edge_color_mode != "cycle":
            self.layer.edge_color_mode = "cycle"
        if self.layer.face_color_mode != "cycle":
            self.layer.face_color_mode = "cycle"
        route_key = self.request.presentation.route_key
        self.request.mount_layer(self.layer)
        self.request.pipeline.server.bind_result_selection_layer(self.layer)
        self.request.pipeline.dimension_label_overlay.setup_for_layer(route_key)
        self.layer.visible = True
        logger.info(
            "🔬 NAPARI PROCESS: Created ROI layer %s with %d shape members in "
            "%d bounded work unit(s)",
            route_key,
            len(self.payload.data),
            len(self.chunks),
        )
        return True


@dataclass(frozen=True, slots=True)
class NapariShapesLayerDisplayHandler(
    NapariSelectablePresentationRetention, NapariLayerDisplayHandler,
):
    """Build or update a native N-D Napari Shapes layer from routed ROIs."""

    streaming_data_type: ClassVar[StreamingDataType] = StreamingDataType.SHAPES
    title_suffix: ClassVar[str] = "ROIs"
    # Native Shapes.add() emits model and canvas events for every work unit.
    # These profiled bounds keep Qt responsive while avoiding dozens of
    # increasingly expensive redraws for ordinary high-content ROI layers.
    MAX_SHAPES_PER_WORK_UNIT: ClassVar[int] = 2_048
    MAX_VERTICES_PER_WORK_UNIT: ClassVar[int] = 65_536

    def display_work(
        self,
        request: NapariLayerDisplayRequest,
    ) -> NapariLayerDisplayWork:
        pipeline = request.pipeline
        presentation = request.presentation
        logger.info(
            "🔬 NAPARI PROCESS: Building native ROIs for %s from %d items",
            presentation.route_key,
            len(request.items),
        )

        shape_payload = NapariShapeLayerPayload.build(
            layer_items=request.items,
            axis_projection=presentation.projection,
            aggregate_axis_bindings=presentation.aggregate_axis_bindings,
        ).align_display_axes(presentation)
        color_projection = shape_payload.color_projection
        chunks = shape_payload.chunks(
            max_shape_count=self.MAX_SHAPES_PER_WORK_UNIT,
            max_vertex_count=self.MAX_VERTICES_PER_WORK_UNIT,
        )

        axis_labels = presentation.axis_labels
        if axis_labels is not None:
            logger.info(
                "🔬 NAPARI PROCESS: ROI route %s carries layer-local axis_labels=%s",
                presentation.route_key,
                axis_labels,
            )

        layer_kwargs: dict[str, LayerKwargValue] = {
            "edge_color_cycle": color_projection.cycle,
            "face_color_cycle": color_projection.cycle,
            "opacity": 0.7,
            "ndim": shape_payload.ndim,
            "visible": False,
        }
        if shape_payload.result_metadata:
            layer_kwargs["metadata"] = dict(shape_payload.result_metadata)
        layer_kwargs.update(presentation.spatial_layer_kwargs(request.items))
        if axis_labels is not None:
            layer_kwargs["axis_labels"] = axis_labels
        return NapariShapesLayerDisplayWork(
            request=request,
            payload=shape_payload,
            chunks=chunks,
            color_projection=color_projection,
            common_layer_kwargs=layer_kwargs,
        )

    def handle(self, request: NapariLayerDisplayRequest) -> None:
        """Synchronously exhaust work for direct handler callers and tests."""

        work = self.display_work(request)
        while not work.advance():
            pass


@dataclass(frozen=True, slots=True)
class NapariPointsLayerDisplayHandler(
    NapariSelectablePresentationRetention, NapariLayerDisplayHandler,
):
    """Build or update a Napari points layer from routed point payloads."""

    streaming_data_type: ClassVar[StreamingDataType] = StreamingDataType.POINTS
    title_suffix: ClassVar[str] = "points"
    result_coordinate_authority: ClassVar[type[ViewerResultElementCoordinateAuthority]] = (
        ViewerPointCoordinateAuthority
    )

    def geometric_component_values(
        self,
        items: Sequence[NapariStreamLayerItem],
        component_axis_semantics: ViewerComponentAxisSemantics,
    ) -> ComponentValues:
        """Keep the represented source span, not just occupied point Z, navigable."""
        z_component = AllComponents.Z_INDEX.value
        coordinates = tuple(
            (item, fractional_z)
            for item in items
            for shape in item.data
            if (payload := ShapePayload(shape)).shape_type == "points"
            if (fractional_z := ROIFractionalZ.decode(payload.metadata.metadata))
            is not None
        )
        if not coordinates:
            return {}
        if z_component not in component_axis_semantics.layout.components_for_mode(
            ViewerComponentMode.STACK
        ):
            raise ValueError(
                "Fractional-Z point ROI requires a projected z_index axis."
            )
        domain = component_axis_semantics.required_component_values((z_component,))[
            z_component
        ]
        represented: set[ComponentValue] = set()
        for item, fractional_z in coordinates:
            anchor = ViewerComponentCoordinateAuthority.required_value(
                item.address.components,
                z_component,
                context="Napari fractional-Z point",
            )
            try:
                start = domain.index(anchor)
            except ValueError as exc:
                raise ValueError(
                    f"Fractional-Z point anchor {anchor!r} is absent from the "
                    f"declared Z domain {domain!r}."
                ) from exc
            stop = start + ceil(fractional_z.value)
            if stop >= len(domain):
                raise ValueError(
                    f"Fractional-Z point {fractional_z.value!r} exceeds the "
                    f"declared Z domain from anchor {anchor!r}."
                )
            represented.update(domain[start:])
        return {z_component: [value for value in domain if value in represented]}

    def handle(self, request: NapariLayerDisplayRequest) -> None:
        pipeline = request.pipeline
        presentation = request.presentation
        logger.info(
            "🔬 NAPARI PROCESS: Building points layer for %s from %d items",
            presentation.route_key,
            len(request.items),
        )

        points_data, properties = _build_nd_points(
            request.items,
            presentation.projection,
        )
        points_data = presentation.align_coordinates(points_data)
        axis_labels = presentation.axis_labels

        layer_kwargs = {
            "properties": properties,
            "face_color": "green",
            "size": 3,
        }
        layer_kwargs.update(presentation.spatial_layer_kwargs(request.items))
        if axis_labels is not None:
            layer_kwargs["axis_labels"] = axis_labels
        request.create_or_update_layer(
            layer_kind=NapariLayerKind.POINTS,
            data=points_data,
            layer_kwargs=layer_kwargs,
        )
        pipeline.dimension_label_overlay.setup_for_layer(presentation.route_key)

        logger.info(
            "🔬 NAPARI PROCESS: Created points layer %s with %d points",
            presentation.route_key,
            len(points_data),
        )


class NapariLayerDisplayPipeline:
    """Owns debounced Napari layer display and update routing."""

    def __init__(self, server: "NapariViewerServer") -> None:
        self.server = server
        self.axis_projector = ViewerLayerAxisProjector()
        self.payload_axis_policy = NapariImagePayloadAxisLabelPolicy()
        route_resolver = NapariDimensionLabelRouteResolver(server)
        self.dimension_label_store = NapariDimensionLabelStore(server)
        self.dimension_label_overlay = NapariDimensionLabelOverlayController(
            server,
            route_resolver,
        )
        self._display_work_by_route: dict[
            str,
            tuple[NapariPendingLayerUpdate, NapariLayerDisplayWork],
        ] = {}

    def clear_display_work(self) -> None:
        """Discard every deferred display continuation for a reset or shutdown."""

        self._display_work_by_route.clear()

    def purge_display_work(self, route_key: str) -> None:
        self._display_work_by_route.pop(route_key, None)

    def require_retirement_boundary(self) -> None:
        if self._display_work_by_route:
            raise RuntimeError("Cannot retire layers with unfinished display work.")

    def display_axis_projection(
        self,
        layer_key: str,
        component_axis_semantics: ViewerComponentAxisSemantics,
        layer_items: list[NapariStreamLayerItem],
        aggregate_axis_bindings: NapariAggregateAxisBindingSet | None = None,
        *,
        publish: bool = True,
        viewer_component_values: ComponentValues | None = None,
    ) -> ViewerLayerAxisProjection:
        """Return route-local coordinates projected into the viewer axis domain."""
        if aggregate_axis_bindings is None:
            aggregate_axis_bindings = NapariAggregateAxisBindingSet()

        data_type = layer_items[0].address.stream_layer_data_type
        geometric_component_values = NapariLayerDisplayHandler.for_data_type(
            data_type
        ).geometric_component_values(layer_items, component_axis_semantics)

        projection_request = (
            ViewerLayerAxisProjectionRequestAuthority.from_component_axis_semantics(
                route_key=layer_key,
                component_axis_semantics=component_axis_semantics,
                layer_items=layer_items,
                route_value_tracker=self.server.component_values,
                aggregate_component_values=aggregate_axis_bindings.component_values,
                geometric_component_values=geometric_component_values,
                publish=publish,
                viewer_component_values=viewer_component_values,
            )
        )
        return self.axis_projector.project(projection_request)

    def reconcile_mounted_axis_projections(
        self,
        *,
        updated_route_key: str | None = None,
        viewer_component_values: ComponentValues | None = None,
        apply: bool = True,
        rematerialize: bool = False,
    ) -> None:
        """Align mounted routes with the viewer-wide semantic coordinate domain.

        Independently streamed routes can declare different subsets of the same
        component axis.  A newly observed value may therefore change the shared
        coordinate assigned to an already mounted singleton route.  Shape-neutral
        changes are applied directly to that route's native transform and semantic
        presentation.  A change that would alter stored array extents fails during
        dispatch instead of leaving silently misaligned layers.
        """

        for (
            route_key,
            state,
        ) in self.server.layer_route_state.mounted_dimension_states():
            if route_key == updated_route_key or state.presentation is None:
                continue
            items = self.server.component_groups.existing_items_for(route_key)
            if not items:
                continue
            axis_projection_semantics = state.presentation.axis_projection_semantics()
            aggregate_axis_bindings = NapariAggregateAxisBindingAuthority.bindings(
                items,
                axis_projection_semantics,
            )
            projection = self.display_axis_projection(
                route_key,
                axis_projection_semantics,
                items,
                aggregate_axis_bindings,
                publish=apply,
                viewer_component_values=viewer_component_values,
            )
            presentation = replace(state.presentation, projection=projection)
            if (
                presentation.aligned_component_shape()
                != state.presentation.aligned_component_shape()
            ):
                if rematerialize:
                    NapariLayerDisplayHandler.for_data_type(
                        items[0].address.stream_layer_data_type
                    ).rematerialize(
                        NapariRematerializationRequest(
                            pipeline=self,
                            items=items,
                            presentation=presentation,
                            display_config=state.display_config,
                        )
                    )
                    continue
                raise ValueError(
                    "Napari shared semantic axis expansion requires route "
                    f"{route_key!r} to be rematerialized; old component shape="
                    f"{state.presentation.aligned_component_shape()!r}, new="
                    f"{presentation.aligned_component_shape()!r}."
                )
            if not apply:
                continue
            layer = self.server.layer_route_state.layer(route_key)
            layer.translate = presentation.spatial_layer_kwargs(
                items, presentation.payload_axis_labels
            )["translate"]
            self.dimension_label_store.apply(presentation)

    def schedule_layer_update(
        self,
        layer_key: str,
        data_type: StreamingDataType,
        layer_route: NapariLayerRoute,
        items: list[NapariStreamLayerItem],
    ) -> None:
        if self.server.layer_route_state.cancel_pending_update(layer_key):
            logger.debug(f"🔬 NAPARI PROCESS: Cancelled pending update for {layer_key}")
        self._display_work_by_route.pop(layer_key, None)

        timer = QTimer()
        timer.setSingleShot(True)
        update = NapariPendingLayerUpdate.from_semantics(
            timer=timer,
            data_type=data_type,
            semantics=layer_route,
            display_config=layer_route.display_config,
            items=items,
        )
        timer.timeout.connect(update.retained_callback(
            partial(self.execute_scheduled_layer_update, layer_key),
        ))
        self.server.layer_batch_processor_debounce_policy.start_timer(timer)
        self.server.layer_route_state.set_pending_update(layer_key, update)
        logger.debug(
            "🔬 NAPARI PROCESS: Scheduled update for %s in %sms",
            layer_key,
            self.server.layer_batch_processor_debounce_policy.delay_ms,
        )

    def execute_scheduled_layer_update(
        self,
        layer_key: str,
        update: NapariPendingLayerUpdate,
    ) -> None:
        """Advance one debounced route in bounded Qt callbacks."""

        if self.server.layer_route_state.pending_update_for(layer_key) is not update:
            return
        try:
            work = self._work_for_update(
                layer_key=layer_key,
                update=update,
            )
            if work.advance():
                self._complete_scheduled_work(layer_key, update)
                return
            QTimer.singleShot(
                NAPARI_SETTLEMENT_UPDATE_YIELD_MS,
                update.retained_callback(partial(self.execute_scheduled_layer_update, layer_key)),
            )
        except Exception as error:
            self.server.layer_route_state.record_update_error(layer_key, error)
            self._display_work_by_route.pop(layer_key, None)
            if self.server.layer_route_state.pending_update_for(layer_key) is update:
                self.server.layer_route_state.pop_pending_update(layer_key)
            logger.exception(
                "🔬 NAPARI PROCESS: Failed scheduled layer work for %s",
                layer_key,
            )
            return

    def _complete_scheduled_work(
        self,
        layer_key: str,
        update: NapariPendingLayerUpdate,
    ) -> None:
        """Release one exact debounced update after all display work completes."""

        self._display_work_by_route.pop(layer_key, None)
        if self.server.layer_route_state.pending_update_for(layer_key) is update:
            self.server.layer_route_state.pop_pending_update(layer_key)
        self.server.layer_route_state.clear_update_error(layer_key)

    def _work_for_update(
        self,
        *,
        layer_key: str,
        update: NapariPendingLayerUpdate,
    ) -> NapariLayerDisplayWork:
        """Return or prepare the exact handler-owned work for one update."""

        existing = self._display_work_by_route.get(layer_key)
        if existing is not None and existing[0] is update:
            return existing[1]
        work = self.execute_layer_update(
            layer_key,
            update.data_type,
            update,
        )
        self._display_work_by_route[layer_key] = (update, work)
        return work

    def execute_layer_update(
        self,
        layer_key: str,
        data_type: StreamingDataType,
        layer_axis_projection_semantics: NapariPendingLayerUpdate,
    ) -> NapariLayerDisplayWork:
        try:
            layer_items = layer_axis_projection_semantics.items
            if not layer_items:
                logger.warning(
                    f"🔬 NAPARI PROCESS: Empty item group for {layer_key}, skipping update"
                )
                return NapariImmediateLayerDisplayWork(lambda: None)

            batch_processor = self.server.batch_processors.get_or_create(
                layer_key=layer_key,
                napari_server=self.server,
            )
            work = batch_processor.add_items(
                layer_key=layer_key,
                items=layer_items,
                display_payload=layer_axis_projection_semantics,
                component_names_metadata=self.server.component_name_metadata,
            )
            if not isinstance(work, NapariLayerDisplayWork):
                raise TypeError(
                    "Napari batch display adapter must return NapariLayerDisplayWork."
                )
            self.server.layer_route_state.clear_update_error(layer_key)
            return work
        except Exception as error:
            self.server.layer_route_state.record_update_error(layer_key, error)
            logger.exception(
                "🔬 NAPARI PROCESS: Failed to update layer %s",
                layer_key,
            )
            raise

    def settlement_progress(self) -> ViewerSettleProgress:
        """Begin or observe an incremental Qt-driven settlement cycle."""

        settlement = self.server.layer_route_state.begin_settlement()
        if settlement.active_route is None:
            self._schedule_next_settlement_update(settlement)
        return settlement.progress()

    def _schedule_next_settlement_update(
        self,
        settlement: NapariLayerSettlementState,
    ) -> None:
        if settlement.failed or settlement.active_route is not None:
            return
        if settlement.completed_update_count == len(settlement.updates):
            try:
                self.server.layer_route_state.require_updates_succeeded()
            except Exception:
                settlement.fail()
            return

        claimed_update = settlement.begin_next()
        if claimed_update is None:
            return
        route_key, update = claimed_update
        QTimer.singleShot(
            NAPARI_SETTLEMENT_UPDATE_YIELD_MS,
            update.retained_callback(partial(self._execute_settlement_update, settlement, route_key)),
        )

    def _execute_settlement_update(
        self,
        settlement: NapariLayerSettlementState,
        route_key: str,
        update: NapariPendingLayerUpdate,
    ) -> None:
        """Advance one bounded route work unit and publish genuine progress."""

        try:
            settlement.begin_active_work_unit(route_key)
            work = self._work_for_update(
                layer_key=route_key,
                update=update,
            )
            if not work.advance():
                settlement.complete_active_work_unit(route_key)
                QTimer.singleShot(
                    NAPARI_SETTLEMENT_UPDATE_YIELD_MS,
                    update.retained_callback(partial(self._execute_settlement_update, settlement, route_key)),
                )
                return
        except Exception as error:
            self.server.layer_route_state.record_update_error(route_key, error)
            self._display_work_by_route.pop(route_key, None)
            logger.exception(
                "🔬 NAPARI PROCESS: Failed settlement layer work for %s",
                route_key,
            )
            settlement.fail_active(route_key)
            return
        self._display_work_by_route.pop(route_key, None)
        self.server.layer_route_state.clear_update_error(route_key)
        settlement.complete_active(route_key)
        self._schedule_next_settlement_update(settlement)

    def display_layer_batch(
        self,
        *,
        layer_key: str,
        items: list[NapariStreamLayerItem],
        display_payload: NapariPendingLayerUpdate,
        component_names_metadata: ViewerComponentNameMetadata,
    ) -> NapariLayerDisplayWork:
        if component_names_metadata:
            self.server.component_name_metadata.merge(component_names_metadata)

        if not items:
            raise ValueError(f"Napari display batch for {layer_key!r} has no items.")

        data_type = items[0].address.stream_layer_data_type
        for item in items:
            if item.address.stream_layer_data_type is not data_type:
                raise ValueError(
                    "Napari display route "
                    f"{layer_key!r} mixed data types: {data_type!r} and "
                    f"{item.address.stream_layer_data_type!r}."
                )

        aggregate_axis_bindings = NapariAggregateAxisBindingAuthority.bindings(
            items,
            display_payload,
        )
        display_layout = ViewerObjectDisplayConfigInput(
            display_payload.display_config
        ).layout().with_shared_stack_axes(tuple(
            layout
            for _route, state in self.server.layer_route_state.mounted_dimension_states()
            for layout in state.display_layouts
        ))
        projection_semantics = display_payload.for_display_layout(display_layout)
        preview_values = self.server.component_values.shared_values_for(
            display_layout.components_for_mode(ViewerComponentMode.STACK),
            replacement_route=layer_key,
            additional_component_values=display_payload.component_values(),
        )
        self.reconcile_mounted_axis_projections(
            updated_route_key=layer_key,
            viewer_component_values=preview_values,
            apply=False,
        )
        axis_projection = self.display_axis_projection(
            layer_key,
            projection_semantics,
            items,
            aggregate_axis_bindings,
            publish=False,
        )
        work = NapariLayerDisplayHandler.for_data_type(data_type).display_work(
            NapariLayerDisplayRequest(
                pipeline=self,
                items=items,
                presentation=NapariAxisPresentation(
                    entries=display_payload.entries,
                    layout=display_layout,
                    route_key=layer_key,
                    projection=axis_projection,
                    aggregate_axis_bindings=aggregate_axis_bindings,
                ),
                display_config=display_payload.display_config,
            )
        )
        logger.info(
            "🔬 NAPARI PROCESS: Prepared %d %s item(s) for layer %s",
            len(items),
            data_type.value,
            layer_key,
        )
        return work


class NapariMessageTypeBase(ABC):
    """Shared class-level registry key contract for message handlers."""

    __registry_key__ = "message_type"
    __skip_if_no_key__ = True
    message_type: ClassVar[str | None] = None


class NapariControlMessageAction(NapariMessageTypeBase, metaclass=AutoRegisterMeta):
    """Registered handler for one Napari control message type."""

    __registry__: ClassVar[dict[str, type["NapariControlMessageAction"]]] = {}

    def dispatch(self, server, message, completed, failed) -> None:
        """Default synchronous action hook on the shared reply owner."""
        completed(self.handle(server, message))

    @classmethod
    def dispatch_accepted_request(
        cls, server, request: NapariAcceptedControlRequest
    ) -> None:
        """Complete the existing socket reply queue without blocking Qt paint."""
        message_type = request.message.get(ViewerControlResponseField.TYPE.value)
        action = cls.for_message_type(
            message_type if isinstance(message_type, str) else None
        )
        completed = partial(cls._complete_control_reply, server, request.response_queue)
        try:
            action.dispatch(
                server,
                request.message,
                completed,
                partial(cls._failed_observation, server, completed),
            )
        except Exception as error:
            completed(server.control_error_response(error))

    @staticmethod
    def _complete_control_reply(server, response_queue, response) -> None:
        response_queue.put(server.serialize_control_response(response))

    @staticmethod
    def _failed_observation(server, completed, failure) -> None:
        completed(
            ViewerWindowSnapshotFailureReply.from_control_error(
                server.control_error_response(failure.error),
                failure,
            )
        )

    @classmethod
    def for_message_type(cls, message_type: str | None) -> "NapariControlMessageAction":
        if message_type in cls.__registry__:
            return cls.__registry__[message_type]()
        return NapariUnknownControlMessageAction()

    @classmethod
    def endpoint_control_capabilities(
        cls,
    ) -> frozenset[EndpointControlCapability]:
        """Derive generic endpoint lifecycle capabilities from registered actions."""

        registered_message_types = frozenset(cls.__registry__)
        return frozenset(
            capability
            for capability in EndpointControlCapability
            if capability is EndpointControlCapability.PING
            or capability.value in registered_message_types
        )

    @abstractmethod
    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        """Handle a control message and return the control reply."""

    def transport_thread_response(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object] | None:
        """Return a socket-thread-safe reply, or defer this action to Qt."""

        del server, message
        return None


class NapariShutdownControlMessageAction(NapariControlMessageAction):
    """Shared shutdown behavior for graceful and force shutdown requests."""

    message_type = None

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        del message
        logger.info("🔬 NAPARI SERVER: %s requested, closing viewer", self.message_type)
        server.request_shutdown()
        if server.viewer is not None:
            from qtpy import QtCore

            QtCore.QTimer.singleShot(100, server.viewer.close)
        return ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS,
                response_type=ResponseType.SHUTDOWN_ACK.value,
                message="Napari viewer shutting down",
            )
        ).to_wire_mapping()


class NapariGracefulShutdownControlMessageAction(NapariShutdownControlMessageAction):
    """Registered graceful shutdown action."""

    message_type = ControlMessageType.SHUTDOWN.value


class NapariForceShutdownControlMessageAction(NapariShutdownControlMessageAction):
    """Registered force shutdown action."""

    message_type = ControlMessageType.FORCE_SHUTDOWN.value


class NapariClearStateControlMessageAction(NapariControlMessageAction):
    """Registered action that clears accumulated streaming state."""

    message_type = ViewerControlMessageType.CLEAR_STATE.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        del message
        logger.info(
            "🔬 NAPARI SERVER: Clearing component groups (had %d groups)",
            len(server.component_groups),
        )
        server.clear_accumulated_stream_state()
        return ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS,
                response_type="clear_state_ack",
                message="Component groups cleared",
            )
        ).to_wire_mapping()


class NapariProcessLaunchControlMessageAction(NapariControlMessageAction):
    """Report immutable process-global settings without entering the Qt thread."""

    message_type = OpenHCSViewerControlMessageType.PROCESS_LAUNCH.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        del message
        response = ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS,
                response_type="process_launch_ack",
            )
        ).to_wire_mapping()
        response[ViewerControlField.PROCESS_LAUNCH.value] = (
            server.process_launch.to_wire_mapping()
        )
        return response

    def transport_thread_response(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        return self.handle(server, message)


class NapariSettleControlMessageAction(NapariControlMessageAction):
    """Registered action that drains queued debounced layer updates."""

    message_type = ViewerControlMessageType.SETTLE.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        del message
        unavailable = self._unavailable_response(server)
        if unavailable is not None:
            return unavailable
        return self._progress_response(
            server,
            server.display_pipeline.settlement_progress(),
        )

    def transport_thread_response(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object] | None:
        """Snapshot an existing settlement without waiting for Qt rendering."""

        del message
        unavailable = self._unavailable_response(server)
        if unavailable is not None:
            return unavailable
        progress = server.layer_route_state.existing_settlement_progress()
        if progress is None:
            return None
        return self._progress_response(server, progress)

    @staticmethod
    def _unavailable_response(
        server: "NapariViewerServer",
    ) -> dict[str, object] | None:
        if server.transport_failure is not None:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="settle_ack",
                    message=(
                        "Viewer transport failed before settlement: "
                        f"{server.transport_failure}"
                    ),
                )
            ).to_wire_mapping()
        if server.viewer is None:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="settle_ack",
                    message="Napari viewer is not available.",
                )
            ).to_wire_mapping()
        return None

    @staticmethod
    def _progress_response(
        server: "NapariViewerServer",
        progress: ViewerSettleProgress,
    ) -> dict[str, object]:
        failed = progress.phase is ViewerSettlePhase.FAILED
        failure = server.layer_route_state.update_failure_message()
        return ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                (
                    ViewerProtocolStatus.ERROR
                    if failed
                    else ViewerProtocolStatus.SUCCESS
                ),
                response_type="settle_ack",
                message=(
                    f"Viewer settlement failed: {failure}"
                    if failed
                    else (
                        "Viewer settlement progress: "
                        f"{progress.completed_update_count}/"
                        f"{progress.total_update_count}."
                    )
                ),
            ),
            fields=progress.to_wire_mapping(),
        ).to_wire_mapping()


@dataclass(frozen=True, slots=True)
class ShapeCoordinateBounds:
    """Aggregate YX coordinate bounds for Napari shape payload state."""

    min_y: float | None
    min_x: float | None
    max_y: float | None
    max_x: float | None
    coordinate_count: int = 0

    @classmethod
    def empty(cls) -> "ShapeCoordinateBounds":
        return cls(None, None, None, None, 0)

    @property
    def has_coordinates(self) -> bool:
        return self.coordinate_count > 0

    def union(self, other: "ShapeCoordinateBounds") -> "ShapeCoordinateBounds":
        if not self.has_coordinates:
            return other
        if not other.has_coordinates:
            return self
        return type(self)(
            min_y=min(float(self.min_y), float(other.min_y)),
            min_x=min(float(self.min_x), float(other.min_x)),
            max_y=max(float(self.max_y), float(other.max_y)),
            max_x=max(float(self.max_x), float(other.max_x)),
            coordinate_count=self.coordinate_count + other.coordinate_count,
        )

    def outside_source_shape(self, source_shape_yx: tuple[int, int]) -> bool:
        if not self.has_coordinates:
            return False
        height, width = source_shape_yx
        # Mask-derived Napari polygons can trace image pixel edges at +/-0.5.
        min_y = -0.5
        min_x = -0.5
        max_y = height - 0.5
        max_x = width - 0.5
        return (
            float(self.min_y) < min_y
            or float(self.min_x) < min_x
            or float(self.max_y) > max_y
            or float(self.max_x) > max_x
        )

    def to_wire_mapping(self) -> dict[str, NapariWireValue]:
        if not self.has_coordinates:
            return {}
        return {
            "min_yx": (float(self.min_y), float(self.min_x)),
            "max_yx": (float(self.max_y), float(self.max_x)),
            "coordinate_count": self.coordinate_count,
        }

    @classmethod
    def from_shape_payload(
        cls,
        payload: Mapping[str, NapariWireValue],
    ) -> "ShapeCoordinateBounds | None":
        coordinates = payload.get(NapariWireField.COORDINATES.value)
        if coordinates is not None:
            return cls.from_yx_coordinates(coordinates)
        center = payload.get(NapariWireField.CENTER.value)
        radii = payload.get(NapariWireField.RADII.value)
        if center is not None and radii is not None:
            return cls.from_center_radii(center, radii)
        return None

    @classmethod
    def from_yx_coordinates(
        cls,
        coordinates: NapariWireValue,
    ) -> "ShapeCoordinateBounds | None":
        array = np.asarray(coordinates, dtype=float)
        if array.ndim == 1 and array.size == 2:
            array = array.reshape(1, 2)
        if array.ndim < 2 or array.shape[-1] != 2:
            return None
        points = array.reshape(-1, 2)
        return cls.from_points(points)

    @classmethod
    def from_center_radii(
        cls,
        center: NapariWireValue,
        radii: NapariWireValue,
    ) -> "ShapeCoordinateBounds | None":
        center_array = np.asarray(center, dtype=float)
        radii_array = np.asarray(radii, dtype=float)
        if center_array.shape != (2,) or radii_array.shape != (2,):
            return None
        y, x = center_array
        radius_y, radius_x = radii_array
        return cls(
            min_y=float(y - radius_y),
            min_x=float(x - radius_x),
            max_y=float(y + radius_y),
            max_x=float(x + radius_x),
            coordinate_count=4,
        )

    @classmethod
    def from_points(cls, points: np.ndarray) -> "ShapeCoordinateBounds":
        return cls(
            min_y=float(points[:, 0].min()),
            min_x=float(points[:, 1].min()),
            max_y=float(points[:, 0].max()),
            max_x=float(points[:, 1].max()),
            coordinate_count=int(points.shape[0]),
        )


@dataclass(frozen=True, slots=True)
class NapariResultElementSelectionState:
    """Observed native feature-row selection for one mounted Napari layer."""

    supported: bool
    feature_row_count: int = 0
    selected_data_indices: tuple[int, ...] = ()


@dataclass(frozen=True, slots=True)
class NapariResultSelectionGroupBinding:
    """Bind native feature rows to one declared cross-layer object subject."""

    subject_token: object
    id_feature: str

    def __post_init__(self) -> None:
        if not self.id_feature:
            raise ValueError(
                "NapariResultSelectionGroupBinding.id_feature cannot be empty."
            )


@dataclass(frozen=True, slots=True)
class NapariResultSelectionGroupState:
    """One object subject represented by one or more native feature rows."""

    subject_token: object
    subject_id: object
    member_indices: tuple[int, ...]


@dataclass(frozen=True, slots=True)
class NapariResultSelectionGroupIndex:
    """Runtime-derived member lookup for one declared object subject."""

    binding: NapariResultSelectionGroupBinding
    subject_ids_by_index: tuple[Hashable, ...]
    member_indices_by_subject_id: Mapping[Hashable, tuple[int, ...]]

    def state(self, data_index: int) -> NapariResultSelectionGroupState:
        """Resolve one feature row without rescanning mounted layer features."""

        if data_index < 0 or data_index >= len(self.subject_ids_by_index):
            raise ValueError(
                f"Result group data index {data_index} is outside "
                f"{len(self.subject_ids_by_index)} row(s)."
            )
        subject_id = self.subject_ids_by_index[data_index]
        return NapariResultSelectionGroupState(
            subject_token=self.binding.subject_token,
            subject_id=subject_id,
            member_indices=self.member_indices_by_subject_id[subject_id],
        )

    def members_for(self, subject_id: object) -> tuple[int, ...]:
        """Return members for one compatible cross-layer subject identifier."""

        if not isinstance(subject_id, Hashable):
            return ()
        return self.member_indices_by_subject_id.get(subject_id, ())


class NapariResultSelectionGroupAuthority:
    """Resolve object-owned ROI groups from framework-declared feature metadata."""

    @staticmethod
    def feature_values(
        layer: NapariLayerHandle,
        feature_name: str,
    ) -> tuple[object, ...] | None:
        try:
            values = cast(Mapping[str, Sequence[object]], layer.features)[feature_name]
        except (KeyError, TypeError):
            metadata = cast(NapariShapesLayerHandle, layer).metadata
            metadata_values = metadata.get(feature_name)
            if (
                metadata_values is None
                or isinstance(metadata_values, (str, bytes))
                or not isinstance(metadata_values, Sequence)
            ):
                return None
            values = metadata_values
        return tuple(
            value.item() if isinstance(value, np.generic) else value for value in values
        )

    @classmethod
    def declared_binding(
        cls,
        layer: NapariLayerHandle,
    ) -> NapariResultSelectionGroupBinding | None:
        layer_metadata = cast(NapariShapesLayerHandle, layer).metadata
        metadata_subject = layer_metadata.get(
            ObjectArtifactSubjectBinding.SUBJECT_FEATURE
        )
        metadata_ids = cls.feature_values(
            layer,
            ObjectArtifactSubjectBinding.SUBJECT_ID_FEATURE,
        )
        if metadata_subject is not None or metadata_ids is not None:
            if metadata_subject is None or metadata_ids is None:
                raise ValueError(
                    "OpenHCS result layer metadata requires both subject and ID values."
                )
            if len(metadata_ids) != len(layer.features):
                raise ValueError(
                    "OpenHCS result layer subject IDs do not align with feature rows."
                )
            return NapariResultSelectionGroupBinding(
                subject_token=metadata_subject,
                id_feature=ObjectArtifactSubjectBinding.SUBJECT_ID_FEATURE,
            )

        return None

    @classmethod
    def index(
        cls,
        layer: NapariLayerHandle,
        binding: NapariResultSelectionGroupBinding,
    ) -> NapariResultSelectionGroupIndex:
        """Derive the immutable row-to-subject lookup when a layer is mounted."""

        values = cls.feature_values(layer, binding.id_feature)
        if values is None:
            raise ValueError(
                f"Bound result group feature {binding.id_feature!r} is absent."
            )
        members_by_subject_id: dict[Hashable, list[int]] = {}
        subject_ids: list[Hashable] = []
        for data_index, subject_id in enumerate(values):
            if not isinstance(subject_id, Hashable):
                raise TypeError(
                    "OpenHCS result group subject IDs must be hashable; "
                    f"row {data_index} carried {type(subject_id).__name__}."
                )
            subject_ids.append(subject_id)
            members_by_subject_id.setdefault(subject_id, []).append(data_index)
        return NapariResultSelectionGroupIndex(
            binding=binding,
            subject_ids_by_index=tuple(subject_ids),
            member_indices_by_subject_id=MappingProxyType(
                {
                    subject_id: tuple(indices)
                    for subject_id, indices in members_by_subject_id.items()
                }
            ),
        )


class NapariResultElementSelectionAuthority:
    """Own native feature-row selection without layer-kind or assay dispatch."""

    @classmethod
    def state(
        cls,
        layer: NapariLayerHandle | None,
    ) -> NapariResultElementSelectionState:
        if layer is None:
            return NapariResultElementSelectionState(supported=False)
        selectable_layer = cast(NapariShapesLayerHandle, layer)
        try:
            feature_row_count = len(selectable_layer.features)
            native_selected_data = tuple(selectable_layer.selected_data)
        except AttributeError:
            return NapariResultElementSelectionState(supported=False)
        if feature_row_count < 0:
            raise ValueError("Napari feature row count must be nonnegative.")
        selected_data_indices: list[int] = []
        for index in native_selected_data:
            if isinstance(index, bool) or not isinstance(index, Integral) or index < 0:
                raise TypeError(
                    "Napari selected_data must contain nonnegative integer indices."
                )
            selected_data_indices.append(int(index))
        return NapariResultElementSelectionState(
            supported=True,
            feature_row_count=feature_row_count,
            selected_data_indices=tuple(sorted(selected_data_indices)),
        )

    @classmethod
    def require_data_index(
        cls,
        layer: NapariLayerHandle,
        data_index: int,
    ) -> NapariResultElementSelectionState:
        state = cls.state(layer)
        if not state.supported:
            raise ValueError(
                "Target layer does not support native feature-bearing data selection."
            )
        if data_index >= state.feature_row_count:
            raise ValueError(
                f"Viewer data_index {data_index} is outside "
                f"{state.feature_row_count} populated feature row(s)."
            )
        return state

    @classmethod
    def select(
        cls,
        layer: NapariLayerHandle,
        data_index: int,
    ) -> NapariResultElementSelectionState:
        return cls.select_indices(layer, (data_index,))

    @classmethod
    def select_indices(
        cls,
        layer: NapariLayerHandle,
        data_indices: Iterable[int],
    ) -> NapariResultElementSelectionState:
        """Select one exact, validated set of native feature rows."""

        indices = tuple(sorted(set(data_indices)))
        if not indices:
            raise ValueError("Napari result selection must contain at least one row.")
        for data_index in indices:
            if isinstance(data_index, bool) or not isinstance(data_index, Integral):
                raise TypeError("Napari result selection indices must be integers.")
            cls.require_data_index(layer, int(data_index))
        selectable_layer = cast(NapariShapesLayerHandle, layer)
        selectable_layer.selected_data = set(indices)
        observed = cls.state(layer)
        if observed.selected_data_indices != indices:
            raise RuntimeError(
                "Napari did not retain the requested native data selection."
            )
        return observed


class NapariResultSelectionController:
    """Turn native result selection into an unambiguous visible viewer state."""

    def __init__(self, server: "NapariViewerServer") -> None:
        self.server = server
        self._callbacks: weakref.WeakKeyDictionary[
            object,
            Callable[[object], None],
        ] = weakref.WeakKeyDictionary()
        self._observed_indices: weakref.WeakKeyDictionary[
            object,
            tuple[int, ...],
        ] = weakref.WeakKeyDictionary()
        self._group_indices: weakref.WeakKeyDictionary[
            object,
            NapariResultSelectionGroupIndex,
        ] = weakref.WeakKeyDictionary()
        self._selection_observers: list[Callable[[], None]] = []
        self._pending_generation = 0
        self._refreshing_highlights = False
        self._synchronizing_group_selection = False
        self.ensure_default_highlight_thickness()
        self.ensure_default_highlight_color()

    @contextmanager
    def preserve_selection(
        self,
        route_key: str,
    ):
        """Retain source members across remounts without replaying navigation.

        Selection is translated through native features derived by the original
        source payload builder. There is no persistent row roster, coordinate
        matching, or assumption that an old table index still names that member.
        """
        layer = self.server.layer_route_state.layer(route_key)
        state = NapariResultElementSelectionAuthority.state(layer)
        identities = self._element_identities(layer, state)
        selected = frozenset(identities[index] for index in state.selected_data_indices)
        binding = self._group_indices.get(layer)
        bound = self.is_bound_result_layer(layer)
        synchronizing = self._synchronizing_group_selection
        self._synchronizing_group_selection = True
        self._pending_generation += 1
        try:
            yield
            target = self.server.layer_route_state.layer(route_key)
            target_state = NapariResultElementSelectionAuthority.state(target)
            target_identities = self._element_identities(target, target_state)
            indices = tuple(
                index for index, identity in enumerate(target_identities)
                if identity in selected
            )
            if bound:
                if layer is not target:
                    cast(NapariShapesLayerHandle, layer).events.highlight.disconnect(
                        self._callbacks.pop(layer)
                    )
                    self._observed_indices.pop(layer, None)
                    self._group_indices.pop(layer, None)
                self.bind(target, binding.binding if binding is not None else None)
            cast(NapariShapesLayerHandle, target).selected_data = set(indices)
            observed = NapariResultElementSelectionAuthority.state(target)
            if observed.selected_data_indices != indices:
                raise RuntimeError("Napari did not retain rematerialized member selection.")
            if bound:
                self._observed_indices[target] = indices
        finally:
            self._synchronizing_group_selection = synchronizing
        self._notify_selection_observers()

    @staticmethod
    def _element_identities(
        layer: NapariLayerHandle,
        state: NapariResultElementSelectionState,
    ) -> tuple[object, ...]:
        if state.feature_row_count == 0:
            return ()
        identities = NapariResultSelectionGroupAuthority.feature_values(
            layer, NapariStreamLayerItem.ELEMENT_IDENTITY_FEATURE,
        )
        if identities is None or len(identities) != state.feature_row_count:
            raise ValueError("Selectable stream rows require source element identities.")
        if len(set(identities)) != len(identities):
            raise ValueError("Selectable stream source element identities must be unique.")
        return identities

    def select(
        self,
        layer: NapariLayerHandle,
        data_index: int,
    ) -> NapariResultElementSelectionState:
        """Select exactly the bound object members and verify native readback."""
        NapariResultElementSelectionAuthority.require_data_index(layer, data_index)
        linked = self._synchronize_linked_group(layer, data_index)
        for candidate, member_indices in linked:
            observed = NapariResultElementSelectionAuthority.state(candidate)
            if observed.selected_data_indices != member_indices:
                raise RuntimeError(
                    "Napari did not retain the canonical linked result selection."
                )
        return NapariResultElementSelectionAuthority.state(layer)

    @staticmethod
    def _highlight_settings():
        """Return Napari's native, Preferences-backed highlight authority."""

        from napari.settings import get_settings

        return get_settings().appearance.highlight

    def ensure_default_highlight_thickness(self) -> int:
        """Replace Napari's nearly invisible stock width while preserving choices."""

        settings = self._highlight_settings()
        if settings.highlight_thickness == 1:
            settings.highlight_thickness = _DEFAULT_RESULT_SELECTION_HIGHLIGHT_THICKNESS
        return int(settings.highlight_thickness)

    def ensure_default_highlight_color(self) -> tuple[float, float, float, float]:
        """Replace Napari's stock cyan when it would blend into result layers."""

        settings = self._highlight_settings()
        color = tuple(float(component) for component in settings.highlight_color)
        if color == _NAPARI_STOCK_HIGHLIGHT_COLOR:
            settings.highlight_color = list(_DEFAULT_RESULT_SELECTION_HIGHLIGHT_COLOR)
            color = _DEFAULT_RESULT_SELECTION_HIGHLIGHT_COLOR
        return cast(tuple[float, float, float, float], color)

    def set_highlight_thickness(self, thickness: int) -> None:
        """Set the native selected-outline width and redraw current selections."""

        if isinstance(thickness, bool) or not isinstance(thickness, int):
            raise TypeError("Napari result highlight thickness must be an integer.")
        if thickness < 1 or thickness > 10:
            raise ValueError(
                "Napari result highlight thickness must be between 1 and 10."
            )
        settings = self._highlight_settings()
        settings.highlight_thickness = thickness
        self.refresh_highlights()

    def set_highlight_color(self, color: Sequence[float]) -> None:
        """Set the native selected-outline color and redraw current selections."""

        rgba = self._normalize_rgba(color, context="result highlight")
        settings = self._highlight_settings()
        settings.highlight_color = list(rgba)
        self.refresh_highlights()

    @staticmethod
    def _normalize_rgba(
        color: Sequence[float],
        *,
        context: str,
    ) -> tuple[float, float, float, float]:
        if isinstance(color, (str, bytes)) or len(color) != 4:
            raise ValueError(f"Napari {context} color must contain RGBA values.")
        rgba = tuple(float(component) for component in color)
        if any(
            not np.isfinite(component) or component < 0 or component > 1
            for component in rgba
        ):
            raise ValueError(
                f"Napari {context} RGBA values must be finite and between 0 and 1."
            )
        return cast(tuple[float, float, float, float], rgba)

    def is_bound_result_layer(self, layer: object) -> bool:
        """Return whether a native layer owns OpenHCS result selection."""

        return layer in self._callbacks

    def result_layer_color(
        self,
        layer: NapariLayerHandle,
    ) -> tuple[float, float, float, float]:
        """Return the first native edge color for a bound result layer."""

        if not self.is_bound_result_layer(layer):
            raise ValueError("Target layer is not a bound OpenHCS result layer.")
        colors = np.asarray(
            cast(NapariShapesLayerHandle, layer).edge_color,
            dtype=float,
        )
        if colors.ndim == 1:
            color = colors
        elif colors.ndim == 2 and len(colors):
            color = colors[0]
        else:
            raise ValueError("Bound OpenHCS result layer has no native edge color.")
        return self._normalize_rgba(color, context="result layer")

    def set_result_layer_color(
        self,
        layer: NapariLayerHandle,
        color: Sequence[float],
    ) -> None:
        """Apply one native edge color to every ROI in a bound result layer."""

        if not self.is_bound_result_layer(layer):
            raise ValueError("Target layer is not a bound OpenHCS result layer.")
        rgba = self._normalize_rgba(color, context="result layer")
        cast(NapariShapesLayerHandle, layer).edge_color = list(rgba)
        self._notify_selection_observers()

    def result_group_color(
        self,
        layer: NapariLayerHandle,
    ) -> tuple[float, float, float, float]:
        """Return the native edge color for the selected object-owned ROI group."""

        state = NapariResultElementSelectionAuthority.state(layer)
        if not state.selected_data_indices:
            raise ValueError("Bound OpenHCS result layer has no selected ROI group.")
        colors = np.asarray(
            cast(NapariShapesLayerHandle, layer).edge_color,
            dtype=float,
        )
        if colors.ndim == 1:
            color = colors
        elif colors.ndim == 2 and len(colors):
            color = colors[state.selected_data_indices[0]]
        else:
            raise ValueError("Bound OpenHCS result layer has no native edge color.")
        return self._normalize_rgba(color, context="result group")

    def set_result_group_color(
        self,
        layer: NapariLayerHandle,
        color: Sequence[float],
    ) -> None:
        """Recolor every native ROI member of the selected object subject."""

        state = NapariResultElementSelectionAuthority.state(layer)
        if not state.selected_data_indices:
            raise ValueError("Bound OpenHCS result layer has no selected ROI group.")
        rgba = self._normalize_rgba(color, context="result group")
        linked = self._linked_group_members(layer, state.selected_data_indices[0])
        for candidate, member_indices in linked:
            candidate_state = NapariResultElementSelectionAuthority.state(candidate)
            result_layer = cast(NapariShapesLayerHandle, candidate)
            colors = np.asarray(result_layer.edge_color, dtype=float)
            if colors.ndim == 1:
                colors = np.broadcast_to(
                    colors,
                    (candidate_state.feature_row_count, 4),
                ).copy()
            elif colors.ndim == 2 and len(colors) == candidate_state.feature_row_count:
                colors = colors.copy()
            else:
                raise ValueError(
                    "Bound OpenHCS result layer edge colors do not align with features."
                )
            colors[np.asarray(member_indices, dtype=int)] = rgba
            result_layer.edge_color = colors
        self._notify_selection_observers()

    def connect_selection_observer(self, callback: Callable[[], None]) -> None:
        """Observe native group selection or result color changes."""

        self._selection_observers.append(callback)

    def _notify_selection_observers(self) -> None:
        for callback in tuple(self._selection_observers):
            callback()

    def refresh_highlights(self) -> None:
        """Redraw selected native layers without scheduling navigation again."""

        self._refreshing_highlights = True
        try:
            for layer in tuple(self._callbacks):
                state = NapariResultElementSelectionAuthority.state(
                    cast(NapariLayerHandle, layer)
                )
                if state.selected_data_indices:
                    cast(NapariShapesLayerHandle, layer).events.highlight()
        finally:
            self._refreshing_highlights = False

    def bind(
        self,
        layer: NapariLayerHandle,
        group_binding: NapariResultSelectionGroupBinding | None = None,
    ) -> None:
        """Refresh derived group lookup and bind native selection exactly once."""

        result_layer = cast(NapariShapesLayerHandle, layer)
        NapariResultElementSelectionAuthority.state(layer)
        resolved_group_binding = (
            group_binding
            if group_binding is not None
            else NapariResultSelectionGroupAuthority.declared_binding(layer)
        )
        if resolved_group_binding is None:
            self._group_indices.pop(layer, None)
        else:
            self._group_indices[layer] = NapariResultSelectionGroupAuthority.index(
                layer,
                resolved_group_binding,
            )
        if layer in self._callbacks:
            return
        layer_reference = weakref.ref(layer)

        def on_highlight(_event: object = None) -> None:
            bound_layer = layer_reference()
            if bound_layer is None or self._refreshing_highlights:
                return
            self._queue_selection(cast(NapariLayerHandle, bound_layer))

        result_layer.events.highlight.connect(on_highlight)
        self._callbacks[layer] = on_highlight
        self._observed_indices[layer] = NapariResultElementSelectionAuthority.state(
            layer
        ).selected_data_indices

    def _queue_selection(self, layer: NapariLayerHandle) -> None:
        if self._synchronizing_group_selection:
            return
        state = NapariResultElementSelectionAuthority.state(layer)
        previous_indices = self._observed_indices.get(layer, ())
        self._observed_indices[layer] = state.selected_data_indices
        if state.selected_data_indices == previous_indices:
            # Shapes highlight events also report redraws, layer activation,
            # and other presentation changes. Replaying an unchanged result
            # selection here steals focus and can make another layer impossible
            # to select.
            return
        self._pending_generation += 1
        generation = self._pending_generation
        if not state.selected_data_indices:
            self._notify_selection_observers()
            return
        newly_selected = tuple(
            index
            for index in state.selected_data_indices
            if index not in previous_indices
        )
        data_index = (
            newly_selected[-1] if newly_selected else state.selected_data_indices[-1]
        )
        self._synchronize_linked_group(layer, data_index)
        layer_reference = weakref.ref(layer)
        QTimer.singleShot(
            0,
            lambda: self._apply_selection(
                layer_reference,
                data_index,
                generation,
            ),
        )

    def _linked_group_members(
        self,
        layer: NapariLayerHandle,
        data_index: int,
    ) -> tuple[tuple[NapariLayerHandle, tuple[int, ...]], ...]:
        source_index = self._group_indices.get(layer)
        if source_index is None:
            return ((layer, (data_index,)),)
        source_group = source_index.state(data_index)
        linked: list[tuple[NapariLayerHandle, tuple[int, ...]]] = []
        for candidate, candidate_index in tuple(self._group_indices.items()):
            if candidate_index.binding.subject_token != source_group.subject_token:
                continue
            member_indices = candidate_index.members_for(source_group.subject_id)
            if member_indices:
                linked.append((cast(NapariLayerHandle, candidate), member_indices))
        return tuple(linked) or ((layer, source_group.member_indices),)

    def _synchronize_linked_group(
        self,
        layer: NapariLayerHandle,
        data_index: int,
    ) -> tuple[tuple[NapariLayerHandle, tuple[int, ...]], ...]:
        linked = self._linked_group_members(layer, data_index)
        self._synchronizing_group_selection = True
        try:
            for candidate, member_indices in linked:
                cast(NapariShapesLayerHandle, candidate).selected_data = set(
                    member_indices
                )
                self._observed_indices[candidate] = member_indices
        finally:
            self._synchronizing_group_selection = False
        self._notify_selection_observers()
        return linked

    def select_result_element(
        self,
        layer: NapariLayerHandle,
        data_index: int,
    ) -> tuple[tuple[NapariLayerHandle, tuple[int, ...]], ...]:
        """Select the complete declared result subject containing one row."""

        NapariResultElementSelectionAuthority.require_data_index(layer, data_index)
        return self._synchronize_linked_group(layer, data_index)

    def _apply_selection(
        self,
        layer_reference: weakref.ReferenceType[object],
        data_index: int,
        generation: int,
    ) -> None:
        if generation != self._pending_generation:
            return
        layer = layer_reference()
        if layer is None or layer not in self.server.viewer.layers:
            return
        native_layer = cast(NapariLayerHandle, layer)
        state = NapariResultElementSelectionAuthority.state(native_layer)
        if data_index not in state.selected_data_indices:
            return

        result_layer = cast(NapariShapesLayerHandle, layer)
        result_layer.visible = True
        layer_selection = self.server.viewer.layers.selection
        if layer not in layer_selection or len(layer_selection) <= 1:
            # Napari defines ``active`` as "select only". Preserve an existing
            # multi-layer selection so its combined native Features Table does
            # not collapse after every row click.
            layer_selection.active = layer

        route_key = self.server.layer_route_state.route_for_layer(native_layer)
        if route_key is None:
            logger.warning(
                "Selected Napari result layer is mounted without an OpenHCS route."
            )
            return
        try:
            navigation = NapariNavigationControlMessageAction()
            axis_indices = navigation.result_element_axis_indices(
                self.server,
                native_layer,
                route_key,
                data_index,
            )
            self._refreshing_highlights = True
            try:
                if axis_indices:
                    viewer_step = navigation.axis_step(
                        self.server,
                        native_layer,
                        ViewerNavigationControlOptions.from_overrides(
                            route_key=route_key,
                            axis_indices=axis_indices,
                        ),
                    )
                    self.server.viewer.dims.current_step = viewer_step
            finally:
                # Napari clears Shapes.selected_data when a dims change slices the
                # selected geometry out of view. Re-assert the same authoritative
                # member even if navigation fails so a UI interaction cannot erase
                # an otherwise valid native selection.
                try:
                    self._synchronize_linked_group(native_layer, data_index)
                finally:
                    self._refreshing_highlights = False
        except Exception:
            logger.exception(
                "Failed to navigate to selected Napari result element %d on %s",
                data_index,
                route_key,
            )


def _install_result_selection_toolbar(
    result_selection_dock: QDockWidget,
    controller: NapariResultSelectionController,
):
    """Expose native selection thickness beside the result-table workflow."""

    from qtpy.QtGui import QColor
    from qtpy.QtWidgets import QColorDialog, QLabel, QPushButton, QSpinBox, QToolBar

    qt_window = result_selection_dock.window()
    toolbar = QToolBar("OpenHCS ROI selection", qt_window)
    toolbar.setObjectName("openhcs_roi_selection_toolbar")
    label = QLabel("Selected ROI outline:", toolbar)
    thickness = QSpinBox(toolbar)
    thickness.setObjectName("openhcs_roi_highlight_thickness")
    thickness.setRange(1, 10)
    thickness.setSuffix(" px")
    thickness.setToolTip(
        "Width of Napari's native selected-ROI outline. Color remains available "
        "under Napari Preferences > Appearance > Highlight."
    )
    thickness.setValue(controller.ensure_default_highlight_thickness())
    thickness.valueChanged.connect(controller.set_highlight_thickness)
    highlight_settings = controller._highlight_settings()
    color_button = QPushButton("Selection color", toolbar)
    color_button.setObjectName("openhcs_roi_highlight_color")
    layer_color_button = QPushButton("ROI layer color", toolbar)
    layer_color_button.setObjectName("openhcs_roi_layer_color")
    group_color_button = QPushButton("ROI group color", toolbar)
    group_color_button.setObjectName("openhcs_roi_group_color")

    def sync_from_preferences(_event: object = None) -> None:
        thickness.setValue(int(highlight_settings.highlight_thickness))

    def sync_color_from_preferences(_event: object = None) -> None:
        rgba = tuple(float(value) for value in highlight_settings.highlight_color)
        color = QColor.fromRgbF(*rgba)
        foreground = "#000000" if color.lightnessF() > 0.55 else "#ffffff"
        color_button.setStyleSheet(
            "QPushButton { "
            f"background-color: {color.name()}; color: {foreground}; "
            "padding-left: 8px; padding-right: 8px; }"
        )
        color_button.setToolTip(
            f"Selected ROI outline color ({color.name()}). Also synchronized "
            "with Napari Preferences > Appearance > Highlight."
        )

    def active_result_layer() -> NapariLayerHandle | None:
        viewer = controller.server.viewer
        if viewer is None:
            return None
        layer = viewer.layers.selection.active
        if layer is None or not controller.is_bound_result_layer(layer):
            return None
        return layer

    def sync_layer_color(_event: object = None) -> None:
        layer = active_result_layer()
        layer_color_button.setEnabled(layer is not None)
        if layer is None:
            layer_color_button.setStyleSheet("")
            layer_color_button.setToolTip(
                "Select one OpenHCS ROI layer to recolor every ROI in that layer."
            )
            return
        rgba = controller.result_layer_color(layer)
        color = QColor.fromRgbF(*rgba)
        foreground = "#000000" if color.lightnessF() > 0.55 else "#ffffff"
        layer_color_button.setStyleSheet(
            "QPushButton { "
            f"background-color: {color.name()}; color: {foreground}; "
            "padding-left: 8px; padding-right: 8px; }"
        )
        layer_color_button.setToolTip(
            "Apply one edge color to every ROI in the active OpenHCS result layer."
        )

    def sync_group_color(_event: object = None) -> None:
        layer = active_result_layer()
        state = NapariResultElementSelectionAuthority.state(layer)
        has_group = layer is not None and bool(state.selected_data_indices)
        group_color_button.setEnabled(has_group)
        if layer is None or not has_group:
            group_color_button.setStyleSheet("")
            group_color_button.setToolTip(
                "Select one ROI to recolor every ROI member of its declared object group."
            )
            return
        rgba = controller.result_group_color(layer)
        color = QColor.fromRgbF(*rgba)
        foreground = "#000000" if color.lightnessF() > 0.55 else "#ffffff"
        group_color_button.setStyleSheet(
            "QPushButton { "
            f"background-color: {color.name()}; color: {foreground}; "
            "padding-left: 8px; padding-right: 8px; }"
        )
        group_color_button.setToolTip(
            "Recolor the selected object group while preserving other ROI groups."
        )

    def choose_color() -> None:
        initial = QColor.fromRgbF(
            *(float(value) for value in highlight_settings.highlight_color)
        )
        chosen = QColorDialog.getColor(
            initial,
            qt_window,
            "Selected ROI outline color",
        )
        if chosen.isValid():
            controller.set_highlight_color(
                (chosen.redF(), chosen.greenF(), chosen.blueF(), 1.0)
            )

    def choose_layer_color() -> None:
        layer = active_result_layer()
        if layer is None:
            sync_layer_color()
            return
        initial = QColor.fromRgbF(*controller.result_layer_color(layer))
        chosen = QColorDialog.getColor(
            initial,
            qt_window,
            "ROI layer color",
        )
        if chosen.isValid():
            controller.set_result_layer_color(
                layer,
                (chosen.redF(), chosen.greenF(), chosen.blueF(), 1.0),
            )
            sync_layer_color()

    def choose_group_color() -> None:
        layer = active_result_layer()
        if layer is None:
            sync_group_color()
            return
        state = NapariResultElementSelectionAuthority.state(layer)
        if not state.selected_data_indices:
            sync_group_color()
            return
        initial = QColor.fromRgbF(*controller.result_group_color(layer))
        chosen = QColorDialog.getColor(
            initial,
            qt_window,
            "ROI group color",
        )
        if chosen.isValid():
            controller.set_result_group_color(
                layer,
                (chosen.redF(), chosen.greenF(), chosen.blueF(), 1.0),
            )
            sync_group_color()

    highlight_settings.events.highlight_thickness.connect(sync_from_preferences)
    highlight_settings.events.highlight_color.connect(sync_color_from_preferences)
    color_button.clicked.connect(choose_color)
    layer_color_button.clicked.connect(choose_layer_color)
    group_color_button.clicked.connect(choose_group_color)
    controller.connect_selection_observer(sync_group_color)
    if controller.server.viewer is not None:
        controller.server.viewer.layers.selection.events.active.connect(
            sync_layer_color
        )
        controller.server.viewer.layers.selection.events.active.connect(
            sync_group_color
        )
    toolbar.addWidget(label)
    toolbar.addWidget(thickness)
    toolbar.addWidget(color_button)
    toolbar.addWidget(group_color_button)
    toolbar.addWidget(layer_color_button)
    sync_color_from_preferences()
    sync_layer_color()
    sync_group_color()
    qt_window.addToolBar(Qt.ToolBarArea.BottomToolBarArea, toolbar)
    return toolbar


@dataclass(frozen=True, slots=True)
class NapariViewerProjectionABC(ABC, Generic[NapariViewerProjectionRequestT]):
    """Shared projection of live Napari route and component stores."""

    MAX_NONZERO_COORDINATE_PROJECTION_COUNT: ClassVar[int] = 65_536
    MAX_NONZERO_EXAMPLE_COORDINATE_COUNT: ClassVar[int] = 16
    payload_summary_type: ClassVar[type[ViewerPayloadSummary]] = ViewerPayloadSummary
    payload_record_type: ClassVar[type[ViewerPayloadRecord]] = ViewerPayloadRecord

    server: "NapariViewerServer"
    viewer: NapariViewerLayerCreator
    request: NapariViewerProjectionRequestT

    def wire_envelope(
        self,
        *,
        response_type: str,
        layers: tuple[dict[str, NapariWireValue], ...],
    ) -> dict[str, NapariWireValue]:
        viewport_control = NapariNativeViewportPresentation.for_viewer(self.viewer)
        return {
            ViewerControlResponseField.TYPE.value: response_type,
            ViewerControlResponseField.STATUS.value: _ACK_SUCCESS,
            ViewerControlField.VIEWER.value: {
                ViewerDescriptorField.TYPE.value: ViewerType.NAPARI.wire_value,
                ViewerDescriptorField.TITLE.value: self.server.napari_window_title,
            },
            ViewerControlField.LAYER_COUNT.value: len(layers),
            ViewerControlField.LAYERS.value: layers,
            ViewerControlField.NATIVE_VIEWPORT.value: (
                viewport_control.snapshot().to_wire_mapping()
                if viewport_control is not None
                else None
            ),
        }

    def route_keys(self) -> tuple[str, ...]:
        route_keys = tuple(
            dict.fromkeys(
                (
                    *self.server.layer_route_state.layer_titles,
                    *self.server.component_groups.groups,
                )
            )
        )
        route_key = self._route_key_filter()
        if route_key is None:
            return route_keys
        return tuple(candidate for candidate in route_keys if candidate == route_key)

    def layer_state_for(self, route_key: str) -> dict[str, NapariWireValue]:
        dimension_state = self.server.layer_route_state.dimension_state_for(route_key)
        items = self.server.component_groups.existing_items_for(route_key)
        layer = self.mounted_layer(route_key)
        native_transform = self.layer_native_transform(layer)
        intensity_control = NapariNativeImageIntensityPresentation.for_layer(layer)
        native_intensity = (
            intensity_control.snapshot() if intensity_control is not None else None
        )
        if items is None:
            item_tuple: tuple[NapariStreamLayerItem, ...] = ()
        else:
            item_tuple = tuple(items)
        layer_visible = False
        layer_selected = False
        if layer is not None:
            layer_visible = bool(layer.visible)
            layer_selected = layer is self.viewer.layers.selection.active
        result_selection = NapariResultElementSelectionAuthority.state(layer)
        component_values = self.component_values_for(dimension_state, item_tuple)
        payload_summaries = self.payload_summaries_for(dimension_state, item_tuple)
        producer_identities = tuple(
            sorted(
                self.server.component_groups.producer_identities_for(route_key),
                key=lambda producer: producer.output_key,
            )
        )
        return {
            ViewerLayerField.ROUTE_KEY.value: route_key,
            ViewerLayerField.PRODUCER_IDENTITIES.value: tuple(
                producer.to_payload() for producer in producer_identities
            ),
            ViewerLayerField.TITLE.value: self.layer_title(route_key),
            ViewerLayerField.MOUNTED.value: layer is not None,
            ViewerLayerField.ITEM_COUNT.value: len(item_tuple),
            ViewerLayerField.DATA_TYPES.value: tuple(
                dict.fromkeys(
                    item.address.stream_layer_data_type.value for item in item_tuple
                )
            ),
            ViewerLayerField.COMPONENT_VALUES.value: component_values,
            ViewerLayerField.COMPONENT_VALUE_COUNT.value: len(item_tuple),
            ViewerLayerField.COMPONENT_VALUES_TRUNCATED.value: (
                len(component_values) < len(item_tuple)
            ),
            ViewerLayerField.PAYLOAD_SUMMARIES.value: payload_summaries,
            ViewerLayerField.PAYLOAD_SUMMARY_COUNT.value: len(item_tuple),
            ViewerLayerField.PAYLOAD_SUMMARIES_TRUNCATED.value: (
                len(payload_summaries) < len(item_tuple)
            ),
            ViewerLayerField.AXIS_LABELS.value: dimension_state.axis_labels,
            ViewerLayerField.STACK_AXES.value: dimension_state.stack_axes,
            ViewerLayerField.AXIS_OFFSETS.value: dimension_state.axis_offsets,
            ViewerLayerField.SCALAR_LABELS.value: dimension_state.scalar_labels,
            ViewerLayerField.LABELS.value: dimension_state.labels,
            ViewerLayerField.AXIS_COMPONENT_VALUES.value: self.axis_component_values(
                dimension_state
            ),
            ViewerLayerField.ROUTED_COMPONENT_VALUES.value: (
                self.routed_component_values(dimension_state)
            ),
            ViewerLayerField.ROUTED_COMPONENT_COORDINATES.value: (
                self.routed_component_coordinates(dimension_state)
            ),
            ViewerLayerField.DATA_SHAPE.value: self.layer_data_shape(layer),
            ViewerLayerField.NATIVE_TRANSFORM.value: native_transform.to_wire_mapping(),
            ViewerLayerField.NATIVE_INTENSITY.value: (
                native_intensity.to_wire_mapping()
                if native_intensity is not None
                else None
            ),
            ViewerLayerField.VISIBLE.value: layer_visible,
            ViewerLayerField.SELECTED.value: layer_selected,
            ViewerLayerField.FEATURE_ROW_COUNT.value: (
                result_selection.feature_row_count
            ),
            ViewerLayerField.SELECTED_DATA_INDICES.value: (
                result_selection.selected_data_indices
            ),
            ViewerLayerField.PENDING_UPDATE.value: (
                route_key in self.server.layer_route_state.layer_pending_updates
            ),
        }

    def component_values_for(
        self,
        dimension_state: NapariDimensionLayerState,
        items: tuple[NapariStreamLayerItem, ...],
    ) -> tuple[dict[str, ComponentValue], ...]:
        controls = self.state_controls()
        if not controls.include_component_values:
            return ()
        aggregate_axis_bindings = (
            dimension_state.presentation.aggregate_axis_bindings
            if dimension_state.presentation is not None
            else NapariAggregateAxisBindingSet()
        )
        return tuple(
            aggregate_axis_bindings.item_scalar_components(item)
            for item in self._bounded_items(
                items,
                controls.max_component_values_per_layer,
            )
        )

    def payload_summaries_for(
        self,
        dimension_state: NapariDimensionLayerState,
        items: tuple[NapariStreamLayerItem, ...],
    ) -> tuple[dict[str, NapariWireValue], ...]:
        controls = self.state_controls()
        if not controls.include_payload_summaries:
            return ()
        aggregate_axis_bindings = (
            dimension_state.presentation.aggregate_axis_bindings
            if dimension_state.presentation is not None
            else NapariAggregateAxisBindingSet()
        )
        return tuple(
            self.payload_summary(
                item,
                aggregate_axis_bindings.item_scalar_components(item),
                item.data,
                aggregate_axis_bindings,
            ).to_wire_mapping()
            for item in self._bounded_items(
                items,
                controls.max_payload_summaries_per_layer,
            )
        )

    @staticmethod
    def _bounded_items(
        items: tuple[NapariStreamLayerItem, ...],
        limit: int | None,
    ) -> tuple[NapariStreamLayerItem, ...]:
        if limit is None:
            return items
        return items[:limit]

    @abstractmethod
    def state_controls(self) -> ViewerStateControlOptions:
        """Return the state-detail controls for this projection."""

    @abstractmethod
    def _route_key_filter(self) -> str | None:
        """Return the route selected by this projection, when any."""

    def layer_title(self, route_key: str) -> str | None:
        if route_key not in self.server.layer_route_state.layer_titles:
            return None
        return self.server.layer_route_state.title_for(route_key)

    def layer_is_mounted(self, route_key: str) -> bool:
        return self.mounted_layer(route_key) is not None

    def mounted_layer(self, route_key: str) -> NapariLayerHandle | None:
        if not self.server.layer_route_state.has_layer(route_key):
            return None
        layer = self.server.layer_route_state.layer(route_key)
        if layer not in self.viewer.layers:
            return None
        return layer

    @staticmethod
    def layer_data_shape(layer: NapariLayerHandle | None) -> tuple[int, ...]:
        if layer is None:
            return ()
        data = layer.data
        if isinstance(data, np.ndarray):
            return tuple(int(axis) for axis in data.shape)
        if isinstance(data, list):
            return (len(data),)
        raise TypeError(
            "Napari layer data must be an ndarray or vector-shape list, "
            f"got {type(data).__name__}."
        )

    @staticmethod
    def layer_native_transform(
        layer: NapariLayerHandle | None,
    ) -> ViewerNativeLayerTransform:
        if layer is None:
            return ViewerNativeLayerTransform()
        return NapariNativeLayerTransformInspection(layer).snapshot()

    @staticmethod
    def axis_component_values(
        dimension_state: NapariDimensionLayerState,
    ) -> dict[str, list[ComponentValue]]:
        if dimension_state.presentation is None:
            return {}
        return {
            component: list(values)
            for component, values in (
                dimension_state.presentation.projection.component_values.items()
            )
        }

    @staticmethod
    def routed_component_values(
        dimension_state: NapariDimensionLayerState,
    ) -> dict[str, list[ComponentValue]]:
        if dimension_state.presentation is None:
            return {}
        return {
            component: list(values)
            for component, values in (
                dimension_state.presentation.projection.routed_component_values.items()
            )
        }

    @staticmethod
    def routed_component_coordinates(
        dimension_state: NapariDimensionLayerState,
    ) -> tuple[tuple[ComponentValue, ...], ...]:
        if dimension_state.presentation is None:
            return ()
        return dimension_state.presentation.projection.routed_component_coordinates

    @classmethod
    def payload_summary(
        cls,
        item: NapariStreamLayerItem,
        components: Mapping[str, ComponentValue],
        data: LayerData,
        aggregate_axis_bindings: NapariAggregateAxisBindingSet | None = None,
    ) -> ViewerPayloadSummary:
        summary: dict[str, NapariWireValue] = {
            ViewerPayloadField.DATA_TYPE.value: item.address.stream_layer_data_type.value,
            ViewerPayloadField.PATH.value: item.address.path,
            ViewerPayloadField.COMPONENTS.value: dict(components),
            "payload_type": type(data).__name__,
        }
        summary.update(
            item.image_metadata.source_spatial_domain.to_viewer_wire_mapping()
        )
        if aggregate_axis_bindings is not None and aggregate_axis_bindings.bindings:
            summary["aggregate_component_values"] = {
                binding.component: tuple(binding.values)
                for binding in aggregate_axis_bindings.bindings
            }
        if isinstance(data, np.ndarray):
            summary.update(cls.array_summary(data))
        elif isinstance(data, (list, tuple)):
            summary["item_count"] = len(data)
            summary[ViewerPayloadSummaryField.NONZERO_COUNT.value] = len(data)
            summary.update(cls.shape_payload_summary(data))
        return cls.payload_summary_type.from_wire_mapping(summary)

    @classmethod
    def shape_payload_summary(
        cls,
        payloads: Sequence[NapariWireValue],
    ) -> dict[str, NapariWireValue]:
        shape_payload_count = 0
        missing_source_shape_count = 0
        coordinate_count = 0
        out_of_bounds_count = 0
        aggregate_bounds = ShapeCoordinateBounds.empty()
        for payload in payloads:
            if not isinstance(payload, Mapping):
                continue
            shape_payload_count += 1
            source_shape = cls.shape_source_spatial_shape(payload)
            if source_shape is None:
                missing_source_shape_count += 1
            bounds = ShapeCoordinateBounds.from_shape_payload(payload)
            if bounds is None:
                continue
            coordinate_count += bounds.coordinate_count
            aggregate_bounds = aggregate_bounds.union(bounds)
            if source_shape is not None and bounds.outside_source_shape(source_shape):
                out_of_bounds_count += 1

        summary: dict[str, NapariWireValue] = {
            "shape_payload_count": shape_payload_count,
            "missing_source_spatial_shape_count": missing_source_shape_count,
            "shape_coordinate_count": coordinate_count,
            "shape_out_of_source_bounds_count": out_of_bounds_count,
        }
        if aggregate_bounds.has_coordinates:
            summary["shape_coordinate_bounds_yx"] = aggregate_bounds.to_wire_mapping()
        return summary

    @staticmethod
    def shape_source_spatial_shape(
        payload: Mapping[str, NapariWireValue],
    ) -> tuple[int, int] | None:
        metadata = payload.get(ViewerWireField.METADATA.value)
        if not isinstance(metadata, Mapping):
            return None
        return SourceSpatialDomain.from_viewer_wire_mapping(
            metadata,
            source_label="Napari shape payload state projection",
            value_name="Napari shape payload",
        ).source_shape_yx

    @classmethod
    def array_summary(cls, array: np.ndarray) -> dict[str, NapariWireValue]:
        nonzero_count = int(np.count_nonzero(array))
        summary: dict[str, NapariWireValue] = {
            ViewerPayloadSummaryField.SHAPE.value: tuple(
                int(axis) for axis in array.shape
            ),
            "dtype": str(array.dtype),
            "size": int(array.size),
            ViewerPayloadSummaryField.NONZERO_COUNT.value: nonzero_count,
        }
        summary.update(
            cls.nonzero_coordinate_summary(
                array,
                nonzero_count=nonzero_count,
            )
        )
        if array.size:
            summary["min"] = cls.json_scalar(array.min())
            summary["max"] = cls.json_scalar(array.max())
        return summary

    @classmethod
    def nonzero_coordinate_summary(
        cls,
        array: np.ndarray,
        *,
        nonzero_count: int,
    ) -> dict[str, NapariWireValue]:
        """Project exact bounds and bounded examples for sparse array payloads."""

        if nonzero_count > cls.MAX_NONZERO_COORDINATE_PROJECTION_COUNT:
            return {
                ViewerPayloadSummaryField.NONZERO_COORDINATE_OMISSION_REASON.value: (
                    "nonzero count exceeds bounded coordinate projection limit "
                    f"{cls.MAX_NONZERO_COORDINATE_PROJECTION_COUNT}"
                )
            }

        coordinates = np.argwhere(array != 0)
        if nonzero_count == 0:
            return {
                ViewerPayloadSummaryField.NONZERO_EXAMPLE_COORDINATES.value: (),
            }

        example_count = min(
            nonzero_count,
            cls.MAX_NONZERO_EXAMPLE_COORDINATE_COUNT,
        )
        example_indices = np.linspace(
            0,
            nonzero_count - 1,
            num=example_count,
            dtype=np.int64,
        )
        return {
            ViewerPayloadSummaryField.NONZERO_MIN_COORDINATE.value: tuple(
                int(value) for value in coordinates.min(axis=0)
            ),
            ViewerPayloadSummaryField.NONZERO_MAX_COORDINATE.value: tuple(
                int(value) for value in coordinates.max(axis=0)
            ),
            ViewerPayloadSummaryField.NONZERO_EXAMPLE_COORDINATES.value: tuple(
                tuple(int(value) for value in coordinates[index])
                for index in example_indices
            ),
        }

    @staticmethod
    def json_scalar(value: np.generic | bool | int | float | str) -> NapariWireValue:
        if isinstance(value, np.generic):
            scalar = value.item()
        else:
            scalar = value
        if isinstance(scalar, (bool, int, float, str)):
            return scalar
        return str(scalar)


class NapariViewerStateProjection(NapariViewerProjectionABC[ViewerStateControlOptions]):
    """Project live Napari route/component stores into agent-readable state."""

    def state_controls(self) -> ViewerStateControlOptions:
        return self.request

    def _route_key_filter(self) -> str | None:
        return self.request.route_key

    @staticmethod
    def native_dimensions(viewer) -> ViewerNativeDimensions:
        """Read live Dims/camera/canvas, including changes made by the user."""
        dims = viewer.dims
        return ViewerNativeDimensions(
            order=tuple(int(axis) for axis in dims.order),
            ndisplay=int(dims.ndisplay),
            displayed_axes=tuple(
                str(dims.axis_labels[axis]) for axis in dims.displayed
            ),
            point=tuple(float(value) for value in dims.point),
            camera_angles=tuple(float(angle) for angle in viewer.camera.angles),
            canvas_size=(
                (
                    int(viewer.window.qt_viewer.canvas.native.width()),
                    int(viewer.window.qt_viewer.canvas.native.height()),
                )
                if isinstance(viewer, napari.Viewer)
                else None
            ),
        )

    def to_wire_mapping(self) -> dict[str, NapariWireValue]:
        route_keys = self.route_keys()
        layers = tuple(self.layer_state_for(route_key) for route_key in route_keys)
        wire_mapping = self.wire_envelope(response_type="state_ack", layers=layers)
        wire_mapping.update(
            {
                ViewerControlField.NATIVE_DIMENSIONS.value: self.native_dimensions(
                    self.viewer
                ).to_wire_mapping(),
                ViewerControlField.ACTIVE_DIMENSION_LABEL_ROUTE.value: (
                    self.server.layer_route_state.active_dimension_label_route
                ),
                ViewerControlField.VIEWER_NDIM.value: int(self.viewer.dims.ndim),
                ViewerControlField.CURRENT_STEP.value: tuple(
                    int(step) for step in self.viewer.dims.current_step
                ),
                ViewerControlField.AXIS_LABELS.value: tuple(
                    str(label) for label in self.viewer.dims.axis_labels
                ),
                ViewerControlField.COMPONENT_GROUP_COUNT.value: len(
                    self.server.component_groups
                ),
                ViewerControlField.COMPONENT_ITEM_COUNT.value: sum(
                    self.server.component_groups.item_count(route_key)
                    for route_key in route_keys
                ),
            }
        )
        return wire_mapping


@dataclass(slots=True)
class _NapariShapePayloadBudget:
    remaining_payloads: int | None

    def record_limit(self, maximum_per_record: int) -> int:
        if self.remaining_payloads is None:
            return maximum_per_record
        return min(maximum_per_record, self.remaining_payloads)

    def consume(self, payload_count: int) -> None:
        if self.remaining_payloads is None:
            return
        self.remaining_payloads -= payload_count


class NapariViewerPayloadProjection(
    NapariViewerProjectionABC[ViewerPayloadProjectionOptions]
):
    """Project live Napari layer payloads with axis-coordinate evidence."""

    def state_controls(self) -> ViewerStateControlOptions:
        return ViewerStateControlOptions.from_overrides(
            route_key=self.request.controls.route_key,
        )

    def to_wire_mapping(self) -> dict[str, NapariWireValue]:
        payload_budget = _NapariShapePayloadBudget(
            self.request.max_total_shape_payloads
        )
        layers = tuple(
            self.layer_payloads_for(route_key, payload_budget)
            for route_key in self.route_keys()
        )
        return self.wire_envelope(response_type="payloads_ack", layers=layers)

    def _route_key_filter(self) -> str | None:
        return self.request.controls.route_key

    def layer_payloads_for(
        self,
        route_key: str,
        payload_budget: _NapariShapePayloadBudget | None = None,
    ) -> dict[str, NapariWireValue]:
        if payload_budget is None:
            payload_budget = _NapariShapePayloadBudget(
                self.request.max_total_shape_payloads
            )
        layer_state = self.layer_state_for(route_key)
        items = self.server.component_groups.existing_items_for(route_key)
        item_tuple: tuple[NapariStreamLayerItem, ...] = ()
        if items is not None:
            item_tuple = tuple(items)
        dimension_state = self.server.layer_route_state.dimension_state_for(route_key)
        return {
            ViewerLayerField.ROUTE_KEY.value: route_key,
            ViewerLayerField.PRODUCER_IDENTITIES.value: layer_state[
                ViewerLayerField.PRODUCER_IDENTITIES.value
            ],
            ViewerLayerField.TITLE.value: layer_state[ViewerLayerField.TITLE.value],
            ViewerLayerField.MOUNTED.value: layer_state[ViewerLayerField.MOUNTED.value],
            ViewerLayerField.ITEM_COUNT.value: len(item_tuple),
            ViewerLayerField.AXIS_LABELS.value: layer_state[
                ViewerLayerField.AXIS_LABELS.value
            ],
            ViewerLayerField.STACK_AXES.value: layer_state[
                ViewerLayerField.STACK_AXES.value
            ],
            ViewerLayerField.PENDING_UPDATE.value: layer_state[
                ViewerLayerField.PENDING_UPDATE.value
            ],
            ViewerLayerField.PAYLOADS.value: tuple(
                record
                for item in item_tuple
                for record in self.records_for_item(
                    item,
                    route_key,
                    dimension_state,
                    payload_budget,
                )
            ),
        }

    def records_for_item(
        self,
        item: NapariStreamLayerItem,
        route_key: str,
        dimension_state: NapariDimensionLayerState,
        payload_budget: _NapariShapePayloadBudget,
    ) -> tuple[dict[str, NapariWireValue], ...]:
        if dimension_state.presentation is None:
            if not self.axis_indices_match((), dimension_state):
                return ()
            return (
                self.record_for_item(
                    item,
                    route_key,
                    (),
                    (),
                    None,
                    payload_budget,
                ),
            )

        aggregate_axis_bindings = dimension_state.presentation.aggregate_axis_bindings
        aggregate_index_tuples = self.aggregate_index_tuples(aggregate_axis_bindings)
        records: list[dict[str, NapariWireValue]] = []
        for aggregate_indices in aggregate_index_tuples:
            components = aggregate_axis_bindings.item_component_values(
                item,
                aggregate_indices,
            )
            axis_indices = dimension_state.presentation.projection.coordinate_index(
                components,
                context="Napari payload inspection",
            )
            if not self.axis_indices_match(axis_indices, dimension_state):
                continue
            records.append(
                self.record_for_item(
                    item,
                    route_key,
                    aggregate_indices,
                    axis_indices,
                    aggregate_axis_bindings,
                    payload_budget,
                )
            )
        return tuple(records)

    def axis_indices_match(
        self,
        axis_indices: tuple[int, ...],
        dimension_state: NapariDimensionLayerState,
    ) -> bool:
        if self.request.controls.axis_indices is None:
            return True
        if isinstance(self.request.controls.axis_indices, Mapping):
            return self.semantic_axis_indices_match(
                axis_indices,
                dimension_state,
                self.request.controls.axis_indices,
            )
        return tuple(axis_indices) == self.request.controls.axis_indices

    @staticmethod
    def semantic_axis_indices_match(
        axis_indices: tuple[int, ...],
        dimension_state: NapariDimensionLayerState,
        semantic_axis_indices: Mapping[str, int],
    ) -> bool:
        if dimension_state.presentation is None:
            if semantic_axis_indices:
                raise ValueError(
                    "Napari payload axis_indices require a route with semantic "
                    "axis presentation."
                )
            return True
        return dimension_state.presentation.route_local_component_indices_match(
            axis_indices,
            semantic_axis_indices,
            context="Napari payload axis_indices",
        )

    @staticmethod
    def aggregate_index_tuples(
        aggregate_axis_bindings: NapariAggregateAxisBindingSet,
    ) -> tuple[tuple[int, ...], ...]:
        if not aggregate_axis_bindings.bindings:
            return ((),)
        return tuple(
            tuple(indices)
            for indices in product(
                *(range(binding.extent) for binding in aggregate_axis_bindings.bindings)
            )
        )

    def record_for_item(
        self,
        item: NapariStreamLayerItem,
        route_key: str,
        aggregate_indices: tuple[int, ...],
        axis_indices: tuple[int, ...],
        aggregate_axis_bindings: NapariAggregateAxisBindingSet | None,
        payload_budget: _NapariShapePayloadBudget,
    ) -> dict[str, NapariWireValue]:
        components = dict(item.address.components)
        data = item.data
        if aggregate_axis_bindings is not None:
            components = dict(
                aggregate_axis_bindings.item_component_values(
                    item,
                    aggregate_indices,
                )
            )
            data = self.aggregate_data_slice(item.data, aggregate_indices)

        array_values, array_value_summary = self.array_value_projection(
            data,
            image_metadata=item.image_metadata,
            source_data=item.data,
            removed_leading_axes=len(aggregate_indices),
        )
        return self.payload_record_type(
            route_key=route_key,
            data_type=item.address.stream_layer_data_type.value,
            path=item.address.path,
            components=components,
            axis_indices=axis_indices,
            aggregate_axis_indices=aggregate_indices,
            summary=self.payload_summary(item, components, data),
            array_values=array_values,
            array_value_summary=array_value_summary,
            shape_payloads=self.shape_payloads(data, payload_budget),
        ).to_wire_mapping()

    @staticmethod
    def aggregate_data_slice(
        data: LayerData,
        aggregate_indices: tuple[int, ...],
    ) -> LayerData:
        if not aggregate_indices:
            return data
        if isinstance(data, np.ndarray):
            return data[aggregate_indices]
        return data

    def array_value_projection(
        self,
        data: LayerData,
        *,
        image_metadata: ImagePayloadMetadata | None = None,
        source_data: LayerData | None = None,
        removed_leading_axes: int = 0,
    ) -> tuple[tuple[NapariWireValue, ...], ViewerArrayValueSummary]:
        if not self.request.controls.include_array_values:
            return (), ViewerArrayValueSummary()
        summary: dict[str, NapariWireValue] = {
            "requested": True,
            "included": False,
        }
        if not isinstance(data, np.ndarray):
            summary["omitted_reason"] = "payload_not_ndarray"
            return (), ViewerArrayValueSummary.from_wire_mapping(summary)

        sample, slice_summary = self.array_value_sample(
            data,
            image_metadata=image_metadata,
            source_data=source_data,
            removed_leading_axes=removed_leading_axes,
        )
        summary.update(slice_summary)
        summary.update(
            {
                "dtype": str(sample.dtype),
                ViewerPayloadSummaryField.SHAPE.value: tuple(
                    int(axis_size) for axis_size in sample.shape
                ),
                "size": int(sample.size),
                ViewerPayloadSummaryField.NONZERO_COUNT.value: int(
                    np.count_nonzero(sample)
                ),
            }
        )
        if sample.size > 0:
            summary["min"] = self.json_scalar(np.min(sample))
            summary["max"] = self.json_scalar(np.max(sample))
        if "omitted_reason" in summary:
            return (), ViewerArrayValueSummary.from_wire_mapping(summary)
        if sample.size > self.request.controls.max_array_elements:
            summary["omitted_reason"] = "max_array_elements_exceeded"
            summary["max_array_elements"] = self.request.controls.max_array_elements
            return (), ViewerArrayValueSummary.from_wire_mapping(summary)

        summary["included"] = True
        value = self.wire_value(sample)
        if isinstance(value, tuple):
            return value, ViewerArrayValueSummary.from_wire_mapping(summary)
        return (value,), ViewerArrayValueSummary.from_wire_mapping(summary)

    def array_value_sample(
        self,
        data: np.ndarray,
        *,
        image_metadata: ImagePayloadMetadata | None = None,
        source_data: np.ndarray | None = None,
        removed_leading_axes: int = 0,
    ) -> tuple[np.ndarray, dict[str, NapariWireValue]]:
        """Original bounded sampler; controls declare axes, metadata owns layout."""
        controls = self.request.controls
        if controls.array_slices is None:
            return data, {
                "slice_ranges": tuple((0, int(axis_size)) for axis_size in data.shape)
            }
        axes = controls.sample_axis_indices(
            data,
            image_metadata,
            data if source_data is None else source_data,
            removed_leading_axes,
        )
        if len(controls.array_slices) > data.ndim:
            sample = (
                data.reshape((1,))[0:0]
                if data.ndim == 0
                else data[tuple(slice(0, 0) for _ in data.shape)]
            )
            return sample, {
                "slice_ranges": (),
                "requested_slice_ranges": controls.array_slices,
                "omitted_reason": "slice_rank_exceeds_array_rank",
            }
        bounds_by_axis = dict(zip(axes, controls.array_slices, strict=True))
        slices: list[slice] = []
        applied_ranges: list[tuple[int, int]] = []
        for axis_index, axis_size in enumerate(data.shape):
            start, stop = bounds_by_axis.get(axis_index, (0, int(axis_size)))
            bounded_start = min(start, int(axis_size))
            bounded_stop = min(stop, int(axis_size))
            slices.append(slice(bounded_start, bounded_stop))
            applied_ranges.append((bounded_start, bounded_stop))
        return data[tuple(slices)], {
            "slice_ranges": tuple(applied_ranges),
            "requested_slice_ranges": controls.array_slices,
        }

    def shape_payloads(
        self,
        data: LayerData,
        payload_budget: _NapariShapePayloadBudget,
    ) -> tuple[dict[str, NapariWireValue], ...]:
        if not self.request.controls.include_shape_payloads:
            return ()
        if not isinstance(data, (list, tuple)):
            return ()
        record_limit = payload_budget.record_limit(
            self.request.controls.max_shape_payloads
        )
        if not record_limit:
            return ()
        records: list[dict[str, NapariWireValue]] = []
        for payload in data:
            if not isinstance(payload, Mapping):
                continue
            records.append(
                {
                    str(key): self.wire_value(value)
                    for key, value in (
                        self.request.shape_payload_projection.selected_items(payload)
                    )
                }
            )
            if len(records) >= record_limit:
                break
        payload_budget.consume(len(records))
        return tuple(records)

    @classmethod
    def wire_value(cls, value: NapariWireValue) -> NapariWireValue:
        if isinstance(value, np.ndarray):
            return cls.wire_value(value.tolist())
        if isinstance(value, np.generic):
            return NapariViewerStateProjection.json_scalar(value)
        if isinstance(value, Mapping):
            return {
                str(key): cls.wire_value(mapping_value)
                for key, mapping_value in value.items()
            }
        if isinstance(value, (list, tuple)):
            return tuple(cls.wire_value(item) for item in value)
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        return str(value)


class NapariStateControlMessageAction(NapariControlMessageAction):
    """Registered action that reports live layer and axis state."""

    message_type = ViewerControlMessageType.STATE.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        if server.viewer is None:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="state_ack",
                    message="Napari viewer is not available.",
                )
            ).to_wire_mapping()

        request = message.get(ViewerControlResponseField.PAYLOAD.value)
        if not isinstance(request, ViewerStateControlOptions):
            raise TypeError(
                "Napari state control payload must be ViewerStateControlOptions."
            )
        return NapariViewerStateProjection(
            server=server,
            viewer=server.viewer,
            request=request,
        ).to_wire_mapping()


class NapariPayloadsControlMessageAction(NapariControlMessageAction):
    """Registered action that reports live payload records by layer and axis."""

    message_type = ViewerControlMessageType.PAYLOADS.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        if server.viewer is None:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="payloads_ack",
                    message="Napari viewer is not available.",
                )
            ).to_wire_mapping()

        request = message.get(ViewerControlResponseField.PAYLOAD.value)
        if not isinstance(request, ViewerPayloadProjectionOptions):
            raise TypeError(
                "Napari payload control payload must be "
                "ViewerPayloadProjectionOptions."
            )
        return NapariViewerPayloadProjection(
            server=server,
            viewer=server.viewer,
            request=request,
        ).to_wire_mapping()


class NapariMountedRouteControlMessageAction(NapariControlMessageAction):
    """Shared exact mounted-route boundary for routed native commands."""

    def _mounted_layer(
        self,
        server: "NapariViewerServer",
        route_key: str,
    ) -> NapariLayerHandle:
        if not server.layer_route_state.has_layer(route_key):
            raise ValueError(
                f"No Napari layer is registered for route_key {route_key!r}."
            )
        layer = server.layer_route_state.layer(route_key)
        if layer not in server.viewer.layers:
            raise ValueError(
                f"Napari layer for route_key {route_key!r} is not mounted."
            )
        return layer

    @staticmethod
    def matched_image_records(
        items: list[NapariStreamLayerItem],
        dimension_state: NapariDimensionLayerState,
        request: ViewerRoutedImageControlOptions,
    ) -> tuple[
        tuple[
            NapariStreamLayerItem,
            LayerData,
            dict[str, ComponentValue],
            tuple[int, ...],
            tuple[int, ...],
        ],
        ...,
    ]:
        """Select original image planes through the existing semantic axis owner."""
        presentation = dimension_state.presentation
        if presentation is None:
            if request.axis_indices:
                raise ValueError(
                    "Image axis_indices require a route with semantic axis projection."
                )
            return tuple(
                (item, item.data, dict(item.address.components), (), ())
                for item in items
            )
        aggregate_bindings = presentation.aggregate_axis_bindings
        records = []
        for item in items:
            for (
                aggregate_indices
            ) in NapariViewerPayloadProjection.aggregate_index_tuples(
                aggregate_bindings
            ):
                components = aggregate_bindings.item_component_values(
                    item, aggregate_indices
                )
                axis_indices = presentation.projection.coordinate_index(
                    components, context="Napari image payload selection"
                )
                if not presentation.route_local_component_indices_match(
                    axis_indices,
                    request.axis_indices,
                    context="Viewer image axis_indices",
                ):
                    continue
                records.append(
                    (
                        item,
                        NapariViewerPayloadProjection.aggregate_data_slice(
                            item.data, aggregate_indices
                        ),
                        dict(components),
                        axis_indices,
                        aggregate_indices,
                    )
                )
        return tuple(records)


class NapariFeatureMeasurementControlMessageAction(
    NapariMountedRouteControlMessageAction
):
    """Read-only bounded measurement; executes on the owning Qt thread."""

    request_type: ClassVar[type[ViewerFeatureMeasurementControlOptions]]

    def handle(
        self, server: "NapariViewerServer", message: Mapping[str, object]
    ) -> dict[str, object]:
        try:
            request = message.get(ViewerControlResponseField.PAYLOAD.value)
            if not isinstance(request, self.request_type):
                raise TypeError(
                    f"Measurement payload must be {self.request_type.__name__}."
                )
            measurement, coordinates = self._admitted_plane(server, request)
            result = self.measure(measurement, request)
            response = ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS, response_type=f"{self.message_type}_ack"
            ).to_wire_mapping()
            response.update(
                to_jsonable({"measurement": result, "coordinates": coordinates})
            )
            return response
        except Exception as error:
            return ViewerControlReplyHeader(
                ViewerProtocolStatus.ERROR,
                response_type=f"{self.message_type}_ack",
                message=str(error),
            ).to_wire_mapping()

    @abstractmethod
    def measure(
        self,
        plane: NativeImageMeasurement,
        request: ViewerFeatureMeasurementControlOptions,
    ) -> object:
        """Measure the concrete declaration's geometry."""

    def _admitted_plane(
        self,
        server: "NapariViewerServer",
        request: ViewerFeatureMeasurementControlOptions,
    ) -> tuple[NativeImageMeasurement, ViewerMeasurementCoordinates]:
        if server.viewer is None or server.viewer.dims.ndisplay != 2:
            raise ValueError("Measurement requires an available 2D viewer.")
        if set(server.viewer.dims.displayed) != set(
            range(server.viewer.dims.ndim - 2, server.viewer.dims.ndim)
        ):
            raise ValueError("Measurement requires the native YX spatial display axes.")
        layer = self._mounted_layer(server, request.route_key)
        if not isinstance(layer, napari.layers.Image) or layer.rgb or layer.multiscale:
            raise TypeError(
                "Measurement route must mount one scalar, non-multiscale Image."
            )
        if server.layer_route_state.pending_update_for(request.route_key) is not None:
            raise ValueError(
                "Measurement route has pending data; settle before measuring."
            )
        items = server.component_groups.existing_items_for(request.route_key)
        if not items or len(items) > 128:
            raise ValueError(
                "Measurement requires a bounded route with 1..128 original items."
            )
        if any(
            item.address.stream_layer_data_type is not StreamingDataType.IMAGE
            for item in items
        ):
            raise TypeError("Measurement requires original image payloads.")
        state = server.layer_route_state.dimension_state_for(request.route_key)
        presentation = state.presentation
        if presentation is not None:
            if set(request.axis_indices) != set(
                presentation.route_local_component_axes
            ):
                raise ValueError(
                    f"Measurement requires exact route-local axes {presentation.route_local_component_axes!r}."
                )
            combinations = 1
            for binding in presentation.aggregate_axis_bindings.bindings:
                combinations *= binding.extent
            if combinations * len(items) > 128:
                raise ValueError(
                    "Measurement routed plane selection exceeds128 records before slicing."
                )
        records = self.matched_image_records(items, state, request)
        if len(records) != 1:
            raise ValueError(
                "Measurement coordinates must select exactly one original plane, not sparse padding or ambiguous records."
            )
        item, data, components, indices, aggregate_indices = records[0]
        domain = item.image_metadata.source_spatial_domain
        if not isinstance(data, np.ndarray) or data.ndim != 2:
            raise ValueError(
                "Measurement requires a native scalar 2D plane; unbound stack/color dimensions are unsupported."
            )
        domain.require_image_window(data.shape)
        origin = domain.origin_yx if domain.origin_yx is not None else (0, 0)
        labels = presentation.axis_labels if presentation is not None else ("y", "x")
        local_indices = (
            presentation.route_local_component_indices(
                indices, context="Measurement coordinates"
            )
            if presentation is not None
            else {}
        )
        prefix = tuple(float(local_indices.get(axis, 0)) for axis in labels[:-2])
        if layer.ndim != len(prefix) + 2:
            raise ValueError(
                "Measurement image rank disagrees with declared native axes."
            )

        def world(point: tuple[float, float]) -> tuple[float, ...]:
            return tuple(layer.data_to_world((*prefix, *point)))

        coordinates = ViewerMeasurementCoordinates(
            route_key=request.route_key,
            source_path=item.address.path,
            producer=item.producer,
            components=components,
            axis_indices=dict(request.axis_indices),
            aggregate_axis_indices=aggregate_indices,
            layer_axis_labels=labels,
            source_domain=ViewerSourceSpatialDomainPayload(
                origin_yx=domain.origin_yx, source_shape_yx=domain.source_shape_yx
            ),
            source_spacing=item.image_metadata.source_voxel_spacing,
            native_transform=NapariNativeLayerTransformInspection(layer).snapshot(),
            world_units=tuple(str(unit) for unit in layer.units),
        )
        return NativeImageMeasurement(data, origin, world), coordinates


class NapariPolylineMeasurementControlMessageAction(
    NapariFeatureMeasurementControlMessageAction
):
    message_type = OpenHCSViewerControlMessageType.MEASURE_POLYLINE.value
    request_type = ViewerPolylineControlOptions

    def measure(
        self, plane: NativeImageMeasurement, request: ViewerPolylineControlOptions
    ) -> object:
        return plane.polyline(request)


class NapariRegionMeasurementControlMessageAction(
    NapariFeatureMeasurementControlMessageAction
):
    message_type = OpenHCSViewerControlMessageType.MEASURE_REGION.value
    request_type = ViewerRegionControlOptions

    def measure(
        self, plane: NativeImageMeasurement, request: ViewerRegionControlOptions
    ) -> object:
        return plane.region(request)


class NapariPresentationControlMessageAction(NapariControlMessageAction):
    """Shared nominal admission, native apply/readback and reply lifecycle."""

    request_type: ClassVar[type]
    response_field: ClassVar[ViewerControlField]

    @abstractmethod
    def apply_presentation(self, server, request) -> ViewerDeclaredWireValue:
        """Apply through the actual native owner and return its current state."""

    def handle(
        self, server: "NapariViewerServer", message: Mapping[str, object]
    ) -> dict[str, object]:
        try:
            request = message.get(ViewerControlResponseField.PAYLOAD.value)
            if not isinstance(request, self.request_type):
                raise TypeError(f"Presentation payload must be {self.request_type.__name__}.")
            snapshot = self.apply_presentation(server, request)
            response = ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS,
                response_type=f"{self.message_type}_ack",
            ).to_wire_mapping()
            response[self.response_field.value] = snapshot.to_wire_mapping()
            return response
        except Exception as error:
            return ViewerControlReplyHeader(
                ViewerProtocolStatus.ERROR,
                response_type=f"{self.message_type}_ack",
                message=str(error),
            ).to_wire_mapping()


class NapariViewportControlMessageAction(NapariPresentationControlMessageAction):
    message_type = ViewerControlMessageType.VIEWPORT.value
    request_type = ViewerNativeViewportPresentation
    response_field = ViewerControlField.NATIVE_VIEWPORT

    def apply_presentation(self, server, request):
        control = NapariNativeViewportPresentation.for_viewer(server.viewer)
        if control is None:
            raise ValueError("The viewer does not expose native 2D viewport presentation.")
        control.apply(request)
        return control.snapshot()


class NapariImageColorControlMessageAction(
    NapariPresentationControlMessageAction, NapariMountedRouteControlMessageAction,
):
    """Independent exact-route and native reply capabilities compose by C3 MRO."""

    message_type = OpenHCSViewerControlMessageType.IMAGE_COLOR.value
    request_type = ViewerImageColorControlOptions
    response_field = ViewerControlField.NATIVE_IMAGE_COLOR

    def apply_presentation(self, server, request):
        layer = self._mounted_layer(server, request.route_key)
        if not isinstance(layer, Image) or layer.rgb:
            raise ValueError("Color presentation requires a mounted scalar Napari Image.")
        colormap = ensure_colormap(request.presentation.colormap)
        blending = Blending(request.presentation.blending)
        layer.colormap = colormap
        layer.blending = blending
        return ViewerNativeImageColorPresentation(layer.colormap.name, layer.blending)


class NapariWindowPresentationControlMessageAction(NapariPresentationControlMessageAction):
    message_type = OpenHCSViewerControlMessageType.WINDOW_PRESENTATION.value
    request_type = ViewerNativeWindowControlOptions
    response_field = ViewerControlField.NATIVE_WINDOW

    def apply_presentation(self, server, request):
        control = NapariNativeWindowPresentation(server.viewer.window.qt_viewer.window())
        request.apply_to(control)
        return control.snapshot()


class NapariImageIntensityControlMessageAction(NapariMountedRouteControlMessageAction):
    """Apply a typed native image presentation on the owning Qt thread."""

    message_type = ViewerControlMessageType.IMAGE_INTENSITY.value

    def _state_reply(
        self,
        server: "NapariViewerServer",
        request: ViewerImageIntensityControlOptions,
        header: ViewerControlReplyHeader,
    ) -> dict[str, object]:
        response = NapariViewerStateProjection(
            server=server,
            viewer=server.viewer,
            request=ViewerStateControlOptions.from_overrides(
                route_key=request.route_key,
                include_component_values=False,
                include_payload_summaries=False,
            ),
        ).to_wire_mapping()
        response.update(header.to_wire_mapping())
        return response

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        request = message.get(ViewerControlResponseField.PAYLOAD.value)
        acknowledgement = ViewerControlMessageType.IMAGE_INTENSITY.acknowledgement_type
        try:
            if server.viewer is None:
                raise RuntimeError("Napari viewer is not available.")
            if not isinstance(request, ViewerImageIntensityControlOptions):
                raise TypeError(
                    "Image intensity payload must be ViewerImageIntensityControlOptions."
                )
            layer = self._mounted_layer(server, request.route_key)
            control = NapariNativeImageIntensityPresentation.for_layer(layer)
            if control is None:
                raise TypeError(
                    "The mounted route does not expose native image intensity controls."
                )
            control.apply(request.presentation)
            return self._state_reply(
                server,
                request,
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.SUCCESS,
                    response_type=acknowledgement,
                    message="Native image presentation applied.",
                ),
            )
        except Exception as exc:
            header = ViewerControlReplyHeader(
                ViewerProtocolStatus.ERROR,
                response_type=acknowledgement,
                message=str(exc),
            )
            if server.viewer is not None and isinstance(
                request, ViewerImageIntensityControlOptions
            ):
                try:
                    return self._state_reply(server, request, header)
                except Exception as snapshot_error:
                    header = ViewerControlReplyHeader(
                        ViewerProtocolStatus.ERROR,
                        response_type=acknowledgement,
                        message=f"{exc}; native state readback failed: {snapshot_error}",
                    )
            return ViewerControlReplyPayload(
                header,
            ).to_wire_mapping()


class NapariIntensityWindowControlMessageAction(NapariMountedRouteControlMessageAction):
    """Apply one percentile window derived from native routed image payloads."""

    message_type = ViewerControlMessageType.APPLY_INTENSITY_WINDOW.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        if server.viewer is None:
            return self._error("Napari viewer is not available.")
        try:
            request = message.get(ViewerControlResponseField.PAYLOAD.value)
            if not isinstance(request, ViewerIntensityWindowControlOptions):
                raise TypeError(
                    "Napari intensity-window payload must be "
                    "ViewerIntensityWindowControlOptions."
                )
            return self._apply(server, request)
        except Exception as exc:
            return self._error(str(exc))

    @classmethod
    def _apply(
        cls,
        server: "NapariViewerServer",
        request: ViewerIntensityWindowControlOptions,
    ) -> dict[str, object]:
        route_key = request.route_key
        viewer = server.viewer
        if viewer is None:
            raise RuntimeError("Napari viewer is not available.")
        if not server.layer_route_state.has_layer(route_key):
            raise ValueError(
                f"No Napari layer is registered for route_key {route_key!r}."
            )
        layer = server.layer_route_state.layer(route_key)
        if layer not in viewer.layers:
            raise ValueError(
                f"Napari layer for route_key {route_key!r} is not mounted."
            )
        items = server.component_groups.existing_items_for(route_key)
        if not items:
            raise ValueError(
                f"Napari route {route_key!r} has no routed image payloads."
            )
        non_image_types = tuple(
            dict.fromkeys(
                item.address.stream_layer_data_type.value
                for item in items
                if item.address.stream_layer_data_type is not StreamingDataType.IMAGE
            )
        )
        if non_image_types:
            raise ValueError(
                f"Napari route {route_key!r} is not an image route; "
                f"payload types are {non_image_types!r}."
            )
        dimension_state = server.layer_route_state.dimension_state_for(route_key)
        records = cls.matched_image_records(items, dimension_state, request)
        if not records:
            raise ValueError(
                f"Napari image route {route_key!r} has no payload records matching "
                f"axis_indices {dict(request.axis_indices)!r}."
            )
        finite_payloads: list[np.ndarray] = []
        contributing_payload_count = 0
        contributing_pixel_count = 0
        matched_payload_identities: list[dict[str, object]] = []
        for item, data, components, axis_indices, aggregate_indices in records:
            matched_payload_identities.append(
                {
                    ViewerPayloadField.PATH.value: item.address.path,
                    ViewerPayloadField.COMPONENTS.value: components,
                    ViewerPayloadField.AXIS_INDICES.value: axis_indices,
                    ViewerPayloadField.AGGREGATE_AXIS_INDICES.value: aggregate_indices,
                }
            )
            if not isinstance(data, np.ndarray):
                raise TypeError(
                    f"Napari image route {route_key!r} contains a non-array payload."
                )
            try:
                finite_values = data[np.isfinite(data)].reshape(-1)
            except TypeError as exc:
                raise TypeError(
                    f"Napari image route {route_key!r} contains non-numeric data."
                ) from exc
            if not finite_values.size:
                continue
            finite_payloads.append(finite_values)
            contributing_payload_count += 1
            contributing_pixel_count += int(finite_values.size)
        if not finite_payloads:
            raise ValueError(
                f"Napari image route {route_key!r} has no finite pixel data."
            )
        pixels = np.concatenate(finite_payloads)
        resolved = np.percentile(
            pixels,
            (request.low_percentile, request.high_percentile),
        )
        low_limit, high_limit = (float(resolved[0]), float(resolved[1]))
        if (
            not np.isfinite(low_limit)
            or not np.isfinite(high_limit)
            or low_limit >= high_limit
        ):
            raise ValueError(
                "Resolved viewer intensity limits must be finite and strictly "
                f"increasing, got {(low_limit, high_limit)!r}."
            )
        if not hasattr(layer, "contrast_limits"):
            raise TypeError(
                f"Napari image route {route_key!r} does not expose native "
                "contrast_limits."
            )
        layer.contrast_limits = (low_limit, high_limit)
        response = ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS,
                response_type="intensity_window_ack",
                message="Viewer intensity window applied.",
            )
        ).to_wire_mapping()
        response.update(
            {
                ViewerIntensityWindowField.ROUTE_KEY.value: route_key,
                ViewerIntensityWindowField.REQUESTED_PERCENTILES.value: (
                    float(request.low_percentile),
                    float(request.high_percentile),
                ),
                ViewerIntensityWindowField.AXIS_INDICES.value: dict(
                    request.axis_indices
                ),
                ViewerIntensityWindowField.RESOLVED_LIMITS.value: (
                    low_limit,
                    high_limit,
                ),
                ViewerIntensityWindowField.MATCHED_PAYLOAD_COUNT.value: len(records),
                ViewerIntensityWindowField.MATCHED_PAYLOAD_IDENTITIES.value: tuple(
                    matched_payload_identities
                ),
                ViewerIntensityWindowField.CONTRIBUTING_PAYLOAD_COUNT.value: (
                    contributing_payload_count
                ),
                ViewerIntensityWindowField.CONTRIBUTING_PIXEL_COUNT.value: (
                    contributing_pixel_count
                ),
            }
        )
        return response

    @staticmethod
    def _error(message: str) -> dict[str, object]:
        return ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                ViewerProtocolStatus.ERROR,
                response_type="intensity_window_ack",
                message=message,
            )
        ).to_wire_mapping()


@dataclass(frozen=True, slots=True)
class NapariPreparedNavigation:
    """Validated Napari navigation ready for mutation in one Qt turn."""

    layer: NapariLayerHandle
    request: ViewerNavigationControlOptions
    viewer_step: tuple[int, ...] | None
    viewer_order: tuple[int, ...] | None = None

    def changes_viewer_state(self, server: "NapariViewerServer") -> bool:
        viewer = server.viewer
        if viewer is None:
            raise RuntimeError("Napari viewer is not available.")
        return (
            (
                self.request.visible is not None
                and bool(self.layer.visible) != self.request.visible
            )
            or (
                self.request.selected is not None
                and (viewer.layers.selection.active is self.layer)
                != self.request.selected
            )
            or (
                self.viewer_step is not None
                and tuple(int(step) for step in viewer.dims.current_step)
                != self.viewer_step
            )
            or (
                self.viewer_order is not None
                and (
                    tuple(viewer.dims.order) != self.viewer_order
                    or viewer.dims.ndisplay != 2
                )
            )
            or self.request.data_index is not None
        )


class NapariNavigationControlMessageAction(NapariMountedRouteControlMessageAction):
    """Registered action that selects viewer layers and semantic axis indices."""

    message_type = ViewerControlMessageType.NAVIGATE.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        if server.viewer is None:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="navigation_ack",
                    message="Napari viewer is not available.",
                )
            ).to_wire_mapping()

        try:
            request = message.get(ViewerControlResponseField.PAYLOAD.value)
            if not isinstance(request, ViewerNavigationControlOptions):
                raise TypeError(
                    "Napari navigation control payload must be "
                    "ViewerNavigationControlOptions."
                )
            self.apply(server, request)
        except Exception as exc:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="navigation_ack",
                    message=str(exc),
                )
            ).to_wire_mapping()

        response = NapariViewerStateProjection(
            server=server,
            viewer=server.viewer,
            request=ViewerStateControlOptions.from_overrides(
                route_key=request.route_key,
                include_component_values=False,
                include_payload_summaries=False,
            ),
        ).to_wire_mapping()
        response[ViewerControlResponseField.TYPE.value] = "navigation_ack"
        response[ViewerControlResponseField.MESSAGE.value] = (
            "Viewer navigation applied."
        )
        return response

    def prepare(
        self,
        server: "NapariViewerServer",
        request: ViewerNavigationControlOptions,
    ) -> NapariPreparedNavigation:
        layer = self._mounted_layer(server, request.route_key)
        viewer_order = None
        if request.display_axes is not None:
            dimension_state = server.layer_route_state.dimension_state_for(
                request.route_key
            )
            presentation = dimension_state.presentation
            if presentation is None:
                raise ValueError(
                    "Orthogonal review requires a mounted semantic route presentation."
                )
            viewer_order = presentation.display_order(
                request.display_axes, tuple(server.viewer.dims.order)
            )
            self._require_display_compatibility(
                server, layer, request, viewer_order[-2:]
            )
        if request.data_index is not None:
            NapariResultElementSelectionAuthority.require_data_index(
                layer,
                request.data_index,
            )
            target_visible = (
                bool(layer.visible) if request.visible is None else request.visible
            )
            target_selected = (
                server.viewer.layers.selection.active is layer
                if request.selected is None
                else request.selected
            )
            if not target_visible or not target_selected:
                raise ValueError(
                    "Viewer data_index requires the target result layer to be "
                    "visible and selected."
                )
            result_axis_indices = self.result_element_axis_indices(
                server,
                layer,
                request.route_key,
                request.data_index,
                displayed_axis_indices=(
                    tuple(server.viewer.dims.displayed)
                    if viewer_order is None
                    else viewer_order[-2:]
                ),
            )
            conflicts = {
                axis_name: (result_index, request.axis_indices[axis_name])
                for axis_name, result_index in result_axis_indices.items()
                if axis_name in request.axis_indices
                and request.axis_indices[axis_name] != result_index
            }
            if conflicts:
                raise ValueError(
                    "Viewer data_index axis coordinates conflict with explicit "
                    f"axis_indices: {conflicts!r}."
                )
            request = replace(
                request,
                axis_indices={**result_axis_indices, **request.axis_indices},
            )
        viewer_step = (
            self.axis_step(server, layer, request) if request.axis_indices else None
        )
        return NapariPreparedNavigation(
            layer=layer,
            request=request,
            viewer_step=viewer_step,
            viewer_order=viewer_order,
        )

    @staticmethod
    def _require_display_compatibility(
        server: "NapariViewerServer",
        target: NapariLayerHandle,
        request: ViewerNavigationControlOptions,
        displayed: tuple[int, ...],
    ) -> None:
        """Validate the resulting visible graph before mutating any member."""
        for layer in server.viewer.layers:
            visible = (
                request.visible
                if layer is target and request.visible is not None
                else layer.visible
            )
            if not visible:
                continue
            if isinstance(layer, napari.layers.Shapes) and set(displayed) != {
                server.viewer.dims.ndim - 2,
                server.viewer.dims.ndim - 1,
            }:
                raise ValueError(
                    "Visible planar Shapes do not provide volumetric cross-sections; "
                    "hide planar ROI layers before orthogonal review or use XY."
                )
            route_key = server.layer_route_state.route_for_layer(layer)
            if route_key is None:
                raise ValueError(
                    "Orthogonal review requires semantic presentations for every visible layer."
                )
            presentation = server.layer_route_state.dimension_state_for(
                route_key
            ).presentation
            if presentation is None:
                raise ValueError(
                    f"Visible route {route_key!r} has no semantic axis presentation."
                )
            dimensions = presentation.viewer_dimension_indices(server.viewer.dims.ndim)
            spatial_dimensions = {
                dimensions[presentation.axis_labels.index(axis)]
                for axis in presentation.spatial_axis_labels
            }
            if not set(displayed).issubset(spatial_dimensions):
                raise ValueError(
                    f"Visible route {route_key!r} does not share the requested spatial dimensions."
                )
            if (
                tuple(
                    presentation.axis_labels[dimensions.index(axis)]
                    for axis in displayed
                )
                != request.display_axes
            ):
                raise ValueError(
                    f"Visible route {route_key!r} has incompatible spatial axis semantics."
                )

    def apply(
        self,
        server: "NapariViewerServer",
        request: ViewerNavigationControlOptions,
        *,
        refresh_overlay: bool = True,
    ) -> None:
        self.apply_prepared(
            server,
            self.prepare(server, request),
            refresh_overlay=refresh_overlay,
        )

    def apply_prepared(
        self,
        server: "NapariViewerServer",
        prepared: NapariPreparedNavigation,
        *,
        refresh_overlay: bool = True,
    ) -> None:
        layer = prepared.layer
        request = prepared.request
        if prepared.viewer_order is not None:
            server.viewer.dims.ndisplay = 2
            server.viewer.dims.order = prepared.viewer_order
        if request.visible is not None:
            layer.visible = request.visible
        if prepared.viewer_step is not None:
            server.viewer.dims.current_step = prepared.viewer_step
        if request.selected is True:
            server.viewer.layers.selection.active = layer
        elif (
            request.selected is False and server.viewer.layers.selection.active is layer
        ):
            server.viewer.layers.selection.active = None
        if request.data_index is not None:
            server.result_selection_controller.select(
                layer,
                request.data_index,
            )

        if refresh_overlay:
            server.display_pipeline.dimension_label_overlay.refresh()
        if request.data_index is not None:
            server.raise_result_selection_surface()

    def result_element_axis_indices(
        self,
        server: "NapariViewerServer",
        layer: NapariLayerHandle,
        route_key: str,
        data_index: int,
        *,
        displayed_axis_indices: tuple[int, ...] | None = None,
    ) -> dict[str, int]:
        """Derive one result element's route-local slice from native geometry."""

        NapariResultElementSelectionAuthority.require_data_index(layer, data_index)
        dimension_state = server.layer_route_state.dimension_state_for(route_key)
        if not dimension_state.axis_labels:
            return {}
        result_layer = cast(NapariShapesLayerHandle, layer)
        try:
            coordinates = result_layer.data[data_index]
        except IndexError as exc:
            raise ValueError(
                f"Viewer data_index {data_index} has no native layer geometry."
            ) from exc
        presentation = dimension_state.presentation
        if presentation is None:
            raise ValueError("Result selection requires a semantic route presentation.")
        dimensions = presentation.viewer_dimension_indices(server.viewer.dims.ndim)
        displayed = (
            tuple(server.viewer.dims.displayed)
            if displayed_axis_indices is None
            else displayed_axis_indices
        )
        items = server.component_groups.existing_items_for(route_key)
        if not items:
            raise ValueError("Result selection requires its original routed source items.")
        coordinate_authority = NapariLayerDisplayHandler.for_data_type(
            items[0].address.stream_layer_data_type,
        ).result_coordinate_authority
        return coordinate_authority.axis_indices(
            coordinates=cast(Sequence[object], coordinates),
            axis_labels=dimension_state.axis_labels,
            spatial_axis_labels=presentation.spatial_axis_labels,
            displayed_axis_indices=tuple(
                local_axis
                for local_axis, viewer_axis in enumerate(dimensions)
                if viewer_axis in displayed
            ),
        )

    def axis_step(
        self,
        server: "NapariViewerServer",
        layer: NapariLayerHandle,
        request: ViewerNavigationControlOptions,
    ) -> tuple[int, ...]:
        dimension_state = server.layer_route_state.dimension_state_for(
            request.route_key
        )
        axis_labels = dimension_state.axis_labels
        if not axis_labels:
            raise ValueError(
                f"Route {request.route_key!r} has no semantic axis labels to navigate."
            )
        current_step = [int(step) for step in server.viewer.dims.current_step]
        local_shape = NapariViewerStateProjection.layer_data_shape(layer)
        presentation = dimension_state.presentation
        if presentation is None:
            raise ValueError(
                f"Route {request.route_key!r} has no axis presentation for semantic navigation."
            )
        dimensions = presentation.viewer_dimension_indices(len(current_step))
        for axis_name, local_axis_index in request.axis_indices.items():
            axis_position = self._axis_position(
                axis_labels,
                axis_name,
                request.route_key,
            )
            if axis_position >= len(current_step):
                raise ValueError(
                    f"Axis {axis_name!r} is outside viewer current_step "
                    f"for route {request.route_key!r}."
                )
            self._validate_local_axis_index(
                dimension_state,
                local_shape,
                axis_name,
                axis_position,
                local_axis_index,
            )
            viewer_axis_origins = server.layer_route_state.axis_origins_for(axis_labels)
            current_step[dimensions[axis_position]] = presentation.viewer_step(
                local_axis_index,
                axis_position,
                viewer_axis_origin=viewer_axis_origins[axis_position],
            )
        return tuple(current_step)

    @staticmethod
    def _axis_position(
        axis_labels: tuple[str, ...],
        axis_name: str,
        route_key: str,
    ) -> int:
        if axis_name not in axis_labels:
            raise ValueError(
                f"Route {route_key!r} has no axis {axis_name!r}; "
                f"available axes are {axis_labels!r}."
            )
        return axis_labels.index(axis_name)

    @staticmethod
    def _validate_local_axis_index(
        dimension_state: NapariDimensionLayerState,
        local_shape: tuple[int, ...],
        axis_name: str,
        axis_position: int,
        local_axis_index: int,
    ) -> None:
        if axis_name in dimension_state.labels:
            local_extent = len(dimension_state.labels[axis_name])
        elif axis_position < len(local_shape):
            local_extent = local_shape[axis_position]
        else:
            return
        if local_axis_index >= local_extent:
            raise ValueError(
                f"Axis {axis_name!r} index {local_axis_index} is outside "
                f"the route-local extent {local_extent}."
            )


class NapariLayerRetirementControlMessageAction(NapariControlMessageAction):
    """Qt-owned registered action; the coordinator owns the retirement recipe."""

    message_type = OpenHCSViewerControlMessageType.RETIRE_LAYERS.value

    def handle(self, server, message) -> dict[str, object]:
        try:
            request = message.get(ViewerControlResponseField.PAYLOAD.value)
            if not isinstance(request, ViewerWindowLayerRetirementRequest):
                raise TypeError("Retirement requires ViewerWindowLayerRetirementRequest.")
            retired = _NAPARI_COMPONENT_DISPLAY_COORDINATOR.retire_layers(server, request)
            receipt = ViewerLayerRetirementReceipt(
                applied=True, retired_route_keys=retired,
                remaining_route_keys=tuple(server.layer_route_state.layers),
            )
            response = ViewerControlReplyHeader(
                ViewerProtocolStatus.SUCCESS, response_type="layer_retirement_ack",
            ).to_wire_mapping()
            response[ViewerControlField.RETIREMENT.value] = receipt.to_wire_mapping()
            return response
        except Exception as error:
            return ViewerControlReplyHeader(
                ViewerProtocolStatus.ERROR, response_type="layer_retirement_ack",
                message=str(error),
            ).to_wire_mapping()


class NapariLayerIsolationControlMessageAction(NapariControlMessageAction):
    """Apply one atomic visibility and selection projection to mounted layers."""

    message_type = ViewerControlMessageType.ISOLATE_LAYERS.value

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        if server.viewer is None:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="layer_isolation_ack",
                    message="Napari viewer is not available.",
                )
            ).to_wire_mapping()

        try:
            request = message.get(ViewerControlResponseField.PAYLOAD.value)
            if not isinstance(request, ViewerLayerIsolationControlOptions):
                raise TypeError(
                    "Napari layer isolation payload must be "
                    "ViewerLayerIsolationControlOptions."
                )
            changed_route_count, missing_route_keys = self._apply(server, request)
        except Exception as exc:
            return ViewerControlReplyPayload(
                ViewerControlReplyHeader(
                    ViewerProtocolStatus.ERROR,
                    response_type="layer_isolation_ack",
                    message=str(exc),
                )
            ).to_wire_mapping()

        applied = not missing_route_keys
        response = NapariViewerStateProjection(
            server=server,
            viewer=server.viewer,
            request=ViewerStateControlOptions.from_overrides(
                include_component_values=False,
                include_payload_summaries=False,
            ),
        ).to_wire_mapping()
        response[ViewerControlResponseField.TYPE.value] = "layer_isolation_ack"
        response[ViewerControlResponseField.MESSAGE.value] = (
            "Viewer layer isolation applied."
            if applied
            else "Viewer layer isolation was not applied because routes are missing."
        )
        response[ViewerLayerIsolationField.APPLIED.value] = applied
        response[ViewerLayerIsolationField.CHANGED_ROUTE_COUNT.value] = (
            changed_route_count
        )
        response[ViewerLayerIsolationField.MISSING_ROUTE_KEYS.value] = (
            missing_route_keys
        )
        return response

    @staticmethod
    def _apply(
        server: "NapariViewerServer",
        request: ViewerLayerIsolationControlOptions,
    ) -> tuple[int, tuple[str, ...]]:
        mounted_layers = tuple(
            (route_key, layer)
            for layer in server.viewer.layers
            if (route_key := server.layer_route_state.route_for_layer(layer))
            is not None
        )
        mounted_routes = frozenset(route_key for route_key, _ in mounted_layers)
        missing_route_keys = tuple(
            route_key
            for route_key in request.effective_visible_route_keys
            if route_key not in mounted_routes
        )
        if missing_route_keys:
            return 0, missing_route_keys

        navigation_action = NapariNavigationControlMessageAction()
        prepared_navigations = tuple(
            navigation_action.prepare(server, request.navigation_for(route_key))
            for route_key, _ in mounted_layers
        )
        changed_route_count = sum(
            prepared.changes_viewer_state(server) for prepared in prepared_navigations
        )
        for prepared in prepared_navigations:
            navigation_action.apply_prepared(
                server,
                prepared,
                refresh_overlay=False,
            )
        server.display_pipeline.dimension_label_overlay.refresh()
        return changed_route_count, ()


class NapariScreenshotControlMessageAction(
    NapariControlMessageAction, ViewerWindowSnapshotService
):
    """Registered action that captures the Napari Qt window."""

    message_type = ViewerControlMessageType.SCREENSHOT.value

    @staticmethod
    def qt_core():
        """Use Napari/Vispy's existing QtPy authority for timer and PNG device."""
        from qtpy import QtCore

        return QtCore

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        """Explicit immediate capture; observed conditions cannot bypass dispatch."""
        request = self.snapshot_request(server, message)
        return self._native_reply(
            server,
            self.snapshot_reply(
                self.snapshot_descriptor(server),
                super().capture(request),
            ),
        )

    def dispatch(self, server, message, completed, failed) -> None:
        super().request_viewer_capture(
            self.snapshot_request(server, message),
            self.snapshot_descriptor(server),
            partial(self._complete_native_reply, server, completed),
            failed,
        )

    @staticmethod
    def snapshot_descriptor(server) -> ViewerWindowDescriptor:
        return ViewerWindowDescriptor(
            viewer_type=ViewerType.NAPARI, title=server.napari_window_title
        )

    @staticmethod
    def snapshot_request(server, message):
        if server.viewer is None:
            raise ValueError("Napari viewer is not available.")

        from pyqt_reactive.services.window_snapshot import (
            QtWindowSnapshotRequest,
            OpenGLWidgetSnapshotRenderOwner,
            WindowSnapshotCaptureSpec,
        )

        capture_spec = message.get(ViewerControlResponseField.PAYLOAD.value)
        if not isinstance(capture_spec, WindowSnapshotCaptureSpec):
            raise TypeError(
                "Napari screenshot control payload must be WindowSnapshotCaptureSpec."
            )
        return QtWindowSnapshotRequest(
            widget=server.viewer.window.qt_viewer.window(),
            capture=capture_spec,
            subject_id=f"{ViewerType.NAPARI.wire_value}_{server.port}",
            title=server.napari_window_title,
            operation_deadline=capture_spec.snapshot_operation_deadline(),
            render_owner=OpenGLWidgetSnapshotRenderOwner(
                server.viewer.window.qt_viewer.canvas.native
            ),
        )

    def _complete_native_reply(self, server, completed, response) -> None:
        completed(self._native_reply(server, response))

    @staticmethod
    def _native_reply(server, response):
        response[ViewerControlField.NATIVE_DIMENSIONS.value] = (
            NapariViewerStateProjection.native_dimensions(
                server.viewer
            ).to_wire_mapping()
        )
        return response


class NapariUnknownControlMessageAction(NapariControlMessageAction):
    """Return a protocol error for an unregistered control message type."""

    message_type = None

    def handle(
        self,
        server: "NapariViewerServer",
        message: Mapping[str, object],
    ) -> dict[str, object]:
        del server
        requested_type = message.get(ViewerControlResponseField.TYPE.value)
        return ViewerControlReplyPayload(
            ViewerControlReplyHeader(
                ViewerProtocolStatus.ERROR,
                response_type=ResponseType.ERROR.value,
                message=f"Unsupported Napari control message: {requested_type!r}.",
            )
        ).to_wire_mapping()


class NapariStreamMessageHandler(NapariMessageTypeBase, metaclass=AutoRegisterMeta):
    """Registered handler for one Napari stream message type."""

    @classmethod
    def for_message_type(
        cls,
        message_type: ViewerBatchMessageType,
    ) -> "NapariStreamMessageHandler":
        if message_type not in cls.__registry__:
            raise ValueError(
                f"Napari stream messages must be registered message types, got {message_type!r}."
            )
        return cls.__registry__[message_type]()

    @abstractmethod
    def accept(
        self,
        server: "NapariViewerServer",
        data: Mapping[str, NapariWireValue],
    ) -> NapariAcceptedStreamBatch:
        """Copy one decoded stream message into receiver-owned memory."""


class NapariBatchStreamMessageHandler(NapariStreamMessageHandler):
    """Registered stream handler for batched Napari payloads."""

    message_type = ViewerBatchMessageType.BATCH

    def accept(
        self,
        server: "NapariViewerServer",
        data: Mapping[str, NapariWireValue],
    ) -> NapariAcceptedStreamBatch:
        batch_payload = NapariBatchPayload.from_json_payload(data)
        return NapariAcceptedStreamBatch(
            payload=batch_payload,
            items=tuple(
                server._accept_single_image(
                    image_info,
                    batch_payload,
                    batch_payload.viewer_display_config,
                )
                for image_info in batch_payload.images
            ),
        )


class NapariDataTransportPump:
    """Socket-owning stream intake that never waits for Qt rendering."""

    def __init__(self, server: "NapariViewerServer") -> None:
        self.server = server
        self._stop_event = threading.Event()
        self._ready_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._startup_error: Exception | None = None

    def start(self) -> None:
        """Bind and serve the data endpoint from its dedicated owner thread."""

        if self._thread is not None:
            raise RuntimeError("Napari data transport pump is already started.")
        self._stop_event.clear()
        self._ready_event.clear()
        self._startup_error = None
        self._thread = threading.Thread(
            target=self._serve,
            name=f"napari-data-transport-{self.server.port}",
            daemon=True,
        )
        self._thread.start()
        if not self._ready_event.wait(timeout=10.0):
            raise TimeoutError(
                f"Napari data transport failed to bind port {self.server.port}."
            )
        if self._startup_error is not None:
            raise RuntimeError(
                f"Napari data transport failed to start on port {self.server.port}."
            ) from self._startup_error

    def stop(self) -> None:
        """Stop intake and wait for the socket-owning thread to release it."""

        self._stop_event.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=5.0)
            if thread.is_alive():
                logger.warning(
                    "Napari data transport thread on port %s did not stop promptly",
                    self.server.port,
                )
        self._thread = None

    def _serve(self) -> None:
        context = zmq.Context()
        socket = None
        try:
            socket = self.server.bind_data_socket(context)
            poller = zmq.Poller()
            poller.register(socket, zmq.POLLIN)
            self._ready_event.set()
            logger.info(
                "🔬 NAPARI PROCESS: Data transport pump bound %s",
                self.server.data_transport_url(),
            )
            while not self._stop_event.is_set() and self.server.is_running():
                if socket not in dict(poller.poll(timeout=50)):
                    continue
                message = socket.recv()
                reply = self.server.accept_stream_message(message)
                socket.send_json(reply.to_wire_mapping())
        except Exception as error:
            if not self._ready_event.is_set():
                self._startup_error = error
                self._ready_event.set()
            elif not self._stop_event.is_set():
                logger.exception("🔬 NAPARI PROCESS: Data transport pump failed")
                self.server.record_transport_failure(error)
        finally:
            if socket is not None:
                socket.close(linger=0)
            context.term()


class NapariControlTransportPump:
    """Socket owner that keeps typed settlement observable while Qt renders."""

    def __init__(self, server: "NapariViewerServer") -> None:
        self.server = server
        self._stop_event = threading.Event()
        self._ready_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._startup_error: Exception | None = None

    def start(self) -> None:
        """Bind and serve the control endpoint from its dedicated owner thread."""

        if self._thread is not None:
            raise RuntimeError("Napari control transport pump is already started.")
        self._stop_event.clear()
        self._ready_event.clear()
        self._startup_error = None
        self._thread = threading.Thread(
            target=self._serve,
            name=f"napari-control-transport-{self.server.control_port}",
            daemon=True,
        )
        self._thread.start()
        if not self._ready_event.wait(timeout=10.0):
            raise TimeoutError(
                "Napari control transport failed to bind port "
                f"{self.server.control_port}."
            )
        if self._startup_error is not None:
            raise RuntimeError(
                "Napari control transport failed to start on port "
                f"{self.server.control_port}."
            ) from self._startup_error

    def stop(self) -> None:
        """Stop control intake and wait for the socket-owning thread."""

        self._stop_event.set()
        thread = self._thread
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=5.0)
            if thread.is_alive():
                logger.warning(
                    "Napari control transport thread on port %s did not stop promptly",
                    self.server.control_port,
                )
        self._thread = None

    def _serve(self) -> None:
        context = zmq.Context()
        socket = None
        try:
            socket = self.server.bind_control_socket(context)
            poller = zmq.Poller()
            poller.register(socket, zmq.POLLIN)
            self._ready_event.set()
            logger.info(
                "🔬 NAPARI PROCESS: Control transport pump bound %s",
                self.server.control_transport_url(),
            )
            while not self._stop_event.is_set() and self.server.is_running():
                if socket not in dict(poller.poll(timeout=50)):
                    continue
                payload = self._response_payload(socket.recv())
                socket.send(payload)
        except Exception as error:
            if not self._ready_event.is_set():
                self._startup_error = error
                self._ready_event.set()
            elif not self._stop_event.is_set():
                logger.exception("🔬 NAPARI PROCESS: Control transport pump failed")
                self.server.record_transport_failure(error)
        finally:
            if socket is not None:
                socket.close(linger=0)
            context.term()

    def _response_payload(self, request_payload: bytes) -> bytes:
        """Dispatch a control request to its declared thread owner."""

        try:
            message = pickle.loads(request_payload)
            if not isinstance(message, Mapping):
                raise TypeError("Napari control request must decode to a mapping.")
        except Exception as error:
            return self.server.serialize_control_response(
                self.server.control_error_response(error)
            )

        msg_type = message.get(ViewerControlResponseField.TYPE.value)
        if msg_type == ControlMessageType.PING.value:
            return self.server.control_response_payload(message)
        action = NapariControlMessageAction.for_message_type(
            msg_type if isinstance(msg_type, str) else None
        )
        transport_response = action.transport_thread_response(
            self.server,
            message,
        )
        if transport_response is not None:
            return self.server.serialize_control_response(transport_response)

        response_queue: queue.Queue[bytes] = queue.Queue(maxsize=1)
        self.server.accepted_control_requests.put(
            NapariAcceptedControlRequest(message, response_queue)
        )
        while True:
            try:
                return response_queue.get(timeout=0.05)
            except queue.Empty:
                if self._stop_event.is_set() or not self.server.is_running():
                    return self.server.serialize_control_response(
                        self.server.control_error_response(
                            RuntimeError(
                                "Napari viewer stopped before completing its "
                                "Qt-bound control request."
                            )
                        )
                    )


class NapariViewerServer(OpenHCSViewerServerABC):
    """
    ZMQ server for Napari viewer that receives images from clients.

    Inherits from ZMQServer ABC to get ping/pong, port management, etc.
    Uses a REP socket so each streamed payload retains acknowledgement semantics.
    """

    _server_type = ViewerType.NAPARI.wire_value

    def _create_pong_response(self):
        """Advertise the lifecycle actions registered by this viewer server."""

        return replace(
            super()._create_pong_response(),
            control_capabilities=(
                NapariControlMessageAction.endpoint_control_capabilities()
            ),
        )

    def __init__(self, request: NapariViewerServerRequest):
        """
        Initialize Napari viewer server.

        Args:
            request: Typed Napari server construction request.
        """
        # Initialize with REP socket for receiving images (synchronous request/reply)
        # REP socket forces workers to wait for acknowledgment before closing shared memory
        super().__init__(
            request.port,
            viewer_type=ViewerType.NAPARI.wire_value,
            host=request.process_launch.listen_host,
            log_file_path=request.log_file_path,
            data_socket_type=zmq.REP,
            transport_mode=request.transport_mode,
            config=OPENHCS_ZMQ_CONFIG,
        )
        # Advertise the endpoint application identity on every heartbeat so
        # clients can reject stale viewer endpoints before dispatch.
        self.application = OPENHCS_ENDPOINT_APPLICATION
        self.napari_window_title = request.viewer_title
        self.replace_layers = request.replace_layers
        self.process_launch = request.process_launch
        self.viewer = None
        self.result_selection_surface: NapariResultSelectionSurface | None = None
        self.result_selection_toolbar = None
        self.layer_route_state = NapariLayerRouteStateStore.empty()
        self.component_groups = NapariComponentGroupStore()
        self.component_name_metadata = ViewerComponentNameMetadata.empty()

        self.component_values = ViewerRouteComponentValueTracker()
        # Debouncing + locking for layer updates to prevent race conditions
        self.layer_update_lock = threading.Lock()  # Prevent concurrent updates
        self.layer_batch_processor_debounce_policy = NapariLayerBatchDebouncePolicy()
        self.batch_processors = NapariBatchProcessorStore(
            debounce_policy=self.layer_batch_processor_debounce_policy,
        )
        self.display_pipeline = NapariLayerDisplayPipeline(self)
        self.result_selection_controller = NapariResultSelectionController(self)
        self.accepted_stream_batches: queue.Queue[NapariAcceptedStreamBatch] = (
            queue.Queue()
        )
        self.accepted_control_requests: queue.Queue[NapariAcceptedControlRequest] = (
            queue.Queue()
        )
        self.data_transport_pump = NapariDataTransportPump(self)
        self.control_transport_pump = NapariControlTransportPump(self)
        self.transport_failure: Exception | None = None

        # Ack socket handled by StreamingVisualizerServer

    def raise_result_selection_surface(self) -> None:
        """Make the authoritative ROI table and Napari window prominent."""

        surface = self.require_result_selection_surface()
        surface.dock.show()
        surface.dock.raise_()
        NapariNativeWindowPresentation(surface.dock.window()).focus()

    def bind_result_selection_layer(self, layer: NapariLayerHandle) -> None:
        """Bind native selection behavior to one authoritative streamed layer."""

        self.result_selection_controller.bind(layer)
        surface = self.require_result_selection_surface()
        surface.manager.connect_layer(layer)
        surface.dock.show()

    def require_result_selection_surface(self) -> NapariResultSelectionSurface:
        """Mount and return the one first-party native ROI selection surface."""

        if self.viewer is None:
            raise RuntimeError("Napari viewer is not available.")
        if self.result_selection_surface is None:
            from openhcs.napari_roi_manager import QRoiManager

            manager = QRoiManager(self.viewer)
            dock = self.viewer.window.add_dock_widget(
                manager,
                name="OpenHCS ROI Manager",
                area="bottom",
                add_vertical_stretch=False,
            )
            self.result_selection_surface = NapariResultSelectionSurface(
                dock=dock,
                manager=manager,
            )
        return self.result_selection_surface

    def start(self) -> None:
        """Bind each ZMQ endpoint in its dedicated socket-owner thread."""

        with self._lock:
            if self._running:
                return
            self._running = True

        try:
            self.control_transport_pump.start()
            self.data_transport_pump.start()
        except Exception:
            self.stop()
            raise
        logger.info(
            "ZMQ Server started on %s (REP), control %s",
            self.data_transport_url(),
            self.control_transport_url(),
        )

    def stop(self) -> None:
        """Stop each socket from the same thread that created it."""

        with self._lock:
            self._running = False
        self.data_transport_pump.stop()
        self.control_transport_pump.stop()
        with self._lock:
            if self.transport_mode is TransportMode.IPC:
                remove_ipc_socket(self.port, self.config)
                remove_ipc_socket(self.control_port, self.config)
        logger.info("ZMQ Server stopped")

    def record_transport_failure(self, error: Exception) -> None:
        """Retain a terminal intake failure for control-plane diagnostics."""

        self.transport_failure = error

    def require_viewer(self):
        """Resolve native availability at its original lifecycle owner."""
        if self.viewer is None:
            raise RuntimeError("Napari viewer is not available.")
        return self.viewer

    def request_shutdown(self) -> None:
        """Stop accepting display work and cancel every deferred layer update."""

        super().request_shutdown()
        pending_updates = self.layer_route_state.drain_pending_updates()
        self.display_pipeline.clear_display_work()
        if pending_updates:
            logger.info(
                "🔬 NAPARI SERVER: Cancelled %d pending layer update(s) for shutdown",
                len(pending_updates),
            )

    def display_layer_batch(
        self,
        *,
        layer_key: str,
        items: list[NapariStreamLayerItem],
        display_payload: NapariPendingLayerUpdate,
        component_names_metadata: ViewerComponentNameMetadata,
    ) -> NapariLayerDisplayWork:
        """Display one debounced batch through the composed display pipeline."""
        return self.display_pipeline.display_layer_batch(
            layer_key=layer_key,
            items=items,
            display_payload=display_payload,
            component_names_metadata=component_names_metadata,
        )

    def clear_accumulated_stream_state(self) -> None:
        """Cancel intake work without orphaning inspectable mounted payloads.

        A pipeline execution is not a native-layer removal. Mounted raw and
        previous-result routes retain the data and domains that their controls
        inspect; unmounted intake belongs only to the cancelled stream cycle.
        """
        self.layer_route_state.reset_settlement()
        pending_updates = self.layer_route_state.drain_pending_updates()
        self.display_pipeline.clear_display_work()
        if pending_updates:
            logger.info(
                "🔬 NAPARI SERVER: Cancelled %d pending layer update(s) before "
                "clearing stream state",
                len(pending_updates),
            )
        if self.viewer is not None:
            _NAPARI_COMPONENT_DISPLAY_COORDINATOR._reconcile_deleted_layers(self)
        retained_routes = frozenset(self.layer_route_state.layers)
        for route_key in tuple(
            self.layer_route_state.layer_titles.keys()
            | self.component_groups.groups.keys()
        ):
            if route_key not in retained_routes:
                _NAPARI_COMPONENT_DISPLAY_COORDINATOR.purge_route(self, route_key)
        self.component_values.retain_routes(retained_routes)
        self.display_pipeline.reconcile_mounted_axis_projections(rematerialize=True)
        if not retained_routes:
            self.component_name_metadata.clear()
        self.layer_route_state.clear_update_errors()
        self.batch_processors = NapariBatchProcessorStore(
            debounce_policy=self.layer_batch_processor_debounce_policy,
        )

    def handle_control_message(
        self,
        message: Mapping[str, object],
    ) -> dict[str, object]:
        """
        Handle control messages beyond ping/pong.

        Supported message types:
        - shutdown: Graceful shutdown (closes viewer)
        - force_shutdown: Force shutdown (same as shutdown for Napari)
        - clear_state: Clear accumulated component groups (for new pipeline runs)
        """
        msg_type = message.get(ViewerControlResponseField.TYPE.value)
        if not isinstance(msg_type, str):
            msg_type = None
        return NapariControlMessageAction.for_message_type(msg_type).handle(
            self,
            message,
        )

    def display_image(self, image_data: np.ndarray, metadata: ComponentMap) -> None:
        """Display a single image payload (best-effort helper)."""
        image_info = {
            ViewerWireField.PATH.value: DEFAULT_DIRECT_IMAGE_PATH,
            ViewerWireField.DATA.value: image_data,
            ViewerWireField.SHAPE.value: image_data.shape,
            ViewerWireField.DTYPE.value: image_data.dtype,
            ViewerWireField.METADATA.value: metadata,
            ViewerWireField.PRODUCER_IDENTITY.value: StreamProducerIdentity.fixed_output(
                FixedStreamProducerIdentityKind.DIRECT,
                "direct_image",
            ).to_payload(),
        }
        self._process_single_image(
            image_info,
            ViewerComponentAxisSemanticsAuthority.empty(),
            NapariDisplayConfig(),
        )

    def accept_stream_message(self, message: bytes) -> NapariStreamMessageReply:
        """Copy one wire batch and enqueue it before acknowledging ownership."""

        import json

        msg_type: ViewerBatchMessageType | None = None
        try:
            data = json.loads(message.decode("utf-8"))
            msg_type = ViewerBatchMessageType(
                str(
                    PayloadMap(data, "Napari message").required(
                        ViewerBatchWireField.TYPE
                    )
                )
            )
            accepted_batch = NapariStreamMessageHandler.for_message_type(
                msg_type
            ).accept(self, data)
            # Receipt certifies ownership, not display completion. Invalidate a
            # prior terminal settlement before acknowledging this new work.
            with self.layer_route_state.mutation_boundary():
                self.layer_route_state.reset_settlement()
                self.accepted_stream_batches.put(accepted_batch)
            return NapariStreamMessageReply.success(msg_type)
        except Exception as error:
            logger.error(
                "🔬 NAPARI PROCESS: Failed to accept stream message: %s",
                error,
                exc_info=True,
            )
            return NapariStreamMessageReply.failure(msg_type, str(error))

    def process_accepted_stream_messages(self) -> int:
        """Drain receiver-owned batches into viewer state on the Qt thread."""

        processed_count = 0
        while True:
            try:
                accepted_batch = self.accepted_stream_batches.get_nowait()
            except queue.Empty:
                return processed_count
            try:
                accepted_batch.dispatch_to(self)
            except Exception as error:
                self.layer_route_state.record_update_error(None, error)
                logger.exception("Failed to project accepted Napari batch metadata")
            processed_count += 1

    def process_messages(self) -> None:
        """Drain control actions whose registered owners require the Qt thread."""

        while True:
            try:
                request = self.accepted_control_requests.get_nowait()
            except queue.Empty:
                return
            NapariControlMessageAction.dispatch_accepted_request(self, request)

    def _accept_single_image(
        self,
        image_info: Mapping[str, NapariWireValue],
        layer_axis_projection_semantics: ViewerComponentAxisSemantics,
        display_config: NapariDisplayConfig,
    ) -> NapariAcceptedStreamItem:
        """Materialize one payload without reading or mutating Qt state."""

        payload = NapariImagePayload.from_payload(
            image_info,
            layer_axis_projection_semantics,
            display_config,
        )
        loaded_data = _NAPARI_PAYLOAD_DATA_LOADER.load(payload)
        return NapariAcceptedStreamItem(payload=payload, data=loaded_data)

    def _process_single_image(
        self,
        image_info: Mapping[str, NapariWireValue],
        layer_axis_projection_semantics: ViewerComponentAxisSemantics,
        display_config: NapariDisplayConfig,
    ) -> None:
        """Materialize and display one direct payload on the Qt thread."""

        self._process_loaded_image(
            self._accept_single_image(
                image_info,
                layer_axis_projection_semantics,
                display_config,
            )
        )

    def _process_loaded_image(self, item: NapariAcceptedStreamItem) -> None:
        """Route one receiver-owned payload into deferred Napari display."""

        payload = item.payload
        payload_address = item.payload.address
        logger.info(
            f"🔍 NAPARI PROCESS: Received {payload_address.stream_layer_data_type} with metadata: {payload_address.components} (path: {payload_address.path})"
        )

        try:
            if isinstance(item.data, np.ndarray):
                logger.info(
                    "🔬 STREAM RECEIVE: path=%s components=%s %s",
                    payload_address.path,
                    payload_address.components,
                    NapariViewerStateProjection.array_summary(item.data),
                )
            _NAPARI_COMPONENT_DISPLAY_COORDINATOR.display(
                data=item.data,
                stream_layer_context=payload,
                server=self,
            )
            self.send_ack(payload.transfer, status=_ACK_SUCCESS)

        except Exception as e:
            self.layer_route_state.record_update_error(None, e)
            logger.error(
                f"🔬 NAPARI PROCESS: Failed to process {payload_address.stream_layer_data_type} {payload_address.path}: {e}",
                exc_info=True,
            )
            self.send_ack(payload.transfer, status=_ACK_ERROR, error=str(e))
            # Don't re-raise - continue processing other messages instead of crashing


def run_napari_viewer_process(
    port: int,
    viewer_title: str,
    replace_layers: bool = False,
    log_file_path: str | None = None,
    transport_mode: TransportMode = TransportMode.IPC,
    scope_accent_color: str | None = None,
    font_dpi: int | None = None,
    listen_host: str = "127.0.0.1",
) -> None:
    """
    Napari viewer process entry point. Runs in a separate process.
    Listens for ZeroMQ messages with image data to display.

    Args:
        port: ZMQ port to listen on
        viewer_title: Title for the napari viewer window
        replace_layers: If True, replace existing layers; if False, add new layers with unique names
        log_file_path: Path to log file (for client discovery via ping/pong)
        transport_mode: ZMQ transport mode (IPC or TCP)
        scope_accent_color: Exact UI-owned scope accent used to frame this window
        font_dpi: Explicit Qt font DPI applied before viewer construction
        listen_host: Explicit TCP bind interface; defaults to local-only
    """
    import polystore
    from openhcs.runtime.import_authority import OpenHCSRuntimeImportAuthority

    logger.warning(
        "Viewer import provenance: server=%s; openhcs_root=%s; polystore=%s",
        __file__,
        OpenHCSRuntimeImportAuthority.current().import_root,
        polystore.__file__,
    )
    server: NapariViewerServer | None = None
    try:
        request = NapariViewerServerRequest(
            port=port,
            viewer_title=viewer_title,
            replace_layers=replace_layers,
            log_file_path=log_file_path,
            transport_mode=transport_mode,
            process_launch=ViewerProcessLaunchConfig(
                qt_font_dpi=font_dpi,
                listen_host=listen_host,
            ),
        )

        # Create ZMQ server instance (inherits from ZMQServer ABC)
        server = NapariViewerServer(request)

        # OpenCV wheels can replace Qt's platform-plugin path when imported.
        # Reassert the active binding's authoritative path after module imports
        # and immediately before native Qt/Napari construction.
        ViewerQtEnvironmentPolicy(font_dpi=font_dpi).apply_to(os.environ)

        # Create napari viewer in this process (main thread)
        viewer = napari.Viewer(title=viewer_title, show=True)
        server.viewer = viewer
        from openhcs.runtime.napari_orthogonal_widget import OpenHCSOrthogonalWidget

        orthogonal_widget = OpenHCSOrthogonalWidget(server)
        viewer.window.add_dock_widget(
            orthogonal_widget, name="OpenHCS Spatial Planes", area="right"
        )
        result_selection_surface = server.require_result_selection_surface()
        _apply_default_window_layout(viewer, result_selection_surface.dock)
        server.result_selection_toolbar = _install_result_selection_toolbar(
            result_selection_surface.dock,
            server.result_selection_controller,
        )
        if scope_accent_color is not None:
            _apply_scope_accent_styling(
                result_selection_surface.dock,
                scope_accent_color,
            )
        logger.info("🔬 NAPARI PROCESS: Qt viewer construction complete")

        # Initialize layers dictionary with existing layers (for reconnection scenarios)
        for layer in viewer.layers:
            server.layer_route_state.set_layer(layer.name, layer)

        # Enable text overlay for dimension labels
        viewer.text_overlay.visible = True
        viewer.text_overlay.color = "white"
        viewer.text_overlay.font_size = 14

        # Use proper Qt event loop integration
        from qtpy import QtWidgets

        # Get the Qt application
        app = QtWidgets.QApplication.instance()
        if app is None:
            app = QtWidgets.QApplication(sys.argv)

        # Ensure the application DOES quit when the napari window closes
        app.setQuitOnLastWindowClosed(True)

        # Set up a QTimer for message processing
        message_service_started = False
        message_timer: QTimer | None = None
        message_service_start_error: Exception | None = None

        def fail_message_service_start(error: Exception) -> None:
            nonlocal message_service_start_error
            message_service_start_error = error
            if message_timer is not None:
                message_timer.stop()
            logger.exception("🔬 NAPARI PROCESS: Failed to start Qt message service")
            app.quit()

        def process_messages() -> None:
            nonlocal message_service_started
            if not message_service_started:
                try:
                    server.start()
                # A Qt callback cannot propagate to the launcher. Convert every
                # endpoint-start failure into the retained startup error instead.
                except Exception as error:  # noqa: BLE001
                    fail_message_service_start(error)
                    return
                message_service_started = True
                logger.info("🔬 NAPARI PROCESS: First Qt message-service callback")
                logger.info("🔬 NAPARI PROCESS: ZMQ endpoints bound")

            # The socket-owning transport thread has already copied shared-memory
            # payloads. Drain those immutable batches before control settlement so
            # a SETTLE request cannot overtake accepted display work.
            server.process_accepted_stream_messages()

            # Process control messages (ping/pong handled by ABC) on Qt because
            # viewer state and navigation remain Qt-owned.
            server.process_messages()

        # Do not publish transport endpoints until Qt has dispatched at least one
        # event and the recurring service timer is live. Endpoint presence must
        # never advertise a server that the event loop cannot yet service.
        def start_message_service() -> None:
            nonlocal message_timer
            message_timer = QTimer(app)
            try:
                message_timer.timeout.connect(process_messages)
                message_timer.start(50)
            except Exception as error:
                fail_message_service_start(error)

        QTimer.singleShot(0, start_message_service)

        logger.info("🔬 NAPARI PROCESS: Starting Qt event loop")

        # Run the Qt event loop - this keeps napari responsive
        app.exec_()
        if message_timer is not None:
            message_timer.stop()
        if message_service_start_error is not None:
            raise RuntimeError(
                "Napari Qt message service failed during startup."
            ) from message_service_start_error

    except Exception:
        logger.exception("🔬 NAPARI PROCESS: Fatal error")
        raise
    finally:
        logger.info("🔬 NAPARI PROCESS: Shutting down")
        if server is not None:
            server.stop()
