Exact selected original owners for PR404 ROI-only checkpoint
===========================================================

Original PR394 faf61ad87c550fa2d8ef44313344db74b378b857 supplies seven files:
core/steps/abstract.py, processing/materialization/core.py,
core/steps/function_artifact_materialization.py, core/steps/function_outputs.py,
core/virtual_workspace_metadata.py, core/orchestrator/worker_execution.py and
core/orchestrator/compiled_plate_execution.py. Paths are relative to openhcs.
Other imports are from receiving base 889bca2e1f69ef6bfb50ded599903c23b019ccbb.
The two orchestrator files close import dependencies on removed old functions;
no worker or scientific computation is invoked. Initial five-file collection
failure is retained. No compatibility alias was introduced to hide that failure.

Only two proposed files differ. Exact Git blobs:
core/steps/function_outputs.py:
  original 05b7fb539c4fbf7b0b1e8ab35b0e971dfc3f9d2a
  proposed d44e511e9711cde0b1c8d3fad93b00d8ddad7de4
core/virtual_workspace_metadata.py:
  original ff4abc6d0c387f7e2068e1f6332b961b5b253aed
  proposed 63ce7c84ff2b7807d00d09e5b93168caf94e2050

Original R0 synthetic exact proposed commit:
e960fe80e396e1c43447aa9990e133c985f22b3d
tree 8ab6dc59fe9c23122cbdea3f35da2de0c2e474ad
parent faf61ad87c550fa2d8ef44313344db74b378b857
No branch/ref, ordinary index or production worktree file changed.
The alternate index and raw detector output are archived. Original R0 owner:
/home/ts/wt/comms-ratchet-pinned-ui348-20261001 at
3b03785f45df2ef5dc62ba6aed99294192ecbb01, Python3.14, root openhcs.

Test history: collection failure; original four reds/one pass; 60-second
projected harness timeout with optional ImageJ bootstrap; corrected disk-only
factory gives two reds/three passes because metadata publishing was default-off
in the fixture; enabled explicit compiled metadata contract gives five passes.
Every input, original failure and final receipt is retained, without replaying
Dalton's scientific/native request. Result archives contain synthetic bytes;
geometry, array content and held-out sources are never decoded. The final suite
forbids optional backend bootstrap and repeated rendering after successful save.

The incomplete bootstrap cache was excluded from evidence archives and removed
after the first archive compared cleanly: exact owned cache/polystore/imagej,
1508931494 logical bytes, 1.5GiB reported filesystem usage. No scientific,
source or unknown-input data was removed.
