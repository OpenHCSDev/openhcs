import json,os,subprocess
from pathlib import Path
root=Path('/home/ts/code/projects/openhcs-kernel-readiness-fix');runs=root.parent/'openhcs-benchmark-runs'
roster=json.loads(Path('/tmp/kernel_readiness_broad_roster_20261001.json').read_text())
for i,p in enumerate(roster):
 while not (root/p).is_file():
  assert '/' in p,p
  p=p.rsplit('/',1)[0]+'.py'
 roster[i]=p
roster=sorted(set(roster)|{'tests/unit/test_cellprofiler_kernel_preparation.py','tests/unit/agent/test_mcp_dev_client_generated_inputs.py'})
env=dict(os.environ,PYTHONPATH=str(root),OPENHCS_CPU_ONLY='true',NUMBA_CACHE_DIR='/tmp/openhcs-source-identity-shared-cache-20260930',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
command=['/usr/bin/taskset','-c','5','/home/ts/code/projects/openhcs/.venv/bin/python','-m','pytest',*roster,'--junitxml='+str(runs/'kernel-readiness-broad-20261001.xml')]
(runs/'kernel-readiness-broad-source-20261001.json').write_text(json.dumps(dict(revision=revision,command=command,files=roster),indent=2)+'\n')
with (runs/'kernel-readiness-broad-20261001.log').open('w') as stream:
 result=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
