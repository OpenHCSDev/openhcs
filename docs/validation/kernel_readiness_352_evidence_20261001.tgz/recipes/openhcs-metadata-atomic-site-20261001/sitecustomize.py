import atexit,functools,importlib.abc,importlib.machinery,json,os,sys,time
from pathlib import Path
root=Path(os.environ["OPENHCS_DIAGNOSTIC_SOURCE"])
runs=Path("/home/ts/code/projects/openhcs-benchmark-runs")
ready=False
count=0
source_axis_counts={}
def emit(event):
    with (runs/"perf-main094-metadata-validation-events-20261001.jsonl").open("a") as stream:stream.write(json.dumps(event)+"\n")
def fast_without_axis(self):
    if self.plane_axis is None:raise ValueError("Image metadata has no leading plane axis to remove.")
    channel=self.source_channel_axis
    if channel==0:raise ValueError("Image metadata cannot declare the same leading axis as both plane and channel.")
    if channel is not None and channel>0:channel-=1
    return self.replace_fields(source_provenance=self.source_provenance.with_runtime_planes_as_contributors(),plane_axis=None,source_channel_axis=channel,source_plane_intensity_scales=(),source_plane_dtypes=(),unit_interval_intensity=None if self.unit_interval_intensity is None else self.unit_interval_intensity.without_source_planes())
class Loader(importlib.abc.Loader):
    def __init__(self,loader):self.loader=loader
    def create_module(self,spec):return self.loader.create_module(spec)
    def exec_module(self,module):
        self.loader.exec_module(module)
        if module.__name__=="numba.core.dispatcher":
            original=module.Dispatcher.compile
            @functools.wraps(original)
            def compile(dispatcher,*args,**kwargs):
                if not ready:return original(dispatcher,*args,**kwargs)
                prior=[str(s) for s in dispatcher.signatures];start=time.perf_counter()
                try:return original(dispatcher,*args,**kwargs)
                finally:emit(dict(kind="late_dispatcher_compile",module=dispatcher.py_func.__module__,function=dispatcher.py_func.__name__,signature=str(args[0]),prior_signatures=prior,seconds=time.perf_counter()-start))
            module.Dispatcher.compile=compile;return
        assert Path(module.__file__).resolve()==root/(module.__name__.replace(".","/")+".py")
        if module.__name__=="openhcs.core.runtime_image_values":
            module.ImagePayloadMetadata.without_leading_plane_axis=fast_without_axis
            return
        original=module.FunctionCatalogExecutionServer.prepare_runtime_capabilities
        @functools.wraps(original)
        def prepare(server,status_callback=None):
            global ready
            original(server,status_callback);ready=True;emit(dict(kind="readiness"))
        module.FunctionCatalogExecutionServer.prepare_runtime_capabilities=prepare
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname not in ("openhcs.core.runtime_image_values",):return None
        spec=importlib.machinery.PathFinder.find_spec(fullname,path,target)
        assert spec is not None and isinstance(spec.loader,importlib.machinery.SourceFileLoader)
        spec.loader=Loader(spec.loader);return spec
sys.meta_path.insert(0,Finder())
