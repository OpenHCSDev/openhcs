import csv
import fcntl
import json
import subprocess
from dataclasses import replace
from pathlib import Path

from benchmark.runtime_env import configure_headless_cpu_benchmark_runtime

configure_headless_cpu_benchmark_runtime('WARNING')

from benchmark.cellprofiler_comparison import (
    ComparisonMetricPolicy,
    load_comparison_cases,
    run_comparison_suite,
)
from openhcs.core.config import GlobalPipelineConfig
from openhcs.runtime.zmq_config import OPENHCS_ZMQ_CONFIG
from openhcs.runtime.zmq_execution_client import ZMQExecutionClient
from zmqruntime import DataControlPortPairAuthority

source = Path('/home/ts/code/projects/openhcs-kernel-readiness-fix')
runs = source.parent / 'openhcs-benchmark-runs'
manifest = source / 'benchmark/manifests/official30_portable_axis1.json'
output = runs / 'kernel-readiness-native-parity-20261001'
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert revision.startswith('e6a87e560'), revision
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()
rows = list(csv.DictReader((runs / 'official30-native-complete-fresh-20260928/observations.csv').open()))
native = {row['case_name']: Path(row['native_output_path']) for row in rows}
rescued = ('ExampleFly', 'ExampleYeastColonies', 'ExampleFlyURL',
           'ExampleIlluminationCorrection_Example1_AllMethod', 'ExampleUntangleWorms',
           'cp_tutorial_3d_monolayer', 'cp_tutorial_pixel_based_classification',
           'cp_tutorial_translocation_final')
cases = load_comparison_cases(manifest)
assert len(cases) == 30 and len(native) == 30
cases = tuple(sorted(cases, key=lambda case: (case.name not in rescued, cases.index(case))))
cases = tuple(replace(case, equivalence_reference_output_dir=native[case.name]) for case in cases)
assert all(case.equivalence_reference_output_dir.is_dir() for case in cases)
receipt = dict(source=str(source), revision=revision,
               base='094425c8c81324da7a3878379074e1bd8234ff52',
               native_reference_receipt='official30-native-complete-fresh-20260928/observations.csv',
               native_clocks_used_for_speedup=False,
               scope='one well, one inline worker, typed native parity; pipeline clocks exclude ready server startup',
               manifest=str(manifest), case_names=[case.name for case in cases])
(runs / 'kernel-readiness-native-parity-source-20261001.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt), flush=True)
port = DataControlPortPairAuthority.acquire(
    OPENHCS_ZMQ_CONFIG, transport_mode=OPENHCS_ZMQ_CONFIG.transport_mode).data_port
from scripts.mcp_thesis_demo_live import official_runtime_lock_path
lock_path = official_runtime_lock_path()
lock_path.parent.mkdir(parents=True, exist_ok=True)
lease = lock_path.open("a+")
fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
with lease, ZMQExecutionClient(port=port, persistent=False):
    print('Mandatory registry/kernel preparation complete; starting parity cases.', flush=True)
    observations = run_comparison_suite(
        cases, output_root=output, suite_id='kernel-readiness-native-parity-20261001',
        repeats=1, require_native_reference=True, continue_on_error=True,
        metric_policy=ComparisonMetricPolicy(collect_memory=False),
        coverage_manifest_path=manifest,
        openhcs_global_config=GlobalPipelineConfig(num_workers=1, use_threading=False),
        openhcs_execution_port=port,
        rerun_command=('taskset', '-c', '5', '/home/ts/code/projects/openhcs/.venv/bin/python', __file__),
        rerun_working_directory=Path.cwd())
print('Completed', len(observations), 'native comparisons', flush=True)
final = list(csv.DictReader((output/'observations.csv').open()))
failures = [{key: row[key] for key in ('case_name', 'equivalent', 'difference_count',
                                      'native_error_message', 'openhcs_error_message')}
            for row in final if row['equivalent'] != 'True']
print(json.dumps(dict(count=len(final), failures=failures), indent=2), flush=True)
assert len(final) == 30 and not failures
