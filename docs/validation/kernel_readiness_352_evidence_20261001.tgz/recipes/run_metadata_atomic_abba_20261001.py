import csv, hashlib, json, os, subprocess
from pathlib import Path
root=Path('/home/ts/code/projects/openhcs');runs=root.parent/'openhcs-benchmark-runs'
site=Path('/tmp/openhcs-metadata-atomic-site-20261001');site.mkdir(exist_ok=False)
original=Path('/tmp/openhcs-main094-metadata-validation-site-20261001/sitecustomize.py').read_text()
start=original.index('        if module.__name__=="openhcs.core.runtime_image_values":')
end=original.index('        original=module.FunctionCatalogExecutionServer.prepare_runtime_capabilities',start)
replacement='        if module.__name__=="openhcs.core.runtime_image_values":\n            module.ImagePayloadMetadata.without_leading_plane_axis=fast_without_axis\n            return\n'
source=original[:start]+replacement+original[end:]
# Measure the sole metadata change. Remove compile/readiness and diagnostic event hooks.
source=source.replace('("openhcs.core.runtime_image_values","numba.core.dispatcher","openhcs.runtime.zmq_execution_server")','("openhcs.core.runtime_image_values",)')
source=source[:source.index('atexit.register')]
(site/'sitecustomize.py').write_text(source)
observations=[]
for index,variant in enumerate(('control','candidate','candidate','control')):
 revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 assert revision=='094425c8c81324da7a3878379074e1bd8234ff52'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
 output=runs/f'perf-metadata-atomic-abba-{index}-{variant}-20261001';assert not output.exists()
 path=str(root) if variant=='control' else str(site)+':'+str(root)
 env=dict(os.environ,PYTHONPATH=path,OPENHCS_DIAGNOSTIC_SOURCE=str(root),OPENHCS_CPU_ONLY='true',NUMBA_CACHE_DIR='/tmp/openhcs-source-identity-shared-cache-20260930',OPENHCS_REFERENCE_EXPORT_PIPELINES_ROOT=str(root/'benchmark/reference_exports/official30_value_completion_20260914'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONHASHSEED='0')
 command=['/usr/bin/taskset','-c','5',str(root/'.venv/bin/python'),str(root/'scripts/benchmark_cppipe_well_throughput.py'),'--manifest',str(root/'benchmark/manifests/official30_portable_axis1.json'),'--mode','1w_1t','--case','cp_tutorial_3d_monolayer','--output-dir',str(output)]
 with output.with_suffix('.log').open('w') as stream: result=subprocess.run(command,cwd='/tmp',env=env,stdout=stream,stderr=subprocess.STDOUT)
 assert result.returncode==0,(index,result.returncode)
 rows=list(csv.DictReader((output/'well_throughput.csv').open()));assert len(rows)==1 and rows[0]['status']=='success'
 row=dict(index=index,variant=variant,source=revision,command=command,injection_sha256=hashlib.sha256(source.encode()).hexdigest(),diagnostic_injection=variant=='candidate',scope='ordinary public pipeline/default memory observer, CPU5 one well/thread; server startup/shutdown excluded; prototype performance admission only',result=rows[0])
 observations.append(row);(runs/'perf-metadata-atomic-abba-observations-20261001.json').write_text(json.dumps(observations,indent=2)+'\n')
 print(json.dumps(row),flush=True)
