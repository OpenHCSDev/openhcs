# OpenHCS configuration

from openhcs.core.config import (
    AnalysisConsolidationConfig,
    GlobalPipelineConfig,
    PathPlanningConfig,
    WellFilterConfig,
)
from pathlib import Path

path_root = Path('/home/ts/code/projects/openhcs-benchmark-runs/kernel-readiness-native-parity-20261001/tool_outputs/OpenHCS_ExampleFly_ExampleFlyURL')

config = GlobalPipelineConfig(
    materialization_results_path=path_root / 'images_ExampleFlyURL_converted_cppipe' / 'results',
    materialize_runtime_artifacts=False,
    well_filter_config=WellFilterConfig(
        well_filter=1
    ),
    analysis_consolidation_config=AnalysisConsolidationConfig(
        enabled=False
    ),
    path_planning_config=PathPlanningConfig(
        output_dir_suffix='_ExampleFlyURL_converted_cppipe',
        global_output_folder=path_root
    )
)