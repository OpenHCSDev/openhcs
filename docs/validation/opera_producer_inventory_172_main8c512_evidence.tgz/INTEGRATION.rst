PR333 normal main integration source evidence
============================================

Source owner only. Old public head a339a6d20c5c2b8c04ed3fecd3bd1496e7c839cf;
normal two-parent merge 03e3315d03fe775ed57ad71c5805507c946cfcf8 includes main
8c512d404f8707a6a1be311406c0af2a089360f7. Later publication adds documentation
and this archive only. No authored production/test changes after old head.

All shards run from
/home/ts/wt/openhcs-opera-producer-inventory-172-20261001 using the existing
/home/ts/code/projects/openhcs/.venv/bin/python, taskset -c 0,
PYTHONDONTWRITEBYTECODE=1, OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1,
MKL_NUM_THREADS=1 and TMPDIR equal to this owned scratch directory.
PYTHONPATH consists of the above worktree and
/home/ts/wt/polystore-metadata-namespace-327-20261001/src (read-only).
No environments/dependencies downloaded or changed. Original supervisor reused
byte-for-byte from the previous archive; one process group supervised per shard.
Exact child commands and observed limits/exit/time/RSS are in command JSON files.

Contracts: unittest discover -s tests/source_contracts -p test_*.py -v.
Regression: pytest --noconftest -o addopts= -p no:cacheprovider -q with existing
tests/unit/test_synthetic_generator_zero_geometry.py,
tests/unit/test_synthetic_generator_randomness.py,
tests/unit/test_synthetic_imagexpress_bioformats_compatibility.py and
tests/unit/test_source_projection.py.
Identity: verify_integration_identity.py, unchanged public import origins,
Git-object byte equality and exact two-parent merge, old archive and frozen XML.
No patched assertions, weakened tests, changed cap or caller/registry branches.

Resource guard run before shards returned warning exit 2: 21.0 GiB available
RAM, home 19.9 GiB (user 20 GiB threshold warning-only), swap 13.7 GiB, root
8.2 GiB. This is not a guard pass. All shard summaries show limit null and exit0.
Disposable scratch size remains far below 256 MiB. Only owned terminal scratch
is removed after fresh archive extraction and byte comparison.

ACCEPTANCE.parent.rst is an exact read-only copy of the parent receipt at
/home/ts/wt/openhcs-issue-batch-20260929/producer-installed-20261001/ACCEPTANCE.rst.
This source owner did not run/replay MCP, install anything or claim acceptance
of the later main compiler/runtime delta. Parent's successful original live
journey remains pinned to 67db source/a339 docs. Parent qualifies applicability.
Issue337 read-only inspection belongs to Arendt; no competing patch.

Current full-context R1 is INCOMPLETE at its enforced 512 MiB cap before head
comparison; no rerun, waiver, metric gaming or broad guard pass. Original old
source archive is unchanged SHA256
326541e4ccb3a4b5378ad4322614c4d9bdc03448bba9575535548f02285aaa7b,
and retains its actual historical old pin/baseline/negative witnesses.
