"""Owned disposable command supervisor; no product/runtime changes."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

scratch = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
start = time.monotonic()
peak = 0
reason = None
with (scratch / f"{name}.log").open("w") as output:
    process = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT,
                               start_new_session=True)
    while process.poll() is None:
        rss = 0
        for stat_path in Path("/proc").glob("[0-9]*/stat"):
            try:
                stat = stat_path.read_text().rpartition(") ")[2].split()
                if int(stat[2]) == process.pid:
                    rss += int(stat[21]) * os.sysconf("SC_PAGE_SIZE")
            except (OSError, ValueError, IndexError):
                continue
        peak = max(peak, rss)
        scratch_bytes = sum(p.stat().st_size for p in scratch.rglob("*") if p.is_file())
        if rss > 512 * 1024**2:
            reason = "512 MiB combined process-group RSS"
        elif scratch_bytes > 256 * 1024**2:
            reason = "256 MiB owned scratch"
        elif time.monotonic() - start > 60:
            reason = "60s shard"
        if reason:
            os.killpg(process.pid, signal.SIGKILL)
            break
        time.sleep(0.05)
    result = process.wait()
summary = dict(command=command, exit=result, limit=reason,
               peak_rss_mib=round(peak / 1024**2, 2),
               seconds=round(time.monotonic() - start, 2))
(scratch / f"{name}.command.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary))
log = (scratch / f"{name}.log").read_text()
print(log if len(log) < 8000 else f"Full output: {scratch / f'{name}.log'}")
sys.exit(result if result >= 0 else 1)
