Installed producer MCP acceptance
=================================

Parent integration owner. Reviewed source67dbefb3caf8848901f6561d6bd274a84accee92;
PR333a339a6d20c5c2b8c04ed3fecd3bd1496e7c839cf adds only receipt/archive.
Wheel SHA2564738a7cb1362a83a2f4a8df68f1076e38925fdbf93c70adb706589d51d3e294f.
The separate candidate installation and full managed13-file skill copy were
verified against that source, without modifying frozen blind installations.

Original installed public MCP journey
-------------------------------------

Read live.stdin/live.stdout/live.timing. Original shell71660 terminated
normally at2026-10-01T05:22:05Z with exit0. Initial/final MCP health identify
the same PID640178 and started_at1790831781.5360966; version0.8.7,56 packaged
resources ready, no stale sources or reconnect/restart required. No operation
was replayed or replaced after an observation timeout. PID is now absent and
the original validation.lock can be acquired. Parent Xvfb/VNC and desktop
windows were not changed; no scientific/native/JVM/viewer launch occurred.

Actual first-use/folder-onboarding/pipeline guidance and capability discovery
preceded mutation. Four disposable 32x32,1x1-grid,2-channel,2-Z fixtures used
seed7,4 cells,zero overlap and zero stage error, omitted singleton tokens:
raw/native Opera and raw/native ImageXpress. All four returned4 images with
no error/warning. Source physical paths include unpadded Opera site tokens
and repeated ImageXpress basenames under distinct ZStep folders.

Four empty PipelineDocument artifact-plan calls initialized raw layouts and
reopened native workspaces. All produced four distinct complete logical
addresses, channel1/2,Z1/2,site1,time1,one well (Opera R01C01;ImageXpress A01).
Every source reference resolves to its exact existing physical file. The two
raw calls report the expected initialization warning; native calls do not.
No processing steps, execution jobs or axis work were introduced.

SourceVoxelSpacing and OpenHCSPlaneAddress owners decode the captured records
in verify_live_receipts.py; no alternate product parser/schema was authored.
Native/raw inventories agree by typed address despite legitimate virtual-path
prefix differences. Opera physical calibration is1.1867525298988042um/pixel;
ImageXpress0.65um/pixel, with matching persisted physical per-plane spacing.
Eight exposed MCP samples at native origin8/8,size8x8,source32x32uint16 confirm
four raw/native pairs have identical64 pixel values and typed address/spacing:
channel1/Z1 and channel2/Z2 for both microscopes. This is bounded sample parity,
not a complete-array identity proof or biological accuracy evidence.

Four final read-only inspections reopen persisted workspace inventories with
all four planes and all five correct component catalogs, no errors/warnings.
Administrative original-record verifier ran from the actual installed-I-B
Python and exited0 in0.293s. It parses the30 original captured MCP responses
and never reopens image arrays or replays commands. Transcript SHA256:
3c42cf3ea4c0859e9315a85c76ec5fb15e5f724d35027d694afec5cc538970c2.

Limits and separate defect
-------------------------

Initial raw ImageXpress read-only inspection reports Z1 only despite listing
four physical files across ZStep_1 and ZStep_2. After real initialization it
correctly reports Z1/2. The read-only inventory consumer calls
parser.parse_filename(Path(filename).name), discarding folder coordinates;
the ImageXpress acquisition handler already owns those semantics. This is a
separate inspection defect, not source-plane loss in the qualified producer.
Fix it through existing nominal source/handler ownership without mutating a
raw workspace merely to inspect it or duplicating a ZStep regex in the service.

Original R0 and focused source behavior are qualified in PR333's archive.
Parent's unchanged full-context R1 completed baseline analysis then hit its
512MiB enforced group-RSS cap before head comparison. R1 is INCOMPLETE, not
passed, waived or a reason to claim full ZIP/surface closure. Preserve exact
original logs and source context. Remote main's later compiler331 merge is
not part of this installed source pin; normal integration and affected-delta
qualification remain separate from this exact successful journey.
