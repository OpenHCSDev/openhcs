"""Source-only identity witness; uses ordinary public module imports."""
import hashlib
import importlib
from pathlib import Path
import subprocess

ROOT = Path('/home/ts/wt/openhcs-opera-producer-inventory-172-20261001')
OLD = 'a339a6d20c5c2b8c04ed3fecd3bd1496e7c839cf'
MAIN = '8c512d404f8707a6a1be311406c0af2a089360f7'
MERGE = '03e3315d03fe775ed57ad71c5805507c946cfcf8'
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

assert git('rev-parse', 'HEAD').decode().strip() == MERGE
assert git('rev-list', '--parents', '-n', '1', MERGE).decode().split() == [MERGE, OLD, MAIN]
modules = (
    'openhcs.demo.synthetic_data',
    'openhcs.core.components.parser_metaprogramming',
    'openhcs.microscopes.imagexpress',
    'openhcs.microscopes.opera_phenix',
    'openhcs.core.virtual_workspace_metadata',
    'openhcs.core.artifacts',
)
for name in modules:
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    relative = path.relative_to(ROOT).as_posix()
    authority = OLD if name in modules[:4] else MAIN
    assert path.read_bytes() == git('show', f'{authority}:{relative}')
    print(name, relative, hashlib.sha256(path.read_bytes()).hexdigest(), authority)

for relative in (
    'tests/integration/helpers/fixture_utils.py',
    'tests/source_contracts/test_synthetic_acquisition_identity.py',
    'openhcs/microscopes/opera_phenix_xml_parser.py',
    'docs/validation/opera_producer_inventory_172_source_evidence.tgz',
):
    data = (ROOT / relative).read_bytes()
    assert data == git('show', f'{OLD}:{relative}')
    print('unchanged', relative, hashlib.sha256(data).hexdigest(), OLD)
print('PASS: ordinary imports, exact merge parents, owned source/tests, frozen XML and original archive')
