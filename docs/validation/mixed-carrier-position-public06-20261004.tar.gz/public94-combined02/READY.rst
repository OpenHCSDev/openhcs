One combined600/614 native-only receiving loan
============================================

Singer is sole original recorded-client/native custodian. Dewey publishes the
existing FUND once. No scientist/provider/viewer/helper is launched by this
publication. Existing three references remain byte-exact; two are already
terminal and do not count as active science. P00188 remains uninterrupted.

Exact qualified package02 target/source42203213 and whole proof are named by
../COMBINED-READY02.rst and ../package02/BYTE-QUALIFICATION.json. No dependency
on PR612/PyQt publication. Two tiny registered cases share ONE original native
6012/ACK7012 process and ONE recorded client; viewer ports disabled, DISPLAY94,
CPU8. All failure/UNKNOWN inputs remain nonreplayable. Normal typed close,
process exit, endpoints and original client EOF are Singer's responsibilities.

Positive predecessor custody is the original public94-catalog/NATIVE-RECEIVING
receipt: PTY86785 terminal0 and native80562 exact typed process_exited=true.
Current80562/79625/79249 absent and all four old endpoints empty corroborate
that receipt, not substitute for it. Existing X/WM/VNC InvocationIDs match the
original helper handoff; all memory/swap properties infinity. No helper changes.

64Mi retained/192Mi scratch are incremental planning estimates for this small
public receiving, not enforced quotas. Actual host pressure and disk checks
remain original. No arbitrary RAM cap is imposed. Both source proposals and
original public sample expectations are in ../COMBINED-READY02.rst; no private
scientific case or current scientist output is used.

Once the original source/input/target seal and atomic publication pass, Singer
starts ONCE with tools.exec_command tty=true, retaining that original handle::

  bash /home/ts/wt/openhcs-issue-batch-20260929/engineering-ongoing-disk-pressure-20261004/source/scripts/blind_analysis/operations/recorded-mcp.sh /home/ts/wt/openhcs-issue-batch-20260929/next-three-taskonly539543-20261003/FUND ENGINEERING600614_94 singer600614_start01

The original recorder performs fresh startup admission before log creation.
No second client, adoption by port, observer runtime or scientific launch.
