"""Validate this synthetic case's original public replies and native export."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).parent
engineering = root.parent
target = engineering / 'package02/target'
sys.path.insert(0, str(target))
output = root / 'ENGINEERING600614_94/author-workspace/output'
transcript = output / 'runtime/mcp.stdout'
text = transcript.read_text()
decoder = json.JSONDecoder()
cursor = 0
replies = []
while cursor < len(text):
    start = text.find('{', cursor)
    if start < 0:
        break
    try:
        document, cursor = decoder.raw_decode(text, start)
    except json.JSONDecodeError:
        cursor = start + 1
        continue
    if isinstance(document, dict) and 'results' in document:
        replies.extend(document['results'])

import numpy as np
from skimage.color import rgb2gray
import openhcs
from openhcs.core.runtime_image_values import image_payload_data, image_payload_metadata
from openhcs.runtime.zmq_execution_observation import ZMQRuntimeExecutionObservationExport
assert Path(openhcs.__file__).is_relative_to(target)

samples = [item['payloads'][0] for item in replies
           if item['tool'] == 'openhcs_sample_plate_image']
scalar = np.arange(180, dtype=np.uint8).reshape(12, 15)
rgb = np.stack((scalar, np.full_like(scalar, 32), np.full_like(scalar, 240)), axis=-1)
gray_expected = scalar.astype(np.float32) / 255
color_expected = rgb2gray(rgb.astype(np.float32) / 255)
expected_intensity = {
    'GrayIndependent': gray_expected,
    'ColorIndependent': color_expected,
    'Forward': (gray_expected + color_expected) / 2,
    'Reverse': (gray_expected + color_expected) / 2,
}
validated = []
for name, expected in expected_intensity.items():
    matches = [sample for sample in samples if '/results-intensity02/' in sample['plate_path']
               and sample['requested_image_path'].endswith('_' + name + '.tif')]
    assert len(matches) == 1, (name, len(matches))
    sample = matches[0]
    assert sample['errors'] == [] and sample['sample_included']
    assert sample['sample_shape'] == [12, 15] and sample['selected_resolution_index'] == 0
    actual = np.asarray(sample['sample_values'], dtype=np.float32)
    np.testing.assert_allclose(actual, expected)
    assert sample['source_metadata']['OpenHCSSourceVoxelSpacingZYX'] == '0.5,0.5'
    assert sample['source_metadata']['OpenHCSSourceVoxelSpacingUnit'] == 'micrometers'
    validated.append(dict(name=name, elements=actual.size,
        maximum_absolute_error=float(np.max(np.abs(actual - expected)))))

for channel in (1, 2):
    matches = [sample for sample in samples if '/results-positions01/' in sample['plate_path']
               and sample['source_metadata']['channel'] == channel]
    assert len(matches) == 1, (channel, len(matches))
    sample = matches[0]
    assert sample['errors'] == [] and sample['sample_included']
    assert sample['sample_shape'] == [14, 20] and sample['selected_resolution_index'] == 0
    expected = np.zeros((14, 20), dtype=np.uint16)
    for site in range(1, 10):
        row, column = divmod(site - 1, 3)
        expected[row * 5:row * 5 + 4, column * 7:column * 7 + 6] = 10 * channel + site
    np.testing.assert_array_equal(np.asarray(sample['sample_values']), expected)
    assert sample['source_metadata']['OpenHCSSourceVoxelSpacingZYX'] == '0.25,0.5'
    assert sample['source_metadata']['OpenHCSSourceVoxelSpacingUnit'] == 'micrometers'
    validated.append(dict(name='MosaicChannel' + str(channel), elements=expected.size,
        maximum_absolute_error=0))

observations = {}
for name in ('intensity-values02.json', 'positions-values01.json'):
    export = ZMQRuntimeExecutionObservationExport.read(output / name)
    observation = export.require_valid_observation()
    records = [record for group in observation.records_by_axis.values() for record in group]
    print('NATIVE_RECORDS', name, [(record.key.name, record.key.scope.value,
        type(record.data).__name__) for record in records], flush=True)
    observations[name] = (export, records)

positions_export, position_records = observations['positions-values01.json']
position_values = [record for record in position_records if record.key.name == 'positions']
assert len(position_values) == 2
expected_positions = [(column * 7 - 2, row * 5 - 1)
                      for row in range(3) for column in range(3)]
for record in position_values:
    np.testing.assert_array_equal(record.data, expected_positions)
    assert record.key.scope.axis_id == 'A01'
    assert record.key.scope.value in ('1', '2')
    metadata = record.materialization_source_metadata
    assert metadata is not None
    records = metadata.source_metadata_by_payload()
    print('POSITION_SOURCE_PLANES', record.key.scope.value, len(records), flush=True)
    assert len(records) == 9
    sites = [int(item.source_component_metadata['site']) for item in records]
    channels = [str(item.source_component_metadata['channel']) for item in records]
    assert sites == list(range(1, 10))
    assert channels == [record.key.scope.value] * 9

intensity_export, intensity_records = observations['intensity-values02.json']
for name, expected in expected_intensity.items():
    records = [record for record in intensity_records if record.key.name == name]
    assert len(records) == 1, (name, len(records))
    np.testing.assert_allclose(np.asarray(image_payload_data(records[0].data)).squeeze(), expected)
    metadata = image_payload_metadata(records[0].data)
    print('INTENSITY_PROVENANCE', name, metadata.source_provenance.represented_source_image_names,
          len(metadata.source_provenance.represented_source_identities), flush=True)

for packet, acquisition in (('public-packet01', 'acquisition-intensity01'),
                            ('public-positions01', 'acquisition-positions01')):
    inputs = json.loads((engineering / packet / 'INPUTS.json').read_text())
    for item in inputs:
        path = output / acquisition / Path(item['path']).name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item['sha256']

print(json.dumps(dict(status='PASS', source_head='42203213d744b2b0393c9966868e8d02ec45c3d9',
    imported=str(openhcs.__file__), public_samples=validated,
    execution_ids=[intensity_export.execution_id, positions_export.execution_id],
    transcript_sha256=hashlib.sha256(transcript.read_bytes()).hexdigest()), indent=2), flush=True)
