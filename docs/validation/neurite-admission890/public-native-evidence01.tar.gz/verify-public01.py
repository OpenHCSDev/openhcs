"""Read original installed runtime observations and saved admission evidence."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np
import tifffile
import openhcs
from openhcs.runtime.zmq_execution_observation import ZMQRuntimeExecutionObservationExport
from openhcs.core.runtime_image_values import image_payload_data, image_payload_metadata

root = Path('/run/media/ts/hdd/openhcs-engineering/engineering893-public96-receiving20')
target = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering-pre-first-routing-20261004/receiving20/target')
assert Path(openhcs.__file__).is_relative_to(target)
export = ZMQRuntimeExecutionObservationExport.read(root / 'values01')
export.require_valid_observation()
records = export.records_by_axis['A01']
assert len(records) == 17, len(records)
by_name = {record.key.name: record for record in records}
images = root / 'results/acquisition_openhcs/images'
stem = 'A01_s001_w2_z001_t001'
planes = {}
proof = {}
for field in ('enhanced_response', 'threshold_support', 'retained_support', 'local_response', 'local_support'):
    name = 'neurite_' + field
    record = by_name[name]
    values = np.asarray(image_payload_data(record.data)).squeeze()
    path = images / (stem + '_' + name + '.checkpoint.tif')
    saved = tifffile.imread(path).squeeze()
    assert saved.shape == values.shape == (128, 128)
    np.testing.assert_array_equal(saved, values)
    if field.endswith('response'):
        assert saved.dtype == np.float32
    else:
        assert saved.dtype == np.bool_
    metadata = image_payload_metadata(record.data)
    assert metadata.source_voxel_spacing.values_zyx == (.5, .5)
    planes[field] = saved
    proof[name] = {'shape': list(saved.shape), 'dtype': str(saved.dtype), 'minimum': float(saved.min()), 'maximum': float(saved.max()), 'runtime_equal_saved_elements': saved.size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'metadata': repr(metadata)}
np.testing.assert_array_equal(planes['threshold_support'], planes['retained_support'])
np.testing.assert_array_equal(planes['local_support'], planes['local_response'] >= 100)
candidate = tifffile.imread(images / (stem + '_neurite_candidate_mask.checkpoint.tif')).squeeze()
np.testing.assert_array_equal(candidate, planes['retained_support'] & planes['local_support'])
raw = tifffile.imread(root / 'acquisition/A01_s1_w2_z1_t1.tif')
np.testing.assert_array_equal(raw, tifffile.imread(images / (stem + '.tif')))
tables = {}
for path in (root / 'results/acquisition_openhcs/results').glob('*details.csv'):
    with path.open(newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert rows and all(row['coordinate_unit'] == 'pixels' for row in rows)
    tables[path.name] = len(rows)
graph = by_name['neurite_morphology'].data
assert graph.coordinate_spacing.unit.value == 'pixels'
assert graph.source_voxel_spacing.values_zyx == (.5, .5)
print(json.dumps({'installed_origin': openhcs.__file__, 'execution_id': export.execution_id, 'valid_observation': True, 'runtime_artifact_count': len(records), 'response_planes': proof, 'candidate_intersection_equal': True, 'disabled_seed_retention_equal': True, 'raw_unchanged_elements': raw.size, 'graph_edge_count': len(graph.edges), 'csv_rows': tables, 'values_sha256': hashlib.sha256((root / 'values01').read_bytes()).hexdigest()}, indent=2))
