"""Check original public replies against saved engineering values, no execution."""
from pathlib import Path
import hashlib
import json
import numpy as np
import tifffile

receipt = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering893/public96-receiving20')
root = Path('/run/media/ts/hdd/openhcs-engineering/engineering893-public96-receiving20')
runtime = receipt / 'ADMIN893_PUBLIC20_96/author-workspace/output/runtime'
text = (runtime / 'mcp.stdout').read_text()
decoder = json.JSONDecoder()
position = 0
replies = []
while position < len(text):
    position = text.find('{', position)
    if position < 0:
        break
    try:
        value, length = decoder.raw_decode(text[position:])
    except ValueError:
        position += 1
        continue
    position += length
    if isinstance(value, dict) and 'results' in value:
        for result in value['results']:
            assert not result['mcp_error'], result
            replies.extend((result['tool'], payload) for payload in result['payloads'])
assert replies
images = root / 'results/acquisition_openhcs'
sample_proofs = []
for tool, payload in replies:
    if tool == 'openhcs_sample_plate_image':
        saved = tifffile.imread(images / payload['virtual_path']).squeeze()
        np.testing.assert_array_equal(np.asarray(payload['sample_values'], dtype=saved.dtype), saved[60:68, 60:68])
        assert payload['dtype'] == 'float32'
        sample_proofs.append({'tool': tool, 'path': payload['virtual_path'], 'exact_elements': 64})
    if tool == 'openhcs_sample_viewer_window_image':
        assert payload['observed'] and payload['returned_record_count'] == 1
        record = payload['records'][0]
        saved = tifffile.imread(images / record['summary']['path']).squeeze()
        np.testing.assert_array_equal(np.asarray(record['array_values'], dtype=saved.dtype), saved[60:68, 60:68])
        assert record['summary']['dtype'] == 'float32'
        sample_proofs.append({'tool': tool, 'path': record['summary']['path'], 'exact_elements': 64})
states = [payload for tool, payload in replies if tool == 'openhcs_get_viewer_window_state']
assert len(states) >= 3
assert states[0]['native_viewport'] == states[-1]['native_viewport']
assert states[0]['native_dimensions'] == states[-1]['native_dimensions']
for layer in states[-1]['layers']:
    assert not layer['pending_update']
    assert layer['native_transform']['scale'][-2:] == [.5, .5]
    assert layer['native_transform']['translate'][-2:] == [0., 0.]
    summary = layer['payload_summaries'][0]
    assert summary['components'] == {'channel': 2, 'site': 1, 'z_index': 1, 'timepoint': 1, 'well': 'A01'}
    assert summary['shape'] == summary['source_spatial_shape_yx'] == [128, 128]
    assert summary['spatial_origin_yx'] == [0, 0]
    assert summary['source_voxel_spacing'] == {'unit': 'micrometers', 'values_zyx': [.5, .5]}
captures = []
for tool, payload in replies:
    if tool == 'openhcs_viewer_snapshot_window':
        assert payload['captured'] and payload['frame_condition'] == 'render_complete'
        resource = payload['resource']
        path = Path(resource['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == resource['sha256']
        captures.append({'path': str(path), 'sha256': resource['sha256']})
assert len(captures) == 5
viewer_close = next(payload for tool, payload in replies if tool == 'openhcs_close_viewer_window')
native_close = next(payload['outcome'] for tool, payload in replies if tool == 'openhcs_close_owned_runtime')
assert all(close['acknowledged'] and close['process_exited'] and close['succeeded'] for close in (viewer_close, native_close))
assert len(sample_proofs) == 4
print(json.dumps({'public_reply_count': len(replies), 'public_and_native_float_samples': sample_proofs, 'matched_native_viewport': states[-1]['native_viewport'], 'mounted_route_count': len(states[-1]['layers']), 'all_routes_source_channel': 2, 'native_scale_yx': [.5,.5], 'full_source_shape_yx': [128,128], 'captures': captures, 'viewer_close': viewer_close, 'native_close': native_close, 'mcp_journals': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (runtime/'mcp.stdin', runtime/'mcp.stdout', runtime/'mcp.timing')}}, indent=2))
