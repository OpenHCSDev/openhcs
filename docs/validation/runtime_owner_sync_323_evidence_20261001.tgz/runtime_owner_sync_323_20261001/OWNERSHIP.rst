Runtime cache declaration identity and test context lifetime
==========================================================

Context: production 68aed451f, synchronized with main 8c512d404; complete original
ClassDef census 5,129/5,117 with all 12 OPEN retained, before and after. Original
R1 uses complete dependency context and its two configured detectors. Existing
R0/R1 do not prove authored semantics or all-detector cleanliness.

Question: which declared type owns a process-local singleton and construction
lock? ProcessLocalBoundedCache states one singleton per concrete subclass.
Attribute inheritance previously made a warmed parent authoritative for a new
child. Required owner/consumer pair: subclass declaration -> shared lifetime
owner's cooperative __init_subclass__; process_cache/clear_process_cache consume
those owned attributes. Forbidden: numerical consumer repair, mirror registry,
or runtime type/absence fallback to compensate for an inherited singleton.
BoundedCache retains LRU storage; SynchronizedBoundedCache retains instance
mutation locking; AutoRegisterMeta retains registration and cleanup views.
The existing slotted dataclass replaces its class object, so the cooperative
super call names the final public owner instead of the original __class__ cell.
Actual MRO/hook, construction, concurrent child, slotted-child and warmed-diamond
behavior is executed in tests. This initialization correction is authored; no
NRA operation is claimed to prove its runtime equivalence. Four pre-fix controls
fail; all corrected controls pass, including registered/identity-bound families.

Independent test-context question: who restores saved/live global projections?
Existing objectstate.global_config.GlobalContextValues owns capture/apply. Two
source-projection tests now scope their global edits with a pytest fixture using
that owner. No new context schema, default reset, fabricated HTD metadata or
microscope/admission bypass. Unchanged main passes checkpoint tests alone but
fails 2/101 in the specified module order. Corrected ordered and broad controls
pass with strict original address/pixel/calibration assertions.

Production consumers of the broader PR remain store queries, six numerical
object-column consumers, registered kernel providers, four numerical cache
domains and logger-bound profiling. Their algorithms/provider effects retain
their nominal leaves; deleted legacy globals/forwarders are not restored.
External dynamic references to removed private paths remain an OPEN boundary.
