Synced runtime-owner qualification (#323, #336, PR326)
====================================================

Source: 68aed451f1a8423b2e9b91ce82f05432ccc3ccf0.
Main: 8c512d404f8707a6a1be311406c0af2a089360f7.
1524 local tests and 20 subtests pass; one optional Napari skip and two existing
watershed warnings. Full broad test source differs only by final formatting of
the added cache tests; the exact final focused 111-test gate also passes.
Original R0/R1 pass without increases; complete census retains all 12 OPEN.
Native-reference qualification: 30/30 equivalent, all difference_count=0.
Existing 1e-6 abs/rel tolerances and exact discrete/identity/declared-image checks
remain. Retained native scientific outputs are reused. Native clocks/speedup
columns in raw reports are NOT fresh comparative performance evidence.

Matched public-route ABBA uses current main/candidate, CPU5, one well/thread,
ready-server warming, current pins and shared persistent Numba cache. All eight
observations succeed. Means of two samples per side:
ImagingFlow main/candidate compile 1.5215/1.8756, execute 14.4819/14.5734,
total 16.6821/17.1260 seconds. Advanced segmentation compile 1.8741/1.9916,
execute 9.4418/8.9992, total 12.3862/12.1013 seconds. ImagingFlow total is 0.4439s
higher, including 0.3541s compilation; this residual is not hidden. These small
samples do not establish neutrality or a general speedup. Ownership repair and
performance target remain separate. Server startup/shutdown are excluded from
pipeline clocks. No tests/audits/builds/replays overlap timed pipeline work.

SHA256SUMS authenticates the included artifacts. Exact controller/task recipes,
source assertions, dependency pins, measured receipts, main negative controls,
local XML, original guards/census and ownership decision are retained. Large
scientific input/output files remain in the benchmark workspace.
