Latest-main qualification supplement
====================================

Current production f7b39a2a49ce07134d58ef8ae61c85e2395fd93f includes main
f24a828da16691b83284622a01e1765b1d147e66. Main's acquisition filename ownership
change is integrated. Dependency pins are unchanged. 1538 tests and 42 subtests
pass; one optional skip and two existing watershed warnings. Original R0/R1
pass with no increases, census 5129/5117/12 OPEN unchanged. The repeated complete
native-reference suite passes 30/30 with every difference_count=0 on this exact
production source. Existing numerical/image/identity checks remain strict.
The ordinary ABBA observations remain tied to prior 68aed451f / main8c512d404;
they are not relabeled as measurements of the new integration. No new speedup,
native clock or scaling figure claim. Historical README and owner decisions
retain their source-specific meaning. This supplement is current qualification.
