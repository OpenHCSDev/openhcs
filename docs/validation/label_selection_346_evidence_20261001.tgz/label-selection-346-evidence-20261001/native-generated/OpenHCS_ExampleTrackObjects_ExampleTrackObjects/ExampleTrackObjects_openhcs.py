# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import LazyStepSourceBindingsConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.color import (
    ColorToGrayMode,
    color_to_gray,
)
from openhcs.processing.backends.cellprofiler.image_geometry import tile
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.outlines import overlay_outlines
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    SaveImagesFilenameMethod,
    save_images,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerThresholdAssignment,
    CellProfilerThresholdMethod,
)
from openhcs.processing.backends.cellprofiler.tracking import track_objects

pipeline_steps = [
    FunctionStep(
        func=(color_to_gray, {
                'mode': ColorToGrayMode.COMBINE,
                'name_the_output_image': 'OrigGray'
            }),
        name='ColorToGray',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 25,
                'max_diameter': 9999,
                'threshold_min': 0.01,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'Embryos'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(measure_object_size_shape, {
                'calculate_advanced': False,
                'calculate_zernikes': False
            }),
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=measure_object_intensity,
        name='MeasureObjectIntensity'
    ),
    FunctionStep(
        func=(track_objects, {
                'save_color_coded_image': True
            }),
        name='TrackObjects'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'select_image_on_which_to_display_outlines': 'OrigGray',
                'name_the_output_image': 'OutlineImage'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=(tile, {
                'rows': 1,
                'auto_columns': True,
                'tile_assembly_method': 'within_cycles',
                'select_an_input_image': 'OrigColor',
                'select_an_additional_image_to_tile': (
                    'OutlineImage',
                    'TrackedCells'
                ),
                'name_the_output_image': 'AdjacentImage'
            }),
        name='Tile',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True
        )
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': '\\g<Specimen>-\\g<FrameNumber>',
                'file_format': SaveImagesFileFormat.PNG,
                'output_location': '\\g<Run>',
                'bit_depth': SaveImagesBitDepth.UINT8,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_the_image_to_save': 'AdjacentImage'
            }),
        name='SaveImages'
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'add_image_metadata': True,
                'calculate_aggregate_means': True,
                'output_directory': '{Run}',
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Embryos',
                        ),
                        file_name='Embryos.csv'
                    )
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]