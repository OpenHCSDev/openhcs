# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import (
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceBindingOrigin,
    SourceFilterClause,
    SourceFilterMatchType,
    SourceFilterSubject,
    SourceSelector,
)
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.illumination import correct_illumination_apply
from openhcs.processing.backends.cellprofiler.image_math import ImageMathOperation
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.measurement_math import calculate_math
from openhcs.processing.backends.cellprofiler.outlines import (
    OutlineSourceKind,
    overlay_outlines,
)
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    save_images,
)
from openhcs.processing.backends.cellprofiler.secondary import (
    SecondaryMethod,
    identify_secondary_objects,
    identify_tertiary_objects,
)
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import CellProfilerThresholdMethod

pipeline_steps = [
    FunctionStep(
        func=(correct_illumination_apply, {
                'select_the_input_image': 'OrigProtein',
                'select_the_illumination_function': 'IllumProtein',
                'name_the_output_image': 'CorrProtein'
            }),
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'select_the_input_image': 'OrigDNA',
                'select_the_illumination_function': 'IllumDNA',
                'name_the_output_image': 'CorrDNA'
            }),
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 5,
                'max_diameter': 30,
                'maxima_suppression_size': 5.0,
                'name_the_primary_objects_to_be_identified': 'Nuclei'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(identify_secondary_objects, {
                'method': SecondaryMethod.DISTANCE_B,
                'threshold_method': CellProfilerThresholdMethod.MINIMUM_CROSS_ENTROPY,
                'distance_to_dilate': 8,
                'fill_holes': False,
                'select_the_input_image': 'CorrProtein',
                'name_the_objects_to_be_identified': 'Cells'
            }),
        name='IdentifySecondaryObjects'
    ),
    FunctionStep(
        func=(identify_tertiary_objects, {
                'select_the_larger_identified_objects': 'Cells',
                'select_the_smaller_identified_objects': 'Nuclei',
                'name_the_tertiary_objects_to_be_identified': 'Cytoplasm'
            }),
        name='IdentifyTertiaryObjects'
    ),
    FunctionStep(
        func=[
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nuclei',
                    'select_images_to_measure': 'CorrProtein'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cells',
                    'select_images_to_measure': 'CorrProtein'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cytoplasm',
                    'select_images_to_measure': 'CorrProtein'
                })
        ],
        name='MeasureObjectIntensity'
    ),
    FunctionStep(
        func=[
            (calculate_math, {
                    'operand1_feature': 'Intensity_MeanIntensity_CorrProtein',
                    'operand2_feature': 'Intensity_MeanIntensity_CorrProtein',
                    'operation': ImageMathOperation.DIVIDE,
                    'output_name': 'Ratio1',
                    'select_the_numerator_objects': 'Nuclei',
                    'select_the_denominator_objects': 'Cells'
                }),
            (calculate_math, {
                    'operand1_feature': 'Intensity_MeanIntensity_CorrProtein',
                    'operand2_feature': 'Intensity_MeanIntensity_CorrProtein',
                    'operation': ImageMathOperation.DIVIDE,
                    'output_name': 'Ratio2',
                    'select_the_numerator_objects': 'Cytoplasm',
                    'select_the_denominator_objects': 'Cells'
                })
        ],
        name='CalculateMath'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'outline_source_kinds': (
                    OutlineSourceKind.OBJECTS,
                    OutlineSourceKind.OBJECTS
                ),
                'outline_colors': (
                    'Blue',
                    'Green'
                ),
                'select_image_on_which_to_display_outlines': 'CorrProtein',
                'select_objects_to_display': (
                    'Nuclei',
                    'Cells'
                ),
                'name_the_output_image': 'Outlined'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=(save_images, {
                'single_file_name': 'OrigProtein',
                'append_suffix': True,
                'filename_suffix': '_Outlined',
                'bit_depth': SaveImagesBitDepth.UINT8,
                'base_image_folder': 'Elsewhere...|/Users/veneskey/svn/pipeline/ExampleImages/ExampleVitraImages',
                'record_file_and_path': False,
                'select_image_name_for_file_prefix': 'OrigProtein',
                'select_the_image_to_save': 'Outlined'
            }),
        name='SaveImages',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='OrigProtein',
                    selector=SourceSelector(
                        filters=(
                            SourceFilterClause(
                                subject=SourceFilterSubject.FILE,
                                match_type=SourceFilterMatchType.CONTAINS,
                                value='Channel 1'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    load_as_monochrome=True
                ),
            )
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'calculate_aggregate_means': True,
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Nuclei',
                        ),
                        file_name='Nuclei.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Cells',
                        ),
                        file_name='Cells.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Cytoplasm',
                        ),
                        file_name='Cytoplasm.csv'
                    )
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]