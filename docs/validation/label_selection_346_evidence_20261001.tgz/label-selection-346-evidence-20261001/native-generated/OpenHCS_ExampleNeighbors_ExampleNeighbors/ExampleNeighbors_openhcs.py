# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.color import color_to_gray
from openhcs.processing.backends.cellprofiler.crop import crop
from openhcs.processing.backends.cellprofiler.image_math import (
    ImageMathOperation,
    image_math,
)
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.neighbors import (
    DistanceMethod,
    measure_object_neighbors,
)
from openhcs.processing.backends.cellprofiler.outlines import overlay_outlines
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    save_images,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(crop, {
                'left_right_rectangle_positions': (
                    45,
                    629
                ),
                'top_bottom_rectangle_positions': (
                    1,
                    445
                ),
                'ellipse_center': (
                    500,
                    500
                ),
                'ellipse_x_radius': 400.0,
                'ellipse_y_radius': 200.0,
                'name_the_output_image': 'Cropped'
            }),
        name='Crop',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(color_to_gray, {
                'channel_indices': (
                    0,
                ),
                'contributions': (
                    1.0,
                ),
                'name_the_output_image': 'OrigRed'
            }),
        name='ColorToGray'
    ),
    FunctionStep(
        func=(image_math, {
                'operation': ImageMathOperation.INVERT,
                'name_the_output_image': 'InvertedRed'
            }),
        name='ImageMath'
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 5,
                'max_diameter': 9999,
                'automatic_smoothing': False,
                'smoothing_filter_size': 4,
                'automatic_suppression': False,
                'maxima_suppression_size': 4.0,
                'threshold_correction_factor': 0.7,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'Cells'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'name_the_output_image': 'InvertedRedOutlines'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=(measure_object_neighbors, {
                'distance_method': DistanceMethod.EXPAND,
                'neighbor_distance': 5,
                'retain_neighbor_count_image': True,
                'neighbor_count_colormap': 'hot',
                'name_the_output_image': (
                    'ColorNeighbors',
                    'PercentTouching'
                )
            }),
        name='MeasureObjectNeighbors'
    ),
    FunctionStep(
        func=(measure_object_size_shape, {
                'calculate_advanced': False,
                'calculate_zernikes': False
            }),
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=(measure_object_intensity, {
                'select_images_to_measure': 'OrigRed'
            }),
        name='MeasureObjectIntensity'
    ),
    FunctionStep(
        func=[
            (save_images, {
                    'single_file_name': 'OrigBlue',
                    'append_suffix': True,
                    'filename_suffix': '_ColorNeighbors',
                    'file_format': SaveImagesFileFormat.PNG,
                    'bit_depth': SaveImagesBitDepth.UINT8,
                    'overwrite': False,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_image_name_for_file_prefix': 'Original',
                    'select_the_image_to_save': 'ColorNeighbors'
                }),
            (save_images, {
                    'single_file_name': 'OrigBlue',
                    'append_suffix': True,
                    'filename_suffix': '_InvertedRed',
                    'file_format': SaveImagesFileFormat.PNG,
                    'bit_depth': SaveImagesBitDepth.UINT8,
                    'overwrite': False,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_image_name_for_file_prefix': 'Original',
                    'select_the_image_to_save': 'InvertedRedOutlines'
                })
        ],
        name='SaveImages',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'calculate_aggregate_means': True,
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Cells',
                        ),
                        file_name='Cells.csv'
                    )
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]