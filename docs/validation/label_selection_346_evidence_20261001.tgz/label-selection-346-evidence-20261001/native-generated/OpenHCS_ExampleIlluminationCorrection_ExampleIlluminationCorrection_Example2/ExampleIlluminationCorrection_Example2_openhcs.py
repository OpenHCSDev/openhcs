# Edit this pipeline and save to apply changes

from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.illumination import (
    FilterSizeMethod,
    IlluminationCorrectionMethod,
    IntensityChoice,
    RescaleOption,
    SmoothingMethod,
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.object_images import (
    ImageMode,
    convert_objects_to_image,
)
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFilenameMethod,
    save_images,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdAssignment,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 20,
                'max_diameter': 50,
                'exclude_size': False,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'UncorrectedNuclei'
            }),
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'block_size': 8,
                'rescale_option': RescaleOption.NO,
                'smoothing_method': SmoothingMethod.MEDIAN_FILTER,
                'filter_size_method': FilterSizeMethod.OBJECT_SIZE,
                'object_width': 16,
                'name_the_output_image': 'SmallBlockIllum'
            }),
        name='CorrectIlluminationCalculate',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'name_the_output_image': 'SmallBlockCorrected'
            }),
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 20,
                'max_diameter': 50,
                'exclude_size': False,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'SmallBlockCorrectedNuclei'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'block_size': 20,
                'rescale_option': RescaleOption.NO,
                'smoothing_method': SmoothingMethod.MEDIAN_FILTER,
                'filter_size_method': FilterSizeMethod.MANUALLY,
                'manual_filter_size': 50,
                'name_the_output_image': 'LargeBlockIllum'
            }),
        name='CorrectIlluminationCalculate',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'Grayscale',
                'select_the_illumination_function': 'LargeBlockIllum',
                'name_the_output_image': 'LargeBlockCorrected'
            }),
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 20,
                'max_diameter': 50,
                'exclude_size': False,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'LargeBlockCorrectedNuclei'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'select_the_input_objects': 'UncorrectedNuclei',
                'name_the_output_image': 'OpenHCSReferenceLabels_UncorrectedNuclei'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': 'reference_labels__UncorrectedNuclei',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_the_image_to_save': 'OpenHCSReferenceLabels_UncorrectedNuclei'
            }),
        name='SaveImages'
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'select_the_input_objects': 'SmallBlockCorrectedNuclei',
                'name_the_output_image': 'OpenHCSReferenceLabels_SmallBlockCorrectedNuclei'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': 'reference_labels__SmallBlockCorrectedNuclei',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_the_image_to_save': 'OpenHCSReferenceLabels_SmallBlockCorrectedNuclei'
            }),
        name='SaveImages'
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'select_the_input_objects': 'LargeBlockCorrectedNuclei',
                'name_the_output_image': 'OpenHCSReferenceLabels_LargeBlockCorrectedNuclei'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': 'reference_labels__LargeBlockCorrectedNuclei',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_the_image_to_save': 'OpenHCSReferenceLabels_LargeBlockCorrectedNuclei'
            }),
        name='SaveImages'
    )
]