# Edit this pipeline and save to apply changes

from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.illumination import (
    CalculationScope,
    FilterSizeMethod,
    SmoothingMethod,
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    SaveImagesFilenameMethod,
    SaveImagesWhen,
    save_images,
)

pipeline_steps = [
    FunctionStep(
        func=(correct_illumination_calculate, {
                'smoothing_method': SmoothingMethod.MEDIAN_FILTER,
                'filter_size_method': FilterSizeMethod.MANUALLY,
                'manual_filter_size': 12,
                'calculation_scope': CalculationScope.ALL_FIRST_CYCLE,
                'name_the_output_image': 'SuboptimalIllumGreen'
            }),
        name='CorrectIlluminationCalculate',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'select_the_input_image': 'OrigGreen',
                'select_the_illumination_function': 'SuboptimalIllumGreen',
                'name_the_output_image': 'SuboptimalCorrGreen'
            }),
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'smoothing_method': SmoothingMethod.MEDIAN_FILTER,
                'filter_size_method': FilterSizeMethod.MANUALLY,
                'manual_filter_size': 125,
                'calculation_scope': CalculationScope.ALL_FIRST_CYCLE,
                'name_the_output_image': 'OptimalIllumGreen'
            }),
        name='CorrectIlluminationCalculate',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'select_the_input_image': 'OrigGreen',
                'select_the_illumination_function': 'OptimalIllumGreen',
                'name_the_output_image': 'OptimalCorrGreen'
            }),
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': 'Illum',
                'file_format': SaveImagesFileFormat.NPY,
                'bit_depth': SaveImagesBitDepth.FLOAT32,
                'when_to_save': SaveImagesWhen.FIRST_CYCLE,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_the_image_to_save': 'OptimalIllumGreen'
            }),
        name='SaveImages'
    )
]