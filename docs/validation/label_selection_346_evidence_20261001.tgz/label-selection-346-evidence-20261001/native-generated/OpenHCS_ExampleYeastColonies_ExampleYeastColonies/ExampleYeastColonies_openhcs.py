# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
    VariableComponents,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceBindingOrigin,
    SourceFilterClause,
    SourceFilterMatchType,
    SourceFilterSubject,
    SourceSelector,
)
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.alignment import (
    AlignModule,
    align,
)
from openhcs.processing.backends.cellprofiler.classification import (
    ClassificationBinChoice,
    SingleMeasurementClassificationRule,
    classify_objects_single_measurement,
)
from openhcs.processing.backends.cellprofiler.color import color_to_gray
from openhcs.processing.backends.cellprofiler.illumination import (
    IlluminationCorrectionMethod,
    IntensityChoice,
    RescaleOption,
    SmoothingMethod,
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.image_geometry import mask_image
from openhcs.processing.backends.cellprofiler.image_math import (
    ImageMathOperation,
    image_math,
)
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.outlines import overlay_outlines
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    WatershedMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    save_images,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import CellProfilerThresholdAssignment

pipeline_steps = [
    FunctionStep(
        func={
            '1': (color_to_gray, {
                    'name_the_output_image': (
                        'OrigRed',
                        'OrigGreen',
                        'OrigBlue'
                    )
                })
        },
        name='ColorToGray',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'object_dilation_radius': 0,
                'block_size': 22,
                'rescale_option': RescaleOption.NO,
                'smoothing_method': SmoothingMethod.GAUSSIAN_FILTER,
                'select_the_input_image': 'OrigRed',
                'name_the_output_image': 'IllumRed'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'object_dilation_radius': 0,
                'block_size': 22,
                'rescale_option': RescaleOption.NO,
                'smoothing_method': SmoothingMethod.GAUSSIAN_FILTER,
                'select_the_input_image': 'OrigBlue',
                'name_the_output_image': 'IllumBlue'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'object_dilation_radius': 0,
                'block_size': 22,
                'rescale_option': RescaleOption.NO,
                'smoothing_method': SmoothingMethod.GAUSSIAN_FILTER,
                'select_the_input_image': 'OrigGreen',
                'name_the_output_image': 'IllumGreen'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'OrigRed',
                'select_the_illumination_function': 'IllumRed',
                'name_the_output_image': 'CorrRed'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'OrigBlue',
                'select_the_illumination_function': 'IllumBlue',
                'name_the_output_image': 'CorrBlue'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'OrigGreen',
                'select_the_illumination_function': 'IllumGreen',
                'name_the_output_image': 'CorrGreen'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=(image_math, {
                'after_factor': 0.5,
                'select_the_first_image': 'CorrBlue',
                'select_the_second_image': 'CorrGreen',
                'name_the_output_image': 'CombinedImage'
            }),
        name='ImageMath'
    ),
    FunctionStep(
        func=(align, {
                'additional_alignment_modes': (
                    AlignModule.AdditionalMode.SIMILARLY,
                ),
                'select_the_first_input_image': 'PlateTemplate',
                'select_the_second_input_image': 'CorrRed',
                'select_the_additional_image': 'CombinedImage',
                'name_the_first_output_image': 'AlignedPlate',
                'name_the_second_output_image': 'AlignedRed',
                'name_the_output_image': 'AlignedCombined'
            }),
        name='Align',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.SITE
        ),
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='PlateTemplate',
                    selector=SourceSelector(
                        filters=(
                            SourceFilterClause(
                                subject=SourceFilterSubject.FILE,
                                match_type=SourceFilterMatchType.EQUALS,
                                value='PlateTemplate.png'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    component_identity=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='2'
                        ),
                    ),
                    load_as_monochrome=True,
                    load_as_mask=True
                ),
            )
        )
    ),
    FunctionStep(
        func=(mask_image, {
                'select_the_input_image': 'CombinedImage',
                'select_image_for_mask': 'AlignedPlate',
                'name_the_output_image': 'MaskedCombined'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(mask_image, {
                'select_the_input_image': 'CorrRed',
                'select_image_for_mask': 'AlignedPlate',
                'name_the_output_image': 'MaskedRedPlate'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(image_math, {
                'operation': ImageMathOperation.SUBTRACT,
                'truncate_low': False,
                'select_the_second_image': 'MaskedCombined',
                'name_the_output_image': 'SubtractedRed'
            }),
        name='ImageMath'
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 1,
                'unclump_method': UnclumpMethod.SHAPE,
                'watershed_method': WatershedMethod.SHAPE,
                'automatic_smoothing': False,
                'smoothing_filter_size': 0,
                'automatic_suppression': False,
                'maxima_suppression_size': 2.0,
                'low_res_maxima': False,
                'threshold_min': 0.001,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'select_the_input_image': 'MaskedRedPlate',
                'name_the_primary_objects_to_be_identified': 'Colonies'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=measure_object_intensity,
        name='MeasureObjectIntensity'
    ),
    FunctionStep(
        func=(measure_object_size_shape, {
                'calculate_advanced': False,
                'calculate_zernikes': False
            }),
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=(classify_objects_single_measurement, {
                'classification_rules': (
                    SingleMeasurementClassificationRule(
                        measurement_feature='AreaShape_Area',
                        bin_choice=ClassificationBinChoice.CUSTOM,
                        bin_count=1,
                        custom_thresholds=(
                            0.0,
                            5.0,
                            75.0,
                            1300.0
                        ),
                        bin_names=(
                            'Tiny',
                            'Small',
                            'Large'
                        )
                    ),
                    SingleMeasurementClassificationRule(
                        measurement_feature='Intensity_MeanIntensity_SubtractedRed',
                        bin_choice=ClassificationBinChoice.CUSTOM,
                        wants_low_bin=True,
                        wants_high_bin=True,
                        custom_thresholds=(
                            0.05,
                        ),
                        bin_names=(
                            'White',
                            'Red'
                        )
                    )
                )
            }),
        name='ClassifyObjects'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'select_image_on_which_to_display_outlines': 'MaskedRedPlate',
                'name_the_output_image': 'OutlinedColonies'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=(save_images, {
                'single_file_name': 'OrigColor',
                'append_suffix': True,
                'filename_suffix': '_outlines',
                'file_format': SaveImagesFileFormat.PNG,
                'bit_depth': SaveImagesBitDepth.UINT8,
                'overwrite': False,
                'base_image_folder': 'Elsewhere...|/Users/veneskey/svn/pipeline/ExampleImages/ExampleYeastColonies_BT_Images',
                'record_file_and_path': False,
                'select_image_name_for_file_prefix': 'OrigColor',
                'select_the_image_to_save': 'OutlinedColonies'
            }),
        name='SaveImages',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='OrigColor',
                    selector=SourceSelector(
                        filters=(
                            SourceFilterClause(
                                subject=SourceFilterSubject.FILE,
                                match_type=SourceFilterMatchType.CONTAINS,
                                value='6-1.jpg'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    component_identity=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='1'
                        ),
                    ),
                    source_channel_axis=-1
                ),
            )
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'calculate_aggregate_means': True,
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Colonies',
                        ),
                        file_name='Colonies.csv'
                    )
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]