# OpenHCS pipeline

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
    Microscope,
    VariableComponents,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import (
    LazyAnalysisConsolidationConfig,
    LazyCompilationDebugConfig,
    LazyDtypeConfig,
    LazyFijiDisplayConfig,
    LazyFijiStreamingConfig,
    LazyNapariDisplayConfig,
    LazyNapariStreamingConfig,
    LazyPathPlanningConfig,
    LazyPlateMetadataConfig,
    LazyProcessingConfig,
    LazySequentialProcessingConfig,
    LazyStepMaterializationConfig,
    LazyStepWellFilterConfig,
    LazyStreamingDefaults,
    LazyTiffConfig,
    LazyVFSConfig,
    LazyWellFilterConfig,
    LazyZarrConfig,
    MultiprocessingStartMethod,
    PipelineConfig,
)
from openhcs.core.runtime_tabular_values import FieldSpec
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazySourceBindingsConfig,
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceBindingMatchMethod,
    SourceBindingMatchPlan,
    SourceBindingOrigin,
    SourceFilterClause,
    SourceFilterMatchType,
    SourceFilterSubject,
    SourceSelector,
)
from openhcs.core.source_metadata import (
    SourceVoxelSpacing,
    SourceVoxelSpacingUnit,
)
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.illumination import (
    IlluminationCorrectionMethod,
    IntensityChoice,
    RescaleOption,
    SmoothingMethod,
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.image_geometry import (
    MaskSource,
    mask_image,
)
from openhcs.processing.backends.cellprofiler.image_math import (
    ImageMathOperation,
    image_math,
)
from openhcs.processing.backends.cellprofiler.morphology import (
    ExpandShrinkMode,
    expand_or_shrink_objects,
)
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    SaveImagesFilenameMethod,
    save_images,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)
from pathlib import Path

pipeline_config = PipelineConfig(
    materialization_results_path=Path('results'),
    materialize_runtime_artifacts=True,
    num_workers=1,
    microscope=Microscope.AUTO,
    use_threading=False,
    multiprocessing_start_method=MultiprocessingStartMethod.SPAWN,
    auto_add_output_plate_to_plate_manager=False,
    napari_display_config=LazyNapariDisplayConfig(),
    fiji_display_config=LazyFijiDisplayConfig(),
    well_filter_config=LazyWellFilterConfig(),
    zarr_config=LazyZarrConfig(),
    tiff_config=LazyTiffConfig(),
    vfs_config=LazyVFSConfig(),
    dtype_config=LazyDtypeConfig(),
    processing_config=LazyProcessingConfig(
        variable_components=[
            VariableComponents.SITE
        ],
        group_by=GroupBy.CHANNEL,
        input_source=InputSource.PREVIOUS_STEP
    ),
    source_bindings_config=LazySourceBindingsConfig(
        metadata_rules=(),
        match_plan=SourceBindingMatchPlan(
            method=SourceBindingMatchMethod.ORDER
        ),
        metadata_fields=(
            FieldSpec(
                name='FileLocation',
                dtype=str,
                required=False
            ),
        ),
        source_filters=(
            SourceFilterClause(
                subject=SourceFilterSubject.EXTENSION,
                match_type=SourceFilterMatchType.IS_IMAGE
            ),
            SourceFilterClause(
                subject=SourceFilterSubject.DIRECTORY,
                match_type=SourceFilterMatchType.DOES_NOT_CONTAIN_REGEX,
                value='[\\\\/]\\.'
            )
        ),
        bindings=(
            NamedSourceBinding(
                alias='OrigWorms',
                selector=SourceSelector(
                    filters=(
                        SourceFilterClause(
                            subject=SourceFilterSubject.FILE,
                            match_type=SourceFilterMatchType.CONTAINS,
                            value='ADSAStaphInfection2_A01_w2'
                        ),
                    )
                ),
                origin=SourceBindingOrigin.PIPELINE_START,
                component_identity=(
                    ComponentSelector(
                        component=AllComponents.CHANNEL,
                        value='1'
                    ),
                ),
                load_as_monochrome=True
            ),
        ),
        image_plane_sources=(),
        imported_metadata_tables=(),
        source_stack_components=(),
        grouping_metadata_fields=(),
        source_voxel_spacing=SourceVoxelSpacing(
            values_zyx=(
                1.0,
                1.0,
                1.0
            ),
            unit=SourceVoxelSpacingUnit.RELATIVE
        )
    ),
    step_source_bindings_config=LazyStepSourceBindingsConfig(),
    sequential_processing_config=LazySequentialProcessingConfig(),
    analysis_consolidation_config=LazyAnalysisConsolidationConfig(),
    plate_metadata_config=LazyPlateMetadataConfig(),
    path_planning_config=LazyPathPlanningConfig(),
    step_well_filter_config=LazyStepWellFilterConfig(),
    step_materialization_config=LazyStepMaterializationConfig(),
    streaming_defaults=LazyStreamingDefaults(),
    napari_streaming_config=LazyNapariStreamingConfig(),
    fiji_streaming_config=LazyFijiStreamingConfig(),
    compilation_debug_config=LazyCompilationDebugConfig(
        enabled=True
    )
)

pipeline_steps = [
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 1,
                'exclude_size': False,
                'unclump_method': UnclumpMethod.NONE,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'Well'
            }),
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(expand_or_shrink_objects, {
                'mode': ExpandShrinkMode.SHRINK_DEFINED_PIXELS,
                'iterations': 5,
                'fill_holes': False,
                'name_the_output_objects': 'ShrunkenWell'
            }),
        name='ExpandOrShrinkObjects'
    ),
    FunctionStep(
        func=(image_math, {
                'operation': ImageMathOperation.INVERT,
                'name_the_output_image': 'InvertedWorms'
            }),
        name='ImageMath',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(mask_image, {
                'mask_source': MaskSource.OBJECTS,
                'select_the_input_image': 'InvertedWorms',
                'select_object_for_mask': 'ShrunkenWell',
                'name_the_output_image': 'MaskedInvertedWorms'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'block_size': 2,
                'rescale_option': RescaleOption.NO,
                'name_the_output_image': 'PolynomialIllum'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'MaskedInvertedWorms',
                'select_the_illumination_function': 'PolynomialIllum',
                'name_the_output_image': 'PolynomialCorrected'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=(mask_image, {
                'mask_source': MaskSource.OBJECTS,
                'select_the_input_image': 'OrigWorms',
                'select_object_for_mask': 'ShrunkenWell',
                'name_the_output_image': 'MaskedOrigWorms'
            }),
        name='MaskImage',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'smoothing_method': SmoothingMethod.CONVEX_HULL,
                'name_the_output_image': 'ConvexHullIllumWorm'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'select_the_input_image': 'MaskedOrigWorms',
                'select_the_illumination_function': 'ConvexHullIllumWorm',
                'name_the_output_image': 'ConvexHullCorrWorm'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=[
            (save_images, {
                    'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                    'single_file_name': 'reference_image__PolynomialCorrected',
                    'file_format': SaveImagesFileFormat.NPY,
                    'bit_depth': SaveImagesBitDepth.FLOAT32,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_the_image_to_save': 'PolynomialCorrected'
                }),
            (save_images, {
                    'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                    'single_file_name': 'reference_image__ConvexHullCorrWorm',
                    'file_format': SaveImagesFileFormat.NPY,
                    'bit_depth': SaveImagesBitDepth.FLOAT32,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_the_image_to_save': 'ConvexHullCorrWorm'
                })
        ],
        name='SaveImages'
    )
]