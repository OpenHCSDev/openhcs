# Edit this pipeline and save to apply changes

from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.illumination import (
    IlluminationCorrectionMethod,
    IntensityChoice,
    RescaleOption,
    SmoothingMethod,
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.image_geometry import (
    MaskSource,
    mask_image,
)
from openhcs.processing.backends.cellprofiler.image_math import (
    ImageMathOperation,
    image_math,
)
from openhcs.processing.backends.cellprofiler.morphology import (
    ExpandShrinkMode,
    expand_or_shrink_objects,
)
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    SaveImagesFilenameMethod,
    save_images,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 1,
                'exclude_size': False,
                'unclump_method': UnclumpMethod.NONE,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'Well'
            }),
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(expand_or_shrink_objects, {
                'mode': ExpandShrinkMode.SHRINK_DEFINED_PIXELS,
                'iterations': 5,
                'fill_holes': False,
                'name_the_output_objects': 'ShrunkenWell'
            }),
        name='ExpandOrShrinkObjects'
    ),
    FunctionStep(
        func=(image_math, {
                'operation': ImageMathOperation.INVERT,
                'name_the_output_image': 'InvertedWorms'
            }),
        name='ImageMath',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(mask_image, {
                'mask_source': MaskSource.OBJECTS,
                'select_the_input_image': 'InvertedWorms',
                'select_object_for_mask': 'ShrunkenWell',
                'name_the_output_image': 'MaskedInvertedWorms'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'block_size': 2,
                'rescale_option': RescaleOption.NO,
                'name_the_output_image': 'PolynomialIllum'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'MaskedInvertedWorms',
                'select_the_illumination_function': 'PolynomialIllum',
                'name_the_output_image': 'PolynomialCorrected'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=(mask_image, {
                'mask_source': MaskSource.OBJECTS,
                'select_the_input_image': 'OrigWorms',
                'select_object_for_mask': 'ShrunkenWell',
                'name_the_output_image': 'MaskedOrigWorms'
            }),
        name='MaskImage',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'smoothing_method': SmoothingMethod.CONVEX_HULL,
                'name_the_output_image': 'ConvexHullIllumWorm'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'select_the_input_image': 'MaskedOrigWorms',
                'select_the_illumination_function': 'ConvexHullIllumWorm',
                'name_the_output_image': 'ConvexHullCorrWorm'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=[
            (save_images, {
                    'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                    'single_file_name': 'reference_image__PolynomialCorrected',
                    'file_format': SaveImagesFileFormat.NPY,
                    'bit_depth': SaveImagesBitDepth.FLOAT32,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_the_image_to_save': 'PolynomialCorrected'
                }),
            (save_images, {
                    'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                    'single_file_name': 'reference_image__ConvexHullCorrWorm',
                    'file_format': SaveImagesFileFormat.NPY,
                    'bit_depth': SaveImagesBitDepth.FLOAT32,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_the_image_to_save': 'ConvexHullCorrWorm'
                })
        ],
        name='SaveImages'
    )
]