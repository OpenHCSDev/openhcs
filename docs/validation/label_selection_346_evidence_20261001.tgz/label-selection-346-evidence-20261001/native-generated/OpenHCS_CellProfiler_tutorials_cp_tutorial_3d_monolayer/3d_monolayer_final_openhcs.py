# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazyStepSourceBindingsConfig,
    MetadataSelector,
    NamedSourceBinding,
    SourceBindingOrigin,
    SourceSelector,
)
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.image_geometry import (
    mask_image,
    resize_volumetric,
)
from openhcs.processing.backends.cellprofiler.image_math import (
    ImageMathOperation,
    image_math,
)
from openhcs.processing.backends.cellprofiler.intensity import (
    AutomaticHigh,
    AutomaticLow,
    measure_object_intensity,
    rescale_intensity,
)
from openhcs.processing.backends.cellprofiler.median_filter import medianfilter
from openhcs.processing.backends.cellprofiler.morphology import (
    closing,
    erode_image,
    erode_objects,
    remove_holes_3d,
    resize_objects_3d,
)
from openhcs.processing.backends.cellprofiler.object_images import (
    ImageMode,
    convert_objects_to_image,
)
from openhcs.processing.backends.cellprofiler.outlines import overlay_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    save_images,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import export_to_spreadsheet
from openhcs.processing.backends.cellprofiler.structuring_elements import StructuringElement
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
    threshold,
)
from openhcs.processing.backends.cellprofiler.watershed import (
    WatershedMethod,
    watershed_cellprofiler4,
)

pipeline_steps = [
    FunctionStep(
        func={
            '2': (rescale_intensity, {
                    'automatic_low': AutomaticLow.CUSTOM,
                    'automatic_high': AutomaticHigh.CUSTOM,
                    'select_the_input_image': 'origDNA',
                    'select_image_to_match_in_maximum_intensity': 'None',
                    'name_the_output_image': 'RescaledDNA'
                })
        },
        name='RescaleIntensity',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(resize_volumetric, {
                'resizing_factor_x': 0.5,
                'resizing_factor_y': 0.5,
                'resizing_factor_z': 1.0,
                'name_the_output_image': 'ResizedDNA'
            }),
        name='Resize'
    ),
    FunctionStep(
        func=(medianfilter, {
                'window_size': 5,
                'name_the_output_image': 'MedianFiltDNA'
            }),
        name='MedianFilter'
    ),
    FunctionStep(
        func=(threshold, {
                'name_the_output_image': 'maskDNA'
            }),
        name='Threshold'
    ),
    FunctionStep(
        func=(remove_holes_3d, {
                'diameter': 20.0,
                'name_the_output_image': 'noHolesMaskDNA'
            }),
        name='RemoveHoles'
    ),
    FunctionStep(
        func=(watershed_cellprofiler4, {
                'use_advanced_settings': False,
                'downsample': 2,
                'footprint': 10,
                'gaussian_sigma': 1.0,
                'name_the_output_object': 'downsizedNuclei'
            }),
        name='Watershed'
    ),
    FunctionStep(
        func=(resize_objects_3d, {
                'factor_x': 2.0,
                'factor_y': 2.0,
                'factor_z': 1.0,
                'name_the_output_object': 'Nuclei'
            }),
        name='ResizeObjects'
    ),
    FunctionStep(
        func=(erode_objects, {
                'structuring_element': StructuringElement.BALL,
                'size': 5,
                'select_the_input_object': 'downsizedNuclei',
                'name_the_output_object': 'erodedDownsizedNuclei'
            }),
        name='ErodeObjects'
    ),
    FunctionStep(
        func=(resize_objects_3d, {
                'factor_x': 2.0,
                'factor_y': 2.0,
                'factor_z': 1.0,
                'select_the_input_object': 'erodedDownsizedNuclei',
                'name_the_output_object': 'erodedResizedNuclei'
            }),
        name='ResizeObjects'
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'select_the_input_objects': 'erodedResizedNuclei',
                'name_the_output_image': 'cellSeeds'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func={
            '0': (threshold, {
                    'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                    'name_the_output_image': 'MembThreshold'
                })
        },
        name='Threshold',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(image_math, {
                'operation': ImageMathOperation.INVERT,
                'name_the_output_image': 'MembInvert'
            }),
        name='ImageMath'
    ),
    FunctionStep(
        func=(remove_holes_3d, {
                'diameter': 20.0,
                'name_the_output_image': 'MembInvertRemoveHoles'
            }),
        name='RemoveHoles'
    ),
    FunctionStep(
        func=(image_math, {
                'factors': (
                    1.0,
                    1.0,
                    1.0
                ),
                'select_the_second_image': 'origMemb',
                'select_the_third_image': 'origMito',
                'name_the_output_image': 'Monolayer'
            }),
        name='ImageMath',
        processing_config=LazyProcessingConfig(
            group_by=GroupBy.NONE,
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(resize_volumetric, {
                'resizing_factor_z': 1.0,
                'name_the_output_image': 'DownsizedMonolayer'
            }),
        name='Resize'
    ),
    FunctionStep(
        func=(closing, {
                'size': 17,
                'name_the_output_image': 'ClosedDownsizedMonolayer'
            }),
        name='Closing'
    ),
    FunctionStep(
        func=(resize_volumetric, {
                'resizing_factor_x': 4.0,
                'resizing_factor_y': 4.0,
                'resizing_factor_z': 1.0,
                'name_the_output_image': 'ResizedClosedMonolayer'
            }),
        name='Resize'
    ),
    FunctionStep(
        func=(threshold, {
                'threshold_method': CellProfilerThresholdMethod.MINIMUM_CROSS_ENTROPY,
                'name_the_output_image': 'MonolayerMask'
            }),
        name='Threshold'
    ),
    FunctionStep(
        func=(mask_image, {
                'select_the_input_image': 'MembInvertRemoveHoles',
                'select_image_for_mask': 'MonolayerMask',
                'name_the_output_image': 'MembMasked'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(erode_image, {
                'structuring_element': StructuringElement.BALL,
                'size': 1,
                'slice_by_slice': False,
                'name_the_output_image': 'MembFinal'
            }),
        name='ErodeImage'
    ),
    FunctionStep(
        func=(watershed_cellprofiler4, {
                'watershed_method': WatershedMethod.MARKERS,
                'use_advanced_settings': False,
                'gaussian_sigma': 1.0,
                'select_the_input_image': 'MembFinal',
                'markers': 'cellSeeds',
                'mask': 'MembFinal',
                'name_the_output_object': 'Cells'
            }),
        name='Watershed'
    ),
    FunctionStep(
        func={
            '2': [
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Nuclei'
                    }),
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Cells'
                    })
            ],
            '0': [
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Nuclei'
                    }),
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Cells'
                    })
            ]
        },
        name='MeasureObjectIntensity',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '2': (measure_object_size_shape, {
                    'calculate_advanced': False,
                    'calculate_zernikes': False,
                    'select_object_sets_to_measure': 'Nuclei'
                }),
            '0': (measure_object_size_shape, {
                    'calculate_advanced': False,
                    'calculate_zernikes': False,
                    'select_object_sets_to_measure': 'Cells'
                })
        },
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=(overlay_objects, {
                'opacity': 0.2,
                'select_the_input_image': 'RescaledDNA',
                'select_objects_to_display': 'Nuclei'
            }),
        name='OverlayObjects'
    ),
    FunctionStep(
        func={
            '0': (rescale_intensity, {
                    'automatic_low': AutomaticLow.CUSTOM,
                    'automatic_high': AutomaticHigh.CUSTOM,
                    'select_the_input_image': 'origMemb',
                    'select_image_to_match_in_maximum_intensity': 'None',
                    'name_the_output_image': 'RescaledMemb'
                })
        },
        name='RescaleIntensity',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(overlay_objects, {
                'select_the_input_image': 'RescaledMemb',
                'select_objects_to_display': 'Cells'
            }),
        name='OverlayObjects'
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'select_the_input_objects': 'Nuclei',
                'name_the_output_image': 'NucleiImage'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'single_file_name': 'OrigBlue',
                'append_suffix': True,
                'filename_suffix': '_NucleiLabels',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'lossless_compression': False,
                'record_file_and_path': False,
                'select_image_name_for_file_prefix': 'origDNA',
                'select_the_image_to_save': 'NucleiImage'
            }),
        name='SaveImages',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='origDNA',
                    selector=SourceSelector(
                        metadata=(
                            MetadataSelector(
                                field='ChannelNumber',
                                value='2'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    component_identity=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='2'
                        ),
                    ),
                    load_as_monochrome=True
                ),
            )
        )
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'select_the_input_objects': 'Cells',
                'name_the_output_image': 'CellsImage'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'single_file_name': 'OrigBlue',
                'append_suffix': True,
                'filename_suffix': '_CellsLabels',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'lossless_compression': False,
                'record_file_and_path': False,
                'select_image_name_for_file_prefix': 'origMemb',
                'select_the_image_to_save': 'CellsImage'
            }),
        name='SaveImages',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='origMemb',
                    selector=SourceSelector(
                        metadata=(
                            MetadataSelector(
                                field='ChannelNumber',
                                value='0'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    component_identity=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='0'
                        ),
                    ),
                    load_as_monochrome=True
                ),
            )
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'add_image_metadata': True,
                'filename_prefix': '3d_monolayer_',
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]