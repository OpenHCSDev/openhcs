# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    GroupBy,
    VariableComponents,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.interop.cellprofiler.measurement_scope import CellProfilerMeasurementTargetScope
from openhcs.processing.backends.cellprofiler.color import gray_to_color
from openhcs.processing.backends.cellprofiler.crop import (
    CropModule,
    crop,
)
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFilenameMethod,
    save_images,
)
from openhcs.processing.backends.cellprofiler.secondary import (
    identify_secondary_objects,
    identify_tertiary_objects,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.texture import measure_texture_objects
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdAssignment,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func={
            '1': (crop, {
                    'removal_method': CropModule.RemovalMethod.EDGES,
                    'left_right_rectangle_positions': (
                        501,
                        700
                    ),
                    'top_bottom_rectangle_positions': (
                        251,
                        450
                    ),
                    'ellipse_center': (
                        200,
                        500
                    ),
                    'ellipse_x_radius': 400.0,
                    'ellipse_y_radius': 200.0,
                    'name_the_output_image': 'CropBlue'
                })
        },
        name='Crop',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '2': (crop, {
                    'crop_shape': CropModule.Shape.CROPPING,
                    'removal_method': CropModule.RemovalMethod.EDGES,
                    'left_right_rectangle_positions': (
                        300,
                        600
                    ),
                    'top_bottom_rectangle_positions': (
                        300,
                        600
                    ),
                    'ellipse_center': (
                        500,
                        500
                    ),
                    'ellipse_x_radius': 400.0,
                    'ellipse_y_radius': 200.0,
                    'name_the_output_image': 'CropGreen'
                }),
            '3': (crop, {
                    'crop_shape': CropModule.Shape.CROPPING,
                    'removal_method': CropModule.RemovalMethod.EDGES,
                    'left_right_rectangle_positions': (
                        300,
                        600
                    ),
                    'top_bottom_rectangle_positions': (
                        300,
                        600
                    ),
                    'ellipse_center': (
                        500,
                        500
                    ),
                    'ellipse_x_radius': 400.0,
                    'ellipse_y_radius': 200.0,
                    'name_the_output_image': 'CropRed'
                })
        },
        name='Crop',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'maxima_suppression_size': 5.0,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'log_transform': True,
                'select_the_input_image': 'CropBlue',
                'name_the_primary_objects_to_be_identified': 'Nuclei'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(identify_secondary_objects, {
                'select_the_input_image': 'CropGreen',
                'select_the_input_objects': 'Nuclei',
                'name_the_objects_to_be_identified': 'Cells'
            }),
        name='IdentifySecondaryObjects'
    ),
    FunctionStep(
        func=(identify_tertiary_objects, {
                'select_the_larger_identified_objects': 'Cells',
                'select_the_smaller_identified_objects': 'Nuclei',
                'name_the_tertiary_objects_to_be_identified': 'Cytoplasm'
            }),
        name='IdentifyTertiaryObjects'
    ),
    FunctionStep(
        func={
            '2': [
                (measure_object_size_shape, {
                        'calculate_zernikes': False,
                        'select_object_sets_to_measure': 'Cells'
                    }),
                (measure_object_size_shape, {
                        'calculate_zernikes': False,
                        'select_object_sets_to_measure': 'Cytoplasm'
                    })
            ],
            '1': (measure_object_size_shape, {
                    'calculate_zernikes': False,
                    'select_object_sets_to_measure': 'Nuclei'
                })
        },
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func={
            '1': [
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Nuclei',
                        'select_images_to_measure': 'CropBlue'
                    }),
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Cells',
                        'select_images_to_measure': 'CropBlue'
                    }),
                (measure_object_intensity, {
                        'select_object_sets_to_measure': 'Cytoplasm',
                        'select_images_to_measure': 'CropBlue'
                    })
            ]
        },
        name='MeasureObjectIntensity'
    ),
    FunctionStep(
        func={
            '1': [
                (measure_texture_objects, {
                        'measurement_scope': CellProfilerMeasurementTargetScope.BOTH,
                        'select_object_sets_to_measure': 'Nuclei',
                        'select_images_to_measure': 'CropBlue'
                    }),
                (measure_texture_objects, {
                        'measurement_scope': CellProfilerMeasurementTargetScope.BOTH,
                        'select_object_sets_to_measure': 'Cells',
                        'select_images_to_measure': 'CropBlue'
                    }),
                (measure_texture_objects, {
                        'measurement_scope': CellProfilerMeasurementTargetScope.BOTH,
                        'select_object_sets_to_measure': 'Cytoplasm',
                        'select_images_to_measure': 'CropBlue'
                    })
            ]
        },
        name='MeasureTexture'
    ),
    FunctionStep(
        func=(gray_to_color, {
                'rescale_intensity': False,
                'red_channel': 0,
                'green_channel': 1,
                'blue_channel': 2,
                'select_the_image_to_be_colored_red': 'CropRed',
                'select_the_image_to_be_colored_green': 'CropGreen',
                'select_the_image_to_be_colored_blue': 'CropBlue',
                'name_the_output_image': 'RGBImage'
            }),
        name='GrayToColor',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.SITE
        )
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SEQUENTIAL_NUMBERS,
                'single_file_name': 'CroppedFlyImage',
                'append_suffix': True,
                'filename_suffix': 'RGB',
                'bit_depth': SaveImagesBitDepth.UINT8,
                'overwrite': False,
                'base_image_folder': 'Default Input Folder',
                'record_file_and_path': False,
                'select_the_image_to_save': 'RGBImage'
            }),
        name='SaveImages'
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'calculate_aggregate_means': True,
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Nuclei',
                        ),
                        file_name='Nuclei.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Cells',
                        ),
                        file_name='Cells.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Cytoplasm',
                        ),
                        file_name='Cytoplasm.csv'
                    )
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]