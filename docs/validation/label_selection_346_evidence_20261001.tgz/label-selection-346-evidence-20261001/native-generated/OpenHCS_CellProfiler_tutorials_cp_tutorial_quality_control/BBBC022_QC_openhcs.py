# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import LazyStepSourceBindingsConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.interop.cellprofiler.analyst_export import (
    CPAImageChannelSpec,
    CellProfilerObjectTableMode,
)
from openhcs.processing.backends.cellprofiler.export_to_database import export_to_database
from openhcs.processing.backends.cellprofiler.image_quality import measure_image_quality
from openhcs.processing.backends.cellprofiler.thresholding import CellProfilerOtsuMethod

pipeline_steps = [
    FunctionStep(
        func=[
            (measure_image_quality, {
                    'calculate_threshold': False,
                    'blur_scales': (
                        20,
                        10,
                        5,
                        2
                    )
                }),
            (measure_image_quality, {
                    'include_scaling': False,
                    'calculate_blur': False,
                    'calculate_saturation': False,
                    'calculate_intensity': False,
                    'select_images_to_measure': 'OrigHoechst'
                }),
            (measure_image_quality, {
                    'include_scaling': False,
                    'calculate_blur': False,
                    'calculate_saturation': False,
                    'calculate_intensity': False,
                    'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                    'select_images_to_measure': 'OrigPh_golgi'
                })
        ],
        name='MeasureImageQuality',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(export_to_database, {
                'sqlite_file': 'BBBC022QC.db',
                'experiment_name': 'BBBC022QC',
                'add_table_prefix': True,
                'table_prefix': 'BBBC022QC_',
                'object_table_mode': CellProfilerObjectTableMode.COMBINED,
                'image_channels': (
                    CPAImageChannelSpec(
                        alias='OrigER',
                        image_name='Channel1',
                        channel_color='green'
                    ),
                    CPAImageChannelSpec(
                        alias='OrigHoechst',
                        image_name='Channel2',
                        channel_color='blue'
                    ),
                    CPAImageChannelSpec(
                        alias='OrigMito',
                        image_name='Channel3',
                        channel_color='red'
                    ),
                    CPAImageChannelSpec(
                        alias='OrigPh_golgi',
                        image_name='Channel4',
                        channel_color='yellow'
                    ),
                    CPAImageChannelSpec(
                        alias='OrigSyto',
                        image_name='Channel5',
                        channel_color='magenta'
                    )
                ),
                'location_object': 'None',
                'thumbnail_image_names': (
                    'OrigER',
                    'OrigHoechst',
                    'OrigMito',
                    'OrigPh_golgi',
                    'OrigSyto'
                ),
                'auto_scale_thumbnail_intensities': False,
                'plate_type': '384',
                'wants_group_fields': True,
                'group_fields': (
                    (
                        'PerWell',
                        'ImageNumber, Image_Metadata_Plate, Image_Metadata_Well'
                    ),
                ),
                'phenotype_class_table': 'QCClassification',
                'classification_type': 'image'
            }),
        name='ExportToDatabase',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        ),
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True
        )
    )
]