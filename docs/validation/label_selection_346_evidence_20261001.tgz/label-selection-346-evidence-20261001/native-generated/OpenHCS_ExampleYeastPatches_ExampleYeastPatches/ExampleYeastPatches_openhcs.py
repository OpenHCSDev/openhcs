# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.color import (
    ColorToGrayMode,
    color_to_gray,
)
from openhcs.processing.backends.cellprofiler.crop import (
    CropModule,
    crop,
)
from openhcs.processing.backends.cellprofiler.display_modules import display_data_on_image
from openhcs.processing.backends.cellprofiler.grid import (
    DiameterChoice,
    ShapeChoice,
    define_grid_automatic,
    identify_objects_in_grid,
)
from openhcs.processing.backends.cellprofiler.illumination import (
    IlluminationCorrectionMethod,
    IntensityChoice,
    RescaleOption,
    SmoothingMethod,
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.morphology import closing
from openhcs.processing.backends.cellprofiler.object_filtering import filter_objects
from openhcs.processing.backends.cellprofiler.outlines import (
    LineMode,
    overlay_outlines,
)
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    WatershedMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    save_images,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import export_to_spreadsheet
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(crop, {
                'removal_method': CropModule.RemovalMethod.ALL,
                'left_right_rectangle_positions': (
                    170,
                    1425
                ),
                'top_bottom_rectangle_positions': (
                    150,
                    985
                ),
                'ellipse_center': (
                    500,
                    500
                ),
                'ellipse_x_radius': 400.0,
                'ellipse_y_radius': 200.0,
                'name_the_output_image': 'CropOriginal'
            }),
        name='Crop',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(color_to_gray, {
                'mode': ColorToGrayMode.COMBINE,
                'name_the_output_image': 'CropGray'
            }),
        name='ColorToGray'
    ),
    FunctionStep(
        func=(correct_illumination_calculate, {
                'intensity_choice': IntensityChoice.BACKGROUND,
                'block_size': 40,
                'rescale_option': RescaleOption.NO,
                'smoothing_method': SmoothingMethod.CONVEX_HULL,
                'name_the_output_image': 'Illumgray'
            }),
        name='CorrectIlluminationCalculate'
    ),
    FunctionStep(
        func=(correct_illumination_apply, {
                'method': IlluminationCorrectionMethod.SUBTRACT,
                'select_the_input_image': 'CropGray',
                'select_the_illumination_function': 'Illumgray',
                'name_the_output_image': 'CorrectedGray'
            }),
        name='CorrectIlluminationApply'
    ),
    FunctionStep(
        func=(closing, {
                'size': 5,
                'name_the_output_image': 'ClosingGray'
            }),
        name='Closing'
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 20,
                'max_diameter': 80,
                'unclump_method': UnclumpMethod.SHAPE,
                'watershed_method': WatershedMethod.SHAPE,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'Prespots'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(measure_object_size_shape, {
                'calculate_advanced': False
            }),
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=(display_data_on_image, {
                'measurement_feature': 'AreaShape_FormFactor',
                'select_the_image_on_which_to_display_the_measurements': 'CorrectedGray',
                'name_the_output_image_that_has_the_measurements_displayed': 'DisplayImage'
            }),
        name='DisplayDataOnImage'
    ),
    FunctionStep(
        func=(display_data_on_image, {
                'measurement_feature': 'AreaShape_Area',
                'select_the_image_on_which_to_display_the_measurements': 'CorrectedGray',
                'name_the_output_image_that_has_the_measurements_displayed': 'DisplayImage'
            }),
        name='DisplayDataOnImage'
    ),
    FunctionStep(
        func=(filter_objects, {
                'measurement_features': (
                    'AreaShape_FormFactor',
                    'AreaShape_Area'
                ),
                'measurement_min_values': (
                    0.6,
                    1500.0
                ),
                'measurement_max_values': (
                    1.0,
                    1.0
                ),
                'measurement_use_minimum': (
                    True,
                    True
                ),
                'measurement_use_maximum': (
                    False,
                    False
                ),
                'name_the_output_objects': 'FilterObjects'
            }),
        name='FilterObjects'
    ),
    FunctionStep(
        func=(define_grid_automatic, {
                'first_spot_row': 1,
                'first_spot_col': 1,
                'second_spot_row': 1,
                'second_spot_col': 1,
                'retain_an_image_of_the_grid': False,
                'select_the_image_on_which_to_display_the_grid': 'CorrectedGray',
                'select_the_previously_identified_objects': 'FilterObjects',
                'name_the_grid': 'Grid'
            }),
        name='DefineGrid'
    ),
    FunctionStep(
        func=[
            (identify_objects_in_grid, {
                    'shape_choice': ShapeChoice.NATURAL,
                    'diameter_choice': DiameterChoice.AUTOMATIC,
                    'select_the_defined_grid': 'Grid',
                    'select_the_guiding_objects': 'Prespots',
                    'name_the_objects_to_be_identified': 'NaturalSpots'
                }),
            (identify_objects_in_grid, {
                    'shape_choice': ShapeChoice.CIRCLE_NATURAL,
                    'diameter_choice': DiameterChoice.AUTOMATIC,
                    'select_the_defined_grid': 'Grid',
                    'select_the_guiding_objects': 'Prespots',
                    'name_the_objects_to_be_identified': 'ForcedSpots'
                })
        ],
        name='IdentifyObjectsInGrid'
    ),
    FunctionStep(
        func=[
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'NaturalSpots',
                    'select_images_to_measure': 'CorrectedGray'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'ForcedSpots',
                    'select_images_to_measure': 'CorrectedGray'
                })
        ],
        name='MeasureObjectIntensity'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'line_mode': LineMode.THICK,
                'select_image_on_which_to_display_outlines': 'CropGray',
                'select_objects_to_display': 'NaturalSpots',
                'name_the_output_image': 'OutlinedNatural'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'line_mode': LineMode.THICK,
                'select_image_on_which_to_display_outlines': 'CropGray',
                'select_objects_to_display': 'ForcedSpots',
                'name_the_output_image': 'OutlinedForced'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=[
            (save_images, {
                    'single_file_name': 'OrigBlue',
                    'append_suffix': True,
                    'filename_suffix': '_NaturalOutline',
                    'file_format': SaveImagesFileFormat.PNG,
                    'bit_depth': SaveImagesBitDepth.UINT8,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_image_name_for_file_prefix': 'original',
                    'select_the_image_to_save': 'OutlinedNatural'
                }),
            (save_images, {
                    'single_file_name': 'OrigBlue',
                    'append_suffix': True,
                    'filename_suffix': '_ForcedOutline',
                    'file_format': SaveImagesFileFormat.PNG,
                    'bit_depth': SaveImagesBitDepth.UINT8,
                    'base_image_folder': 'Elsewhere...|',
                    'record_file_and_path': False,
                    'select_image_name_for_file_prefix': 'original',
                    'select_the_image_to_save': 'OutlinedForced'
                })
        ],
        name='SaveImages',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]