# Edit this pipeline and save to apply changes

from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.object_images import (
    ImageMode,
    convert_objects_to_image,
)
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFilenameMethod,
    save_images,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerAveragingMethod,
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 50,
                'max_diameter': 60,
                'smoothing_filter_size': 6,
                'maxima_suppression_size': 6.7,
                'threshold_correction_factor': 4.0,
                'threshold_method': CellProfilerThresholdMethod.ROBUST_BACKGROUND,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 64,
                'lower_outlier_fraction': 0.02,
                'upper_outlier_fraction': 0.02,
                'averaging_method': CellProfilerAveragingMethod.MODE,
                'number_of_deviations': 0.0,
                'select_the_input_image': 'rawDNA',
                'name_the_primary_objects_to_be_identified': 'Nuclei'
            }),
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'name_the_output_image': 'OpenHCSReferenceLabels_Nuclei'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': 'reference_labels__Nuclei',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False
            }),
        name='SaveImages'
    )
]