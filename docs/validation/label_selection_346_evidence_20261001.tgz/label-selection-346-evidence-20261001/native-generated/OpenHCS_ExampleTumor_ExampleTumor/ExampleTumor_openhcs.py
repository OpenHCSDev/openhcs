# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceBindingOrigin,
    SourceFilterClause,
    SourceFilterMatchType,
    SourceFilterSubject,
    SourceSelector,
)
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.color import (
    ColorToGrayMode,
    color_to_gray,
)
from openhcs.processing.backends.cellprofiler.image_math import image_math
from openhcs.processing.backends.cellprofiler.outlines import (
    LineMode,
    overlay_outlines,
)
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    save_images,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import export_to_spreadsheet
from openhcs.processing.backends.cellprofiler.thresholding import CellProfilerOtsuMethod

pipeline_steps = [
    FunctionStep(
        func={
            '2': (color_to_gray, {
                    'mode': ColorToGrayMode.COMBINE,
                    'name_the_output_image': 'GrayLung'
                }),
            '1': (color_to_gray, {
                    'channel_indices': (
                        1,
                    ),
                    'contributions': (
                        1.0,
                    ),
                    'name_the_output_image': 'GrayTumor'
                })
        },
        name='ColorToGray',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 4,
                'max_diameter': 99999,
                'automatic_smoothing': False,
                'smoothing_filter_size': 15,
                'automatic_suppression': False,
                'maxima_suppression_size': 15.0,
                'threshold_correction_factor': 1.2,
                'threshold_smoothing_scale': 1.0,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 50,
                'select_the_input_image': 'GrayTumor',
                'name_the_primary_objects_to_be_identified': 'tumor'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(measure_object_size_shape, {
                'calculate_advanced': False
            }),
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=(image_math, {
                'factors': (
                    0.5,
                    0.5
                ),
                'name_the_output_image': 'CombinedImage'
            }),
        name='ImageMath'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'line_mode': LineMode.THICK,
                'outline_colors': (
                    'magenta',
                ),
                'name_the_output_image': 'TumorOutline'
            }),
        name='OverlayOutlines'
    ),
    FunctionStep(
        func=(save_images, {
                'single_file_name': 'OrigBlue',
                'append_suffix': True,
                'filename_suffix': '_Tumors',
                'file_format': SaveImagesFileFormat.PNG,
                'bit_depth': SaveImagesBitDepth.UINT8,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_image_name_for_file_prefix': 'ColorFluor',
                'select_the_image_to_save': 'TumorOutline'
            }),
        name='SaveImages',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='ColorFluor',
                    selector=SourceSelector(
                        filters=(
                            SourceFilterClause(
                                subject=SourceFilterSubject.FILE,
                                match_type=SourceFilterMatchType.CONTAINS,
                                value='f.jpg'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    component_identity=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='1'
                        ),
                    ),
                    source_channel_axis=-1
                ),
            )
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]