# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    GroupBy,
    VariableComponents,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.interop.cellprofiler.measurement_scope import CellProfilerMeasurementTargetScope
from openhcs.processing.backends.cellprofiler.alignment import align
from openhcs.processing.backends.cellprofiler.area_occupied import (
    OperandChoice,
    measure_image_area_occupied,
)
from openhcs.processing.backends.cellprofiler.classification import (
    ClassificationBinChoice,
    classify_objects_single_measurement,
)
from openhcs.processing.backends.cellprofiler.colocalization import (
    CostesMethod,
    measure_colocalization,
)
from openhcs.processing.backends.cellprofiler.illumination import (
    correct_illumination_apply,
    correct_illumination_calculate,
)
from openhcs.processing.backends.cellprofiler.image_math import ImageMathOperation
from openhcs.processing.backends.cellprofiler.measurement_math import calculate_math
from openhcs.processing.backends.cellprofiler.morphology import (
    ExpandShrinkMode,
    expand_or_shrink_objects,
    mask_objects,
)
from openhcs.processing.backends.cellprofiler.object_filtering import filter_objects
from openhcs.processing.backends.cellprofiler.primary_objects import identify_primary_objects
from openhcs.processing.backends.cellprofiler.relationships import (
    RelateObjectsDistanceMethod,
    relate_objects,
)
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdAssignment,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func={
            '1': (correct_illumination_calculate, {
                    'name_the_output_image': 'IllumStain1'
                }),
            '2': (correct_illumination_calculate, {
                    'name_the_output_image': 'IllumStain2'
                })
        },
        name='CorrectIlluminationCalculate',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '1': (correct_illumination_apply, {
                    'name_the_output_image': 'CorrectedStain1'
                }),
            '2': (correct_illumination_apply, {
                    'name_the_output_image': 'CorrectedStain2'
                })
        },
        name='CorrectIlluminationApply',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(align, {
                'name_the_first_output_image': 'Stain1',
                'name_the_second_output_image': 'Stain2'
            }),
        name='Align',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.SITE,
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(measure_colocalization, {
                'costes_method': CostesMethod.ACCURATE,
                'measurement_scope': CellProfilerMeasurementTargetScope.IMAGE
            }),
        name='MeasureColocalization',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.SITE
        )
    ),
    FunctionStep(
        func={
            '1': (identify_primary_objects, {
                    'min_diameter': 3,
                    'max_diameter': 15,
                    'threshold_method': CellProfilerThresholdMethod.OTSU,
                    'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                    'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                    'adaptive_window_size': 50,
                    'select_the_input_image': 'Stain1',
                    'name_the_primary_objects_to_be_identified': 'Objects1'
                }),
            '2': (identify_primary_objects, {
                    'min_diameter': 3,
                    'max_diameter': 15,
                    'threshold_method': CellProfilerThresholdMethod.OTSU,
                    'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                    'adaptive_window_size': 50,
                    'select_the_input_image': 'Stain2',
                    'name_the_primary_objects_to_be_identified': 'Objects2'
                })
        },
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(relate_objects, {
                'calculate_distances': RelateObjectsDistanceMethod.CENTROID,
                'save_children_with_parents': False
            }),
        name='RelateObjects'
    ),
    FunctionStep(
        func={
            '1': (expand_or_shrink_objects, {
                    'mode': ExpandShrinkMode.SHRINK_TO_POINT,
                    'fill_holes': False,
                    'name_the_output_objects': 'ShrunkenObjects1'
                }),
            '2': (expand_or_shrink_objects, {
                    'mode': ExpandShrinkMode.SHRINK_TO_POINT,
                    'fill_holes': False,
                    'name_the_output_objects': 'ShrunkenObjects2'
                })
        },
        name='ExpandOrShrinkObjects'
    ),
    FunctionStep(
        func={
            '1': (expand_or_shrink_objects, {
                    'iterations': 2,
                    'fill_holes': False,
                    'select_the_input_objects': 'ShrunkenObjects1',
                    'name_the_output_objects': 'ExpandedObjects1'
                }),
            '2': (expand_or_shrink_objects, {
                    'iterations': 2,
                    'fill_holes': False,
                    'select_the_input_objects': 'ShrunkenObjects2',
                    'name_the_output_objects': 'ExpandedObjects2'
                })
        },
        name='ExpandOrShrinkObjects'
    ),
    FunctionStep(
        func=(relate_objects, {
                'calculate_distances': RelateObjectsDistanceMethod.NONE,
                'save_children_with_parents': False,
                'select_the_parent_objects': 'ExpandedObjects1',
                'select_the_child_objects': 'ExpandedObjects2'
            }),
        name='RelateObjects'
    ),
    FunctionStep(
        func=(classify_objects_single_measurement, {
                'measurement_feature': 'Children_Objects2_Count',
                'bin_choice': ClassificationBinChoice.CUSTOM,
                'wants_low_bin': True,
                'wants_high_bin': True,
                'custom_thresholds': (
                    0.5,
                ),
                'bin_names': (
                    'NotColocalized',
                    'Colocalized'
                ),
                'select_the_object_to_be_classified': 'Objects1'
            }),
        name='ClassifyObjects'
    ),
    FunctionStep(
        func=(filter_objects, {
                'measurement_features': (
                    'Children_Objects2_Count',
                ),
                'measurement_min_values': (
                    1.0,
                ),
                'measurement_max_values': (
                    1.0,
                ),
                'measurement_use_minimum': (
                    True,
                ),
                'measurement_use_maximum': (
                    False,
                ),
                'select_the_object_to_filter': 'Objects1',
                'name_the_output_objects': 'ColocalizedObjects'
            }),
        name='FilterObjects'
    ),
    FunctionStep(
        func=(mask_objects, {
                'select_the_input_objects': 'Objects1',
                'select_the_masking_object': 'Objects2',
                'name_the_output_objects': 'ColocalizedRegion'
            }),
        name='MaskObjects'
    ),
    FunctionStep(
        func=(measure_image_area_occupied, {
                'operand_choices': (
                    OperandChoice.OBJECTS,
                    OperandChoice.OBJECTS
                ),
                'select_objects_to_measure': (
                    'ColocalizedRegion',
                    'Objects1'
                )
            }),
        name='MeasureImageAreaOccupied'
    ),
    FunctionStep(
        func=(calculate_math, {
                'operand1_feature': 'AreaOccupied_AreaOccupied_ColocalizedRegion',
                'operand2_feature': 'AreaOccupied_AreaOccupied_Objects1',
                'operation': ImageMathOperation.DIVIDE,
                'output_name': 'Stain1Colocalized'
            }),
        name='CalculateMath'
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]