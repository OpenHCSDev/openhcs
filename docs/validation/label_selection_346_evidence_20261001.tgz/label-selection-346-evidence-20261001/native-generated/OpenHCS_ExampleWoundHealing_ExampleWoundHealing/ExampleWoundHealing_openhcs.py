# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.area_occupied import (
    OperandChoice,
    measure_image_area_occupied,
)
from openhcs.processing.backends.cellprofiler.color import (
    ColorToGrayMode,
    color_to_gray,
)
from openhcs.processing.backends.cellprofiler.morphology import FillHolesOption
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.smoothing import smooth
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(color_to_gray, {
                'mode': ColorToGrayMode.COMBINE,
                'name_the_output_image': 'OrigGray'
            }),
        name='ColorToGray',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(smooth, {
                'auto_object_size': False,
                'object_size': 20,
                'name_the_output_image': 'Corrected'
            }),
        name='Smooth'
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'exclude_size': False,
                'exclude_border_objects': False,
                'unclump_method': UnclumpMethod.NONE,
                'fill_holes': FillHolesOption.NEVER,
                'threshold_correction_factor': 0.95,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'Tissue'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(measure_image_area_occupied, {
                'operand_choices': (
                    OperandChoice.OBJECTS,
                )
            }),
        name='MeasureImageAreaOccupied'
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'calculate_aggregate_means': True,
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]