# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.feature_enhancement import (
    NeuriteMethod,
    enhance_or_suppress_features,
)
from openhcs.processing.backends.cellprofiler.image_geometry import (
    MaskSource,
    mask_image,
)
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    WatershedMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.relationships import (
    RelateObjectsDistanceMethod,
    relate_objects,
)
from openhcs.processing.backends.cellprofiler.spreadsheet_export import (
    SpreadsheetFileSelection,
    export_to_spreadsheet,
)
from openhcs.processing.backends.cellprofiler.thresholding import CellProfilerThresholdMethod

pipeline_steps = [
    FunctionStep(
        func={
            '1': (identify_primary_objects, {
                    'min_diameter': 120,
                    'max_diameter': 300,
                    'unclump_method': UnclumpMethod.SHAPE,
                    'watershed_method': WatershedMethod.SHAPE,
                    'threshold_method': CellProfilerThresholdMethod.OTSU,
                    'adaptive_window_size': 50,
                    'name_the_primary_objects_to_be_identified': 'Nuclei'
                })
        },
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '2': (enhance_or_suppress_features, {
                    'radius': 5.0,
                    'neurite_method': NeuriteMethod.TUBENESS,
                    'name_the_output_image': 'EnhancedGreen'
                })
        },
        name='EnhanceOrSuppressFeatures',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(mask_image, {
                'mask_source': MaskSource.OBJECTS,
                'name_the_output_image': 'MaskedGreen'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 4,
                'max_diameter': 35,
                'automatic_smoothing': False,
                'smoothing_filter_size': 4,
                'automatic_suppression': False,
                'maxima_suppression_size': 4.0,
                'threshold_method': CellProfilerThresholdMethod.ROBUST_BACKGROUND,
                'adaptive_window_size': 50,
                'name_the_primary_objects_to_be_identified': 'h2ax'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func={
            '1': (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nuclei'
                }),
            '2': measure_object_intensity
        },
        name='MeasureObjectIntensity',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(relate_objects, {
                'calculate_distances': RelateObjectsDistanceMethod.NONE,
                'calculate_per_parent_means': True,
                'save_children_with_parents': False
            }),
        name='RelateObjects'
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'export_all_measurement_types': False,
                'file_selections': (
                    SpreadsheetFileSelection(
                        subjects=(
                            'Image',
                        ),
                        file_name='Image.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'Nuclei',
                        ),
                        file_name='Nuclei.csv'
                    ),
                    SpreadsheetFileSelection(
                        subjects=(
                            'h2ax',
                        ),
                        file_name='h2ax.csv'
                    )
                ),
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]