# Edit this pipeline and save to apply changes

from openhcs.constants.constants import GroupBy
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.classification import (
    ClassificationBinChoice,
    classify_objects_single_measurement,
)
from openhcs.processing.backends.cellprofiler.display_modules import display_data_on_image
from openhcs.processing.backends.cellprofiler.image_math import ImageMathOperation
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.measurement_math import calculate_math
from openhcs.processing.backends.cellprofiler.morphology import FillHolesOption
from openhcs.processing.backends.cellprofiler.object_filtering import filter_objects
from openhcs.processing.backends.cellprofiler.outlines import overlay_outlines
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.relationships import (
    RelateObjectsDistanceMethod,
    relate_objects,
)
from openhcs.processing.backends.cellprofiler.spreadsheet_export import export_to_spreadsheet
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func={
            '1': (identify_primary_objects, {
                    'min_diameter': 8,
                    'max_diameter': 80,
                    'unclump_method': UnclumpMethod.SHAPE,
                    'fill_holes': FillHolesOption.AFTER_DECLUMP,
                    'adaptive_window_size': 50,
                    'name_the_primary_objects_to_be_identified': 'Nuclei'
                }),
            '2': (identify_primary_objects, {
                    'min_diameter': 5,
                    'max_diameter': 20,
                    'automatic_smoothing': False,
                    'fill_holes': FillHolesOption.AFTER_DECLUMP,
                    'threshold_min': 0.05,
                    'threshold_method': CellProfilerThresholdMethod.OTSU,
                    'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                    'adaptive_window_size': 50,
                    'name_the_primary_objects_to_be_identified': 'PH3'
                })
        },
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(relate_objects, {
                'calculate_distances': RelateObjectsDistanceMethod.NONE,
                'save_children_with_parents': False
            }),
        name='RelateObjects'
    ),
    FunctionStep(
        func=(filter_objects, {
                'measurement_features': (
                    'Children_PH3_Count',
                ),
                'measurement_min_values': (
                    1.0,
                ),
                'measurement_max_values': (
                    1.0,
                ),
                'measurement_use_minimum': (
                    True,
                ),
                'measurement_use_maximum': (
                    False,
                ),
                'select_the_object_to_filter': 'Nuclei',
                'name_the_output_objects': 'PH3PosNuclei'
            }),
        name='FilterObjects'
    ),
    FunctionStep(
        func=(measure_object_intensity, {
                'select_object_sets_to_measure': 'Nuclei',
                'select_images_to_measure': (
                    'OrigGreen',
                    'OrigBlue'
                )
            }),
        name='MeasureObjectIntensity',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '2': (overlay_outlines, {
                    'outline_colors': (
                        '#00FF40',
                    ),
                    'select_image_on_which_to_display_outlines': 'OrigGreen',
                    'select_objects_to_display': 'Nuclei',
                    'name_the_output_image': 'OrigGreenOverlay'
                })
        },
        name='OverlayOutlines',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(display_data_on_image, {
                'measurement_feature': 'Intensity_MaxIntensity_OrigGreen',
                'text_color': (
                    1.0,
                    0.0,
                    1.0
                ),
                'select_the_image_on_which_to_display_the_measurements': 'OrigGreenOverlay',
                'select_the_input_objects': 'Nuclei',
                'name_the_output_image_that_has_the_measurements_displayed': 'DisplayImage'
            }),
        name='DisplayDataOnImage'
    ),
    FunctionStep(
        func=(classify_objects_single_measurement, {
                'measurement_feature': 'Intensity_MaxIntensity_OrigGreen',
                'bin_choice': ClassificationBinChoice.CUSTOM,
                'wants_low_bin': True,
                'wants_high_bin': True,
                'custom_thresholds': (
                    0.2,
                ),
                'bin_names': (
                    'PH3Neg',
                    'PH3Pos'
                ),
                'select_the_object_to_be_classified': 'Nuclei'
            }),
        name='ClassifyObjects'
    ),
    FunctionStep(
        func=(calculate_math, {
                'operand1_feature': 'Count_PH3PosNuclei',
                'operand2_feature': 'Count_Nuclei',
                'operation': ImageMathOperation.DIVIDE,
                'final_multiplicand': 100,
                'output_name': 'PercentPositive',
                'select_the_denominator_objects': 'Nuclei'
            }),
        name='CalculateMath'
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'add_filename_prefix': False,
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]