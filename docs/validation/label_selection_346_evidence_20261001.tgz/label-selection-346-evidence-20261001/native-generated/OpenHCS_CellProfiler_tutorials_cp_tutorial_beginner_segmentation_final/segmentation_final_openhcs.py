# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    GroupBy,
    VariableComponents,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.colocalization import measure_colocalization_objects
from openhcs.processing.backends.cellprofiler.feature_enhancement import (
    NeuriteMethod,
    enhance_or_suppress_features,
)
from openhcs.processing.backends.cellprofiler.image_geometry import (
    MaskSource,
    mask_image,
)
from openhcs.processing.backends.cellprofiler.intensity import measure_object_intensity
from openhcs.processing.backends.cellprofiler.morphology import FillHolesOption
from openhcs.processing.backends.cellprofiler.outlines import (
    OutlineSourceKind,
    overlay_outlines,
)
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    WatershedMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.relationships import relate_objects_with_saved_children
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    save_images,
)
from openhcs.processing.backends.cellprofiler.secondary import (
    identify_secondary_objects,
    identify_tertiary_objects,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import export_to_spreadsheet
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerOtsuMethod,
    CellProfilerThresholdAssignment,
    CellProfilerThresholdMethod,
)

pipeline_steps = [
    FunctionStep(
        func=(identify_primary_objects, {
                'max_diameter': 150,
                'unclump_method': UnclumpMethod.SHAPE,
                'watershed_method': WatershedMethod.SHAPE,
                'automatic_smoothing': False,
                'smoothing_filter_size': 20,
                'automatic_suppression': False,
                'maxima_suppression_size': 20.0,
                'fill_holes': FillHolesOption.AFTER_DECLUMP,
                'threshold_correction_factor': 0.9,
                'threshold_min': 0.002,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'select_the_input_image': 'OrigDNA',
                'name_the_primary_objects_to_be_identified': 'Nuclei'
            }),
        name='IdentifyPrimaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_secondary_objects, {
                'threshold_correction_factor': 0.7,
                'threshold_min': 0.003,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'regularization_factor': 0.005,
                'select_the_input_image': 'OrigActin_Golgi_Membrane',
                'select_the_input_objects': 'Nuclei',
                'name_the_objects_to_be_identified': 'Cells'
            }),
        name='IdentifySecondaryObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_tertiary_objects, {
                'shrink_primary': False,
                'select_the_larger_identified_objects': 'Cells',
                'select_the_smaller_identified_objects': 'Nuclei',
                'name_the_tertiary_objects_to_be_identified': 'Cytoplasm'
            }),
        name='IdentifyTertiaryObjects'
    ),
    FunctionStep(
        func=(enhance_or_suppress_features, {
                'radius': 5.0,
                'neurite_method': NeuriteMethod.TUBENESS,
                'select_the_input_image': 'OrigRNA',
                'name_the_output_image': 'FilteredRNA'
            }),
        name='EnhanceOrSuppressFeatures',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(mask_image, {
                'mask_source': MaskSource.OBJECTS,
                'select_the_input_image': 'FilteredRNA',
                'select_object_for_mask': 'Nuclei',
                'name_the_output_image': 'RNA_in_Nuclei'
            }),
        name='MaskImage'
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 2,
                'max_diameter': 15,
                'exclude_border_objects': False,
                'watershed_method': WatershedMethod.SHAPE,
                'otsu_class_count': CellProfilerOtsuMethod.THREE_CLASS,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'name_the_primary_objects_to_be_identified': 'Nucleoli'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(overlay_outlines, {
                'outline_source_kinds': (
                    OutlineSourceKind.OBJECTS,
                    OutlineSourceKind.OBJECTS
                ),
                'outline_colors': (
                    'Red',
                    'Green'
                ),
                'select_image_on_which_to_display_outlines': 'OrigRNA',
                'select_objects_to_display': (
                    'Nuclei',
                    'Nucleoli'
                ),
                'name_the_output_image': 'SanityCheck'
            }),
        name='OverlayOutlines',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=[
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cells',
                    'select_images_to_measure': 'OrigDNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cells',
                    'select_images_to_measure': 'OrigER'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cells',
                    'select_images_to_measure': 'OrigMito'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cells',
                    'select_images_to_measure': 'OrigRNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cytoplasm',
                    'select_images_to_measure': 'OrigDNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cytoplasm',
                    'select_images_to_measure': 'OrigER'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cytoplasm',
                    'select_images_to_measure': 'OrigMito'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Cytoplasm',
                    'select_images_to_measure': 'OrigRNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nuclei',
                    'select_images_to_measure': 'OrigDNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nuclei',
                    'select_images_to_measure': 'OrigER'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nuclei',
                    'select_images_to_measure': 'OrigMito'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nuclei',
                    'select_images_to_measure': 'OrigRNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nucleoli',
                    'select_images_to_measure': 'OrigDNA'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nucleoli',
                    'select_images_to_measure': 'OrigER'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nucleoli',
                    'select_images_to_measure': 'OrigMito'
                }),
            (measure_object_intensity, {
                    'select_object_sets_to_measure': 'Nucleoli',
                    'select_images_to_measure': 'OrigRNA'
                })
        ],
        name='MeasureObjectIntensity',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=[
            (measure_object_size_shape, {
                    'calculate_advanced': False,
                    'select_object_sets_to_measure': 'Cells'
                }),
            (measure_object_size_shape, {
                    'calculate_advanced': False,
                    'select_object_sets_to_measure': 'Cytoplasm'
                }),
            (measure_object_size_shape, {
                    'calculate_advanced': False,
                    'select_object_sets_to_measure': 'Nuclei'
                }),
            (measure_object_size_shape, {
                    'calculate_advanced': False,
                    'select_object_sets_to_measure': 'Nucleoli'
                })
        ],
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func=[
            (measure_colocalization_objects, {
                    'select_object_sets_to_measure': 'Cells',
                    'select_images_to_measure': (
                        'OrigActin_Golgi_Membrane',
                        'OrigDNA',
                        'OrigER',
                        'OrigMito',
                        'OrigRNA'
                    )
                }),
            (measure_colocalization_objects, {
                    'select_object_sets_to_measure': 'Cytoplasm',
                    'select_images_to_measure': (
                        'OrigActin_Golgi_Membrane',
                        'OrigDNA',
                        'OrigER',
                        'OrigMito',
                        'OrigRNA'
                    )
                }),
            (measure_colocalization_objects, {
                    'select_object_sets_to_measure': 'Nuclei',
                    'select_images_to_measure': (
                        'OrigActin_Golgi_Membrane',
                        'OrigDNA',
                        'OrigER',
                        'OrigMito',
                        'OrigRNA'
                    )
                }),
            (measure_colocalization_objects, {
                    'select_object_sets_to_measure': 'Nucleoli',
                    'select_images_to_measure': (
                        'OrigActin_Golgi_Membrane',
                        'OrigDNA',
                        'OrigER',
                        'OrigMito',
                        'OrigRNA'
                    )
                })
        ],
        name='MeasureColocalization',
        processing_config=LazyProcessingConfig(
            variable_components=[
                VariableComponents.CHANNEL
            ],
            group_by=GroupBy.SITE,
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(relate_objects_with_saved_children, {
                'calculate_per_parent_means': True,
                'save_children_with_parents': True,
                'select_the_child_objects': 'Nucleoli',
                'select_the_parent_objects': 'Nuclei',
                'name_the_output_object': 'NucleoliChildObjects'
            }),
        name='RelateObjects'
    ),
    FunctionStep(
        func=(save_images, {
                'single_file_name': 'OrigBlue',
                'append_suffix': True,
                'filename_suffix': '_overlay',
                'output_location': 'overlay_images',
                'bit_depth': SaveImagesBitDepth.UINT8,
                'overwrite': False,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_image_name_for_file_prefix': 'OrigRNA',
                'select_the_image_to_save': 'SanityCheck'
            }),
        name='SaveImages',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'overwrite_existing_files_without_warning': False
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]