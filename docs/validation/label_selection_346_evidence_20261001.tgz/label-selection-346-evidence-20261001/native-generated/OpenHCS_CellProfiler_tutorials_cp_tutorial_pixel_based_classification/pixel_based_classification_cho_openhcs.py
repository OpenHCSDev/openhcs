# Edit this pipeline and save to apply changes

from openhcs.constants.constants import (
    AllComponents,
    GroupBy,
)
from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.source_bindings import (
    ComponentSelector,
    LazyStepSourceBindingsConfig,
    NamedSourceBinding,
    SourceBindingOrigin,
    SourceFilterClause,
    SourceFilterMatchType,
    SourceFilterSubject,
    SourceSelector,
)
from openhcs.core.steps.function_step import FunctionStep
from openhcs.interop.cellprofiler.measurement_scope import CellProfilerMeasurementTargetScope
from openhcs.processing.backends.cellprofiler.color import color_to_gray
from openhcs.processing.backends.cellprofiler.outlines import (
    LineMode,
    overlay_outlines,
)
from openhcs.processing.backends.cellprofiler.primary_objects import (
    UnclumpMethod,
    WatershedMethod,
    identify_primary_objects,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFileFormat,
    save_images_with_measurements,
)
from openhcs.processing.backends.cellprofiler.shape import measure_object_size_shape
from openhcs.processing.backends.cellprofiler.spreadsheet_export import export_to_spreadsheet
from openhcs.processing.backends.cellprofiler.texture import measure_texture_objects
from openhcs.processing.backends.cellprofiler.thresholding import (
    CellProfilerThresholdAssignment,
    CellProfilerThresholdMethod,
    threshold,
)

pipeline_steps = [
    FunctionStep(
        func={
            '1': (threshold, {
                    'threshold_method': CellProfilerThresholdMethod.MINIMUM_CROSS_ENTROPY,
                    'window_size': 10,
                    'smoothing': 1.3488,
                    'name_the_output_image': 'phaseThresh'
                })
        },
        name='Threshold',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '2': (color_to_gray, {
                    'channel_indices': (
                        0,
                    ),
                    'contributions': (
                        1.0,
                    ),
                    'name_the_output_image': 'choSegmented'
                })
        },
        name='ColorToGray',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(identify_primary_objects, {
                'min_diameter': 40,
                'max_diameter': 100,
                'unclump_method': UnclumpMethod.SHAPE,
                'watershed_method': WatershedMethod.SHAPE,
                'smoothing_filter_size': 5,
                'automatic_suppression': False,
                'maxima_suppression_size': 10.0,
                'low_res_maxima': False,
                'threshold_method': CellProfilerThresholdMethod.OTSU,
                'threshold_smoothing_scale': 1.0,
                'assign_middle_to_foreground': CellProfilerThresholdAssignment.BACKGROUND,
                'name_the_primary_objects_to_be_identified': 'Cells'
            }),
        name='IdentifyPrimaryObjects'
    ),
    FunctionStep(
        func=(measure_object_size_shape, {
                'calculate_advanced': False
            }),
        name='MeasureObjectSizeShape'
    ),
    FunctionStep(
        func={
            '1': (measure_texture_objects, {
                    'measurement_scope': CellProfilerMeasurementTargetScope.BOTH
                })
        },
        name='MeasureTexture',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func={
            '1': (overlay_outlines, {
                    'line_mode': LineMode.THICK,
                    'name_the_output_image': 'ChoOverlay'
                })
        },
        name='OverlayOutlines',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(save_images_with_measurements, {
                'saved_image_name': 'ChoOverlay',
                'single_file_name': 'OrigBlue',
                'append_suffix': True,
                'filename_suffix': '_outlines',
                'file_format': SaveImagesFileFormat.PNG,
                'bit_depth': SaveImagesBitDepth.UINT8,
                'base_image_folder': 'Elsewhere...|',
                'lossless_compression': False,
                'record_file_and_path': True,
                'select_image_name_for_file_prefix': 'phase'
            }),
        name='SaveImages',
        source_bindings=LazyStepSourceBindingsConfig(
            enabled=True,
            bindings=(
                NamedSourceBinding(
                    alias='phase',
                    selector=SourceSelector(
                        filters=(
                            SourceFilterClause(
                                subject=SourceFilterSubject.EXTENSION,
                                match_type=SourceFilterMatchType.EQUALS,
                                value='.png'
                            ),
                        )
                    ),
                    origin=SourceBindingOrigin.PIPELINE_START,
                    component_identity=(
                        ComponentSelector(
                            component=AllComponents.CHANNEL,
                            value='1'
                        ),
                    ),
                    load_as_monochrome=True
                ),
            )
        )
    ),
    FunctionStep(
        func=(export_to_spreadsheet, {
                'add_image_metadata': True,
                'filename_prefix': 'cho_',
                'overwrite_existing_files_without_warning': True
            }),
        name='ExportToSpreadsheet',
        processing_config=LazyProcessingConfig(
            variable_components=[],
            group_by=GroupBy.NONE
        )
    )
]