# Edit this pipeline and save to apply changes

from openhcs.constants.input_source import InputSource
from openhcs.core.config import LazyProcessingConfig
from openhcs.core.steps.function_step import FunctionStep
from openhcs.processing.backends.cellprofiler.morphology import combineobjects
from openhcs.processing.backends.cellprofiler.object_images import (
    ImageMode,
    convert_objects_to_image,
)
from openhcs.processing.backends.cellprofiler.save_images import (
    SaveImagesBitDepth,
    SaveImagesFilenameMethod,
    save_images,
)

pipeline_steps = [
    FunctionStep(
        func=(combineobjects, {
                'select_initial_object_set': 'A',
                'select_object_set_to_combine': 'B',
                'name_the_combined_object_set': 'CombinedObjects'
            }),
        name='CombineObjects',
        processing_config=LazyProcessingConfig(
            input_source=InputSource.PIPELINE_START
        )
    ),
    FunctionStep(
        func=(convert_objects_to_image, {
                'image_mode': ImageMode.UINT16,
                'colormap_value': 'Default',
                'name_the_output_image': 'OpenHCSReferenceLabels_CombinedObjects'
            }),
        name='ConvertObjectsToImage'
    ),
    FunctionStep(
        func=(save_images, {
                'filename_method': SaveImagesFilenameMethod.SINGLE_NAME,
                'single_file_name': 'reference_labels__CombinedObjects',
                'bit_depth': SaveImagesBitDepth.UINT16,
                'base_image_folder': 'Elsewhere...|',
                'record_file_and_path': False,
                'select_the_image_to_save': 'OpenHCSReferenceLabels_CombinedObjects'
            }),
        name='SaveImages'
    )
]