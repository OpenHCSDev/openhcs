import hashlib,json,os,statistics,subprocess,time
from pathlib import Path
from benchmark.runtime_env import configure_headless_cpu_benchmark_runtime
configure_headless_cpu_benchmark_runtime("WARNING")
import numpy as np
from openhcs.processing.backends.cellprofiler import shape
source=Path(os.environ["OPENHCS_REPLAY_SOURCE"])
assert Path(shape.__file__).resolve()==source/"openhcs/processing/backends/cellprofiler/shape.py"
revision=subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip()
assert not subprocess.check_output(["git","status","--porcelain"],cwd=source,text=True).strip()
runs=source.parent/"openhcs-benchmark-runs"
records=[]
for path in sorted((runs/"perf-main0c-labelled-select-inputs-20261001").glob("*.npz")):
    with np.load(path) as saved:
        image=saved["image"]; labels=saved["labels"]; requested=saved["label_ids"]
        mask=saved["mask"] if "mask" in saved else None
        expected=tuple(saved[f"expected_axis_{i}"] for i in range(image.ndim))
    actual=shape._maximum_position_of_labels_scipy_select(image,labels,requested,mask=mask)
    for got,want in zip(actual,expected,strict=True):np.testing.assert_array_equal(got,want)
    samples=[]
    for _ in range(5):
        start=time.perf_counter()
        shape._maximum_position_of_labels_scipy_select(image,labels,requested,mask=mask)
        samples.append(time.perf_counter()-start)
    records.append(dict(input=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),exact_positions=True,samples=samples,median=statistics.median(samples)))
receipt=dict(source=str(source),revision=revision,scope="saved real inputs; exact captured production positions; warmed microreplay, not pipeline clocks",records=records,aggregate_median_seconds=sum(r["median"] for r in records))
(runs/f"label-selection-346-production-replay-{os.environ['OPENHCS_REPLAY_VARIANT']}-20261001.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(dict(revision=revision,exact_calls=len(records),aggregate_median_seconds=receipt["aggregate_median_seconds"])),flush=True)
