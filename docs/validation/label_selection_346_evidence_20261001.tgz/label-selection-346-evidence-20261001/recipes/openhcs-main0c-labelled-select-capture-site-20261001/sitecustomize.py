import functools,importlib.abc,importlib.machinery,json,os,sys
from pathlib import Path
runs=Path('/home/ts/code/projects/openhcs-benchmark-runs/perf-main0c-labelled-select-inputs-20261001')
class SelectLoader(importlib.abc.Loader):
    def __init__(self,loader):self.loader=loader
    def create_module(self,spec):return self.loader.create_module(spec)
    def exec_module(self,module):
        self.loader.exec_module(module)
        expected=Path(os.environ['OPENHCS_DIAGNOSTIC_SOURCE'])/'openhcs/processing/backends/cellprofiler/shape.py'
        assert Path(module.__file__).resolve()==expected
        original=module._maximum_position_of_labels_scipy_select
        count=0
        @functools.wraps(original)
        def capture(image,labels,label_ids,*,mask=None):
            nonlocal count
            import numpy as np
            result=original(image,labels,label_ids,mask=mask)
            count+=1
            destination=runs/f'call_{count:03d}.npz'
            assert not destination.exists()
            values={'image':np.asarray(image),'labels':np.asarray(labels),'label_ids':np.asarray(label_ids),
                    **{f'expected_axis_{i}':axis for i,axis in enumerate(result)}}
            if mask is not None:values['mask']=np.asarray(mask)
            np.savez(destination,**values)
            return result
        module._maximum_position_of_labels_scipy_select=capture
class SelectFinder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname!='openhcs.processing.backends.cellprofiler.shape':return None
        spec=importlib.machinery.PathFinder.find_spec(fullname,path,target)
        assert spec is not None and isinstance(spec.loader,importlib.machinery.SourceFileLoader)
        spec.loader=SelectLoader(spec.loader);return spec
sys.meta_path.insert(0,SelectFinder())
