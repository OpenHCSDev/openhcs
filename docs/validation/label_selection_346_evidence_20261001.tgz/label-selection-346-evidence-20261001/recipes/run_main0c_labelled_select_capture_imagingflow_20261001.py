import csv, json, os, subprocess, hashlib
from pathlib import Path
root=Path('/home/ts/code/projects/openhcs')
runs=root.parent/'openhcs-benchmark-runs'
output=runs/'perf-main0c-labelled-select-capture-imagingflow-20261001'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert revision=='0c0563e6538af313345391f2dc314270a86933a0',revision
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert not output.exists(),output
manifest=root/'benchmark/manifests/official30_portable_axis1.json'
env=dict(os.environ,PYTHONPATH='/tmp/openhcs-main0c-labelled-select-capture-site-20261001:'+str(root),OPENHCS_DIAGNOSTIC_SOURCE=str(root),OPENHCS_EXECUTION_DIAGNOSTIC_CASE='imagingflow',OPENHCS_CPU_ONLY='true',NUMBA_CACHE_DIR='/tmp/openhcs-source-identity-shared-cache-20260930',OPENHCS_REFERENCE_EXPORT_PIPELINES_ROOT=str(root/'benchmark/reference_exports/official30_value_completion_20260914'),OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',PYTHONHASHSEED='0')
command=['/usr/bin/taskset','-c','5',str(root/'.venv/bin/python'),str(root/'scripts/benchmark_cppipe_well_throughput.py'),'--manifest',str(manifest),'--mode','1w_1t','--case','ExampleImagingFlowCytometryObjectsInGrid','--output-dir',str(output)]
receipt=dict(revision=revision,source=str(root),command=command,manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),scope='DIAGNOSTIC real labelled-maximum inputs and exact positions capture; ordinary OUTCOMES, public default memory observer, one well/thread; ready-server startup/shutdown excluded',native_timing_or_figures_claim=False)
(runs/'perf-main0c-labelled-select-capture-imagingflow-source-20261001.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Fresh qualified-main frontier starting',revision,flush=True)
with output.with_suffix('.log').open('w') as stream:
 result=subprocess.run(command,cwd='/tmp',env=env,stdout=stream,stderr=subprocess.STDOUT)
rows=list(csv.DictReader((output/'well_throughput.csv').open()))
(runs/'perf-main0c-labelled-select-capture-imagingflow-observations-20261001.json').write_text(json.dumps(dict(**receipt,returncode=result.returncode,rows=rows),indent=2)+'\n')
assert result.returncode==0 and len(rows)==1 and all(r['status']=='success' and r['successful_wells']=='1' for r in rows)
print(json.dumps(dict(count=len(rows),slowest=[{k:r[k] for k in ('case_name','compile_seconds','execute_seconds','total_seconds')} for r in sorted(rows,key=lambda r:float(r['execute_seconds']),reverse=True)[:10]]),indent=2),flush=True)
