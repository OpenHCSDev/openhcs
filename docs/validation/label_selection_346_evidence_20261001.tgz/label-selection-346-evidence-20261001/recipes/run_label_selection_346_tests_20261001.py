from pathlib import Path
import pytest
if __name__ == "__main__":
    roster=Path("/tmp/openhcs-runtime-owners-review-test-roster-20261001.txt").read_text().splitlines()
    roster += ["tests/unit/test_label_geometry_ordered_selection.py", "tests/unit/agent/test_mcp_dev_client_pipeline_results.py", "tests/unit/agent/test_mcp_server.py", "tests/unit/agent/test_imagexpress_readonly_paths.py", "tests/pyqt_gui/test_image_browser_filter_controller.py"]
    raise SystemExit(pytest.main(roster+["-q", "--junitxml=/home/ts/code/projects/openhcs-benchmark-runs/label-selection-346-tests-20261001.xml"]))
