import csv,fcntl,hashlib,json,os,subprocess
from pathlib import Path
from scripts.mcp_thesis_demo_live import official_runtime_lock_path
root=Path("/home/ts/code/projects/openhcs");candidate=root.parent/"openhcs-label-selection-perf";runs=root.parent/"openhcs-benchmark-runs"
expected={"control":"05c3cf2883fb2ce75c14961264dabad633e639ee","candidate":"e476974886d65cd62ea6115b5bec94cf2710a8ca"}
observations=[]
lock_path=official_runtime_lock_path();lock_path.parent.mkdir(parents=True,exist_ok=True)
with lock_path.open("a+") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for i,label in enumerate(("control","candidate","candidate","control")):
        source=root if label=="control" else candidate
        revision=subprocess.check_output(["git","rev-parse","HEAD"],cwd=source,text=True).strip()
        assert revision==expected[label],(label,revision)
        assert not subprocess.check_output(["git","status","--porcelain"],cwd=source,text=True).strip()
        out=runs/f"label-selection-346-production-abba-{i}-{label}-20261001"
        assert not out.exists()
        env=dict(os.environ,PYTHONPATH=str(source),OPENHCS_CPU_ONLY="true",NUMBA_CACHE_DIR="/tmp/openhcs-source-identity-shared-cache-20260930",
                 OPENHCS_REFERENCE_EXPORT_PIPELINES_ROOT=str(root/"benchmark/reference_exports/official30_value_completion_20260914"),
                 OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",NUMEXPR_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1",PYTHONHASHSEED="0")
        command=["/usr/bin/taskset","-c","5",str(root/".venv/bin/python"),str(source/"scripts/benchmark_cppipe_well_throughput.py"),"--manifest",str(source/"benchmark/manifests/official30_portable_axis1.json"),"--mode","1w_1t","--case","ExampleImagingFlowCytometryObjectsInGrid","--output-dir",str(out)]
        with out.with_suffix(".log").open("w") as stream:result=subprocess.run(command,cwd="/tmp",env=env,stdout=stream,stderr=subprocess.STDOUT)
        assert result.returncode==0,(label,result.returncode)
        rows=list(csv.DictReader((out/"well_throughput.csv").open()))
        assert len(rows)==1 and rows[0]["status"]=="success" and rows[0]["successful_wells"]=="1"
        files=list(out.rglob("BF_cells_on_grid.csv"));assert len(files)==1
        digest=hashlib.sha256(files[0].read_bytes()).hexdigest()
        assert digest=="517057a4b018195cc4c57e8503be63a378a8306eb2ecc303d4a025b6eab6dd1c",digest
        row=dict(index=i,variant=label,source=revision,source_path=str(source),command=command,scope="ordinary production public OUTCOMES, default memory observer, one well/thread/CPU; registry and kernels ready before pipeline clock; server startup/shutdown excluded",diagnostic_injection=False,spreadsheet_sha256=digest,result=rows[0])
        observations.append(row);(runs/"label-selection-346-production-abba-observations-20261001.json").write_text(json.dumps(observations,indent=2)+"\n")
        print(json.dumps(row),flush=True)
