import functools,importlib.abc,importlib.machinery,os,sys,json,time,threading
from pathlib import Path
sys.path.insert(0,'/tmp')
ready=False
compile_output=Path('/home/ts/code/projects/openhcs-benchmark-runs/label-selection-346-production-readiness-events-20261001.jsonl')
class SelectLoader(importlib.abc.Loader):
    def __init__(self,loader):self.loader=loader
    def create_module(self,spec):return self.loader.create_module(spec)
    def exec_module(self,module):
        self.loader.exec_module(module)
        if module.__name__=='numba.core.dispatcher':
            original=module.Dispatcher.compile
            @functools.wraps(original)
            def compile(dispatcher,*args,**kwargs):
                if not ready:return original(dispatcher,*args,**kwargs)
                start=time.perf_counter();prior=[str(value) for value in dispatcher.signatures]
                try:return original(dispatcher,*args,**kwargs)
                finally:
                    event={'kind':'numba_compile','variant':os.environ['OPENHCS_DIAGNOSTIC_VARIANT'],'module':dispatcher.py_func.__module__,'function':dispatcher.py_func.__name__,'signature':str(args[0]),'prior_signatures':prior,
                           'after_readiness':ready,'seconds':time.perf_counter()-start}
                    with compile_output.open('a') as stream:stream.write(json.dumps(event)+'\n')
            module.Dispatcher.compile=compile
            return
        expected=Path(os.environ['OPENHCS_DIAGNOSTIC_SOURCE']) / (module.__name__.replace('.','/')+'.py')
        assert Path(module.__file__).resolve()==expected
        if module.__name__=='openhcs.core.orchestrator.worker_execution':
            original=module.execute_worker_lane
            @functools.wraps(original)
            def lane(*args,**kwargs):
                sched=Path(f'/proc/self/task/{threading.get_native_id()}/schedstat')
                before=[int(v) for v in sched.read_text().split()]
                clock=time.perf_counter();cpu=time.thread_time()
                try:return original(*args,**kwargs)
                finally:
                    after=[int(v) for v in sched.read_text().split()]
                    event={'kind':'worker_lane','variant':os.environ['OPENHCS_DIAGNOSTIC_VARIANT'],
                           'seconds':time.perf_counter()-clock,'thread_cpu_seconds':time.thread_time()-cpu,
                           'runqueue_wait_seconds':(after[1]-before[1])/1e9}
                    with compile_output.open('a') as stream:stream.write(json.dumps(event)+'\n')
            module.execute_worker_lane=lane
            return
        original=module.FunctionCatalogExecutionServer.prepare_runtime_capabilities
        @functools.wraps(original)
        def prepare(server,status_callback=None):
            global ready
            original(server,status_callback)
            ready=True
            with compile_output.open('a') as stream:
                stream.write(json.dumps({'kind':'readiness','variant':os.environ['OPENHCS_DIAGNOSTIC_VARIANT'],'seconds':time.perf_counter()})+'\n')
        module.FunctionCatalogExecutionServer.prepare_runtime_capabilities=prepare
class SelectFinder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname not in ('openhcs.runtime.zmq_execution_server','numba.core.dispatcher','openhcs.core.orchestrator.worker_execution'):return None
        spec=importlib.machinery.PathFinder.find_spec(fullname,path,target)
        assert spec is not None and isinstance(spec.loader,importlib.machinery.SourceFileLoader)
        spec.loader=SelectLoader(spec.loader);return spec
sys.meta_path.insert(0,SelectFinder())
