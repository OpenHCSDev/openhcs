"""Function catalog DTOs for agent-facing OpenHCS discovery."""

from __future__ import annotations

import hashlib
import json
from abc import ABC
from collections.abc import Mapping
from dataclasses import dataclass, field, replace
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar, Generic, Self, TypeVar, cast

from zmqruntime.config import TransportMode
from zmqruntime.messages import MessageFields, ProcessIdentity, ResponseType
from zmqruntime.startup import EndpointStartupStatus

from openhcs.agent.dto.common import (
    SCHEMA_VERSION,
    AgentError,
    AgentDataclassCliRequest,
    AgentResultEnvelope,
)
from openhcs.agent.dto.execution_connection import ExecutionConnectionSpec
from openhcs.agent.exceptions import AgentFacingErrorMixin
from openhcs.agent.path_policy import AgentPathPolicy
from openhcs.core.artifacts import ArtifactViewerStreaming
from openhcs.core.function_reference import FunctionReference
from openhcs.processing.custom_functions.source_namespace import CustomFunctionSource

DEFAULT_FUNCTION_DETAIL_DOC_CHARS = 6_000


class FunctionCatalogControlMessageType(str, Enum):
    """Execution-server control messages for the live function catalog."""

    READ_CATALOG = "openhcs_function_catalog_read"
    SEARCH_CATALOG = "openhcs_function_catalog_search"
    READ_DETAIL = "openhcs_function_detail_read"
    READ_REFERENCE = "openhcs_function_reference_read"
    REGISTER_CUSTOM = "openhcs_custom_function_register"
    OBSERVE_CUSTOM_REGISTRATION = "openhcs_custom_function_registration_observe"
    CUSTOM_REGISTRATION_DESTINATION = "openhcs_custom_function_registration_destination"
    START_PREPARATION = "openhcs_function_catalog_prepare"
    READ_PREPARATION = "openhcs_function_catalog_preparation_status"
    CANCEL_PREPARATION = "openhcs_function_catalog_preparation_cancel"


class FunctionCatalogControlField(str, Enum):
    """OpenHCS-specific fields carried by function-catalog control messages."""

    REQUEST = "request"
    CATALOG = "catalog"
    PREPARATION = "preparation"
    DETAIL = "detail"
    REFERENCE = "reference"
    RESULT = "result"


@dataclass(frozen=True)
class FunctionIdentity:
    function_id: str


@dataclass(frozen=True)
class ImportPathRef:
    import_path: str


@dataclass(frozen=True, slots=True)
class FunctionCatalogControlRequestABC(ABC):
    """Nominal owner of one function-catalog control request identity."""

    message_type: ClassVar[FunctionCatalogControlMessageType]

    def __init_subclass__(cls) -> None:
        if "message_type" not in cls.__dict__:
            raise TypeError(
                f"{cls.__name__} must declare its function-catalog message_type."
            )

    @classmethod
    def from_control_payload(cls, payload: Mapping[str, Any]) -> Self:
        """Recover this exact request type from its declared wire message."""

        actual_message_type = FunctionCatalogControlMessageType(
            str(payload[MessageFields.TYPE])
        )
        if actual_message_type is not cls.message_type:
            raise ValueError(
                f"Expected function catalog control type {cls.message_type.value!r}, "
                f"got {actual_message_type.value!r}."
            )
        request = payload[FunctionCatalogControlField.REQUEST.value]
        if not isinstance(request, cls):
            raise TypeError(
                f"{cls.__name__} control payload requires {cls.__name__}, got "
                f"{type(request).__name__}."
            )
        return request


@dataclass(frozen=True, slots=True)
class FunctionSearchRequest(FunctionCatalogControlRequestABC):
    query: str | None = None
    library: str | None = None
    limit: int = 50
    compact_signatures: bool = True

    message_type = FunctionCatalogControlMessageType.SEARCH_CATALOG


@dataclass(frozen=True, slots=True)
class FunctionCatalogOperationHandle(AgentDataclassCliRequest):
    """Incarnation authority shared by catalog lifecycle operations."""

    connection: ExecutionConnectionSpec
    server_identity: ProcessIdentity

    def require_current_owner(self) -> None:
        if self.server_identity != ProcessIdentity.current():
            raise RuntimeError(
                "Function catalog operation owner changed; handle is stale."
            )


@dataclass(frozen=True, slots=True)
class FunctionCatalogPreparationHandle(FunctionCatalogOperationHandle):
    """The one preparation owner in this exact execution-server incarnation."""


@dataclass(frozen=True, slots=True)
class CustomFunctionRegistrationHandle(FunctionCatalogOperationHandle):
    """Content/owner proof for observing publication, not replay permission."""

    content_sha256: str
    function_name: str | None
    persist: bool
    storage_dir: str | None

    @classmethod
    def from_request(cls, request: CustomFunctionRegistrationRequest) -> Self:
        return cls(
            connection=request.connection, server_identity=request.require_server_identity(),
            content_sha256=CustomFunctionSource.content_digest(request.source_code.encode("utf-8")),
            function_name=request.function_name, persist=request.persist,
            storage_dir=request.storage_dir,
        )

    def require_named_source(self) -> CustomFunctionSource:
        if self.function_name is None:
            raise ValueError("Persisted registration observation requires its admitted name.")
        return CustomFunctionSource(self.function_name, self.content_sha256)

    def require_storage_dir(self) -> Path:
        """Decode this handle's admitted source store once for native/path owners."""
        if self.storage_dir is None:
            raise ValueError("Persisted registration observation requires its admitted store.")
        return Path(self.storage_dir)


class CustomFunctionRegistrationObservationOutcome(str, Enum):
    """Current canonical proofs; absence never establishes a failed mutation."""

    NOT_OBSERVED = "not_observed"
    PUBLISHED = "published"
    PERSISTED_ONLY = "persisted_only"
    REGISTERED = "registered"

    @classmethod
    def from_proofs(cls, *, published: bool, persisted: bool, persist: bool) -> Self:
        if published:
            return cls.REGISTERED if persisted or not persist else cls.PUBLISHED
        return cls.PERSISTED_ONLY if persisted else cls.NOT_OBSERVED


@dataclass(frozen=True, kw_only=True)
class CustomFunctionRegistrationObservation(AgentResultEnvelope):
    handle: CustomFunctionRegistrationHandle
    published_sources: tuple[CustomFunctionSource, ...] = ()
    persisted_source: CustomFunctionSource | None = None
    outcome: CustomFunctionRegistrationObservationOutcome = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "outcome", CustomFunctionRegistrationObservationOutcome.from_proofs(
            published=bool(self.published_sources), persisted=self.persisted_source is not None,
            persist=self.handle.persist,
        ))


class FunctionCatalogPreparationOutcome(str, Enum):
    NOT_STARTED = "not_started"
    PENDING = "pending"
    CANCELLING = "cancelling"
    READY = "ready"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def ready(self) -> bool:
        return self is self.READY

    @property
    def terminal(self) -> bool:
        return self in (self.READY, self.FAILED, self.CANCELLED)


@dataclass(frozen=True, kw_only=True)
class FunctionCatalogPreparationState(AgentResultEnvelope):
    handle: FunctionCatalogPreparationHandle
    outcome: FunctionCatalogPreparationOutcome
    progress: EndpointStartupStatus

    def require_ready(self) -> None:
        if not self.outcome.ready:
            raise FunctionCatalogNotReadyError(self)

    def require_handle(self, expected: FunctionCatalogPreparationHandle) -> None:
        if self.handle != expected:
            raise RuntimeError(
                "Function catalog preparation response changed owner/connection."
            )


class FunctionCatalogNotReadyError(AgentFacingErrorMixin, RuntimeError):
    agent_error_code = "function_catalog_not_ready"
    agent_error_hint = "Start/observe the same typed catalog preparation handle; no source was dispatched."

    def __init__(self, state: FunctionCatalogPreparationState) -> None:
        self.preparation = state
        super().__init__(
            f"Catalog preparation {state.handle!r} is {state.outcome.value}: {state.progress.message}. No source was dispatched."
        )


@dataclass(frozen=True, slots=True)
class FunctionCatalogPreparationStartRequest(FunctionCatalogControlRequestABC):
    connection: ExecutionConnectionSpec
    message_type = FunctionCatalogControlMessageType.START_PREPARATION


@dataclass(frozen=True, slots=True)
class FunctionCatalogPreparationStatusRequest(FunctionCatalogControlRequestABC):
    handle: FunctionCatalogPreparationHandle
    message_type = FunctionCatalogControlMessageType.READ_PREPARATION


@dataclass(frozen=True, slots=True)
class FunctionCatalogPreparationCancelRequest(FunctionCatalogControlRequestABC):
    handle: FunctionCatalogPreparationHandle
    message_type = FunctionCatalogControlMessageType.CANCEL_PREPARATION


@dataclass(frozen=True, slots=True)
class FunctionDetailRequest(FunctionIdentity):
    max_doc_chars: int | None = DEFAULT_FUNCTION_DETAIL_DOC_CHARS
    compact_signature: bool = True


ControlRequestT = TypeVar(
    "ControlRequestT",
    bound=FunctionCatalogControlRequestABC,
)
ControlResponseT = TypeVar("ControlResponseT")


@dataclass(frozen=True, slots=True)
class CustomFunctionRegistrationRequest(FunctionCatalogControlRequestABC):
    """Register custom function source through the public custom-function manager."""

    source_code: str
    persist: bool = True
    compact_signature: bool = True
    connection: ExecutionConnectionSpec = field(default_factory=ExecutionConnectionSpec)
    function_name: str | None = None
    storage_dir: str | None = None
    admission_policy: AgentPathPolicy | None = field(default=None, repr=False, compare=False)
    server_identity: ProcessIdentity | None = None

    message_type = FunctionCatalogControlMessageType.REGISTER_CUSTOM

    @classmethod
    def from_fields(
        cls, *, source_code: str, persist: bool = True,
        compact_signature: bool = True, function_name: str | None = None,
        storage_dir: str | None = None, host: str = ExecutionConnectionSpec().host,
        port: int | None = None, transport_mode: TransportMode | None = None,
        persistent: bool = ExecutionConnectionSpec().persistent,
    ) -> Self:
        """Public boundary: callers cannot supply their own write authority."""
        return cls(
            source_code=source_code, persist=persist, compact_signature=compact_signature,
            function_name=function_name, storage_dir=storage_dir,
            connection=ExecutionConnectionSpec(
                host=host, port=port, transport_mode=transport_mode, persistent=persistent,
            ),
        )

    def admitted(self, policy: AgentPathPolicy) -> Self:
        """Admit the exact destination before endpoint dispatch or source evaluation."""
        from openhcs.processing.custom_functions.manager import CustomFunctionManager

        self.connection.require_port("Custom function registration")
        if self.persist:
            if self.function_name is None or self.storage_dir is None:
                raise ValueError("Persisted registration requires function_name and the endpoint's storage_dir.")
            root = Path(self.storage_dir).expanduser()
            if not root.is_absolute():
                raise ValueError("Custom function storage_dir must be absolute.")
            policy.assert_writable(root)
            policy.assert_writable(CustomFunctionManager.source_path_for_name(root, self.function_name))
        return replace(self, admission_policy=policy)

    def require_server_identity(self) -> ProcessIdentity:
        """Require the same native owner that supplied the admission destination."""
        actual = ProcessIdentity.current()
        if self.server_identity != actual:
            raise ValueError(
                f"Custom registration selected server {self.server_identity!r}, "
                f"but reached {actual!r}; no source was evaluated."
            )
        return actual


@dataclass(frozen=True, slots=True)
class CustomFunctionRegistrationDestinationRequest(FunctionCatalogControlRequestABC):
    """Read the persistence owner's exact path without evaluating source."""

    function_name: str | None = None
    message_type = FunctionCatalogControlMessageType.CUSTOM_REGISTRATION_DESTINATION


@dataclass(frozen=True, slots=True)
class CustomFunctionRegistrationObservationRequest(FunctionCatalogControlRequestABC):
    handle: CustomFunctionRegistrationHandle
    message_type = FunctionCatalogControlMessageType.OBSERVE_CUSTOM_REGISTRATION


@dataclass(frozen=True, slots=True)
class CustomFunctionRegistrationDestination:
    storage_dir: str
    source_file_path: str | None
    server_identity: ProcessIdentity = field(default_factory=ProcessIdentity.current)

    def require_request(self, request: CustomFunctionRegistrationRequest) -> None:
        """Reject a different native store before sending executable source."""
        if not request.persist:
            return
        from openhcs.processing.custom_functions.manager import CustomFunctionManager

        expected_root = Path(request.storage_dir).expanduser()
        expected_file = CustomFunctionManager.source_path_for_name(
            expected_root, request.function_name,
        )
        if (
            Path(self.storage_dir).resolve(strict=False) != expected_root.resolve(strict=False)
            or self.source_file_path is None
            or Path(self.source_file_path).resolve(strict=False) != expected_file.resolve(strict=False)
        ):
            raise ValueError(
                f"Selected endpoint owns custom storage {self.storage_dir}, "
                f"source {self.source_file_path}, not requested {expected_file}; "
                "no source was dispatched."
            )

    def require_result(
        self, request: CustomFunctionRegistrationRequest,
        result: CustomFunctionRegistrationResult,
    ) -> None:
        """Require the returned mutation receipt to identify the admitted owner."""
        if result.server_identity != self.server_identity or result.connection != request.connection:
            raise ValueError("Registration returned a different execution owner.")
        if result.persisted != request.persist:
            raise ValueError("Registration returned a different persistence policy.")
        if request.persist and (
            result.storage_dir != self.storage_dir
            or result.source_file_paths != (self.source_file_path,)
        ):
            raise ValueError("Registration returned a different persistence destination.")


class FunctionParameterSource(str, Enum):
    """Nominal source of one callable parameter in agent-facing docs."""

    _runtime_description: str | None

    def __new__(
        cls,
        value: str,
        runtime_description: str | None,
    ) -> FunctionParameterSource:
        member = str.__new__(cls, value)
        member._value_ = value
        member._runtime_description = runtime_description
        return member

    AGENT = ("agent", None)
    PRIMARY_INPUT = (
        "runtime_primary_input",
        "Supplied by OpenHCS from the FunctionStep input image payload; do not "
        "pass this as a function kwarg.",
    )
    ARTIFACT_INPUT = (
        "runtime_artifact_input",
        "Supplied by OpenHCS from a declared artifact input during pipeline "
        "execution; do not pass this as a function kwarg.",
    )
    RUNTIME_PARAMETER = (
        "runtime_parameter",
        "Supplied by OpenHCS runtime execution infrastructure; do not pass this "
        "as a function kwarg.",
    )
    RUNTIME_ADAPTER = (
        "runtime_adapter",
        "Supplied by OpenHCS as a runtime adapter object; do not pass this as a "
        "function kwarg.",
    )

    @property
    def runtime_description(self) -> str | None:
        """Explain the runtime-owned source directly from its declaration."""

        return self._runtime_description


@dataclass(frozen=True, slots=True)
class FunctionCatalogEntry(FunctionIdentity, ImportPathRef):
    name: str
    module: str
    library: str
    signature: str
    summary: str | None
    backend_tags: tuple[str, ...] = ()

    @property
    def membership_identity(
        self,
    ) -> tuple[str, str, str, str, str, tuple[str, ...]]:
        """Return the endpoint callable identity owned by this declaration."""

        return (
            self.function_id,
            self.import_path,
            self.name,
            self.module,
            self.library,
            self.backend_tags,
        )


@dataclass(frozen=True, slots=True)
class FunctionParameterSpec:
    name: str
    annotation: str | None
    default_repr: str | None
    required: bool
    supplied_by: FunctionParameterSource = FunctionParameterSource.AGENT
    description: str | None = None
    enum_import_path: str | None = None
    enum_members: tuple[str, ...] = ()
    enum_values: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.supplied_by, FunctionParameterSource):
            raise TypeError(
                "FunctionParameterSpec.supplied_by requires "
                f"FunctionParameterSource, got {type(self.supplied_by).__name__}."
            )


@dataclass(frozen=True, slots=True)
class FunctionArtifactSpec:
    name: str
    kind: str
    required: bool = True
    sidecar_role: str | None = None
    materialization_uses_source_identity_filename: bool = False
    viewer_streaming: ArtifactViewerStreaming = ArtifactViewerStreaming.AUTOMATIC

    def __post_init__(self) -> None:
        if not isinstance(self.viewer_streaming, ArtifactViewerStreaming):
            raise TypeError(
                "FunctionArtifactSpec.viewer_streaming requires "
                f"ArtifactViewerStreaming, got {type(self.viewer_streaming).__name__}."
            )


@dataclass(frozen=True, slots=True)
class CellProfilerArtifactBindingSummary:
    """One module-owned setting that declares a compile-time artifact term."""

    direction: str
    kind: str
    setting_names: tuple[str, ...]
    parameter_name: str
    runtime_parameter_name: str | None = None
    repeated: bool = False


@dataclass(frozen=True, slots=True)
class CellProfilerModuleDeclarationSummary:
    module_name: str
    declaration_class: str
    validated: bool
    function_names: tuple[str, ...]
    aliases: tuple[str, ...] = ()
    artifact_bindings: tuple[CellProfilerArtifactBindingSummary, ...] = ()
    exact_artifact_contract_requires_compilation: bool = True


@dataclass(frozen=True, slots=True)
class FunctionRuntimeContractSummary:
    callable_kind: str
    processing_contract: str | None = None
    declared_processing_contract: str | None = None
    runtime_bound_parameters: tuple[str, ...] = ()
    required_variable_components: tuple[str, ...] = ()
    artifact_inputs: tuple[FunctionArtifactSpec, ...] = ()
    artifact_outputs: tuple[FunctionArtifactSpec, ...] = ()
    cellprofiler_module: CellProfilerModuleDeclarationSummary | None = None
    source_binding_rule: str | None = None
    materialization_rule: str | None = None
    measurement_rule: str | None = None
    pattern_compatibility_rule: str | None = None


@dataclass(frozen=True, slots=True)
class FunctionDetail:
    schema_version: str
    entry: FunctionCatalogEntry
    parameters: tuple[FunctionParameterSpec, ...]
    doc: str | None
    runtime_contract: FunctionRuntimeContractSummary | None = None
    doc_truncated: bool = False
    doc_chars: int = 0
    max_doc_chars: int | None = None


@dataclass(frozen=True, slots=True)
class FunctionCatalogPage:
    schema_version: str
    revision: str
    items: tuple[FunctionCatalogEntry, ...]
    total: int
    limit: int
    query: str | None = None
    library: str | None = None


@dataclass(frozen=True, slots=True)
class FunctionCatalogControlRequest(FunctionCatalogControlRequestABC):
    """Request the complete catalog owned by one execution endpoint."""

    compact_signatures: bool = True

    message_type = FunctionCatalogControlMessageType.READ_CATALOG


@dataclass(frozen=True, slots=True)
class FunctionDetailControlRequest(
    FunctionIdentity,
    FunctionCatalogControlRequestABC,
):
    """Request one detail from an exact server catalog revision."""

    catalog_revision: str
    max_doc_chars: int | None = DEFAULT_FUNCTION_DETAIL_DOC_CHARS
    compact_signature: bool = True

    message_type = FunctionCatalogControlMessageType.READ_DETAIL


@dataclass(frozen=True, slots=True)
class FunctionReferenceControlRequest(
    FunctionIdentity,
    FunctionCatalogControlRequestABC,
):
    """Request one compiler reference from an exact server catalog revision."""

    catalog_revision: str

    message_type = FunctionCatalogControlMessageType.READ_REFERENCE


@dataclass(frozen=True, slots=True)
class FunctionCatalogControlPayload(Generic[ControlRequestT]):
    """Wire projection of one request declaration and its enum identity."""

    request: ControlRequestT

    @classmethod
    def from_request(cls, request: ControlRequestT) -> Self:
        if not isinstance(request, FunctionCatalogControlRequestABC):
            raise TypeError(
                "Function catalog control payload requires a nominal control "
                f"request, got {type(request).__name__}."
            )
        return cls(request=request)

    def to_dict(self) -> dict[str, Any]:
        return {
            MessageFields.TYPE: self.request.message_type.value,
            FunctionCatalogControlField.REQUEST.value: self.request,
        }


@dataclass(frozen=True, slots=True)
class FunctionCatalogControlResponseBase(Generic[ControlResponseT]):
    """Shared typed transport for one declared successful control response."""

    value: ControlResponseT
    field: ClassVar[FunctionCatalogControlField]
    value_type: ClassVar[type]

    def __init_subclass__(cls) -> None:
        for attribute in ("field", "value_type"):
            if attribute not in cls.__dict__:
                raise TypeError(
                    f"{cls.__name__} must declare function-catalog {attribute}."
                )

    def to_control_response(self) -> dict[str, Any]:
        return {
            MessageFields.STATUS: ResponseType.OK.value,
            self.field.value: self.value,
        }

    @classmethod
    def from_control_response(cls, payload: Mapping[str, Any]) -> Self:
        if payload.get(MessageFields.STATUS) != ResponseType.OK.value:
            raise RuntimeError(str(payload.get(MessageFields.ERROR) or payload))
        value = payload[cls.field.value]
        if not isinstance(value, cls.value_type):
            raise TypeError(
                f"Function catalog response field {cls.field.value!r} requires "
                f"{cls.value_type.__name__}, got {type(value).__name__}."
            )
        return cls(value=cast(ControlResponseT, value))


class FunctionCatalogControlResponse(
    FunctionCatalogControlResponseBase[FunctionCatalogPage]
):
    """Typed response carrying one endpoint-owned catalog projection."""

    field = FunctionCatalogControlField.CATALOG
    value_type = FunctionCatalogPage

    @property
    def catalog(self) -> FunctionCatalogPage:
        return self.value


class FunctionCatalogPreparationStateControlResponse(
    FunctionCatalogControlResponseBase[FunctionCatalogPreparationState]
):
    field = FunctionCatalogControlField.PREPARATION
    value_type = FunctionCatalogPreparationState


class FunctionCatalogPreparationStatus(str, Enum):
    """Control response state while endpoint catalog preparation is active."""

    PENDING = "pending"


@dataclass(frozen=True, slots=True)
class FunctionCatalogPreparationControlResponse:
    """Typed signal that the endpoint is actively preparing its catalog."""

    status: EndpointStartupStatus
    retry_after_seconds: float = 0.1

    def to_control_response(self) -> dict[str, Any]:
        return {
            MessageFields.STATUS: FunctionCatalogPreparationStatus.PENDING.value,
            FunctionCatalogControlField.PREPARATION.value: self,
        }

    @classmethod
    def from_control_response(
        cls,
        payload: Mapping[str, Any],
    ) -> FunctionCatalogPreparationControlResponse | None:
        if (
            payload.get(MessageFields.STATUS)
            != FunctionCatalogPreparationStatus.PENDING.value
        ):
            return None
        preparation = payload.get(FunctionCatalogControlField.PREPARATION.value)
        if not isinstance(preparation, cls):
            raise TypeError(
                "Pending function catalog response requires "
                "FunctionCatalogPreparationControlResponse, got "
                f"{type(preparation).__name__}."
            )
        return preparation


class FunctionDetailControlResponse(FunctionCatalogControlResponseBase[FunctionDetail]):
    """Typed response carrying one revision-consistent function detail."""

    field = FunctionCatalogControlField.DETAIL
    value_type = FunctionDetail

    @property
    def detail(self) -> FunctionDetail:
        return self.value


class FunctionReferenceControlResponse(
    FunctionCatalogControlResponseBase[FunctionReference]
):
    """Typed response carrying one server-owned compiler reference."""

    field = FunctionCatalogControlField.REFERENCE
    value_type = FunctionReference

    @property
    def reference(self) -> FunctionReference:
        return self.value


@dataclass(frozen=True, kw_only=True, slots=True)
class CustomFunctionRegistrationResult(AgentResultEnvelope):
    """Result of registering custom function source through the public manager."""

    registered_count: int = 0
    persisted: bool = True
    storage_dir: str | None = None
    source_file_paths: tuple[str, ...] = ()
    functions: tuple[FunctionCatalogEntry, ...] = ()
    next_steps: tuple[str, ...] = ()
    connection: ExecutionConnectionSpec = field(default_factory=ExecutionConnectionSpec)
    server_identity: ProcessIdentity | None = None
    observation_handle: CustomFunctionRegistrationHandle | None = None

    @classmethod
    def uncertain(
        cls, request: CustomFunctionRegistrationRequest, error: Exception,
    ) -> Self:
        """Preserve the actual cause and same-owner read-only recovery identity."""
        handle = CustomFunctionRegistrationHandle.from_request(request)
        cause = error.to_agent_error() if isinstance(error, AgentFacingErrorMixin) else AgentError.from_exception(
            "custom_function_registration_uncertain", error,
            hint="Preserve the original request. Observe this handle; do not replay registration. Absence is not proof of no mutation.",
        )
        return cls(
            schema_version=SCHEMA_VERSION, persisted=request.persist,
            storage_dir=request.storage_dir, connection=request.connection,
            server_identity=request.server_identity, observation_handle=handle,
            errors=(cause,),
            next_steps=("Observe this observation_handle with openhcs_get_custom_function_registration_status; do not replay source.",),
        )


class CustomFunctionRegistrationControlResponse(
    FunctionCatalogControlResponseBase[CustomFunctionRegistrationResult]
):
    """Typed response carrying endpoint-owned custom registration results."""

    field = FunctionCatalogControlField.RESULT
    value_type = CustomFunctionRegistrationResult

    @property
    def result(self) -> CustomFunctionRegistrationResult:
        return self.value


class CustomFunctionRegistrationDestinationControlResponse(
    FunctionCatalogControlResponseBase[CustomFunctionRegistrationDestination]
):
    field = FunctionCatalogControlField.RESULT
    value_type = CustomFunctionRegistrationDestination

    @property
    def destination(self) -> CustomFunctionRegistrationDestination:
        return self.value


class CustomFunctionRegistrationObservationControlResponse(
    FunctionCatalogControlResponseBase[CustomFunctionRegistrationObservation]
):
    field = FunctionCatalogControlField.RESULT
    value_type = CustomFunctionRegistrationObservation


def catalog_page(
    *,
    items: tuple[FunctionCatalogEntry, ...],
    catalog_items: tuple[FunctionCatalogEntry, ...],
    total: int,
    limit: int,
    query: str | None,
    library: str | None,
) -> FunctionCatalogPage:
    return FunctionCatalogPage(
        schema_version=SCHEMA_VERSION,
        revision=function_catalog_revision(catalog_items),
        items=items,
        total=total,
        limit=limit,
        query=query,
        library=library,
    )


def function_catalog_revision(items: tuple[FunctionCatalogEntry, ...]) -> str:
    """Return a deterministic revision of endpoint callable membership.

    Presentation choices such as compact signatures and bounded summaries do not
    change which callable identity the endpoint owns, so they are intentionally
    excluded from the membership revision.
    """

    encoded = json.dumps(
        [item.membership_identity for item in items],
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()
