"""Read the original installed observation and persisted engineering artifacts."""
from pathlib import Path
import csv
import hashlib
import json
import zipfile
import openhcs
from openhcs.runtime.zmq_execution_observation import ZMQRuntimeExecutionObservationExport
from openhcs.core.source_metadata import SourceVoxelSpacingUnit

root = Path('/run/media/ts/hdd/openhcs-engineering/engineering541-public88-20261005')
target = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering-pre-first-routing-20261004/receiving17/attempt02/target')
assert Path(openhcs.__file__).is_relative_to(target)
export = ZMQRuntimeExecutionObservationExport.read(root / 'values01')
export.require_valid_observation()
records = export.records_by_axis['A01']
assert len(records) == 12, len(records)
graph = next(record.data for record in records if record.key.name == 'neurite_morphology')
assert graph.coordinate_unit is SourceVoxelSpacingUnit.PIXELS
assert not graph.source_voxel_spacing.has_values
results = root / 'results/acquisition_openhcs/results'
tables = tuple(results.glob('*details.csv'))
assert len(tables) == 2
table_counts = {}
for path in tables:
    with path.open(newline='') as handle:
        rows = list(csv.DictReader(handle))
    assert rows and all(row['coordinate_unit'] == 'pixels' for row in rows)
    assert not any('_um' in field for field in rows[0])
    table_counts[path.name] = len(rows)
archive = results / 'A01_s001_w2_z001_t001_neurite_morphology_step0.graph.roi.zip'
with zipfile.ZipFile(archive) as handle:
    metadata = json.loads(handle.read('__polystore_roi_metadata__.json'))
assert len(metadata) == len(graph.edges) == 3
for value in metadata.values():
    assert value['coordinate_unit'] == 'pixels'
    assert value['openhcs_image_payload_metadata']['source_voxel_spacing']['values_zyx'] == []
assert not tuple(results.glob('*.swc'))
print(json.dumps({
    'installed_origin': openhcs.__file__,
    'execution_id': export.execution_id,
    'valid_observation': True,
    'runtime_artifact_count': len(records),
    'graph_coordinate_unit': graph.coordinate_unit.value,
    'acquisition_spacing': repr(graph.source_voxel_spacing),
    'graph_edges': len(graph.edges),
    'csv_rows': table_counts,
    'roi_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'values_sha256': hashlib.sha256((root / 'values01').read_bytes()).hexdigest(),
}, indent=2))
