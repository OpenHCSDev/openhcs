"""Write only declared tiny synthetic acquisition TIFFs, once."""
import hashlib
import json
from pathlib import Path
import numpy as np
import tifffile

root = Path(__file__).parent
acquisition = root / 'acquisition'
acquisition.mkdir(exist_ok=False)
gray = np.arange(180, dtype=np.uint8).reshape(12, 15)
color = np.stack((gray, np.full_like(gray, 32), np.full_like(gray, 240)), axis=-1)
inputs = (
    ('A01_s1_w1_z1_t1_Gray.tif', gray, 'minisblack'),
    ('A01_s1_w2_z1_t1_Color.tif', color, 'rgb'),
)
records = []
for name, data, photometric in inputs:
    path = acquisition / name
    tifffile.imwrite(path, data, photometric=photometric)
    records.append(dict(path=str(path), shape=list(data.shape), dtype=str(data.dtype),
                        sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
with (root / 'INPUTS.json').open('x') as stream:
    json.dump(records, stream, indent=2)
print(json.dumps(records))
