"""Ordinary complete source-bound CP pipeline; synthetic inputs only."""
from dataclasses import replace
from pathlib import Path
from openhcs.constants.constants import GroupBy, Microscope, VariableComponents
from openhcs.core.config import LazyPathPlanningConfig, LazyProcessingConfig, LazyNapariStreamingConfig
from openhcs.core.source_bindings import MetadataExtractionRule, MetadataSource
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.interop.cellprofiler.pipeline_import import import_cellprofiler_pipeline

root = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/public-packet01')
pipeline_steps, imported = import_cellprofiler_pipeline(root / 'intensity600.cppipe')
pipeline_config = replace(
    imported,
    microscope=Microscope.SOURCE_BINDINGS,
    processing_config=LazyProcessingConfig(
        variable_components=[VariableComponents.Z_INDEX], group_by=GroupBy.CHANNEL,
    ),
    path_planning_config=LazyPathPlanningConfig(global_output_folder=root / 'results'),
    source_bindings_config=replace(
        imported.source_bindings_config,
        metadata_rules=(MetadataExtractionRule(
            source=MetadataSource.FILE_NAME,
            pattern=r'(?P<well>[A-H]\d{2})_s(?P<site>\d+)_w(?P<channel>\d+)_z(?P<z_index>\d+)_t(?P<timepoint>\d+)_(?:Gray|Color)\.tif',
        ),),
        source_stack_components=(),
        source_voxel_spacing=SourceVoxelSpacing((0.5, 0.5)),
    ),
    napari_streaming_config=LazyNapariStreamingConfig(enabled=False),
)
