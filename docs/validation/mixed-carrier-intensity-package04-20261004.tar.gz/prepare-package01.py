"""Parameterize the existing pinned archive owner; no new package recipe."""
from pathlib import Path

root = Path(__file__).parent
original = root.parent / 'engineering-wholemain-after394-20261004/prepare-source05.py'
program = original.read_text()
program = program.replace("repository = Path('/home/ts/code/projects/openhcs')",
    "repository = Path('/home/ts/wt/openhcs-ui-workflow-rendering-20261001')")
program = program.replace("head = 'a8256f45b1bbd2f9ab1bbd2466bf5823a127c188'",
    "head = 'c63af64a604df4d940bfa716c6edce565ec82d47'")
program = program.replace("assert git('diff', '--name-only', previous, head).decode().splitlines() == [guide]",
    "changed = git('diff', '--name-only', previous, head).decode().splitlines()")
program = program.replace("source = root / 'receiving06/source'", "source = root / 'package01/source'")
program = program.replace("prior_wheel, = (root / 'receiving04/wheels').glob('*.whl')",
    "prior_wheel, = (root.parent / 'engineering-wholemain-after394-20261004/receiving06/wheels-corrected07').glob('*.whl')")
program = program.replace("selected.add('docs/source/development/mcp_knowledge_base_manifest.json')",
    "selected.add('docs/source/development/mcp_knowledge_base_manifest.json')\nselected.update({'setup.cfg', 'THIRD_PARTY_LICENSES'})")
program = program.replace("changed_since_qualified04=[guide]", "changed_since_qualified04=changed")
program = program.replace("prior_attempt='receiving05: archive pathspec failure before any build/install, original log retained'",
    "prior_attempt='none: first engineering599 whole-package attempt; prior owners receipts remain unchanged'")
exec(compile(program, str(original), 'exec'))
