"""Reuse the complete receiving04 Git/source/wheel/installed RECORD verifier."""
from pathlib import Path
import subprocess

root = Path(__file__).parent / 'package01'
repository = '/home/ts/wt/openhcs-ui-workflow-rendering-20261001'
head = 'c63af64a604df4d940bfa716c6edce565ec82d47'
source = root / 'source'
for name in ('setup.py', 'setup.cfg', 'pyproject.toml', 'MANIFEST.in',
             'scripts/build_mcp_knowledge_assets.py'):
    assert (source / name).read_bytes() == subprocess.check_output(
        ['git', '-C', repository, 'show', f'{head}:{name}']), name

original = root.parents[1] / 'engineering-wholemain-after394-20261004/receiving04/qualify-bytes.py'
wrapper = original.read_text().replace(
    '/home/ts/wt/openhcs-basicpy-readiness-20260929', str(source)).replace(
    'a0efb9b5d44e7f99d3c42cb5712724fbf2a4f07a', head)
wrapper = wrapper.replace("exec(compile(program, str(original), 'exec'))", '')
namespace = {'__file__': str(root / 'qualify-bytes.py')}
exec(compile(wrapper, str(original), 'exec'), namespace)
program = namespace['program'].replace(
    "['git', '-C', str(source),", f"['git', '-C', {repository!r},")
program = program.replace("assert git('rev-parse', 'HEAD') == head", '')
program = program.replace(
    "git('diff', '--exit-code', 'HEAD', '--', 'openhcs', 'benchmark', 'packaging', 'docs/source/development/mcp_knowledge_base_manifest.json', 'setup.py', 'pyproject.toml')", '')
program = program.replace("git('ls-files', '-z', '--', 'openhcs', 'benchmark')",
    "git('ls-tree', '-r', '-z', '--name-only', head, '--', 'openhcs', 'benchmark')")
exec(compile(program, str(original), 'exec'), {'__file__': str(root / 'qualify-bytes.py')})
