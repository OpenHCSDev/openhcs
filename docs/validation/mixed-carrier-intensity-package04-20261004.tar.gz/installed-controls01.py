"""Run the affected numerical family against the complete installed package."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).parent
target = root / 'package01/target'
sys.path.insert(0, str(target))
import openhcs
import openhcs.core.runtime_image_values as values
assert Path(openhcs.__file__).is_relative_to(target)
assert Path(values.__file__).is_relative_to(target)
print(json.dumps(dict(source_head='c63af64a604df4d940bfa716c6edce565ec82d47',
    imported=str(values.__file__), sha256=hashlib.sha256(Path(values.__file__).read_bytes()).hexdigest())), flush=True)
import pytest
raise SystemExit(pytest.main(['--noconftest', '--import-mode=importlib',
    '-p', 'no:cacheprovider', '-o', 'addopts=', '-q',
    str(root / 'package01/source/tests/unit/test_mixed_carrier_intensity_domain.py')]))
