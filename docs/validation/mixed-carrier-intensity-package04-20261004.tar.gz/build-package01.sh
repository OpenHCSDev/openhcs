#!/usr/bin/env bash
set -euo pipefail
root=/home/ts/wt/openhcs-issue-batch-20260929/engineering599
paired_python=/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python
dependencies=/home/ts/wt/openhcs-issue-batch-20260929/engineering-wholemain-after394-20261004/dependency-wheels
test ! -e "$root/package01"
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
"$paired_python" -B "$root/prepare-package01.py"
cd "$root/package01/source"
"$paired_python" -B -m build --wheel --no-isolation --outdir "$root/package01/wheels"
cd "$root"
"$paired_python" -B -m pip install --no-index --no-deps --no-compile --target "$root/package01/target" \
 "$root/package01/wheels/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl" \
 "$dependencies/objectstate-1.1.9-py3-none-any.whl" \
 /home/ts/wt/openhcs-issue-batch-20260929/engineering-python-introspect016/artifacts/python_introspect-0.1.16-py3-none-any.whl \
 "$dependencies/polystore-0.3.2-py3-none-any.whl"
