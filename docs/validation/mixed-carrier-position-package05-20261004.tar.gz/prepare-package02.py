"""Same original archive owner for the reviewed combined receiving source."""
from pathlib import Path
original = Path(__file__).parent / 'prepare-package01.py'
program = original.read_text().replace('c63af64a604df4d940bfa716c6edce565ec82d47',
    '42203213d744b2b0393c9966868e8d02ec45c3d9').replace('package01/source', 'package02/source')
program = program.replace('none: first engineering599 whole-package attempt; prior owners receipts remain unchanged',
    'package01 c63 whole qualification retained; reviewed614 added in one new combined whole candidate')
exec(compile(program, str(original), 'exec'))
