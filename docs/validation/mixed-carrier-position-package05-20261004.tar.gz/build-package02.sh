#!/usr/bin/env bash
set -euo pipefail
# Reuse the same original normal builder/materializer, on a distinct source pin/target.
original=/home/ts/wt/openhcs-issue-batch-20260929/engineering599/build-package01.sh
source <(sed -e 's/package01/package02/g' "$original")
