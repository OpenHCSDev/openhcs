"""Affected registered positions controls against the coherent whole target."""
from pathlib import Path
original = Path(__file__).parent / 'installed-controls01.py'
program = original.read_text().replace("'package01/target'", "'package02/target'")
program = program.replace('c63af64a604df4d940bfa716c6edce565ec82d47',
    '42203213d744b2b0393c9966868e8d02ec45c3d9')
program = program.replace("str(root / 'package01/source/tests/unit/test_mixed_carrier_intensity_domain.py')",
    "str(root / 'package02/source/tests/unit/test_source_tile_geometry.py'), '-k', 'position_artifact_preserves or positions_reject or registered_nine_site'")
exec(compile(program, str(original), 'exec'))
