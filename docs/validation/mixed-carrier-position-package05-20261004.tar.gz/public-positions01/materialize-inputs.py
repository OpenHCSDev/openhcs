"""Write18 tiny acquisition TIFFs with original embedded header declarations."""
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET
import numpy as np
import tifffile

root = Path(__file__).parent
acquisition = root / 'acquisition'
acquisition.mkdir(exist_ok=False)
records = []
for channel in (2, 1):
    for site in (9, 3, 7, 1, 8, 2, 6, 4, 5):
        row, column = divmod(site - 1, 3)
        metadata = ET.Element('MetaData')
        plane = ET.SubElement(metadata, 'PlaneInfo')
        values = {
            'OffsetFromWellCenterUmX': (column * 7 - 2) * 0.5,
            'OffsetFromWellCenterUmY': (row * 5 - 1) * 0.25,
            'SiteX': column + 1, 'SiteY': row + 1,
            'spatial-calibration-x': 0.5, 'spatial-calibration-y': 0.25,
            'spatial-calibration-units': 'um', 'spatial-calibration-state': 'on',
        }
        for name, value in values.items():
            ET.SubElement(plane, 'prop', id=name, value=str(value))
        path = acquisition / f'A01_s{site:03d}_w{channel}_z001_t001.tif'
        pixels = np.full((4, 6), 10 * channel + site, dtype=np.uint16)
        tifffile.imwrite(path, pixels, description=ET.tostring(metadata, encoding='unicode'), metadata=None)
        records.append(dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            channel=channel, site=site, positions_xy=[column * 7 - 2, row * 5 - 1],
            shape=list(pixels.shape), value=10 * channel + site))
with (root / 'INPUTS.json').open('x') as stream:
    json.dump(records, stream, indent=2)
print(json.dumps(records))
