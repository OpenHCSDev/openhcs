"""Registered acquisition placement and ordinary assembly; no custom callable."""
from pathlib import Path
from openhcs.constants.constants import GroupBy, Microscope, VariableComponents
from openhcs.core.config import (
    PipelineConfig, LazySourceBindingsConfig, LazyProcessingConfig,
    LazyPathPlanningConfig, LazyNapariStreamingConfig, LazyStepMaterializationConfig,
)
from openhcs.core.source_bindings import MetadataExtractionRule, MetadataSource
from openhcs.core.steps import FunctionStep
from openhcs.processing.backends.pos_gen.acquisition_positions import acquisition_tile_positions
from openhcs.processing.backends.assemblers.assemble_stack_cpu import assemble_stack_cpu
from openhcs.processing.backends.assemblers.blending import TileBlendMethod

root = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/public-positions01')
pipeline_config = PipelineConfig(
    microscope=Microscope.SOURCE_BINDINGS,
    source_bindings_config=LazySourceBindingsConfig(metadata_rules=(MetadataExtractionRule(
        MetadataSource.FILE_NAME,
        r'(?P<well>A\d+)_s(?P<site>\d+)_w(?P<channel>\d+)_z(?P<z_index>\d+)_t(?P<timepoint>\d+)\.tif',
    ),)),
    path_planning_config=LazyPathPlanningConfig(global_output_folder=root / 'results'),
    napari_streaming_config=LazyNapariStreamingConfig(enabled=False),
)
site_processing = LazyProcessingConfig(
    variable_components=[VariableComponents.SITE], group_by=GroupBy.CHANNEL,
)
pipeline_steps = [
    FunctionStep(name='EmbeddedPositions', func=acquisition_tile_positions,
        processing_config=site_processing),
    FunctionStep(name='AssembledChannels', func=(assemble_stack_cpu, {'blend_method': TileBlendMethod.NONE}),
        processing_config=site_processing,
        step_materialization_config=LazyStepMaterializationConfig(enabled=True, sub_dir='checkpoints')),
]
