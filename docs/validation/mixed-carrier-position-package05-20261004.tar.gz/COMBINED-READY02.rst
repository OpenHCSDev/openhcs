Combined600/614 ordinary candidate for one original receiving lease
==================================================================

Published Git source42203213d744b2b0393c9966868e8d02ec45c3d9 on
receiving/mixed-intensity-acquisition-position-20261004 is a normal merge of
600b08f76c and61489d3d645. No source is patched during package preparation.
The only production difference from qualified600c63 is the one acquisition
positions caller migration; main610 guide changes are included normally.
Both original drafts retain their separate source review and readiness claims.

Whole private target:
/home/ts/wt/openhcs-issue-batch-20260929/engineering599/package02/target
Exact wheel SHA256 ebfb65fe1b70741b322d4463d45f2cbd421381c9e603ba3c8240f05a64c1843c.
Original normal builder/install terminal0,7.48s/146624KiB/Swap0/CPU1, offline
no-isolation/no-deps. No new environment, foreign source edit or SCI target change.
Whole original verifier PASS811 source payloads/789Python/910RECORD entries,
all13 skills/declaration-selected knowledge and full RECORD inventories for
OpenHCS,ObjectState1.1.9,python-introspect0.1.16,PolyStore0.3.2.
Installed registered acquisition positions controls:3 PASS/30deselected.
The26 installed600 controls at package01 remain valid: every600 production
byte is identical at package02; no unchanged suite repetition.

Receiving uses one retained normal public CLI with its exact native TCP94
incarnation after Dewey publishes the original funding/writer handoff.
No viewer, new display, second client, scientific input or custom registration.
No native/client launched by Singer at this checkpoint.

Case600 public-packet01: complete NamesAndTypes/SourceBindings pipeline with
known12x15uint8 scalar and12x15x3RGB acquisition arrays. Registered ImageMath
independent normalization and mixed forward/reverse arithmetic must agree in
full persisted public samples, exactsource identities/.5um calibration.

Case614 public-positions01:18 tiny4x6uint16 acquisition TIFFs, nine sites/two
channels, original embedded ImageXpress XML positions/calibration. Native
registered positions artifact must give[(col*7-2,row*5-1)] in exact resolvedsite
order for both channels; ordinary CPU assembly must consume that positions
artifact without guessedgrid. Both saved mosaics are14x20, source9-site
provenance/.25Y/.5Xmicrometer calibration preserved. Every tile's known value
10*channel+site fills its4x6window at(row*5,col*7); remaining pixels arezero.
Native artifact/input join and complete public persisted pixel samples are
receiving obligations, not inferred from source controls.

Original package01 remains retained. Original source/SCI failures and UNKNOWN
inputs are unchanged. Receive actual terminal compile/execute handles, inventory
routes and public replies; no guessedfilepath/receipt. Close only the original
typed native handle, verify exit/endpoints, quit the original recorded client.
No CI gate; merge each qualified scope normally after this actual receiving.
