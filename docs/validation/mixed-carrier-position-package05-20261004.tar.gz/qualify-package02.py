"""Reuse the same original complete whole-package verifier for combined source."""
from pathlib import Path
original = Path(__file__).parent / 'qualify-package01.py'
program = original.read_text().replace("'package01'", "'package02'").replace(
    'c63af64a604df4d940bfa716c6edce565ec82d47', '42203213d744b2b0393c9966868e8d02ec45c3d9')
exec(compile(program, str(original), 'exec'))
