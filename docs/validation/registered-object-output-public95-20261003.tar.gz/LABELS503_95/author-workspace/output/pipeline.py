"""Prepared public document; no import, compile or native execution yet."""
from dataclasses import replace
from pathlib import Path

from openhcs.constants.constants import AllComponents, GroupBy, VariableComponents
from openhcs.core.config import (
    LazyPathPlanningConfig, LazyProcessingConfig, LazyNapariStreamingConfig,
)
from openhcs.core.source_bindings import MetadataExtractionRule, MetadataSource
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.interop.cellprofiler.pipeline_import import import_cellprofiler_pipeline

root = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output')
pipeline_steps, imported_config = import_cellprofiler_pipeline(root / 'labels503.cppipe')
pipeline_config = replace(
    imported_config,
    processing_config=LazyProcessingConfig(
        variable_components=[VariableComponents.Z_INDEX], group_by=GroupBy.CHANNEL,
    ),
    path_planning_config=LazyPathPlanningConfig(global_output_folder=root / 'results01'),
    source_bindings_config=replace(
        imported_config.source_bindings_config,
        metadata_rules=(MetadataExtractionRule(
            source=MetadataSource.FILE_NAME,
            pattern=r'(?P<well>[A-H]\d{2})_s(?P<site>\d+)_w(?P<channel>\d+)_z(?P<z_index>\d+)_t(?P<timepoint>\d+)_Labels\.tif',
        ),),
        source_stack_components=(AllComponents.Z_INDEX,),
        source_voxel_spacing=SourceVoxelSpacing((1.0, 1.0, 1.0)),
    ),
    napari_streaming_config=LazyNapariStreamingConfig(enabled=False),
)
