503 synthetic categorical join source -- PREPARED ONLY
=====================================================

Engineering only; no acquired biological input. Original synthetic TIFF writer
already saved a12x15uint16 plane: label2 rows0:2/cols2:5 (area6, touches border),
label7 rows6:10/cols8:13 (area20). Unchanged input SHA256:
1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e.

Original registered CellProfiler import: ConvertImageToObjects preserves labels,
MeasureObjectSizeShape, FilterObjects default and removed-enabled. Source IDs2/7
must join categorical area rows6/20. Border filter retains source7 as target1;
separate removed complement source2 as target1. Check directed lineage and
actual label pixels, not equal counts. No additional-group/unbounded ABI claim.

No scientific author, source input, frozen target, helper or native process was
modified. Parent release plus original all-members resource admission is needed.
