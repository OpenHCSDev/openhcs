#!/bin/bash
# Prepared only. Original recorder owns parent release, admission and journals.
set -euo pipefail
root=$(dirname "$(realpath "$0")")
operations=$(jq -er '.operation_owner_root' "$root/program.json")
exec bash "$operations/recorded-mcp.sh" "$root" LABELS503_95 "${1:?distinct admission observation}"
