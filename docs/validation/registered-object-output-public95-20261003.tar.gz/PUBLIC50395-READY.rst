50395 original public journey -- preparation checkpoint
=======================================================

PREPARED ONLY. No release, first-start epoch, client journal, MCP/native/viewer
or helper launch. Singer owns this preparation; Dewey handles WM94, Dalton
resource/helper custody, parent membership freeze and runtime release. The
parent-accepted whole target02 and21 installed controls are not repeated.

Exact lane and sources
----------------------

Root /home/ts/wt/openhcs-issue-batch-20260929/engineering503.
Slot LABELS503_95; CPU1, DISPLAY=:95, existing VNC5999.
Native6014/ACK7014; reserved viewer6015/ACK7015 (streaming disabled).
NEVER use sibling live6012/6013,6020/6021,6016/6017 or their ACKs.
Paired Python /home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python.
Private package target02; c0314a17163260b1b05071e0d405ee386fa6a2e0 source,
f9a15dcbd production; wheel SHA256
498367681f9dbd831c05f7e216d012495fce13c12322be1f6e3c119bd9cfc4f5.

Existing original recorded-mcp.sh, mcp-client.sh, slot-env.sh, resource-check.sh
at next-metaxpress-p001-94-20261003/operations are referenced, not copied.
Existing original successor-program.jq projects successor-declaration.json:
no replaced/retired row; adds ONLY this engineering member. Exact jq comparison
PASS: all three original rows (including run_owner_root), resource envelope
and retained history equal the original P001 programme. No scientist state,
source, manifest, handles or resources changed. No new harness/schema/guard,
registry/environment/install, native compiler/warmup policy or protocol shim.

Original environment owner supplies target02 PYTHONPATH, original interpreter,
DISPLAY=:95/xcb/softwareGL, CPU-only and all scientific threadpools1, original
private scratch XDG roots, downloads=false and read-only shared ImageJ cache.
Agent read/write roots contain this output/private scratch and exact6014/7014/
6015/7015 startup reservations; explicit absent UI bridge prevents desktop0
projection. It launches original dev_client --no-resident --timeout-seconds10
shell --no-prompt under the unchanged common slice, one CPU/Swap0. Ordinary
registry initialization and native catalog/kernel preparation remain untouched.
No parallel client, custom recorder, dependency copy or broad cold import.

Closed predecessor and current custody
-------------------------------------

Read original P001/PARENT-H004-TERMINAL.rst: author71131 terminal0,
client45836 terminal2 retained; native1782231/create1790997054.44 and
viewer1800169/create1790997168.05 public ACK/process_exited/endpoint_terminated/
succeeded alltrue, independently absent;6014/7014/6015/7015 nonlistening then.
Final source/output/QA c3db557f remains preserved, not read as SCI input here.
Original helpers were not stopped/restarted. H004 original handoff owns
helper InvIDs e6ab206f03fd434bbb7e4c7800ffda7d (X),
d6f9ac71441d45889137695ee4c59dd6 (WM),
bee4785c8bbb4cba8daec368782d47b1 (VNC).
Dalton directly confirmed the95 assignment and retained WM1757829; parent
must confirm present helper identities and approve this new membership.
Original launcher rechecks helper InvIDs and retired writer scopes before
recording. The old final journals and UNKNOWN dispositions are never replayed.

All-three remaining growth -- NOT a runtime release
---------------------------------------------------

Dalton's actual resource-owner receipt is
neurite-development-skill383-20261001/output/resource-owner-20261002/
WM94-SUCCESSOR-RESOURCE-CLEARANCE-20261003-0452.rst.
Read all: at04:54:48Z, common13238849536/max18522046464B/Swap0,
MemAvailable9360781312B; full remaining common growth+2GiB desktop
7430680576B, fullPSI60=.47/300=.33. All3 original SCI scopes remain
4831838208B/Swap0; active writer handles68661/12213/38812 are parent-owned.
This old measured clearance is NOT503 admission or a guarantee of future RAM.

Original disk declaration remains1024MiB output+192MiB scratch per member,
7168MiB total and2GiB home floor. At the same original observation,21
historical roots2301865984B+all3 full reservations3825205248B=6127071232B.
Adding this fourth member's FULL1275068416B allowance yields7402139648B,
below original7516192768B by114053120B. This is a narrow STATIC remaining
budget margin, not a fresh disk PASS. No total bound increased, SCI allowance
reduced, historical output dropped or current-growth double counted.

Dalton explicitly requires parent freeze/release before a new engineering
admission: we did NOT run the SCI resource guard or assert admission. After
parent review, original recorder runs fresh replacement-mode guard, including
all4 ledger roots/history and full unchanged common remaining growth+desktop,
PSI, helper custody and retired writers. Any determining failure is retained;
do not relax/retry it or launch outside the existing owner. Parent can review
or freeze this packet now without waiting for Dewey's independent WM94 work.

Exact entrypoint -- only AFTER parent release
--------------------------------------------

In one persistent PTY, using a new unique observation token:

  FLEET_PARENT_RELEASED=1 bash /home/ts/wt/openhcs-issue-batch-20260929/engineering503/launch-programme95.sh public95-startup01

This small wrapper is the original494 delegation with only root/slot changed.
It invokes the original recorder, not another admission engine. Original
runtime/mcp.stdin,mcp.stdout,mcp.timing and first-mcp-started.epoch are exclusive
create-once journals in LABELS503_95/author-workspace/output. Retain the single
returned PTY/handle on any failure; no resident/default7777 connection, startup
replay, extra health-client launch or simultaneous second native fleet.

Public commands and returned-handle boundaries
----------------------------------------------

Working directory and sole writable input/output root:
engineering503/LABELS503_95/author-workspace/output.
initial95.commands contains normal health, first-use/headless discovery, exact
tools/schemas and ONE start_owned_runtime6014tcp command. Enter these lines
through the same recorded shell only after release; stop on any failure or
UNKNOWN. No unconditional batch can cross a pending/unknown start.

1. Keep the COMPLETE returned bootstrap handle. Use normal call:

   call openhcs_observe_owned_runtime --arguments '{"handle":<EXACT_RETURNED_BOOTSTRAP_HANDLE>}' --json

   This is a template: replace only with the original JSON object, not guessed
   PID/port fields. Observe that original handle to READY, do not restart it.
   Then ONE explicit selected-endpoint preparation:

   call openhcs_start_function_catalog_preparation --arguments '{"host":"localhost","port":6014,"transport_mode":"tcp","persistent":true}' --json

   Keep the returned preparation handle; observe through
   openhcs_get_function_catalog_preparation_status with that exact handle as
   the arguments object (its original FunctionCatalogPreparationHandle declares
   connection and server_identity, not a handle wrapper). Do not
   start again, select default7777 or assume a local source catalog is native.

2. Original global config command (same494 values):

   call openhcs_create_config --arguments '{"config_type":"global","values":{"num_workers":1,"use_threading":true,"microscope":"source_bindings","materialize_runtime_artifacts":true}}' --json

   Save original returned config_id. Public artifact-plan command:

   artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline.py --global-config-id <RETURNED_CONFIG_ID> --json

   Complete pipeline.py imports original labels503.cppipe through the ORIGINAL
   registered CellProfiler importer, replaces only normal pipeline/source/path/
   streaming config and uses the whole target. No private algorithm/ABI bypass.
   This initialization may write this OWN staged input's native metadata; no
   acquired/frozen source is writable. Check returned axes, step/artifact roles,
   typed domains and paths. Preserve any real compile/binding failure.

3. Create the normal source session WITHOUT execution. To construct its exact
   existing DTO arguments without copying pipeline source into another owner,
   run this text-only command in a coordinator shell and paste its ONE returned
   command into the original retained MCP shell (substitute actual config_id):

   jq -n --rawfile source /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/pipeline.py --arg cfg '<RETURNED_CONFIG_ID>' '{plate_path:"/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input",pipeline_source:$source,global_config_id:$cfg,host:"localhost",port:6014,transport_mode:"tcp",persistent:true}|"call openhcs_create_orchestrator_session_from_pipeline_source --arguments " + (tojson|@sh) + " --json"' -r

   Keep returned session_id. Submit exactly once:

   call openhcs_submit_compile --arguments '{"session_id":"<RETURNED_SESSION_ID>","wait":false}' --json
   call openhcs_get_execution_status --arguments '{"job_id":"<RETURNED_COMPILE_JOB_ID>"}' --json

   Observe that job to terminal; only on actual compiled success submit once:

   call openhcs_submit_pipeline_execution --arguments '{"session_id":"<RETURNED_SESSION_ID>","compile_artifact_id":"<ACTUAL_COMPILE_ARTIFACT_ID>","runtime_observation_export_path":"/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/runtime-values01.json","wait":false}' --json
   call openhcs_get_execution_status --arguments '{"job_id":"<RETURNED_EXECUTE_JOB_ID>"}' --json

   Omit compile_artifact_id if no such ID is returned by the original compile
   receipt; never invent it. Original VALUES export is requested through the
   existing public submission contract, fresh exclusive path, not a private
   runtime read or new serializer. Preserve exact original error if unavailable.

4. After COMPLETE, public inventory (no filename/receipt fabrication):

   call openhcs_query_plate_files --arguments '{"plate_path":"/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input","kind":"all","limit":50,"include_previews":true,"max_preview_lines":16,"max_preview_bytes":65536}' --json

   Query the actual native result workspace/declared result_directory reported
   by artifact plan/job if needed; use original metadata/source receipt route.
   Each ordinary sample uses EXACT inventory image_path, original plate_path,
   microscope_type source_bindings, y0/x0/height12/width15/resolution_index0/
   include_array_values true/max_array_elements180. Discover actual result-image
   IDs, tables and lineage artifacts from public declarations, not path guesses.
   Normal command template, unchanged public request fields:

   call openhcs_sample_plate_image --arguments '{"plate_path":"<EXACT_INVENTORY_PLATE>","image_path":"<EXACT_INVENTORY_IMAGE>","microscope_type":"source_bindings","y":0,"x":0,"height":12,"width":15,"resolution_index":0,"include_array_values":true,"max_array_elements":180}' --json

   Saved labels/source must be2 and7, supported AreaShape_Area rows2=6/7=20.
   Border default and enabled retain source7->target1; enabled complement
   source2->target1, separate domains/artifact names and original directed
   lineage endpoint pairs. Inspect whole tiny CSV preview/VALUES receipt through
   original published owners; equal counts/sequential IDs alone cannot pass.
   If original public inventory/projection does not expose a required join,
   retain that precise limitation, not a private export/remap/reader workaround.

5. Close via openhcs_close_owned_runtime with EXACT bootstrap handle and force
   mode under its ordinary timeout; retain full ACK/process_exited/endpoint
   outcome and verify exact child/listener exit. No viewer should have started.
   Exit original retained MCP shell normally and observe that SAME PTY terminal.
  95 helper custody stays parent/Dalton-owned; do not signal it here.

Prepared acceptance, not native or science evidence
-------------------------------------------------

Tiny12x15 categorical TIFF byte-equals the original synthetic packet; input
SHA1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e.
No new pixel write/import/test/build/install was performed. Packet syntax and
declaration equality are preparation checks, not registry/compile/native proof.
Source21 and whole private installed21 tests remain accepted at their existing
tier; next step is parent membership freeze/release and this exact public join.
Root's unbounded additional-output502 ABI stays separate, not a501 merge gate.

Fresh prospective4 original admission -- PASS, still no release
---------------------------------------------------------------

ONE read-only original owner invocation, preparation95-01/replacement,
terminal0. Root preparation95-01.stdout/stderr and original runtime/resources-
preparation95-01.* retain complete raw results, including host-helper warning2.
No scientific RPC, guard replacement, extra admission engine or native launch.

Current ALL3 output charges769912832/174534656/192843776B plus own prepared
packet36864B; history2301865984B; full4 reservations5100273664B. History+full4
7402139648B under unchanged7516192768B (114053120B remaining ledger margin).
Home9.217GiB vs ALL4 remaining disk growth+2GiB floor5.691GiB PASS.
Common14372208640/max18522046464B/Swap0; FULL remaining common pool
4149837824B plus desktop2048MiB =>6006MiB required, MemAvailable8.877GiB PASS.
PSIfull60=.16/300=.27 below1percent. The host warning2 (home/root/swap used)
is preserved and not relabelled as zero. Actual original narrower guard PASS.
No new cap, SCI allowance reduction, old output removal or historical H004
per-author guard. All95 X/WM/VNC InvIDs exact-original, caps64/32/32MiB/Swap0.

Read FULL Dalton WM94-SUCCESSOR-LIVE-CUSTODY-20261003-0457.rst: actual NEW
WM94 Invocationc9f2b42c5e3b43f4a990e15b4fe4011e at128MiB, actual future
helper allowance224MiB (64+128+32). This is NOT95's helper declaration.
Future94 handoff must retain that new custody, not old32MiB/128 total. Frozen
P001/SCI historical source/manifest/old handoff remain untouched. The successor's
actual memory charge is ALREADY INCLUDED in common current; no double count.
No newly pending WM allocation was silently excluded from the pool-growth check.

Guide512 merged main independently, only canonical point-QA prose; qualified
503target02/c031 bytes stay immutable. No rebuild or hot SCI505 update.
Parent reviews/freezes the packet and releases next; original recorder rechecks
fresh conditions immediately before actual startup. PASS is not that release,
no non-OOM guarantee and not public/native join acceptance.
