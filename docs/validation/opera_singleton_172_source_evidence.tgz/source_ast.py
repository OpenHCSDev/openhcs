"""Focused syntax/call-site witness, deliberately not an NRA certificate."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
paths = (
    "openhcs/microscopes/opera_phenix_xml_parser.py",
    "openhcs/microscopes/opera_phenix.py",
    "openhcs/demo/synthetic_data.py",
    "openhcs/core/source_tile_geometry.py",
    "openhcs/core/runtime_spatial_grid.py",
)
trees = {}
sources = []
for relative in paths:
    source = (root / relative).read_bytes()
    trees[relative] = ast.parse(source, filename=relative)
    sources.append(dict(path=relative, sha256=hashlib.sha256(source).hexdigest()))
parser = next(node for node in trees[paths[0]].body
              if isinstance(node, ast.ClassDef) and node.name == "OperaPhenixXmlParser")
methods = {node.name: node for node in parser.body if isinstance(node, ast.FunctionDef)}
decoder_calls = []
for name in ("get_grid_size", "get_field_positions"):
    calls = [node for node in ast.walk(methods[name])
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
             and node.func.attr == "_get_field_position"]
    assert len(calls) == 1, (name, calls)
    decoder_calls.append(dict(method=name, decoder="_get_field_position", line=calls[0].lineno))
grid = methods["get_grid_size"]
raw_reads = [node.lineno for node in ast.walk(grid)
             if isinstance(node, ast.Subscript) and isinstance(node.slice, ast.Constant)
             and isinstance(node.slice.value, str)]
assert not raw_reads, raw_reads
assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
               and node.func.attr == "sqrt" for node in ast.walk(grid))
metadata_handler = next(node for node in trees[paths[1]].body
                        if isinstance(node, ast.ClassDef)
                        and node.name == "OperaPhenixMetadataHandler")
dimensions = next(node for node in metadata_handler.body
                  if isinstance(node, ast.FunctionDef) and node.name == "get_grid_dimensions")
returns = [node for node in ast.walk(dimensions) if isinstance(node, ast.Return)]
assert len(returns) == 1
assert ast.unparse(returns[0].value) == "(grid_size[1], grid_size[0])"
def tree_id(revision, path):
    return subprocess.check_output(["git", "rev-parse", f"{revision}:{path}"], text=True).strip()

equivalence = {}
for path in ("openhcs", "scripts", "benchmark"):
    base_tree = tree_id("5ce9e308", path)
    main_tree = tree_id("e690c3bf", path)
    qualified_tree = tree_id("1002437c4", path)
    merged_tree = tree_id("HEAD", path)
    assert base_tree == main_tree, (path, "production baseline changed")
    assert qualified_tree == merged_tree, (path, "qualified production changed")
    equivalence[path] = dict(base=base_tree, merged_main=main_tree,
                             qualified=qualified_tree, merged_head=merged_tree)
assert tree_id("1002437c4", "tests/source_contracts") == tree_id("HEAD", "tests/source_contracts")
print(json.dumps(dict(
    proof_scope="focused_ast_only_not_NRA_or_runtime_consumer_execution",
    source_root=str(root), sources=sources, shared_decoder_sites=decoder_calls,
    grid_raw_string_subscripts=raw_reads, unreachable_grid_sqrt_removed=True,
    unchanged_metadata_consumer_return=ast.unparse(returns[0].value),
    base=subprocess.check_output(["git", "rev-parse", "5ce9e308"], text=True).strip(),
    head=subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    qualified_production_tree_equivalence=equivalence,
), indent=2))
