## Scope

Refs #172. Sole source owner for the Opera initialization defect; parent remains integration/merge and installed-acceptance owner. Target is main, as requested. Started from parent PR #206 at 5ce9e3087e603aaf5177ea88363ef48a804c1163 with PolyStore PR #20 (91fd7e8); paired #206/#16 were pending at dispatch and are now normally merged. This branch normally merged current main e690c3bf, including the merged PolyStore pin 84f322e4; only this owned source fix/test/receipt/evidence remain in the PR diff. This PR is draft and parent will integrate/merge. Keep #172 open.

The original installed MCP raw Opera 1x1 generation (no `--openhcs-format`) warned `plate_grid_dimensions_unavailable`; complete empty PipelineDocument artifact-plan failed `OperaPhenixXmlContentError: Could not determine grid size from XML data`. Its XML is unchanged and the original exception is preserved in source evidence.

## Implementation

- Extend the existing XML parser's finite field-coordinate decoding for both grid and field-remapping readers.
- Accept any nonempty valid coordinate population, including one field and colocated channels/planes, without cached mutation or a special singleton path.
- Keep numeric well/channel/plane populations separate, existing axis quantization and first multi-image group precedence.
- Delete unreachable field-ID square/factor guessing; do not infer geometry from field numbers.
- No generator, filename, microscope-base, metadata store, environment, installed package or parent-worktree edits.

## Evidence and limits

Eleven pure-source XML tests pass in a one-CPU, <=512 MiB, <=60s shard. Unchanged original installed-reproducer XML now yields `(1, 1)` and `{1: 1}` remapping, with fresh-parser reopen and original SHA256 retained. All three unchanged CI structural-ratchet roots pass: -4 string-key reads, -14 long-chain terms, no new dispatch or exceptions. Peak observed combined RSS is 83.55 MiB; longest shard 17.71s. Git tree identity proves normal main integration did not change qualified production/test source. Focused current-archive AST/census is recorded separately, with zero parser failures; no full NRA or global R1 certificate claimed.

This proves the parser source boundary only: no public-package discovery, scientific/native runtime, installed MCP or live UI acceptance. Worktree dependency gitlinks remain deliberately uninitialized. Original failures and all source evidence are archived and byte-verified before disposable scratch/tool-worktree cleanup.

`docs/validation/opera_singleton_172.rst` records pattern IDs, ownership witnesses, exact new-case experiments and resources. Separate A01 persisted metadata versus R01C01 filename inventory mismatch remains tracked under #172: its generator/catalog producer is outside this stage-coordinate owner. Parent retains original installed receipts and performs integration/live acceptance.
