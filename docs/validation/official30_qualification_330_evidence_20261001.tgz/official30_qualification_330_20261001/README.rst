Official30 qualification evidence (#330 / PR331)
===============================================

Validated production source: 4c40348354a0680850ac21cdc102d00e460558ee.
Main base: 2cbfc4a0771bf24d153b076bff4a5e321ac039f4.
The final native run completed 30/30 equivalent, all difference_count=0.
Prior 22/30 and 29/30 failure receipts are retained as counterevidence.
Native references come from official30-native-complete-fresh-20260928; the
source receipt identifies the original reference manifest and output paths.
The final gate reuses those scientific outputs; it does not rerun native CP.
Native execution/total clocks and speedup columns in raw suite reports are
retained observations, NOT fresh comparative performance evidence. No new
scaling figure or performance improvement is claimed by this correctness PR.

Scope: manifest official30_portable_axis1.json, each case's selected well,
one inline worker, CPU5, one native thread, no memory observer. Production
run_comparison_suite uses the OpenHCS adapter's typed native observations and
native declared-image checks, 1e-6 absolute/relative numerical tolerances,
and exact discrete/identity checks. Required ZMQ registry/kernel preparation
completes before pipeline clocks. Startup/shutdown and comparison work do not
enter execution clocks. No tests/audits/builds/replays overlap qualification.

586 local tests and 20 subtests passed; one existing optional Napari skip.
Original pinned R0 passes for openhcs/scripts/benchmark with no increases;
original NRA R1 passes both configured detectors with complete dependency
context and no increases. These do not certify all detectors or native science.
The ClassDef census preserves 5,122 declarations, 5,110 projections, 12 OPEN.
The admitted NRA policy move proves its configured syntax/import boundary;
authored metadata, cardinality, formatter and group selection changes are
separately checked by behavior/native qualification. The first rejected move
boundary is retained. No unsupported native creator/invocation proof is claimed.

Use the included final task recipe after checkout of the validated source.
Its reference directories and environment must resolve to the retained inputs;
when those are unavailable, use the public native comparison route with the
configured CellProfiler environment to produce fresh reference observations.
The controller environment is specified in the repository validation note.
All included evidence files are authenticated by SHA256SUMS. Large scientific
outputs remain in the benchmark-run directory, not in this archive.
