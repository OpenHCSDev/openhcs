ExampleFly execution-domain decision
====================================

Bounded context: OpenHCS source 5ccfc45c1 and its original ClassDef census
(5,122 declarations, 5,110 projections, 12 OPEN); original full dependency
R1 resolution. Determining owners: CallableContract.group_scope_inputs,
PathPlannerExecutionGroups.get_execution_groups and artifact_owned_execution_scope,
PathPlannerGroupScope.relation_scope_from_plan, and StepOutputManifestStore.

Required question: which input declaration determines the consumer execution
component domain? The artifact output's GroupLineageSourceRelation selects the
payload input. The filename-prefix source is an independent auxiliary input.
The existing callable contract derives group_scope_inputs from those relations;
no second schema, wrapper or hand-maintained function roster is licensed.

R1 required pair: get_execution_groups -> CallableContract.group_scope_inputs
for the preliminary source-binding projection, then the existing artifact-owned
scope resolver for produced/source-bound payloads.
R2 forbidden pair: consumer execution scope -> auxiliary filename-source channel
when that source is absent from the declared group-scope owner relation.
R3 required pair: producer pattern regrouping -> exact typed producer records.
The runtime manifest and source input admission remain fail-closed.

Saved representative counterexample: ExampleFly GrayToColor produces RGBImage
with typed channel=3 records and group axis SITE. SaveImages declares RGBImage
as its output group-scope source, but also binds OrigBlue/channel=1 for filenames.
The previous compiler froze SaveImages to channel=1 and runtime removed all
valid channel=3 records. Diagnostic source remains unchanged; its sitecustomize
observer is outside production and its clocks are not performance evidence.

Chosen change: project preliminary source bindings through exact group-owner
refs on the existing SourceBindingDeclarationsMixin.for_artifact_refs method.
The existing artifact-owned resolver retains lineage-aware resolution of actual
source payloads and authoritative producer/component domains. Using full source
lineage in the preliminary projection was rejected: a produced composition can
inherit the naming source as one lineage member without giving that member
control of the output execution group. No function-specific SaveImages patch.

Alternative runtime remapping is rejected: it would reinterpret a wrongly
compiled scope and permit runtime to override the compiler declaration. Source
artifact inputs and implicit main-flow functions remain separate controls.
The parameterized planner test admits both a stored cross-axis composition
(dynamic channel domain) and a direct named channel=3 source; the auxiliary
channel=1 cannot restrict either. Full native qualification is required in
addition to these local behavior and structural guards. This is an authored
semantic correction, not an NRA-proved equivalence or a performance claim.
