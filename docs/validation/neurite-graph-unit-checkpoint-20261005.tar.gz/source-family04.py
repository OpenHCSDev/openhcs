"""Bounded #541 source evidence using the original audit Package parser."""
import ast
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/ts/.codex/skills/refactor-audit/scripts")
from audit.findings import Package
from audit.repository import Repository


class SourceScopeRepository(Repository):
    """Original single-file scope adaptation, as qualified in #567."""

    def python_files(self, revision, root):
        if root.endswith(".py"):
            return (root,)
        return super().python_files(revision, root)


checkout = Path("/home/ts/wt/openhcs-ui-workflow-rendering-20261001")
roots = (
    (checkout, "openhcs"),
    (checkout / "external/python-introspect", "src/python_introspect"),
    (checkout / "external/metaclass-registry", "src/metaclass_registry"),
    (checkout / "external/arraybridge", "src/arraybridge"),
)
terms = (
    "SourceVoxelSpacing", "SpatialGraph", "NeuriteOutgrowth",
    "MetaXpressCellBodySettings", "MetaXpressOutgrowthSettings",
    "MetaXpressNuclearSettings", "MetaXpressWavelengthSettings",
    "PixelSizeMetadataArtifactProvider", "MetadataArtifactProvider",
    "DataclassMeasurementColumnarRows", "FieldSpec", "SWCOptions",
    "SpatialGraphROIOptions", "ROIArchiveSourceMetadata", "HiddenPixelSize",
    "SourceSpatialDomain", "neurite_outgrowth_metaxpress",
)
for path, root in roots:
    repo = SourceScopeRepository(path)
    revision = repo.git("rev-parse", "HEAD").strip()
    scopes = sorted({
        str(Path(root) / Path(source).relative_to(root).parts[0])
        for source in repo.python_files(revision, root)
    })
    total = 0
    for scope in scopes:
        package = Package.load(repo, revision, scope)
        print(json.dumps({"root": str(path), "scope": scope,
                          "revision": revision, "parsed": len(package.modules),
                          "unparsed": package.unparsed}), flush=True)
        assert not package.unparsed
        total += len(package.modules)
        for module in package.modules:
            if path != checkout or any(term in module.text for term in terms):
                print(json.dumps({"root": str(path), "path": module.path,
                                  "ast": ast.dump(module.tree, include_attributes=True)}))
        del package
    print(json.dumps({"root": str(path), "revision": revision, "total": total}), flush=True)
print(json.dumps({"limit": "source AST only; no imports/runtime proof/global R1"}))
