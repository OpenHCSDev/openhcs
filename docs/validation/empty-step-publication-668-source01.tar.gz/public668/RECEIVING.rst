668 ordinary multiwell label-image and measurement publication
============================================================

Source owner/receiving: Singer. Planck coordinates the next genuine whole bundle
with official ObjectState1.2 and the original builder/lane owner. No client,
native, viewer, compile or execution is launched by this packet. Do not use a
scientist endpoint or patch frozen receiving03. The exact native endpoint and
incarnation will come from the original released lease, not this document.

This DISTINCT synthetic CPPipe reuses the actually accepted503 scalar04
NamesAndTypes contract: primary Labels image carrier PLUS categorical Objects
source artifact on the same scalar file. Source stack components are empty;
Z1 is metadata, not a nonexistent physical array axis. The unchanged importer
creates declarations; no private object-source binding or alias is fabricated.
Registered ConvertObjectsToImage UINT16 then MeasureObjectSizeShape place a
named saved label image and measurement CSV in the original result destinations.
Two workers/threading and wells A01/A04 exercise ordinary parallel publication.
Default automatic publication remains enabled; no artifacts-only workaround.

Generate NEW synthetic12x15 uint16 categorical acquisitions through the original
ImageFileFormat writer in this packet's acquisition directory: zero background,
label2 at rows2:4/cols2:5 and label7 at rows6:10/cols8:13. Use the same matrix for
A01_s1_w1_z1_t1_Labels.tif and A04_s1_w1_z1_t1_Labels.tif. These engineering
coordinates/IDs are not scientific settings, annotations or reference answers.
No original503 files or frozen scientific inputs are overwritten. Actual
generation and input hashes remain pending until the receiving owner runs it.

Reuse engineering599/public-packet01/PUBLIC.commands and the original626 normal
recorded client/lifecycle owners, substituting this complete pipeline.py,
acquisition, returned config/session/job identities and a NEW values01 export.
Observe the original compile/execution handles; never replay an UNKNOWN result.
Use the currently declared get_execution_status, not the historical undeclared
get_job_status command. No catalogue/provider/viewer/science workaround.

Required actual user-path acceptance: both worker wells complete every declared
step; normal public inventory exposes all saved label images and measurement
tables with exact typed well/site/channel/Z/time addresses. Full resolution0
public label samples must retain every original2/7 pixel exactly. Canonical
VALUES require_valid_observation must admit real measurement rows joined by
typed object_label:2/Area6 and7/Area20 on each well. Source calibration stays
.5/.5micrometers; image/table routes, producer identity and source provenance
come from returned public records and original observation owners, not counts
or guessed filenames. Preserve every public/native reply and exact closure.

The source lifecycle fixture separately proves that an empty measurement update
is valid before another saved image's address arrives, and that permanently
missing addresses still reject FINAL reconciliation. A successful tiny public
parallel run alone does not prove its operations overlapped at that exact race
boundary. Installed/current bundle identity must be asserted; old target05 has
no669 and is NOT receiving proof. The original BBBC007 failure remains intact.
