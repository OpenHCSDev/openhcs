"""Create only the new declared engineering TIFFs through the original format owner."""
import hashlib
import json
from pathlib import Path

import numpy as np
from openhcs.core.image_file_serialization import ImageFileFormat

root = Path("/home/ts/wt/openhcs-issue-batch-20260929/engineering620/public668/acquisition")
paths = tuple(root / f"{well}_s1_w1_z1_t1_Labels.tif" for well in ("A01", "A04"))
if any(path.exists() for path in paths):
    raise FileExistsError("This new fixture is already materialized; retain it, do not replay generation")
root.mkdir(parents=True, exist_ok=True)
labels = np.zeros((12, 15), dtype=np.uint16)
labels[2:4, 2:5] = 2
labels[6:10, 8:13] = 7
for path in paths:
    ImageFileFormat.require_path(path).write(path, labels)
    print(json.dumps({"path": str(path), "shape": list(labels.shape),
        "dtype": str(labels.dtype), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}), flush=True)
