"""Distinct two-well categorical-source publication, through the original importer."""
from dataclasses import replace
from pathlib import Path

from openhcs.constants.constants import GroupBy, Microscope, VariableComponents
from openhcs.core.config import LazyNapariStreamingConfig, LazyPathPlanningConfig, LazyProcessingConfig
from openhcs.core.source_bindings import MetadataExtractionRule, MetadataSource
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.interop.cellprofiler.pipeline_import import import_cellprofiler_pipeline

root = Path("/home/ts/wt/openhcs-issue-batch-20260929/engineering620/public668")
pipeline_steps, imported_config = import_cellprofiler_pipeline(root / "labels-and-measurements.cppipe")
pipeline_config = replace(
    imported_config,
    microscope=Microscope.SOURCE_BINDINGS,
    num_workers=2,
    use_threading=True,
    processing_config=LazyProcessingConfig(
        variable_components=[VariableComponents.Z_INDEX], group_by=GroupBy.CHANNEL,
    ),
    path_planning_config=LazyPathPlanningConfig(global_output_folder=root / "results"),
    source_bindings_config=replace(
        imported_config.source_bindings_config,
        metadata_rules=(MetadataExtractionRule(
            source=MetadataSource.FILE_NAME,
            pattern=r"(?P<well>[A-H]\d{2})_s(?P<site>\d+)_w(?P<channel>\d+)_z(?P<z_index>\d+)_t(?P<timepoint>\d+)_Labels\.tif",
        ),),
        source_stack_components=(),
        source_voxel_spacing=SourceVoxelSpacing((0.5, 0.5)),
    ),
    napari_streaming_config=LazyNapariStreamingConfig(enabled=False),
)
