Empty step publication incorrectly selects completed-directory reconciliation
===========================================================================

Receiving/source triage owner: Singer. This is a distinct publication lifecycle
case, not the storage-extension comparison repaired in merged626/#620. No
production change, installed change, scientific replay or new runtime was made.

Pinned determining sources
--------------------------

Current main: 7e7e9f44afb1f683dbe87c39727f8899a94ed5cf (also664 merge, independently
verified remote main). Original frozen receiving03 target:
engineering-pre-first-routing-20261004/receiving03/target under the issue-batch
root. Its virtual_workspace_metadata.py is BYTE-IDENTICAL to this current main:
SHA256 1a40a500e40e848496405b274675a7977809078f6069f00b731d3e0f09c0686d.

Original native log:
next-bbbc00788-after651-20261004/BBBC007_FRESH651_88/author-workspace/output/
runtime/data/openhcs/logs/openhcs_zmq_server_port_6020_1791141656418933168.log,
lines2395-2430, failure2026-10-04T15:50:20. Original declaration:
that same output/candidate01-technical02.py. Only source declarations and logs
were read, not scientific pixels, references or live author communications.

The original Nuclear geometry step (MeasureObjectSizeShape) fails while
finalize_function_step_outputs calls OpenHCSMetadataWriter.write, then
OutputTarget.write(context, produced_plan=plan). The strict writer reports:

  Saved images lack typed produced addresses:
  ['results/A04_wDNA_nucleus_labels_step0.labels.tif'].

Determining relationship
------------------------

Current OpenHCSMetadataTarget.produced_projection_entries returnsNone for BOTH
planNone (completed-plate reconciliation) and an empty projection_paths sequence
for a real step plan (function_outputs.py868-869). write_for_step still invokes
target.write(context, produced_plan=plan) at1008 when metadata creation is
enabled. RuntimeArtifactMetadataTarget admits saved result directories for
nonimage formats as well as images; a measurements-only output can therefore
participate without an image projection.

AtomicMetadataWriter.publish_source_projection_metadata interpretsNone as
completed-directory reconciliation (virtual_workspace_metadata.py183-191).
VirtualWorkspaceSourceProjectionEntries.publish_into_subdirectory raises the
missing-address error ONLY when reconcile_directory is notNone (524-526).
Consequently the original raising branch proves that this step publication
selected directory reconciliation, although its actual call carries a step
plan. Current main retains this complete decision chain. The current facade
removal/rename does not resolve this state conflation.

This establishes premature final-reconciliation selection. It does NOT establish
whether the A04 missing producer record is temporary concurrent publication or
a separate permanent producer omission. The declaration has two workers; that
alone is not proof of the missing record's cause. The final completed-plate
guard must still reject genuinely missing typed addresses. No filename-derived
address, guard relaxation or automatic output suppression is a repair.

Ownership and acceptance
-------------------------

Open658 headfd8fdd367997f022622da99834a1eaebd787dc98 owns compiler/provider/source
workspace projection; open661 head08937321d97248634f2ba739f20cda9a987a30dc owns
CP consumed input/output recording. Their current published file rosters have
neither function_outputs.py nor virtual_workspace_metadata.py. Open620 is the
old distinct Reverse comparison; merged626 fixes only acquisition-versus-storage
extension ownership. Search found no open exact missing-produced-address issue.
Singer receives this new writer lifecycle defect, coordinating the shared seam
with the active Root658 owner before any implementation. No claim of shared-file
release or new production readiness is made by this source-only receipt.

NRA/catalog: IDEN-1 is the specific lead (one None answering both no projections
and completed publication). BOUND-2 directs reuse of the existing typed
VirtualWorkspaceSourceProjectionEntries and OpenHCSMetadataTarget owners.
Existing nominal target discovery and inherited projection behavior remain the
mechanism; do not add a consumer kind switch, duplicate store or writer loop.
This is semantic source tracing, not a new global AST/R1 or behavioral proof.

Required focused acceptance: a genuine measurement-only step sharing a saved
image destination must publish its own step state without declaring completed
directory reconciliation, while another producer's address is not yet published.
Subsequent image producer publication and completed-plate reconciliation must
expose every declared image once, preserve source/domain/calibration and retain
durable unrelated records. A permanently missing produced address must still
fail final reconciliation. Include empty step, normal image step and actual
completed reconciliation through the original registered finalize/output writer
owners, then the ordinary whole installed public multiaxis path. Do not replay
the frozen scientific attempt. Installed/live acceptance has NOT run here.

The independent aggregate viewer checkpoint failure remains Dewey's routing
scope. It is not repaired or reclassified by this writer triage.
