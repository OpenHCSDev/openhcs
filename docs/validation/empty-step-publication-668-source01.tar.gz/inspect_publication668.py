"""Configure the original audit Package for the publication family, without imports."""

import ast
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/ts/.codex/skills/refactor-audit/scripts")
from audit.findings import Package
from audit.repository import Repository

checkout = Path("/home/ts/wt/openhcs-ui-workflow-rendering-20261001")
repo = Repository(checkout)
revision = repo.git("rev-parse", "HEAD").strip()
terms = (
    "OpenHCSMetadataTarget", "OpenHCSMetadataWriter",
    "VirtualWorkspaceSourceProjectionEntries", "AtomicMetadataWriter",
    "produced_projection_entries", "publish_source_projection_metadata",
    "publish_into_subdirectory", "finalize_completed_plate",
    "finalize_function_step_outputs", "reconcile_directory",
)
failures = []
for root in ("openhcs", "tests", "scripts", "benchmark"):
    paths = repo.python_files(revision, root)
    scopes = sorted({str(Path(*Path(path).parts[:2])) for path in paths
                     if len(Path(path).parts) > 2})
    # Package.load handles files at each package root as part of the full root.
    # Use one original package admission per root, including root-level modules.
    package = Package.load(repo, revision, root)
    selected = 0
    for module in package.modules:
        if any(term in module.text for term in terms):
            selected += 1
            print(json.dumps({"root": root, "path": module.path,
                "sha256": hashlib.sha256(module.text.encode()).hexdigest(),
                "functions": [vars(facts) for facts in package.functions[module.path]],
                "ast": ast.dump(module.tree, include_attributes=True)},
                default=lambda value: sorted(value)), flush=True)
    failures.extend(package.unparsed)
    print(json.dumps({"root": root, "revision": revision,
        "parsed": len(package.modules), "selected": selected,
        "unparsed": package.unparsed}), flush=True)
    del package

keepers = Path("/home/ts/wt/openhcs-issue-batch-20260929/engineering599/source-references")
for dependency in ("PolyStore", "metaclass-registry"):
    path = "external/" + dependency
    version = repo.git("rev-parse", revision + ":" + path).strip()
    dependency_repo = Repository(keepers / dependency)
    package = Package.load(dependency_repo, version, "src")
    for module in package.modules:
        print(json.dumps({"dependency": path, "revision": version,
            "path": module.path,
            "sha256": hashlib.sha256(module.text.encode()).hexdigest(),
            "ast": ast.dump(module.tree, include_attributes=True)}), flush=True)
    failures.extend(package.unparsed)
    print(json.dumps({"dependency": path, "revision": version,
        "parsed": len(package.modules), "unparsed": package.unparsed}), flush=True)
print(json.dumps({"revision": revision, "failures": failures,
    "limits": "original audit AST admission; static symbol/dynamic-reference limits; not global NRA/R1 or behavior"}), flush=True)
raise SystemExit(bool(failures))
