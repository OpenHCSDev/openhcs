"""Offline original SDK admission only; never dispatch the saved viewer request."""
import hashlib
import json
import re
import shlex
from pathlib import Path

from openhcs.agent.capabilities import RetireViewerWindowLayersCapability
from openhcs.agent.dto.execution import ExecutionConnectionSpec
from openhcs.agent.dto.viewer import ViewerWindowLayerRetirementRequest
from openhcs.mcp.server import build_server
import openhcs.agent.dto.viewer as dto
import openhcs.runtime.viewer_controls as controls
import polystore.streaming.identity as identity

batch = Path('/home/ts/wt/openhcs-issue-batch-20260929')
runtime = batch / ('next-r0010-fresh95-after656-20261004/R0010_FRESH656_95/'
                  'author-workspace/output/runtime')
inputs = runtime / 'mcp.stdin'
outputs = runtime / 'mcp.stdout'
before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in (inputs, outputs)}
commands = inputs.read_text().splitlines()
command = commands[156]
assert command.startswith('call openhcs_retire_viewer_window_layers ')
arguments = shlex.split(command)
payload = json.loads(arguments[arguments.index('--arguments') + 1])
decoder = json.JSONDecoder()
last_state = None
text = outputs.read_text()
for opening in re.finditer(r'(?m)^\{', text):
    # Native recorder includes prose around complete ordinary JSON envelopes.
    # Read them as evidence, not as a replacement application codec.
    try:
        envelope, _ = decoder.raw_decode(text, opening.start())
    except json.JSONDecodeError:
        continue
    if not isinstance(envelope, dict):
        continue
    for result in envelope.get('results', []):
        if result['tool'] == 'openhcs_get_viewer_window_state':
            last_state = result['payloads'][0]
        if result['tool'] == RetireViewerWindowLayersCapability.name:
            errors = result['payloads'][0]['errors']
            assert errors[0]['message'] == 'Retirement requires full typed producer identities.'
            break
    else:
        continue
    break
assert last_state is not None
by_route = {layer['route_key']: layer for layer in last_state['layers']}
selected = payload['expected_producers']
assert len(selected) == 11
empty = [route for route, values in selected.items() if not values]
assert len(empty) == 3
assert all(by_route[route]['mounted'] and by_route[route]['item_count'] == 1
           and by_route[route]['producer_identities']
           for route in empty)
assert all(values == by_route[route]['producer_identities']
           for route, values in selected.items() if values)
assert all(by_route[route]['mounted'] for route in selected if route not in empty)

server = build_server()
tool = server._tool_manager.get_tool(RetireViewerWindowLayersCapability.name)
decoded = tool.fn_metadata.arg_model.model_validate(payload)
connection = ExecutionConnectionSpec(
    port=payload['port'], host=payload['host'], transport_mode=decoded.transport_mode,
)
try:
    ViewerWindowLayerRetirementRequest.from_fields(
        connection=connection, expected_producers=decoded.expected_producers,
    )
except ValueError as error:
    assert str(error) == 'Retirement requires full typed producer identities.'
    print('ORIGINAL_SET_REJECTED_BEFORE_DISPATCH', str(error), flush=True)
else:
    raise AssertionError('Original malformed selected set was unexpectedly accepted.')

# Comparison is offline request construction, not retrying the viewer mutation.
mounted = {route: values for route, values in selected.items()
           if by_route[route]['mounted'] and values}
decoded_mounted = tool.fn_metadata.arg_model.model_validate(
    {**payload, 'expected_producers': mounted},
)
request = ViewerWindowLayerRetirementRequest.from_fields(
    connection=connection, expected_producers=decoded_mounted.expected_producers,
)
assert request.as_tool_arguments()['expected_producers'] == mounted
assert len(mounted) == 8
assert all(producer.invocation_key is None
           for values in request.retirement.expected_producers.values()
           for producer in values)
modules = {module.__name__: {'path': module.__file__,
                            'sha256': hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()}
           for module in (dto, controls, identity)}
for path, digest in before.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
print(json.dumps({'sdk': 'original build_server argument model',
                  'full_set': len(selected), 'stale_empty_entries': len(empty),
                  'mounted_null_identity_entries_admitted': len(mounted),
                  'roundtrip_values_unchanged': True, 'dispatches': 0,
                  'modules': modules, 'original_journal_hashes_unchanged': before},
                 sort_keys=True), flush=True)
