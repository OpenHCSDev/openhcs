"""Read original closed receipts through their existing CLI result owner.

No MCP/native process, request replay, registration or image execution.
"""
import hashlib
import json
from pathlib import Path
import inspect

from openhcs.mcp.dev_client_core import McpDevToolResult
from openhcs.serialization.json import to_jsonable
from python_introspect import dataclass_from_mapping

for owner in (McpDevToolResult, dataclass_from_mapping):
    path = Path(inspect.getfile(owner))
    print(json.dumps({"owner": owner.__qualname__, "path": str(path),
                      "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}))

root = Path(__file__).resolve().parent
for item in json.loads((root / "PUBLIC-REPLIES-FINAL01.json").read_text()):
    result = McpDevToolResult(**item).decoded_for_rendering()
    print(json.dumps({"tool": result.tool, "has_errors": result.has_errors(),
                      "decoded_types": [type(value).__qualname__ for value in result.payloads],
                      "diagnostics": to_jsonable(result.diagnostic_errors())}))
