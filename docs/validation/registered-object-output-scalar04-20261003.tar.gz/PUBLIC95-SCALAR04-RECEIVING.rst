50395 scalar-source receiving04
===============================

Parent's original83658 default03 artifact-plan selected SOURCE_BINDINGS correctly
then failed before source sessions/compile/execution: Source Labels.tif shape
(12,15) cannot expose1 declared source stack axes. Exact original mcp.stdout
determining message4886.03 files and original negative remain untouched; no replay.
Sole assigned parent native6014 PID2355303 remains ready. No public call by Singer.

Existing owner explains and rejects the incorrect03 declaration
-------------------------------------------------------------

SourceBindingsConfig.source_stack_components owns source-stack declarations.
SourceBindingWorkspaceProjector._expanded_binding_candidates consumes that tuple
to expose leading physical axes: it loads the file, requires rank >= number of
declared axes+2 spatial dimensions, then enumerates source_axis_indices from
shape[:number_of_declared_axes]. With (), it returns the original candidate
without inventing a leading axis. Thus03 declared a physically absent leading Z
dimension on a scalar12x15 TIFF. This is an authored config error, not a defect
in the strict source-rank validator or503 shape-row implementation.

Separate existing owner: LazyProcessingConfig.variable_components determines
processing grouping/stacking of metadata-addressed source planes. A filename
z_index does not create a third axis inside the TIFF.04 leaves variable Z_INDEX
and GroupBy.CHANNEL unchanged, retaining the original metadata Z coordinate.
Physical source_stack_components is explicitly (), its original typed default.
No product patch, guard waiver, artificial singleton reshape/group or label remap.

Latest NRA/refactor-audit SKILL + authoritative archive catalog reviewed; IDEN-1
keeps physical payload axes and metadata processing coordinates as distinct
facts, BOUND-2 uses the existing typed configuration and source owner. This is a
new complete user declaration, not a structural refactor or new-family scanner.
The earlier complete-family AST/source/installed controls remain historical and
were not rerun. Root394 current675f7eddb4aff51f7e4fb07352e44e8e667633b0 owns
shared source/runtime integration; no shared production edits/crossing.

New complete ordinary documents
-------------------------------

Original output root:
/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output

* labels503-default04.cppipe + pipeline-default04.py -> results-default04.
* labels503-removed04.cppipe + pipeline-removed04.py -> results-removed04.

Both keep original importer, explicit Microscope.SOURCE_BINDINGS, primary Grayscale
Labels + categorical Objects SOURCE_ARTIFACT from SAME TIFF, Metadata matching
on original well/site/channel/Z/timepoint, Shape Objects and one FilterObjects.
Default removed flag omitted; enabled declares original RemovedEnabled. Only
semantic config correction from03 is source_stack_components=(); new filenames/
result paths and removal of now-unused AllComponents import keep04 distinct.
SourceVoxelSpacing1um/streaming disabled/processing Z/channel unchanged.
CPPipe bytes exactly match respective03 files;03 files are not renamed/edited.

Parent EXISTING retained-shell commands, when its independent priority permits:

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-default04.py --global-config-id config-1 --json

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-removed04.py --global-config-id config-1 --json

Only on actual successful plan: NEW session/compile/execute handles and exclusive
default04-values.json / removed04-values.json through original public route and
parent admission. No session2/removed01 execution or unchanged01/02/03 replay.
Public preparation may normally update engineering workspace metadata, never
rewrite the raw TIFF or overwrite original failed documents/outputs/exports.

Unchanged acceptance: raw12x15uint16 categorical IDs2/7, exact shape LABEL_ID
object_label AreaShape_Area6/20; retained7->target1 exact20 pixels, removed2->
separate target1 exact6 pixels. Typed Objects parent -> named child domain;
actual returned producer identity, parent_id/child_id and raw source_ids/target_ids
agree. Default4/enabled6 ABI, no default removed artifact, no count-only shortcut.
Canonical VALUES is gzip/pickle despite .json suffix: original
ZMQRuntimeExecutionObservationExport.read(Path(path)) and .observation(), not
JSON/manual-unpickle/schema mirror. No values export decoded by Singer.

Only04 Python AST syntax checked and CPPipe byte equality/old03/raw hashes
verified. No product import/test/build/install/native/viewer/science input/contact,
new WT/env/deps or sole-parent client operation. Whole qualifiedc031/target02
unchanged; actual public04 pixel/table/lineage qualification remains parent-owned.

SHA256:
raw1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e
default CPPipe7bde88397b53638422c6ba6debe2f408ba95caa36d71c07b4c362663b2f37628
removed CPPipe7e2dab65974b915e876becfb83396c9244633ba452b38bb86dea5e7b1a433bfd
default Pythoncf15ecf7875d3940effd06676963b6ba3c52fe98a9e5523a873d64b283cce5a7
removed Pythonbf3e94150c4417a0993ff48b1b5a84565f4b8bc6abfeee7b4df89340677893bb
