"""Read-only original installed recipe import; no image/runtime execution."""

import hashlib
import json
from pathlib import Path
import sys
import traceback

target = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering-pre-first-routing-20261004/receiving03/target')
sys.path.insert(0, str(target))
from openhcs.interop.cellprofiler.parser import CPPipeParser
from openhcs.interop.cellprofiler.module_declarations import CellProfilerModule
from openhcs.core.source_bindings import SourceBindingsConfig

recipe = target / 'openhcs/agent/resources/knowledge/benchmark/manifests/official30_portable_axis1.sources/dataset_cache/CellProfiler_tutorials/data/3d_monolayer/3d_monolayer_final.cppipe'
parser = CPPipeParser()
modules = tuple(parser.parse(recipe))
bindings = CellProfilerModule.source_bindings_for_modules(
    modules, SourceBindingsConfig(image_plane_sources=parser.image_plane_sources))
print(json.dumps({'recipe': str(recipe), 'sha256': hashlib.sha256(recipe.read_bytes()).hexdigest(),
    'bindings': [(b.alias, str(b.artifact_kind)) for b in bindings.binding_declarations]}), flush=True)
from openhcs.interop.cellprofiler.pipeline_import import import_cellprofiler_pipeline
try:
    steps, config = import_cellprofiler_pipeline(recipe, source_root=recipe.parent / 'images')
    print(json.dumps({'imported_steps': len(steps)}), flush=True)
except Exception:
    traceback.print_exc()
    raise
