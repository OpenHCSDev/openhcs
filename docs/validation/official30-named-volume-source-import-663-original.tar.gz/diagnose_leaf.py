"""Record the original nested-merge exception before its existing catch."""
from pathlib import Path
import json
import runpy
import sys

def observe(frame, event, arg):
    if frame.f_code.co_name != '_merge_nested_dataclass':
        return None
    if event == 'exception':
        exc_type, exc, _ = arg
        print(json.dumps({'stage': 'nested_merge_exception',
            'base_type': type(frame.f_locals['base']).__name__,
            'override_type': type(frame.f_locals['override']).__name__,
            'field': frame.f_locals.get('field_name'),
            'exception_type': exc_type.__name__, 'exception': str(exc),
            'file': frame.f_code.co_filename, 'line': frame.f_lineno}), flush=True)
    return observe

sys.settrace(observe)
runpy.run_path(str(Path(__file__).with_name('diagnose_config.py')), run_name='__main__')
