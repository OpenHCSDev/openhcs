"""Inspect original config construction and nominal inheritance, read-only."""
from pathlib import Path
import json
import sys

target = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering-pre-first-routing-20261004/receiving03/target')
sys.path.insert(0, str(target))
from openhcs.interop.cellprofiler.parser import CPPipeParser
from openhcs.interop.cellprofiler.module_declarations import CellProfilerModule
from openhcs.core.source_bindings import SourceBindingsConfig
from openhcs.core.config import PipelineConfig, ProcessingConfig, LazyStepSourceBindingsConfig
from objectstate import config_context
from objectstate.lazy_factory import resolve_lazy_configurations_for_serialization
from objectstate.context_manager import extract_all_configs_from_context

recipe = target / 'openhcs/agent/resources/knowledge/benchmark/manifests/official30_portable_axis1.sources/dataset_cache/CellProfiler_tutorials/data/3d_monolayer/3d_monolayer_final.cppipe'
parser = CPPipeParser()
modules = tuple(parser.parse(recipe))
bindings = CellProfilerModule.source_bindings_for_modules(
    modules, SourceBindingsConfig(image_plane_sources=parser.image_plane_sources))
config = PipelineConfig.from_config(bindings, ProcessingConfig())
raw = object.__getattribute__(config, 'source_bindings_config')
print(json.dumps({'raw_type': type(raw).__name__,
    'raw_aliases': [b.alias for b in object.__getattribute__(raw, 'bindings')],
    'lazy_step_mro': [t.__name__ for t in LazyStepSourceBindingsConfig.__mro__]}), flush=True)
with config_context(config):
    available = extract_all_configs_from_context()
    print(json.dumps({'context': [
        {'key': t.__name__, 'type': type(v).__name__,
         'aliases': [b.alias for b in v.binding_declarations]}
        for t,v in available.items() if isinstance(v, SourceBindingsConfig)]}), flush=True)
    resolved = resolve_lazy_configurations_for_serialization(LazyStepSourceBindingsConfig())
    print(json.dumps({'resolved_type': type(resolved).__name__,
        'resolved_aliases': [b.alias for b in resolved.binding_declarations]}), flush=True)
