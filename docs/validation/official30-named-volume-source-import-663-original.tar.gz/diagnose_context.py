"""Observe the existing importer's context; do not replace any product method."""
from pathlib import Path
import json
import runpy
import sys

def observe(frame, event, arg):
    if event == 'call' and frame.f_code.co_name == '_parsed_target_units':
        context = frame.f_locals['step_context']
        print(json.dumps({'stage': 'parsed_target_units',
            'enabled': context.source_bindings.enabled,
            'aliases': [b.alias for b in context.source_bindings.binding_declarations],
            'main_flow': [s.name for s in context.main_flow_artifacts],
            'available': [s.name for s in context.available_artifacts]}), flush=True)
    if event == 'call' and frame.f_code.co_name == 'require_available_artifact_input':
        context = frame.f_locals['step_context']
        print(json.dumps({'stage': 'require_available_artifact_input',
            'module': frame.f_locals['module'].name, 'name': frame.f_locals['name'],
            'aliases': [b.alias for b in context.source_bindings.binding_declarations],
            'main_flow': [s.name for s in context.main_flow_artifacts],
            'available': [s.name for s in context.available_artifacts]}), flush=True)
    return observe

sys.settrace(observe)
runpy.run_path(str(Path(__file__).with_name('diagnose_original.py')), run_name='__main__')
