"""Observe original context merging with source fields, no product replacement."""
import json
from pathlib import Path
import runpy
import sys

def observe(frame, event, arg):
    if event == 'return' and frame.f_code.co_name == '_is_compatible_config_type':
        value = frame.f_locals['value']
        if 'SourceBindings' in type(value).__name__:
            expected = frame.f_locals['expected_type']
            print(json.dumps({'stage': 'compatible', 'value': type(value).__name__,
                'expected': str(expected), 'result': arg}), flush=True)
    if event == 'return' and frame.f_code.co_name == '_merge_nested_dataclass':
        if hasattr(arg, 'binding_declarations'):
            print(json.dumps({'stage': 'merged', 'type': type(arg).__name__,
                'aliases': [b.alias for b in arg.binding_declarations]}), flush=True)
    return None

sys.setprofile(observe)
runpy.run_path(str(Path(__file__).with_name('diagnose_config.py')), run_name='__main__')
