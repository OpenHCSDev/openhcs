503 first ordinary wheel/private installed checkpoint
=====================================================

Singer, reviewed source c0314a17163260b1b05071e0d405ee386fa6a2e0 from the explicitly
released505 checkout. Same503 branch, unchanged product/test f9a15dcbd. Existing
paired Python, original setup.py build hooks/native extension declarations,
494 build/install command owners and505 RECORD/declaration-resource verifier.
No selective file patch, new worktree/environment/dependency or scientific input.

ONE build and ONE new unused private install occurred. Whole-wheel readiness
is RED: inherited sparse checkout omits the declared benchmark Python package,
including benchmark.mcp_extension. This is not a501 source/control failure or
the separate Root-owned unbounded502 ABI obligation. No second build/install
is started under the one-build authorization; no public/native process starts.

Artifacts and bounded operations
-------------------------------

Persistent root: /home/ts/wt/openhcs-issue-batch-20260929/engineering503.
Source: /home/ts/wt/openhcs-ui-workflow-rendering-20261001.
Wheel: wheels01/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl,4070338bytes,
SHA2560c85e3790b7ee92db52796b643ec9f8ad20b3a5a620c08da6e0e53069011d84f.
Ordinary pip --no-deps --no-index --no-compile private target: target01.
Interpreter: /home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python.
Shared paired/canonical dependency paths are borrowed read-only; no .pth or
global install/config mutation. Four foreign dirty gitlinks remain unchanged.

Original source-owner release and final privileged whole-root borrower receipt
were reread. A fresh original disk-retirement checker, adapted only for exact
build-cache path, first had300 permission omissions, then privileged check
found zero references/zero omissions. No process was signalled. Both C++ sources
equal original505 wheel bytes and their pre-existing retained object caches
are newer than source. Original builder uses the cache; no second compiler or
binary copying into target. Native source/object hashes: native-cache01.log.

Resource check: RAM available16.4GiB, advisory critical home7.1GiB/root7.6GiB/
existing swap13.4GiB. Every operation uses CPU1(affinity3/CPUQuota100%),
MemoryMax536870912, MemorySwapMax0, RuntimeMaxSec60. No limit is raised.
Build terminal0:7.11s,maxRSS146588KiB,cgroup273178624B,swap0,OOM0.
Install terminal0:.93s,maxRSS48612KiB,cgroup97.7M,swap0,OOM0.
New-control terminal0:6.64s,maxRSS372572KiB,cgroup220844032B,swap0,OOM0.
Existing-control terminal0:5.29s,maxRSS324260KiB,cgroup185913344B,swap0,OOM0.
All owned build/install/control scopes are terminal; original logs retained.

Real installed proof and the determining negative
------------------------------------------------

installed-control01.py asserts whole private-target origins/hashes for shape,
FilterObjects, row/domain/label/query ancestors, protected original ABI validator
and matcher, and both native binaries before executing the ORIGINAL source
controls. Ten new controls PASS, plus11 existing shape/feature/ordinal controls
PASS. Plugin/conftest/bytecode/JIT disabled, no test/threshold weakening. Two
original unknown-async-config warnings remain. No native process/viewer/MCP,
catalog preparation, model, provider, Qt application or scientific author contact.

Original505 namespace qualification PASS in package-openhcs03.stdout:
704 tracked OpenHCS Python/726 tracked payload matches;826 wheel RECORD members,
825 non-RECORD target payload matches;838 installed RECORD files;90 canonical
declared knowledge/plugin/skill resource projections, complete13-file skill,
30 native cppipe resources. Original RECORD/hash/source/entrypoint membership
checks unchanged. Both C++ sources match source/wheel/target; both actual ABI3
binaries match wheel/target. Runtime.59s,maxRSS28584KiB,cgroup18.6M,swap0.
This positive scope does NOT waive the missing declared benchmark package.

First package01 broadening asked all Git benchmark Python to be present, which
also included deliberately excluded results/native-reference trees. Original
assertion failure is retained unedited. Independent Git-tree+pyproject declaration
census excludes the ORIGINAL configured package exclusions and still identifies
89 missing legitimate package Python files,1141351bytes, including
benchmark/mcp_extension.py. Setuptools declares benchmark* and its original
openhcs.agent.capability_extensions entrypoint, so this wheel cannot claim a
whole declared-package/source match. No private reference image/answer was read.

Second scoped verifier attempt completed original namespace/native byte checks
but its appended receipt hash used a variable overwritten by original505 exec;
AttributeError is preserved in package-openhcs02.stderr. Original attempt scripts
are preserved in verifier-failure02-source.tar.gz. Corrected only that receipt
expression to hash original_path.read_bytes(); no input/assertion/limit weakened.
package-openhcs03 is the terminal scoped pass, not a covert full-package pass.

Next exact operational correction and public packet
---------------------------------------------------

Materialize only the89 committed declared benchmark package Python paths in
the SAME released checkout using normal sparse-checkout expansion. Paths derive
from Git and pyproject include/exclude declarations; do not materialize excluded
results/native_refs/manifests, images, heldout inputs or private answers. Preserve
the existing official30 selected resources and all foreign untracked ledgers.
Then one explicitly authorized corrective ordinary build to wheels02 and new
unused target02, unchanged512MiB/Swap0/CPU1, no new env/dependencies. Keep wheels01,
target01 and all negatives intact. No selective installed patch or file copy.

Prepared PUBLIC503_94/labels503.cppipe and complete pipeline.py use original
registered ConvertImageToObjects preserve_label -> MeasureObjectSizeShape ->
FilterObjects default and enabled, through the ORIGINAL CellProfiler importer.
Tiny synthetic12x15 uint16 input recipe has IDs2/7 and known areas6/20. Original
border rule separates source2 to removed1 and source7 to retained1. Required
pixel-ID/table-area/lineage joins are in PUBLIC503_94/PREPARED.rst. Counts alone
are not acceptance. No acquisition input exists yet and the prepared source is
syntax-only checked, not publicly compiled/executed. No new registered wrapper
or substitute algorithm. Parent releases serial engineering94 after SCI turnover
and whole-package/admission review; existing recorded slot/507 owners are reused.

Receipt/pin publication changes only documentation/archive after the original
packaged source.501 working delivery is not held behind arbitrary additional502
ABI or hosted CI. Current wheel completeness is a concrete separate blocker.
Keep every previous frozen505/498 target, original failed jobs and journals,
all untracked evidence and shared native cache intact. No cleanup is authorized.
