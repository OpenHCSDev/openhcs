"""Original505 OpenHCS/resource tier; benchmark completeness stays explicitly RED.

Retain verify-package01.py and its original failed attempt untouched. Its
broadened benchmark assertion included excluded result scripts; here reuse the
original505 namespace unchanged. Declared benchmark completeness is separately
required and not waived by this narrower positive result.
"""
from pathlib import Path
original = Path(__file__).with_name('verify-package01.py')
source = original.read_text()
before = "    ('\"--\", \"openhcs\").splitlines()', '\"--\", \"openhcs\", \"benchmark\").splitlines()'),\n"
assert before in source
exec(compile(source.replace(before,''),str(original),'exec'))
