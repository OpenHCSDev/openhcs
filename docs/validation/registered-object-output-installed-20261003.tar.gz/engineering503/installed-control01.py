"""Repeat the original tiny503 controls against asserted whole-wheel origins."""
from pathlib import Path
import hashlib
import importlib
import json
import sys
import pytest

root = Path(__file__).resolve().parent
target = root / 'target01'
source = Path('/home/ts/wt/openhcs-ui-workflow-rendering-20261001')
modules = (
    'openhcs.processing.backends.cellprofiler.shape',
    'openhcs.processing.backends.cellprofiler.object_filtering',
    'openhcs.core.runtime_measurements',
    'openhcs.core.runtime_object_label_domains',
    'openhcs.core.runtime_object_labels',
    'openhcs.core.runtime_artifact_queries',
    'openhcs.core.runtime_output_matching',
    'openhcs.interop.cellprofiler.module_callable_abi',
    'openhcs.core._tabular_native',
    'openhcs.processing.backends.cellprofiler._granularity_native',
)
origins = {}
for name in modules:
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    assert path.is_relative_to(target), (name, path)
    origins[name] = dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
print(json.dumps(dict(installed_origins=origins, native_process_started=False, viewer_started=False),sort_keys=True),flush=True)
stage = sys.argv[1]
if stage == 'new':
    selected = [str(source/'tests/unit/test_registered_object_output_boundaries.py')]
elif stage == 'existing':
    selected = [str(source/'tests/unit/test_cellprofiler_shape_hotpath.py')]
    selected += [str(source/'tests/unit/test_runtime_values.py')+'::'+name for name in (
        'test_shape_object_feature_table_uses_registered_nominal_contract',
        'test_shape_object_feature_table_rejects_undeclared_dense_feature_domain',
        'test_shape_descriptors_align_with_measured_ids_not_missing_declared_labels',
        'test_shape_center_features_align_to_measured_sparse_object_ids',
    )]
    selected += [str(source/'tests/unit/test_cellprofiler_measurement_rows.py')+'::test_row_sequence_projection_overlays_identity_without_materializing_rows']
else:
    raise ValueError(stage)
status = pytest.main(['--noconftest','--import-mode=importlib','-p','no:cacheprovider','-o','addopts=', '-q',*selected])
scope_path = Path('/proc/self/cgroup').read_text().strip().split(':',2)[2]
scope = Path('/sys/fs/cgroup'+scope_path)
for name in ('memory.max','memory.peak','memory.swap.max','memory.swap.peak','memory.events','cpu.max'):
    print(name+': '+(scope/name).read_text().replace('\n',' '),flush=True)
raise SystemExit(status)
