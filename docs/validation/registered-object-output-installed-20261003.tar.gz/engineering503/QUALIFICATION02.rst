503 complete ordinary private installed qualification
=====================================================

Current acceptance tier: whole declared-package source/wheel/private target
and ORIGINAL21 tiny installed-owner controls PASS. Public MCP/native pixel,
categorical table/lineage join acceptance is still pending parent lane release.
No503 native/viewer/MCP or scientific process has been launched.94 is now a
fresh scientific lane, NOT available engineering capacity. No hosted-CI gate.

This advances retained QUALIFICATION01 after parent's explicit continuation
of whole private qualification. The incomplete first wheel/target and every
original negative remain intact. Shared ABI validators/matcher stay unchanged;
unbounded additional502 ABI is Root-owned and does not hold the501 delivery.

Whole source and original owners
-------------------------------

Same released source checkout:
/home/ts/wt/openhcs-ui-workflow-rendering-20261001.
Source pin c0314a17163260b1b05071e0d405ee386fa6a2e0; product/test f9a15dcbd.
Only sparse materialization changed:89 COMMITTED declared benchmark Python
files,1141351bytes, now present. Git and ORIGINAL pyproject include/exclude
declarations derived the paths. Each file byte-equals its original Git blob.
Excluded native_refs/results/manifests, acquisition/heldout/reference answers
were not expanded/read. Original selected Official30 resources, four foreign
dirty gitlinks and all untracked source/validation history remain preserved.
The whole payload Git diff is empty; no production or packaging owner edits.

Ordinary original setup BuildPyWithMcpKnowledge/native-extension declarations
and494 build/install commands produce the complete wheel, not selective package
patches.505 original RECORD/hash/entrypoint/source/knowledge/skill verifier
owns the qualification algorithm. Additional namespace membership uses original
pyproject package declarations and Git, not a mirrored package roster. Source,
wheel and installed target match793 declared package Python files (704 OpenHCS,
89 benchmark), with no missing or unexpected Python.815 tracked payload files
match, plus90 declaration-derived knowledge/plugin/skill assets and complete
13-file managed skill.30 manifest-derived native cppipe resources are present.
Both original C++ sources match source/wheel/target; both ABI3 binaries match
wheel/target and are actually imported from that target by controls. Both
retained original native-object hashes are unchanged across builds. No native
binary copied from a foreign package, dependency download or new environment.

Current Root394 head4eaacf17e5de3dba59ec217f133fa6e1821c8641 was fetched:
no production difference from bb9c49c2a. The original narrow release remains;
there is no competing shared ABI patch in this checkpoint. Root's broader
runtime/whole-branch R0/R1 remain its independent responsibility. Our original
scoped R0 at f9a15dcbd and source/control archives remain unchanged.

Exact artifacts
---------------

Root: /home/ts/wt/openhcs-issue-batch-20260929/engineering503.
Wheel: wheels02/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl.
Bytes4353627; SHA256
498367681f9dbd831c05f7e216d012495fce13c12322be1f6e3c119bd9cfc4f5.
Private unused target02: original pip --no-deps --no-index --no-compile.
915 wheel RECORD members;914 non-RECORD wheel/target payload matches;
927 installed RECORD files fully hash checked. Canonical resources/skill source
projections and installed entrypoint membership use original505 checks.
Paired interpreter/dependencies read-only, including canonical shared site
backings. No .pth/global package change or frozen505/498 target mutation.

Bounded terminal results
------------------------

Resource snapshot02: RAM available11.7GiB, critical advisory home6.5GiB/root7.6GiB/
existing swap13.4GiB. Serial build/install/verifier/control stages retain CPU1,
affinity3/CPUQuota100%, MemoryMax536870912, MemorySwapMax0, RuntimeMaxSec60.
No raised bound, no swap or OOM in those stages. All owned scopes are inactive.

* Corrective build02:6.76s,maxRSS146772KiB,cgroup213610496B,exit0.
* Install02:.96s,maxRSS48652KiB,cgroup83496960B,exit0.
* Original complete verifier02:.63s,maxRSS29880KiB,cgroup20.1M,exit0.
* New original10 controls:6.79s,maxRSS378456KiB,cgroup227659776B,exit0.
* Existing original11 controls:5.26s,maxRSS327972KiB,cgroup189100032B,exit0.

installed-control02 adapts ONLY the target path from original control01. Before
testing it asserts actual target02 file/hash origins for both repaired leaves,
row/domain/label/query ancestors, protected ABI/matcher and both native binaries.
All original assertions, inputs and pytest selection remain unchanged. The
original ordinal control and genuine cooperative-hook independent declaration
pass, alongside sparse2D/3D categorical areas and optional removed enabled/
disabled/empty checks. Plugins/conftest/bytecode/Numba JIT are disabled; original
two async-config warnings retained. No native process, UI or SCI execution.
Small independent Git-only Python closure census verifies all793 original blobs;
its extra text-only hash pass is not a new behavioral/AST/R0 proof.

Public receiving packet and remaining gate
-----------------------------------------

PUBLIC503_94 is a historical DIRECTORY name, not a display/port reservation.
Its complete PipelineDocument source uses ORIGINAL CellProfiler importer and
registered ConvertImageToObjects(preserve_label=True), MeasureObjectSizeShape,
FilterObjects default and removed-enabled. No registered wrapper/replacement
algorithm or direct native call. Full public validation/compile is still due.

New synthetic engineering input was created through original tifffile writer,
with exact readback, no acquired or SCI data.12x15uint16; source IDs2 and7 have
known areas6 and20. Input file SHA256
1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e.
Parent public acceptance must retain exact source-ID -> AreaShape table values,
original border-filter kept/removed label pixels and directed source/target
lineage endpoints, plus default canonical+3/optional canonical+5 slot admission.
Equal counts alone cannot pass. Original health/first-use/discovery/preparation,
typed public compile/job/inventory/readback owners precede conclusions; no
UNKNOWN replay or native guard relaxation. Details: PUBLIC503_94/PREPARED.rst.

Parent allocates an EXISTING free engineering lane after scientific closure
and admission review. Existing recorded operation/507/resource owners supply
runtime/ledger custody; no new helper/guard/pool or foreign script edits. No
native/MCP start or SCI contact until release. No biological/autonomous claim.

Latest NRA/refactor-audit archive catalog guided use of original owner classes,
declaration-derived closure and source identity: BOUND-2, IDEN-1, IMPL-12. The
source repair's full family AST and deletion/new-case evidence are retained in
the original source receipt; no structural implementation changed in this stage.
