"""Same original controls/origin assertions; second whole target only."""
from pathlib import Path
original = Path(__file__).with_name('installed-control01.py')
recipe = original.read_text()
assert "target = root / 'target01'" in recipe
exec(compile(recipe.replace("target = root / 'target01'", "target = root / 'target02'"),str(original),'exec'))
