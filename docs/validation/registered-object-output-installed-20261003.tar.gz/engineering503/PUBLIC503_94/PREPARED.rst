503 tiny public registered qualification packet
==============================================

Prepared only. No native process, public MCP call or viewer has been started.
Current whole-package target02 is qualified; incomplete target01 remains as
the original retained negative. The packet directory's historical94 name is
NOT a display/port reservation: parent now assigns94 to a fresh scientific
author. No503 engineering lane is released. Parent allocates an existing free
engineering lane only after scientific closure and admission review. Existing
recorded operation/507 slot owners remain authoritative; do not launch a second
native fleet or alter their files.

Original registered module chain: ConvertImageToObjects(preserve_label=True),
MeasureObjectSizeShape, FilterObjects default and FilterObjects removed-enabled.
The original CellProfiler importer in pipeline.py constructs the complete
PipelineDocument declarations; no private sampler, writer, ABI bypass, new
registry, fixture wrapper around the algorithms or selective package change.
Names/settings come from original module declarations. AST syntax alone is
not public validation/compilation or exact runtime binding evidence.

Synthetic input recipe, not acquired biology:
uint16 plane of shape(12,15), initially zero; rows0:2/cols2:5 contain label2;
rows6:10/cols8:13 contain label7. Save through original tifffile writer as
input/A01_s001_w1_z001_t001_Labels.tif using prepare-input01.py.
No existing scientific file or dataset is input. Do not normalize/remap the
categorical source labels; preserve_label is deliberately true.

Acceptance uses public original health -> first-use/capability discovery ->
explicit intended-endpoint catalog preparation -> validate/import artifact
plan -> compile -> execute and observe the ORIGINAL job handle until terminal.
No command/UNKNOWN replay. Ordinary source binding/pipeline job receipts and
public output inventory/readback must identify this exact engineering target.

Required joins, not equal counts: source and saved Objects pixels have nonzero
IDs2/7. Table categorical row2 has AreaShape_Area6; row7 has20, through original
row completion/feature query/export. Absent labels may follow the original
declared-domain contract, but cannot shift or swap those supported values.
FilterObjects default admits canonical+three trailing outputs; enabled admits
canonical+five. Original border rule retains source7 as target1 and removes
source2 as target1 in the separate complement, with original directed lineage
and independent published artifact names. Compare actual label pixels, typed
domains, tables and relationship endpoint pairs; count equality is insufficient.

Default omits the optional removed flag so original callable default False
is exercised. Enabled explicitly sets Yes. No additional object group is
configured: Root owns unbounded repeated-group ABI extension, not this narrow
optional-return admission. Retain strict validator/matcher failures separately.

Then close exact engineering native/MCP owners normally and verify exits.
No biological, autonomous, broader ABI or scientific-run acceptance claim.
