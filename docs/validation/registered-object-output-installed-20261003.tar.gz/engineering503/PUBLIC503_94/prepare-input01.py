"""Write only a new tiny synthetic engineering plane with original tifffile."""
from pathlib import Path
import hashlib
import json
import numpy as np
import tifffile

root = Path(__file__).resolve().parent
path = root / 'input/A01_s001_w1_z001_t001_Labels.tif'
assert not path.exists(), path
image = np.zeros((12,15),dtype=np.uint16)
image[:2,2:5] = 2
image[6:10,8:13] = 7
path.parent.mkdir(parents=True,exist_ok=True)
tifffile.imwrite(path,image,metadata={'axes':'YX'})
readback = tifffile.imread(path)
np.testing.assert_array_equal(readback,image)
print(json.dumps(dict(input=str(path),shape=list(image.shape),dtype=str(image.dtype),
    label_pixel_counts={str(i):int(np.count_nonzero(image==i)) for i in (2,7)},
    sha256=hashlib.sha256(path.read_bytes()).hexdigest(),scientific_input=False,
    original_writer=tifffile.__file__),sort_keys=True))
