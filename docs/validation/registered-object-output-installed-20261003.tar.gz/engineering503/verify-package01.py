"""Reuse505 RECORD/source/declared-resource qualification for a new503 target.

Only source identity, artifact paths and namespace are adapted. Original
membership, RECORD/hash checks and dependency-free projection owners remain.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parent
source = Path('/home/ts/wt/openhcs-ui-workflow-rendering-20261001')
expected = 'c0314a17163260b1b05071e0d405ee386fa6a2e0'
wheel, = (root / 'wheels01').glob('*.whl')
original_path = root.parent / 'next-h004-preparation-20261002/official30-package-implementation-20261003/qualify-bytes.py'
original = original_path.read_text()
adaptations = (
    ('root = Path(__file__).resolve().parent', f'root = Path({str(root)!r})'),
    ('e9e79ac41155745513d6705c85abd7afaee3f35c', expected),
    ('b7bc46a5c44fab203656c974a0c0a506c9295fae', expected),
    ('wheels/merged504/', 'wheels01/'),
    ('scratch/installed505', 'target01'),
    ('816b16f08a24ff92738083b31a440abda36b943ecba1a496976ce28a10b064aa', hashlib.sha256(wheel.read_bytes()).hexdigest()),
    ('"--", "openhcs").splitlines()', '"--", "openhcs", "benchmark").splitlines()'),
    ('"merged_main":main', '"reviewed_source":main'),
    ('"source_main_payload_delta_empty":True', '"reviewed_source_payload_delta_empty":True'),
)
adapted = original
for before, after in adaptations:
    assert before in adapted, before
    adapted = adapted.replace(before, after)
exec(compile(adapted, str(original_path), 'exec'))

tracked = subprocess.check_output(['git', '-C', str(source), 'ls-files', '-z']).decode().split('\0')
with zipfile.ZipFile(wheel) as archive:
    native_sources = tuple(n for n in tracked if n.startswith('openhcs/') and n.endswith('.cpp'))
    native_binaries = tuple(n for n in archive.namelist() if n.startswith('openhcs/') and n.endswith('.so'))
    assert len(native_sources) == len(native_binaries) == 2
    for name in native_sources:
        assert (source/name).read_bytes() == archive.read(name) == (root/'target01'/name).read_bytes(), name
    for name in native_binaries:
        assert archive.read(name) == (root/'target01'/name).read_bytes(), name
print(json.dumps({'original_verifier':str(original_path), 'original_verifier_sha256':hashlib.sha256(original_path.read_bytes()).hexdigest(), 'native_sources':native_sources, 'native_binaries':native_binaries, 'source_wheel_target_equal':True},sort_keys=True))
