#!/usr/bin/env bash
# Path/pin adaptation of engineering494/build-wheel01.sh; same original builder.
set -euo pipefail
source_root=/home/ts/wt/openhcs-ui-workflow-rendering-20261001
package_root=/home/ts/wt/openhcs-issue-batch-20260929/engineering503
paired_python=/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python
test "$(git -C "$source_root" rev-parse HEAD)" = c0314a17163260b1b05071e0d405ee386fa6a2e0
test -z "$(git -C "$source_root" diff --name-only HEAD -- openhcs benchmark packaging setup.py pyproject.toml scripts)"
test ! -e "$package_root/wheels01"
cd "$source_root"
"$paired_python" -B -m build --wheel --no-isolation --outdir "$package_root/wheels01"
scope_path=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
for resource_file in memory.max memory.peak memory.swap.max memory.swap.peak memory.events cpu.max; do
    printf '%s: ' "$resource_file"
    tr '\n' ' ' < "/sys/fs/cgroup$scope_path/$resource_file"
    printf '\n'
done
