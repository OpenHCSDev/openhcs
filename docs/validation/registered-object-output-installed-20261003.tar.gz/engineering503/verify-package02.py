"""Whole current package: original505 verifier plus declared benchmark source.

Retain first incomplete wheel/target and failures. Required Python membership
comes from Git and original pyproject package declarations, not a manual roster.
"""
from pathlib import Path
import fnmatch
import hashlib
import json
import subprocess
import tomllib
import zipfile

root = Path(__file__).resolve().parent
source_root = Path('/home/ts/wt/openhcs-ui-workflow-rendering-20261001')
original = root / 'verify-package01.py'
recipe = original.read_text()
broadened = "    ('\"--\", \"openhcs\").splitlines()', '\"--\", \"openhcs\", \"benchmark\").splitlines()'),\n"
assert broadened in recipe
recipe = recipe.replace(broadened,'').replace("root / 'wheels01'", "root / 'wheels02'")
recipe = recipe.replace("'wheels01/'", "'wheels02/'").replace("'target01'", "'target02'")
recipe = recipe.replace("('scratch/installed505', 'target01')", "('scratch/installed505', 'target02')")
exec(compile(recipe,str(original),'exec'))

source_root = Path('/home/ts/wt/openhcs-ui-workflow-rendering-20261001')
root = Path(__file__).resolve().parent
package_config = tomllib.loads((source_root/'pyproject.toml').read_text())['tool']['setuptools']['packages']['find']
tracked = subprocess.check_output(['git','-C',str(source_root),'ls-tree','-r','--name-only','HEAD','--','benchmark']).decode().splitlines()
wheel, = (root/'wheels02').glob('*.whl')
matched = []
with zipfile.ZipFile(wheel) as archive:
    for name in tracked:
        if not name.endswith('.py'):
            continue
        package = Path(name).parent.as_posix().replace('/','.')
        if not any(fnmatch.fnmatchcase(package,p) for p in package_config['include']):
            continue
        if any(fnmatch.fnmatchcase(package,p) for p in package_config['exclude']):
            continue
        data=(source_root/name).read_bytes()
        assert data == archive.read(name) == (root/'target02'/name).read_bytes(),name
        matched.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    declared_extension=tomllib.loads((source_root/'pyproject.toml').read_text())['project']['entry-points']['openhcs.agent.capability_extensions']
    for name,module in declared_extension.items():
        assert module.replace('.','/')+'.py' in archive.namelist(),(name,module)
print(json.dumps(dict(declared_benchmark_python_matches=len(matched),records=matched,declared_capability_extensions=declared_extension,whole_declared_package_source_wheel_target_equal=True),sort_keys=True))
