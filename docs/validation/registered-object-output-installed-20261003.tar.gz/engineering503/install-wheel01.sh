#!/usr/bin/env bash
# Path adaptation of engineering494/install-wheel01.sh; new unused target only.
set -euo pipefail
package_root=/home/ts/wt/openhcs-issue-batch-20260929/engineering503
paired_python=/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python
test ! -e "$package_root/target01"
"$paired_python" -B -m pip install --no-deps --no-index --no-compile --target "$package_root/target01" "$package_root/wheels01/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl"
scope_path=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
for resource_file in memory.max memory.peak memory.swap.max memory.swap.peak memory.events cpu.max; do
    printf '%s: ' "$resource_file"
    tr '\n' ' ' < "/sys/fs/cgroup$scope_path/$resource_file"
    printf '\n'
done
