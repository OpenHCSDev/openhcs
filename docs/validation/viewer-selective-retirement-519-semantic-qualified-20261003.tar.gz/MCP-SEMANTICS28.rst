Final decoder-owned MCP package checkpoint
=========================================

Issue #528 / implementation #522. Planck is the combined integration owner;
Singer received the narrow source fix on the original #522 branch. Source
d92fd0b8c786d52c4290bf764b3cc3a84da9b600 is published and byte-qualified.
This is the main-based private combined #511/#522/#524 source, not Root394
or a claim that the combined changes are merged main.

Target distinction
------------------

target04 remains the failed scientific startup package. target05 repaired
schema construction but did NOT preserve the original decoder's semantics.
Its original qualification/health/receipts remain historical and unchanged.
Neither is relabelled as the final decoder fix.

NEW immutable ordinary target06 contains the final owner delegation:

  Annotated[StreamProducerIdentity,
            BeforeValidator(StreamProducerIdentity.from_payload)]

This metadata sits directly in the canonical DTO factory annotation. The
existing generated signature preserves extras; FastMCP/Pydantic invokes the
original producer decoder before constructing/accepting the nominal identity.
The downstream original from_payload receives that same typed identity.
No alternate validator implementation, field roster, TypedDict, JSON alias,
codec, registry, fallback, recursion limit or dependency source edit was added.
There is no __post_init__ on the actual original StreamProducerIdentity;
the original from_payload is its wire-admission authority.

Actual original semantics
-------------------------

Required fields reject missing, empty string or None, but normalize admitted
numeric/bool values through the original str conversion. Optional empty strings
become None. Optional integer values use the original int conversion, including
bool and numeric strings. Unknown producer wire keys are ignored by that owner,
not silently promoted to a new stricter policy. Unknown top-level tool parameters
remain forbidden by the existing generated MCP argument model.

installed-controls26.log contains 30 actual installed checks, 11.67s,
peak377876480 bytes, noSwap/OOM0. The actual SDK model is compared against the
unchanged original decoder for bool/int/string coercion, optional normalization,
ignored producer keys and required/null/invalid-int rejection. It also exercises
real full FastMCP construction, raw CLI equivalence, original receipt/error MRO,
original Qt/model retirement and whole-incarnation guards. The generated SDK
Tool.run-to-service/serialized native Qt queue control retains the exact raw
layer/backing array and never queues malformed identity input. This is not a
claim of a detached external TCP receiving journey.

Whole source and actual entrypoint
----------------------------------

Wheel: wheels05/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl
SHA256: 46070edad4363d406b47ea771d07e795bff5eb268c4fa58d564881b5ec48ca04
Source: d92fd0b8c786d52c4290bf764b3cc3a84da9b600.
Target: /home/ts/wt/openhcs-issue-batch-20260929/engineering494/target06.

package26.log verifies all 815 tracked source files, 90 knowledge/skill assets,
all 13 skill members and two compiled native extensions against this NEW ordinary
wheel/target, not an overlay on04/05. PACKAGE28-QUALIFICATION.json verifies all
original RECORDs/scripts and the already-qualified ObjectState1.1.8/9c31e4 and
introspect0.1.14/6f5ac0 wheel/API bytes. 1331 actual files are accounted, including
347 interpreter caches checked against their exact original source compilation;
no file is simply ignored. No new environment, download or shared install.

Actual target06 build_server: 104 tools, terminal0; server-construction27.log.
Actual fresh non-resident stdio health: status=ok, errors=[], packaged resources
ready and target06 source origin; mcp-health27.stdout. The child exited normally.
Build05 max512MiB/peak195313664/OOM0; controls max1GiB, qualification512MiB,
noSwap/CPU1/60s shards. No native/viewer/catalog startup or scientific call.

SCHEMA-FAMILY27-FINAL.json uses the existing refactor-audit AST loader over
704 production and 162 actual introspect/PolyStore/Pydantic/FastMCP modules,
zero parse omissions. Its owner/consumer evidence is read with the canonical
factory MRO, include_extras signature projection and BeforeValidator schema hook.
This named AST evidence is not a global equivalence claim.

Receiving release boundary
--------------------------

Parent owns the isolated95 slot and SCI release. No new scientific author should
use04/05. By the newest explicit parent release, this healthy corrected06
qualifies scientific startup and ordinary baseline analysis after the original
parent resource guard and source/packet freeze. The NEW standalone original989B
archive reopen and actual detached public retirement receiving journey remain
separate feature-merge acceptance gaps, NOT universal gates on a fresh author's
first health/ordinary analysis. Those features are not claimed live-verified.
The original failed producer execution9292 is NOT replayed. Original source4-plane
fixture, metadata ZIP, calibration and failure journals remain protected.
No held-out/scientist data or answer has been inspected. Root435 automatic
publication failure is separately owned and is not hidden by this correction.

The initial READY28/receipt wording followed the prior broader release boundary.
Exact pre-release-correction copies and original first hash manifest are retained;
the parent subsequently narrowed that boundary. Scientific/package/source bytes
and actual qualification strength are unchanged; no rebuild or hotupdate.
