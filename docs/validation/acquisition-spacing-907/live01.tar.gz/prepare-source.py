"""Original pinned archive materializer with explicit source and asset origins.

Manifest/schema/projector come from pinned source. Untracked manifest inputs
come from the retained keeper, proved against its qualified wheel. No script
substitution or alternative knowledge projector is involved.
"""
import hashlib
import json
import runpy
import shutil
import subprocess
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).parent
pin = json.loads((root / 'SOURCE-PIN.json').read_text())
repository = Path(pin['repository'])
asset_origin = Path(pin['retained_asset_root'])
prior_wheel = Path(pin['retained_asset_wheel'])
head = pin['source_head']

def git(*args):
    return subprocess.check_output(['git', '-C', str(repository), *args])

for name in ('scripts/build_mcp_knowledge_assets.py',
             'openhcs/agent/knowledge_manifest_schema.py',
             'openhcs/agent/skill_bundle.py',
             'docs/source/development/mcp_knowledge_base_manifest.json'):
    assert (repository / name).read_bytes() == git('show', f'{head}:{name}'), name
helpers = runpy.run_path(str(repository / 'scripts/build_mcp_knowledge_assets.py'))
projections = helpers['knowledge_source_projections'](
    repository / helpers['KNOWLEDGE_MANIFEST_RELATIVE_PATH'], source_root=repository)
tracked = set(git('ls-tree', '-r', '--name-only', head).decode().splitlines())
selected = set(git('ls-tree', '-r', '--name-only', head, '--',
    'openhcs', 'benchmark', 'packaging', 'scripts', 'setup.py', 'pyproject.toml',
    'MANIFEST.in', 'README.md', 'LICENSE', 'setup.cfg', 'vendor',
    'THIRD_PARTY_LICENSES').decode().splitlines())
selected = {name for name in selected if not name.startswith((
    'benchmark/native_refs/', 'benchmark/results/', 'benchmark/manifests/'))}
selected.update(str(name) for name in projections if str(name) in tracked)
selected.add(str(helpers['KNOWLEDGE_MANIFEST_RELATIVE_PATH']))

# Validate retained inputs before archive creation. The original projector owns
# their membership; their historical origin is separate from the manifest root.
retained_assets = []
with ZipFile(prior_wheel) as wheel:
    for name in projections:
        if str(name) in tracked:
            continue
        retained_path = asset_origin / name
        data = retained_path.read_bytes()
        packaged = (helpers['PACKAGED_KNOWLEDGE_ROOT_RELATIVE_PATH'] / name).as_posix()
        assert wheel.read(packaged) == data, str(name)
        retained_assets.append(dict(path=str(name),
            sha256=hashlib.sha256(data).hexdigest(), origin=str(retained_path),
            qualified_wheel=str(prior_wheel)))

source = root / 'source'
source.mkdir(exist_ok=False)
archive = subprocess.Popen(['git', '-C', str(repository), 'archive', head,
                            *sorted(selected)], stdout=subprocess.PIPE)
with archive.stdout:
    subprocess.run(['tar', '-xf', '-', '-C', str(source)],
                   stdin=archive.stdout, check=True)
assert archive.wait() == 0
for record in retained_assets:
    destination = source / record['path']
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(record['origin'], destination)
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == record['sha256']

# Retained recipe manifests now exist in the archive. Let the SAME projector
# derive their native-source closure there; don't use a manifest outside its
# source root or substitute a private recipe reader.
archive_helpers = runpy.run_path(str(source / 'scripts/build_mcp_knowledge_assets.py'))
complete_projections = archive_helpers['knowledge_source_projections'](
    source / archive_helpers['KNOWLEDGE_MANIFEST_RELATIVE_PATH'], source_root=source)
with ZipFile(prior_wheel) as wheel:
    for name, destination in complete_projections.items():
        if destination.is_file():
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        if str(name) in tracked:
            data = git('show', f'{head}:{name}')
            with destination.open('xb') as output:
                output.write(data)
            selected.add(str(name))
        else:
            retained_path = asset_origin / name
            data = retained_path.read_bytes()
            packaged = (helpers['PACKAGED_KNOWLEDGE_ROOT_RELATIVE_PATH'] / name).as_posix()
            assert wheel.read(packaged) == data, str(name)
            shutil.copyfile(retained_path, destination)
            retained_assets.append(dict(path=str(name),
                sha256=hashlib.sha256(data).hexdigest(), origin=str(retained_path),
                qualified_wheel=str(prior_wheel)))

receipt = dict(source_head=head, repository=str(repository), source=str(source),
    source_kind='read-only Git archive, not a worktree or mutable source checkout',
    selected_files=len(selected),
    source_bytes=sum(p.stat().st_size for p in source.rglob('*') if p.is_file()),
    changed_since_qualified04=git('diff', '--name-only',
        'a0efb9b5d44e7f99d3c42cb5712724fbf2a4f07a', head).decode().splitlines(),
    omitted='setuptools-declared excluded benchmark fixture trees except manifest-declared knowledge assets',
    source_checkout_mutated=False, retained_manifest_assets=retained_assets,
    prior_attempt=f'none for {root.name}; all original prior attempts retained unchanged')
with (root / 'SOURCE-ORIGIN.json').open('x') as output:
    json.dump(receipt, output, indent=2)
print(json.dumps(receipt))
