"""Bounded artifact proof through original Git, RECORD and projection owners."""
import base64
import csv
import hashlib
import io
import json
import runpy
import subprocess
from pathlib import Path
from zipfile import ZipFile
from importlib.metadata import Distribution

root = Path(__file__).parent
pin = json.loads((root / 'SOURCE-PIN.json').read_text())
repository = Path(pin['repository'])
source = root / 'source'
head = pin['source_head']
origin = json.loads((root / 'SOURCE-ORIGIN.json').read_text())
assert origin['source_head'] == head and origin['source'] == str(source)
target = root / 'target'
def git(*args):
    return subprocess.check_output(['git', '-C', str(repository), *args], text=True).strip()
for name in ('setup.py', 'setup.cfg', 'pyproject.toml', 'MANIFEST.in',
             'scripts/build_mcp_knowledge_assets.py'):
    assert (source / name).read_bytes() == subprocess.check_output(
        ['git', '-C', str(repository), 'show', f'{head}:{name}']), name
helpers = runpy.run_path(str(source / 'scripts/build_mcp_knowledge_assets.py'))
projections = helpers['knowledge_source_projections'](source / helpers['KNOWLEDGE_MANIFEST_RELATIVE_PATH'], source_root=source)
bundle = helpers['AgentSkillBundle'].from_manifest(source / helpers['AGENT_PLUGIN_MANIFEST_PATH'])
skills = bundle.source_paths()
projections.update({path.relative_to(source): path for path in skills})
records = []
wheel, = (root / 'wheels').glob('*.whl')
with ZipFile(wheel) as archive:
    record, = (name for name in archive.namelist() if name.endswith('.dist-info/RECORD'))
    for name, digest, size in csv.reader(io.StringIO(archive.read(record).decode())):
        if name == record:
            continue  # pip owns the installed RECORD, including generated scripts.
        data = archive.read(name)
        assert (target / name).read_bytes() == data, name
        if digest:
            algorithm, value = digest.split('=', 1)
            assert base64.urlsafe_b64encode(hashlib.new(algorithm, data).digest()).rstrip(b'=').decode() == value, name
            assert len(data) == int(size), name
        records.append(name)
    matches, excluded = [], []
    for name in filter(None, git('ls-tree', '-r', '-z', '--name-only', head, '--', 'openhcs', 'benchmark').split('\0')):
        if name in archive.namelist():
            assert (source / name).read_bytes() == archive.read(name) == subprocess.check_output(['git', '-C', str(repository), 'show', f'{head}:{name}']), name
            matches.append(name)
        else:
            excluded.append(name)
    import fnmatch, tomllib
    declared_exclusions = tomllib.loads((source / 'pyproject.toml').read_text())['tool']['setuptools']['packages']['find']['exclude']
    assert not [name for name in excluded if name.endswith('.py') and not any(fnmatch.fnmatch(name.replace('/', '.'), pattern) for pattern in declared_exclusions)], 'Undeclared Python exclusion'
    resources = []
    for relative, path in projections.items():
        projected = (helpers['PACKAGED_KNOWLEDGE_ROOT_RELATIVE_PATH'] / relative).as_posix()
        data = path.read_bytes()
        assert archive.read(projected) == data == (target / projected).read_bytes(), projected
        resources.append({'source': str(relative), 'projection': projected, 'sha256': hashlib.sha256(data).hexdigest()})
installed_paths = set()
infos = tuple(target.glob('*.dist-info'))
dependencies = json.loads((root / 'DEPENDENCY-ARTIFACTS.json').read_text())
expected_infos = {'openhcs-0.8.7.dist-info'}
for record in dependencies.values():
    with ZipFile(record['wheel']) as dependency:
        dependency_metadata, = (name for name in dependency.namelist() if name.endswith('.dist-info/METADATA'))
        expected_infos.add(str(Path(dependency_metadata).parent))
assert {info.name for info in infos} == expected_infos
for info in infos:
    scripts = {entry.name for entry in Distribution.at(info).entry_points if entry.group in ('console_scripts', 'gui_scripts')}
    for name, digest, size in csv.reader(io.StringIO((info / 'RECORD').read_text())):
        path = target / name
        if not path.resolve().is_relative_to(target):
            # pip --target relocates declared entrypoints into target/bin.
            relative = Path(name)
            assert relative.parts[:3] == ('..', '..', 'bin') and len(relative.parts) == 4 and relative.name in scripts, name
            path = target / 'bin' / relative.name
        assert path.resolve().is_relative_to(target), name
        data = path.read_bytes()
        installed_paths.add(path.resolve())
        if digest:
            algorithm, value = digest.split('=', 1)
            assert base64.urlsafe_b64encode(hashlib.new(algorithm, data).digest()).rstrip(b'=').decode() == value, name
        if size:
            assert len(data) == int(size), name
assert {path.resolve() for path in target.rglob('*') if path.is_file()} == installed_paths
result = dict(status='PASS', source_head=head, source=str(source), target=str(target), wheel=str(wheel), wheel_sha256=hashlib.sha256(wheel.read_bytes()).hexdigest(), wheel_record_entries=len(records), tracked_source_matches=len(matches), tracked_python_matches=sum(name.endswith('.py') for name in matches), excluded_source_nonpython=excluded, manifest_derived_resources=resources, complete_skill_files=len(skills)-1, dependencies=dependencies, native_catalog_viewer_science_launched=False)
with (root / 'BYTE-QUALIFICATION.json').open('x') as output:
    json.dump(result, output, indent=2)
print(json.dumps({key: value for key, value in result.items() if key not in ('manifest_derived_resources', 'excluded_source_nonpython')}, indent=2))
