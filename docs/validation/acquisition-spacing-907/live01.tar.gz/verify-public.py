"""Check the original recorded replies; issue no MCP request or processing job.

Recording extraction follows receiving28/verify-headless.py. Scientific source
pixels and ROI coordinates are read only to compare them with public readback.
"""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

import numpy as np
import roifile
import tifffile

root = Path(__file__).parent
text = (root / "mcp-headless01.stdout").read_text()
decoder = json.JSONDecoder()
responses = []
position = 0
while position < len(text):
    start = text.find("{", position)
    if start < 0:
        break
    try:
        value, length = decoder.raw_decode(text[start:])
    except json.JSONDecodeError:
        position = start + 1
        continue
    position = start + length
    if isinstance(value, dict) and "results" in value and "server" in value:
        responses.append(value)
assert len(responses) == 22
payloads = []
for response in responses:
    assert response["errors"] == []
    result, = response["results"]
    assert not result["mcp_error"]
    payload, = result["payloads"]
    assert not payload.get("errors", [])
    payloads.append(payload)
assert Path(payloads[0]["server_source_path"]) == root / "target/openhcs/mcp/server.py"
assert payloads[0]["status"] == "ok"
assert 'COMMAND_EXIT_CODE="0"' in text

for line in (root / "original-fixtures.sha256").read_text().splitlines():
    digest, path = line.split("  ", 1)
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
unknown = payloads[6]
assert len(unknown["layers"]) == 2
for layer in unknown["layers"]:
    assert layer["native_transform"]["scale"][-2:] == [1.0, 1.0]
    assert layer["native_transform"]["translate"][-2:] == [0.0, 0.0]
    assert layer["payload_summaries"][0]["source_voxel_spacing"]["values_zyx"] == []
    assert layer["component_values"] == [dict(channel=2, site=1, timepoint=1, well="A01", z_index=1)]
raw_path = Path('/run/media/ts/hdd/openhcs-engineering/engineering541-public88-20261005/results/acquisition_openhcs/images/A01_s001_w2_z001_t001.tif')
raw = tifffile.imread(raw_path).squeeze()
np.testing.assert_array_equal(payloads[13]["records"][0]["array_values"], raw)
assert raw.shape == (128, 128)
shapes = payloads[10]["layers"][0]["payloads"][0]["shape_payloads"]
roi_path = raw_path.parent.parent / 'results/A01_s001_w2_z001_t001_neurite_morphology_step0.graph.roi.zip'
# This native archive also owns a JSON metadata member. Decode its declared
# ImageJ ROI members, not every ZIP entry through roifile's generic ZIP helper.
with ZipFile(roi_path) as archive:
    rois = [roifile.ImagejRoi.frombytes(archive.read(name))
            for name in archive.namelist() if name.endswith(".roi")]
assert len(shapes) == len(rois) == 3
for shape, roi in zip(shapes, rois, strict=True):
    assert shape["metadata"]["coordinate_unit"] == "pixels"
    np.testing.assert_array_equal(shape["coordinates"], roi.coordinates()[:, ::-1])
assert sum(len(shape["coordinates"]) for shape in shapes) == 69

physical = payloads[18]
assert len(physical["layers"]) == 2
for layer in physical["layers"]:
    assert layer["native_transform"]["scale"][-2:] == [0.5, 0.5]
    assert layer["payload_summaries"][0]["source_voxel_spacing"] == dict(unit="micrometers", values_zyx=[0.5, 0.5])
assert payloads[19]["records"][0]["array_values"] == [[12, 13, 14, 15], [16, 17, 18, 19], [20, 21, 22, 23]]
for index in (14, 21):
    assert all(payloads[index][field] for field in ("acknowledged", "endpoint_terminated", "process_exited", "succeeded"))
print(json.dumps(dict(status="PASS", public_replies=22,
    unknown_raw_pixels_equal=16384, graph_paths_equal=3,
    graph_coordinates_equal=69, graph_coordinate_unit="pixels",
    unknown_spacing_values=[], unknown_scale_yx=[1, 1],
    calibrated_raw_pixels_equal=12, calibrated_raw_and_roi_scale_yx=[0.5, 0.5],
    calibrated_unit="micrometers", original_fixture_hashes_unchanged=5,
    viewer_close_ack_exit=[payloads[i]["process_identity"] for i in (14, 21)],
    client_exit=0), indent=2))
