"""Original serial offline build/install phases with explicit artifact inputs."""
import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path(__file__).parent.resolve()
paired_python = Path('/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python')
dependencies = json.loads((root / 'DEPENDENCY-ARTIFACTS.json').read_text())
for record in dependencies.values():
    path = Path(record['wheel'])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == record['sha256'], path
pin = json.loads((root / 'SOURCE-PIN.json').read_text())
scratch = Path(pin['build_scratch'])
assert not any((root / name).exists() for name in ('source', 'target', 'wheels'))
assert not scratch.exists()
for name in ('tmp', 'cache', 'data', 'config', 'matplotlib'):
    (scratch / name).mkdir(parents=True, exist_ok=False)
environment = dict(os.environ,
    TMPDIR=str(scratch / 'tmp'), PIP_CACHE_DIR=str(scratch / 'cache'),
    PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1',
    OMP_NUM_THREADS='1', NUMBA_NUM_THREADS='1')

def run(*args, cwd=root):
    print(json.dumps(dict(stage=list(map(str, args)), cwd=str(cwd))), flush=True)
    subprocess.run(list(map(str, args)), cwd=cwd, env=environment, check=True)

run(paired_python, '-B', root / 'prepare-source.py')
run('/usr/bin/time', '-v', paired_python, '-B', '-m', 'build', '--wheel',
    '--no-isolation', '--outdir', root / 'wheels', cwd=root / 'source')
wheel, = (root / 'wheels').glob('*.whl')
run(paired_python, '-B', '-m', 'pip', 'install', '--no-index', '--no-deps',
    '--no-compile', '--target', root / 'target', wheel,
    *(record['wheel'] for record in dependencies.values()))
environment.update(PYTHONPATH=str(root / 'target'), OPENHCS_HEADLESS='true',
    OPENHCS_CPU_ONLY='true', QT_QPA_PLATFORM='offscreen',
    POLYSTORE_IMAGEJ_ALLOW_DOWNLOAD='false',
    XDG_CACHE_HOME=str(scratch / 'cache'), XDG_DATA_HOME=str(scratch / 'data'),
    XDG_CONFIG_HOME=str(scratch / 'config'), MPLCONFIGDIR=str(scratch / 'matplotlib'))
run(paired_python, '-B', root / 'qualify-bytes.py')
run(paired_python, '-B', '-m', 'openhcs.cli', 'skills', 'sync',
    '--skills-dir', root / 'skills', '--dry-run')
run(paired_python, '-B', '-m', 'openhcs.cli', 'skills', 'sync',
    '--skills-dir', root / 'skills')
