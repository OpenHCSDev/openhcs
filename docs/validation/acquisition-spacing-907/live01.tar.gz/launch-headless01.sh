#!/usr/bin/env bash
# Original dev_client + script recording, unique journals at creation.
set -euo pipefail
root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
scratch=$(jq -er .build_scratch "$root/SOURCE-PIN.json")
for file in mcp-headless01.stdin mcp-headless01.stdout mcp-headless01.timing; do
  test ! -e "$root/$file"
done
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$root/target"
export OPENHCS_HEADLESS=true OPENHCS_CPU_ONLY=true QT_QPA_PLATFORM=xcb POLYSTORE_IMAGEJ_ALLOW_DOWNLOAD=false
export DISPLAY=:88 LIBGL_ALWAYS_SOFTWARE=1
export OPENHCS_UI_BRIDGE_DESCRIPTOR="$root/no-attached-ui.json"
export OPENHCS_AGENT_READ_ROOTS="$root:/run/media/ts/hdd/openhcs-engineering/engineering541-public88-20261005/results/acquisition_openhcs:/home/ts/wt/openhcs-issue-batch-20260929/carrier434-installed-20261002/engineering-440441-01:/home/ts/.openhcs/tcp:$scratch" OPENHCS_AGENT_WRITE_ROOTS="$root:$scratch:/home/ts/.openhcs/tcp"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 NUMBA_NUM_THREADS=1
export XDG_CACHE_HOME="$scratch/cache" XDG_DATA_HOME="$scratch/data" XDG_CONFIG_HOME="$scratch/config"
export TMPDIR="$scratch/tmp" MPLCONFIGDIR="$scratch/matplotlib"
cd /home/ts/wt/openhcs-issue-batch-20260929
exec script -q -e -I "$root/mcp-headless01.stdin" -O "$root/mcp-headless01.stdout" -T "$root/mcp-headless01.timing" -c '/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python -B -m openhcs.mcp.dev_client --no-resident --timeout-seconds 10 shell --no-prompt'
