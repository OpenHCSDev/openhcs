Code and UI editing
===================

The desktop forms and generated Python are two projections of the same live
ObjectState-backed declarations. Pipeline code contains ``PipelineConfig`` and
``FunctionStep`` values; it is not a separate GUI model.

Use the code view attached to the relevant window or scope. A typical round
trip is:

1. edit a pipeline or configuration in the form;
2. open its code projection and inspect the generated declarations;
3. edit the code and apply it;
4. resolve any validation error before the live state is replaced;
5. compile again before execution.

Choose the document that owns the edited object. Pipeline Editor projects one
complete ``PipelineDocument``; a step editor projects one ``FunctionStep``; a
configuration window projects its typed config; Plate Manager projects the
multi-plate aggregate. The available Code controls and MCP document catalog are
discovered from those nominal owners rather than a copied button list.

Select a plate before applying a Pipeline Editor document. Without a selected
plate, the document remains readable for inspection but reports
``writable=False`` and rejects apply requests without changing UI state.

A Plate Manager document also carries its read-time selection scope. An
all-plates document represents the complete visible collection, so applying it
synchronises that collection. A selected document may replace only the named
plates and leaves every unselected plate unchanged. Its payload must contain the
same plate scope IDs that were read; read a fresh document to choose a different
scope.

You can apply a selected document for an idle plate while another plate runs.
Keep the exported global declaration unchanged to preserve any existing global
draft. A submitted global change affects shared defaults and is protected while
plate work is active. An all-plates document keeps its whole-collection commit
semantics.

Pipeline Editor code must define ``pipeline_steps``. You may omit
``pipeline_config`` when the pipeline uses the default ``PipelineConfig()``;
generated code includes the explicit assignment again. Provide
``pipeline_config`` when the pipeline needs non-default source, processing,
viewer, or materialisation settings.

Reuse the exact imports shown in generated code. Plate Manager accepts external
processing functions listed in the execution endpoint's catalogue, including
``skimage.filters.edges.sobel``. Applying the document resolves the selected
catalogue wrapper, preserving its processing contract and runtime controls.
Wildcard imports and functions absent from that catalogue are rejected.

Channel-grouped patterns may combine individual functions, ``(function, kwargs)``
pairs, and lists of functions. Explicit per-function settings, including dtype
conversion and slice-by-slice execution, remain part of the code/UI round trip.

Generated function parameters follow the function's declared signature order,
matching the form's parameter order. Extra keyword parameters follow the
declared parameters in their supplied order. Decimal fields use compact,
locale-aware text, so a value such as ``99.8`` remains readable without changing
the field's configured numeric precision.

Applying a complete Pipeline Editor or Plate Manager code document reconciles
the submitted declaration with the live ObjectState graph. Unchanged and
unambiguously edited occurrences retain their history across reordering; added
occurrences receive new scopes and omitted occurrences are removed. Ambiguous
duplicate edits receive new scopes instead of inheriting state by list position.
Equivalent callable wrappers and explicitly written signature defaults do not
create false occurrence replacements.
Declaration-normalised documents that are already equivalent return
``unchanged`` without invoking the apply path or recording a snapshot.

For the Pipeline Editor, a successful code apply is also the commit action. It
advances the saved baseline of the reconciled pipeline, each active step, and
each nested function parameter state. There is no transient post-apply pipeline
value waiting for a separate Save button. A step or configuration editor that
provides an explicit save action retains that smaller editor's normal dirty-state
workflow.

After applying step code, inspect its function fields directly. An occurrence
keeps its existing child state when its function and editable parameter surface
are unchanged. Adding or removing an explicit keyword can change that surface;
the child is then rebuilt at the same scope so the form does not retain a stale
parameter schema. Changes made in a function form also appear when you reopen
its Code view, including changes to a group that is not currently selected in
the function list.

.. openhcs-gallery:: lazy-inheritance

Clean and resolved views
------------------------

A clean document keeps inherited/default lazy fields sparse, which is normally
the best form to edit and share. A resolved view includes effective inherited
values for inspection. Do not paste a resolved document back merely to change
one field: that can turn inherited values into explicit overrides.

Safe apply and recovery
-----------------------

Code-document reads return a revision token. Validate the edited source without
mutation, review the intended change, then apply against a freshly read token.
If the UI changed in the meantime, re-read and reapply the edit rather than
overwriting the newer state. Apply returns snapshot/revision facts that support
audit and undo; branches and time travel should be inspected before editing a
non-head state.

Dirty markers remain meaningful after a code edit: ``*`` marks unsaved state,
``_`` marks a value that differs from its default, and an inherited value can
have a resolved value even while its raw lazy field is ``None``. Pipeline Editor
code apply clears the unsaved marker for its reconciled graph. On surfaces with
an explicit save or commit action, use that owning action where persistence is
required.

For an attached agent, follow :ref:`openhcs-task-authorization`: routine edits
within existing task authority do not need another approval request. Read,
explain, re-read, validate, apply with the fresh revision and declared
confirmation policy, retain the receipt, then inspect the relevant state
surface. Small field-level ObjectState mutations have a
request token but no base-revision guard; use them only after a fresh field read
and verify immediately afterward. Prefer the code document for atomic related
changes.

pycodify owns generic Python source serialization and import/collision handling.
OpenHCS owns the mapping between UI scope identities, pipeline declarations,
and code documents. Applying code is therefore a validated state transition,
not arbitrary execution inside the widget.

See :doc:`../architecture/code_ui_interconversion` and the pycodify package
documentation for the two sides of the boundary.
