"""Parameterize the existing complete wheel/RECORD/source verifier for626."""
from pathlib import Path

original = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering-wholemain-after394-20261004/receiving04/qualify-bytes.py')
wrapper = original.read_text().replace(
    "original = Path(__file__).parents[2] / 'engineering587/qualify-bytes.py'",
    "original = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering587/qualify-bytes.py')",
).replace("'/home/ts/wt/openhcs-basicpy-readiness-20260929'",
          "'/home/ts/wt/openhcs-ui-workflow-rendering-20261001'").replace(
    "'a0efb9b5d44e7f99d3c42cb5712724fbf2a4f07a'", "'1496b071902841855a521ea3280ade8b2433d47b'")
wrapper = wrapper.replace("exec(compile(program, str(original), 'exec'))", "")
namespace = {'__file__': str(__file__)}
exec(compile(wrapper, str(original), 'exec'), namespace)
program = namespace['program'].replace(
    "'polystore-0.3.2.dist-info'}", "'polystore-0.3.2.dist-info', 'pyqt_reactive-0.3.26.dist-info'}").replace(
    "'polystore0.3.2']", "'polystore0.3.2', 'pyqt-reactive0.3.26']")
exec(compile(program, str(original), 'exec'))
