620 default automatic and named publication: public receiving
============================================================

Use the one existing recorded public client and original typed native lifecycle
after the builder/lane owner releases the exact engineering endpoint. No display,
viewer, scientific input or custom function is required. Do not reuse an UNKNOWN
operation, the original600 failed job, or any active scientist endpoint.

The source is the original synthetic600 Gray/Color TIFFs, copied byte-exact into
this distinct acquisition directory. The CPPipe is unchanged. pipeline.py is the
original full SourceBindings/importer configuration with a new result root and
default automatic persistence enabled, not artifacts-only. Both forward and
reverse ImageMath operands are present with the two independent outputs.

Reuse engineering599/public-packet01/PUBLIC.commands through the original normal
CLI. Substitute this root/acquisition and this pipeline.py, the actual returned
global config/session/job/route handles, and this root/values01 export. Native
host/port/transport come from the original released lifecycle owner, never a
scientist or port-only guess. Observe the original handles; preserve every reply
and error. No duplicate registration, re-submit or replay follows uncertainty.

Required user-path proof: health resolves the whole626 candidate; normal catalogue
preparation, artifact-plan, source session, compile and execution complete. Public
inventory contains exactly four physical images, not a count of lookup aliases.
Full12x15 public samples for GrayIndependent, ColorIndependent, Forward and Reverse
equal the original600 expected720 values exactly; both operand orders succeed.
All preserve declared .5/.5micrometer spacing and original source/channel domain.
Canonical VALUES is loaded through its existing owner, not JSON-mirrored. Retain
the exact source/runtime package identities, original input hashes, all public
responses and exact native/client closure. This proves default publication and
receiving, not biological correctness or a whole630 performance acceptance.

No client/native operation has been started by preparation of this packet.
