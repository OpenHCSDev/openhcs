626 public88 terminal custody and receiving
=========================================

Singer, 2026-10-04 15:15UTC. ONE original recorded client PTY93391,
MCP1370964; native1377287/create1791125937.95, TCP6020/ACK7020.
openhcs_close_owned_runtime used its original returned incarnation-bound handle
once. The complete public reply records errors[], acknowledged=true,
endpoint_terminated=true, process_exited=true and succeeded=true. Native numeric
exit status is not claimed. One subsequent client exit returned actual terminal2;
the original script footer also records COMMAND_EXIT_CODE=2. No viewer started.

Read-only post-close ps finds both exact PIDs absent; ss finds neither6020 nor
7020 listening. The original engineering626-public88-20261004-engineering626_88-mcp.scope
is inactive/dead. No owned operation remains pending or UNKNOWN. Original88
X/VNC/WM helpers were not signalled or replaced; Dewey owns their next lease.
This positive terminal handoff permits Dewey's normal retirement/grant63388;
Singer does not edit the shared funding declaration or launch another client.

Native default automatic AND named publication passed on the qualified whole
receiving02 target/source1496b071902841855a521ea3280ade8b2433d47b. Compile job1
and execution job2 both COMPLETE; execution ac9e7641-b7f4-44ca-bae2-cb4b0e25af9d.
Public inventory contains exactly four images. Full12x15 samples for
GrayIndependent, ColorIndependent, Forward and Reverse each match all180
elements exactly:720 total, channel1/2 and .5/.5micrometer geometry preserved.
The original ZMQRuntimeExecutionObservationExport.read(...).require_valid_observation()
accepts canonical values01, and its four named arrays also match exactly.
The byte-exact synthetic acquisition hashes are unchanged. This is an engineering
publication proof, not biological accuracy or viewer acceptance.

Original startup01 terminal77 was known PRECLIENT with no MCP journals or public
dispatch. Distinct startup02 passed the SAME unchanged original admission rule.
Two later known harness errors remain in the complete original journal: initial
read-only acquisition root refused its required workspace writes before inspection;
and openhcs_get_job_status was not a declared capability, before native dispatch.
The distinct permitted HDD working plate and actual openhcs_get_execution_status
then succeeded. These negatives are not overwritten, hidden, UNKNOWN or replayed.
The retained errors accompany terminal2; no claim of an all-error-free CLI run.

Original closed journals:
ENGINEERING626_88/author-workspace/output/runtime/mcp.stdin
  SHA256482e5241a0bb9f43ece8b729f97420567ab4cb68e384250031d29d233656b016
ENGINEERING626_88/author-workspace/output/runtime/mcp.stdout
  SHA256ae3d3730b8907248496fb2197f4fcdb393a067cd0252c9f6c3718824eb233684
ENGINEERING626_88/author-workspace/output/runtime/mcp.timing
  SHA2569556e57cd3b464694758647329d76e72acba1d4f3be099a98710ef821e77d90e

verify-public01.stdout/stderr are original terminal0,4.20s/282668KiB/Swap0.
Its transcript hash c736104d... is explicitly the PRE-CLOSE observation; the
different closed stdout hash above includes subsequent close and client footer.
No verification was rerun to replace the earlier hash or erase a negative.
Canonical VALUES is
/run/media/ts/hdd/openhcs-engineering/engineering620-public88-20261004/values01
SHA2562776292906ed9f2166c2c605e16530226b5ac312ffb42afee85caa2024c91ec3.
Results are under that same HDD root/results/acquisition_openhcs.
