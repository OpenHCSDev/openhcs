"""Reuse original600 public-reply reader; verify this default-publication case."""
from pathlib import Path

original = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/public94-combined02/verify-received02.py')
reader = original.read_text().partition('import numpy as np')[0]
reader = reader.replace("target = engineering / 'package02/target'", "target = engineering / 'receiving02/target'").replace(
    "output = root / 'ENGINEERING600614_94/author-workspace/output'",
    "output = root / 'ENGINEERING626_88/author-workspace/output'")
exec(compile(reader, str(original), 'exec'))

import numpy as np
from skimage.color import rgb2gray
import openhcs
from openhcs.core.runtime_image_values import image_payload_data, image_payload_metadata
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.runtime.zmq_execution_observation import ZMQRuntimeExecutionObservationExport
assert Path(openhcs.__file__).is_relative_to(target)
artifact_root = Path('/run/media/ts/hdd/openhcs-engineering/engineering620-public88-20261004')
plate = artifact_root / 'results/acquisition_openhcs'
inventory, = [item['payloads'][0] for item in replies if item['tool'] == 'openhcs_query_plate_files']
assert inventory['errors'] == [] and inventory['total_count'] == inventory['returned_count'] == 4
assert inventory['truncated_count'] == 0
assert len({item['key'] for item in inventory['records']}) == 4
assert all(item['kind'] == 'image' for item in inventory['records'])

scalar = np.arange(180, dtype=np.uint8).reshape(12, 15)
rgb = np.stack((scalar, np.full_like(scalar, 32), np.full_like(scalar, 240)), axis=-1)
gray_expected = scalar.astype(np.float32) / 255
color_expected = rgb2gray(rgb.astype(np.float32) / 255)
expected = {'GrayIndependent': gray_expected, 'ColorIndependent': color_expected,
            'Forward': (gray_expected + color_expected) / 2,
            'Reverse': (gray_expected + color_expected) / 2}
samples = [item['payloads'][0] for item in replies if item['tool'] == 'openhcs_sample_plate_image']
assert len(samples) == 4
export = ZMQRuntimeExecutionObservationExport.read(artifact_root / 'values01')
observation = export.require_valid_observation()
records = [record for group in observation.records_by_axis.values() for record in group]
validated = []
for name, pixels in expected.items():
    sample, = [sample for sample in samples if sample['requested_image_path'].endswith('_' + name + '.tif')]
    assert sample['errors'] == [] and sample['sample_included']
    assert sample['plate_path'] == str(plate)
    assert sample['sample_shape'] == [12, 15] and sample['selected_resolution_index'] == 0
    np.testing.assert_array_equal(np.asarray(sample['sample_values'], dtype=np.float32), pixels)
    assert sample['source_metadata']['OpenHCSSourceVoxelSpacingZYX'] == '0.5,0.5'
    assert sample['source_metadata']['OpenHCSSourceVoxelSpacingUnit'] == 'micrometers'
    channel = 2 if name in ('ColorIndependent', 'Reverse') else 1
    assert sample['source_metadata']['channel'] == channel
    record, = [record for record in records if record.key.name == name]
    np.testing.assert_array_equal(np.asarray(image_payload_data(record.data)).squeeze(), pixels)
    metadata = image_payload_metadata(record.data)
    assert metadata.source_voxel_spacing == SourceVoxelSpacing((0.5, 0.5))
    assert metadata.source_image_names == (name,)
    assert str(metadata.source_component_metadata['channel']) == str(channel)
    validated.append({'name': name, 'elements': pixels.size, 'maximum_absolute_error': 0})

inputs = json.loads((engineering.parent / 'engineering599/public-packet01/INPUTS.json').read_text())
for item in inputs:
    image = artifact_root / 'acquisition' / Path(item['path']).name
    assert hashlib.sha256(image.read_bytes()).hexdigest() == item['sha256']
print(json.dumps({'status': 'PASS', 'source_head': '1496b071902841855a521ea3280ade8b2433d47b',
    'imported': str(openhcs.__file__), 'execution_id': export.execution_id,
    'public_samples': validated, 'inventory_count': 4,
    'canonical_observation_valid': True, 'total_public_elements': 720,
    'transcript_sha256': hashlib.sha256(transcript.read_bytes()).hexdigest()}, indent=2))
