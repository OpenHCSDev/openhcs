626 engineering lease candidate
===============================

Singer alone owns the recorded client/native journey. This declaration adds ENGINEERING626_88 through the original627 additional_authors route and replaces or retires no other member. It grants no scientific/provider author: brief is null. Native6020/ACK7020, viewer0/ACK0; existing display88 and its unchanged healthy X/WM/VNC identities are reused. No helper/native/client was started by preparation.

The positive predecessor terminal and separate closed-journal seal are retained at next-r0010-fourth88-after612-20261004/OWNER-R001088-TERMINAL.rst and OWNER-R001088-CLOSED-JOURNALS.sha256. Fresh helper readbacks match the three handoff identities; native6020/21/7020/21 have no listeners.

Original qualified BYTE-QUALIFICATION.json in engineering620/receiving02 is the projector qualification input: source1496b071902841855a521ea3280ade8b2433d47b, whole installed target and wheel fcb8e2c8911211f3b1f090b8d9d38367269173274169680bb785ffb26073ce33. Published3a87c664b is the later docs/receipt checkpoint, not a relabel of installed production bytes.

Declared artifact destination is /run/media/ts/hdd/openhcs-engineering/engineering620-public88-20261004. Singer prepares a distinct pipeline source that uses this actual destination while preserving public01 unchanged. Normal read roots include public01 and the installed knowledge; HOME private control/source and declared HDD artifacts are normal write roots.

Parent completed science publication at FUND ef1e9847e56fc47c86c3a17bc6fe4cbdd9f17020790d69d55c32d9b283669bc8 and returned publisher custody. Actual membership contains exactly the three new scientists; the original science declaration already retired R0010_FRESHMAIN0B_88 using its positive terminal receipt and retained its output once. Redundant retirement would be rejected by the original projector. This engineering proposal adds only ENGINEERING626_88, preserving all three science run owners unchanged.

The normal declared read root is engineering620, the common ancestor of the synthetic public01 inputs, distinct public88 pipeline and qualified receiving02 target. It contains this engineering packet, not scientific data or reference answers. This admits the existing complete source without a symlink bypass, duplicated source file or extra path-authority mechanism.
