626 original public88 custody02
==============================

Known pre-client startup01 recorder25926 terminal77 and original PSI denial
remain in STARTUP01-KNOWN-PRECLIENT.rst/resources-singer626_public88_start01.*.
Dewey explicitly released fresh startup02 with unchanged original admission;
full avg10=0.00/avg60=0.00/avg300=.04 and admission PASS are recorded.

Singer owns the ONE original recorded client PTY93391, MCP1370964,
engineering626-public88-20261004-engineering626_88-mcp.scope invocation
0865b0383c9146a98ce152fc8ef23379. Health confirms exact receiving02/target
server.py, errors[], packaged resources ready. The recorder journals are
ENGINEERING626_88/author-workspace/output/runtime/mcp.{stdin,stdout,timing}.

Exactly one openhcs_start_owned_runtime returned original native1377287,
create1791125937.95, TCP127.0.0.1:6020/ACK7020. Original typed handle and every
progress reply are preserved in mcp.stdout; startup stem
openhcs_zmq_server_port_6020_1791125938736382739. Native is currently preparing
capabilities through its original owner; no viewer is enabled or started.
config-1 is the actual returned global config. No source session, compile or
execution has yet been submitted at this custody checkpoint.

Keep this client and native owned until exact typed close/process exit and
client terminal; no second client, launch, scientific input or uncertain replay.
