626 distinct88 source and declared artifact destinations
=======================================================

Complete source:
  /home/ts/wt/openhcs-issue-batch-20260929/engineering620/public88/pipeline.py
Original source CPPipe and input plate, unchanged/read-only:
  /home/ts/wt/openhcs-issue-batch-20260929/engineering620/public01/intensity620.cppipe
  /home/ts/wt/openhcs-issue-batch-20260929/engineering620/public01/acquisition
Actual working acquisition for the original compiler's metadata writes:
  /run/media/ts/hdd/openhcs-engineering/engineering620-public88-20261004/acquisition
The two TIFFs are copied byte-exact from public01, with original hashes
60d8f467d3628e7f5505b92990f2f2a5dd57a233907127455aa8815ed5e47151 and
83813fb6553d3aeb31ffecd16b0dac3a2ff2897477680913cb15aa232a227c0a.
The first readonly public01 artifact-plan refusal is retained in mcp.stdout:
agent_path_policy_rejected before inspection, because source preparation needs
a writable plate for its native metadata. This is a known harness path failure,
not626 product failure or an UNKNOWN execution. No permission/guard is changed;
the distinct working plate is inside the original declared writable HDD root.
Qualified immutable whole candidate:
  /home/ts/wt/openhcs-issue-batch-20260929/engineering620/receiving02/target
Source1496b0719; published3a87c664b is receiving docs-only, not a new target.

Original627 placement owner's provisioned HDD artifact root:
  /run/media/ts/hdd/openhcs-engineering/engineering620-public88-20261004
The complete pipeline declares global_output_folder at that root/results.
Canonical runtime_observation_export_path for the single execution:
  /run/media/ts/hdd/openhcs-engineering/engineering620-public88-20261004/values01
Use the actual returned public output plate/image routes for inventory/sampling;
do not substitute a physical artifact path for the declared inventory image.

All remaining config, source bindings, calibration, CPPipe and source input
bytes are unchanged from public01. Default automatic persistence remains
enabled; no private writer, artifacts-only bypass, new algorithm or timeout.
Source/comment/output destination differ only for this recorded new receiving
phase. public01 remains unchanged, including its original pipeline source.

Dewey owns the original627 lease projection after parent's sole3SCI publication;
Singer owns the subsequent sole recorded client/native. No program/FUND update,
client, native process or viewer is dispatched by this source checkpoint.
