"""Stream the original audit AST owners for the #501/#502 source family.

Static orchestration only: no product imports, detectors copied, or algorithms
executed. Release every parsed module instead of retaining the whole package.
"""

import ast
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/home/ts/code/projects/nominal-refactor-advisor/skills/refactor-audit/scripts")
from audit.findings import FunctionFacts, ParsedModule
from audit.repository import Repository

repo = Repository(Path.cwd())
revision = repo.git("rev-parse", "HEAD").strip()
root_revision = "22e7acfa6e653649a89fd773d1c5159676bb1f4f"
symbols = frozenset((
    "ObjectFeatureValueTable", "ObjectFeatureArrayDomain", "ObjectLabelDomain",
    "ShapeObjectFeatureValueTable", "ShapeObjectMeasurementRows",
    "ObjectSizeShapeFeatureMeasurement", "DenseObjectSizeShapeMeasurement",
    "SparseIJVObjectSizeShapeMeasurement", "measure_object_size_shape",
    "RuntimeMeasurementFeature", "MeasurementObjectRowIdentity",
    "CellProfilerObjectMeasurementRowPolicy", "ObjectLabelMeasurementSliceRequest",
    "MeasurementSubject", "filter_objects", "FilterObjectsModule",
    "CellProfilerModuleCallableABI", "RuntimeReturnedOutputMatcher",
    "runtime_output_tuple", "validate_callable_artifact_abi",
    "count_cells_single_channel", "normalize_runtime_identifier",
))
paths = repo.python_files(revision, "openhcs")
selected = 0
failures = []
for path in paths:
    source = repo.source(revision, path)
    try:
        module = ParsedModule(path, source, ast.parse(source, path), path[:-3].replace("/", "."))
    except SyntaxError as error:
        failures.append((path, str(error)))
        continue
    references = [
        (node.lineno, ast.unparse(node), type(node.ctx).__name__)
        for node in ast.walk(module.tree)
        if (isinstance(node, ast.Name) and node.id in symbols)
        or (isinstance(node, ast.Attribute) and node.attr in symbols)
    ]
    if not references:
        continue
    selected += 1
    declarations = []
    for node in ast.walk(module.tree):
        if isinstance(node, ast.ClassDef):
            declarations.append({"line": node.lineno, "class": node.name,
                                 "bases": [ast.unparse(base) for base in node.bases]})
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            facts = FunctionFacts(node.name, node.end_lineno - node.lineno + 1)
            facts.visit(node)
            declarations.append({"line": node.lineno, "function": node.name,
                                 "args": ast.unparse(node.args),
                                 "return": ast.unparse(node.returns) if node.returns else None,
                                 "decorators": [ast.unparse(item) for item in node.decorator_list],
                                 "dispatch": {key: sorted(value) for key, value in facts.dispatch.items()},
                                 "type_checks": facts.type_checks,
                                 "constructed": sorted(facts.constructed)})
    imports = [ast.unparse(node) for node in ast.walk(module.tree)
               if isinstance(node, (ast.Import, ast.ImportFrom))]
    root_source = repo.source(root_revision, path)
    print(json.dumps({"path": path, "sha256": hashlib.sha256(source.encode()).hexdigest(),
                      "root_equal": source == root_source, "references": references,
                      "imports": imports, "declarations": declarations}), flush=True)

dependency_root = Path("/home/ts/wt/basicpy-live-candidate-20260930/.venv/lib/python3.12/site-packages/metaclass_registry")
dependency_paths = sorted(dependency_root.rglob("*.py"))
for path in dependency_paths:
    source = path.read_text()
    try:
        module = ParsedModule(str(path), source, ast.parse(source, str(path)), path.stem)
    except SyntaxError as error:
        failures.append((str(path), str(error)))
        continue
    print(json.dumps({"dependency": str(path), "sha256": hashlib.sha256(source.encode()).hexdigest(),
                      "ast": ast.dump(module.tree, include_attributes=True)}), flush=True)
print(json.dumps({"revision": revision, "root_revision": root_revision,
                  "parsed_production": len(paths) - len(failures), "selected_family": selected,
                  "dependency_root": str(dependency_root), "dependency_files": len(dependency_paths),
                  "parse_failures": failures,
                  "limits": "static AST and original audit facts, not execution or global NRA detector proof"}), flush=True)
raise SystemExit(bool(failures))
