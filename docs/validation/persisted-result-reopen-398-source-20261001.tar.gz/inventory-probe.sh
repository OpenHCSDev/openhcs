systemd-run --user --scope -p MemoryMax=512M -p MemorySwapMax=0 -p CPUQuota=100% /usr/bin/time -v timeout 60s taskset -c 0 env PYTHONDONTWRITEBYTECODE=1 OPENHCS_CPU_ONLY=true OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 XDG_CACHE_HOME=/home/ts/.cache/agent-scratch/persisted-result-reopen-20261001/cache PYTHONPATH=/home/ts/wt/openhcs-knowledge-lazy-conversion-20261001:/home/ts/wt/pyqt-reactive-render-complete-snapshot-20261001/src /home/ts/wt/openhcs-generated-inputs-installed-parent-20261001/.venv/bin/python - <<'PY' > /home/ts/.cache/agent-scratch/persisted-result-reopen-20261001/original-public-auto-inventory.log 2>&1
import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch
import openhcs
installed = Path("/home/ts/wt/openhcs-generated-inputs-installed-parent-20261001/.venv/lib/python3.12/site-packages/openhcs")
for name, relative in (
    ("openhcs.core._tabular_native", "core/_tabular_native.abi3.so"),
    ("openhcs.processing.backends.cellprofiler._granularity_native", "processing/backends/cellprofiler/_granularity_native.abi3.so"),
):
    spec = importlib.util.spec_from_file_location(name, installed / relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
from openhcs.agent.services.plate_inspection_service import PlateInspectionService
from openhcs.agent.path_policy import AgentPathPolicy
from openhcs.agent.dto.plate import PlateFileQueryRequest
from openhcs.serialization.json import to_jsonable
root = Path("/home/ts/wt/openhcs-issue-batch-20260929/neurite-development-skill383-20261001/output/assisted-2-candidate-1b/input_openhcs")
service = PlateInspectionService(path_policy=AgentPathPolicy.with_roots(readable_roots=(root,), writable_roots=()))
with patch.object(subprocess, "Popen", side_effect=AssertionError("Source-only route check cannot launch processes")):
    request = PlateFileQueryRequest.from_fields(plate_path=str(root), kind="image", limit=20, include_previews=False)
    print(json.dumps(to_jsonable(service.query_files(request)), indent=2))
PY
