"""Main-only receiver checkpoint; Root-dependent controls remain frozen."""
from pathlib import Path

root = Path(__file__).parent
program = (root / 'source-control09.py').read_text()
program = program.replace('source09', 'source12')
program = program.replace('source-control09-scratch', 'source-control12-scratch')
program = program.replace(
    "exec(compile(original, str(root / 'source-control08.py'), 'exec'))",
    '''original = original.replace('test_live_fractional_z_point_source.py',
                                'test_point_roi_receiver_domain.py')
original = original.replace(
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_source_provenance_nested_identity.py",\\n', '')
original = original.replace(
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_graph_roi_source_roundtrip_134.py",\\n', '')
exec(compile(original, str(root / 'source-control08.py'), 'exec'))''',
)
exec(compile(program, str(root / 'source-control09.py'), 'exec'))
