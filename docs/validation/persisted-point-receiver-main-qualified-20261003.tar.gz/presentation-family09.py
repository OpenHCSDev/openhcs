"""Extend the original refactor-audit AST inventory, not another scanner."""
from pathlib import Path

original = Path(__file__).parents[1].joinpath('live-points-152-ast.py').read_text()
original = original.replace("owners = ('ROIFractionalZ'", "owners = ('NapariAxisPresentation', 'SourceVoxelSpacing', 'SourceVoxelSpacingUnit', 'ViewerComponentValueDomain', 'ViewerLayerAxisProjectionStep', 'StreamingService', 'NapariShapeFeatureColumns', 'ShapePayload', 'StreamImagePayloadMetadataProjector', 'SourceMetadataFields', 'FileRoiSidecarArtifactSourceProjection', 'NapariViewerProjectionABC', 'ROIFractionalZ'")
original = original.replace("methods = ('source_component_domain'", "methods = ('translate', 'viewer_step', 'label_index', 'spatial_layer_kwargs', 'spacing_for_ndim', 'coordinate_values', 'observed', 'declare', 'geometry', 'decode', 'feature_metadata', 'item_fields', 'to_viewer_image_metadata', 'from_viewer_image_metadata', 'source_component_domain'")
exec(compile(original, str(__file__), 'exec'))
