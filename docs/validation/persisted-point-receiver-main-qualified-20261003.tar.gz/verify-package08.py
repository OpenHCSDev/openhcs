"""Current test-consumer checkpoint has identical complete packaged inputs."""
from pathlib import Path

root = Path(__file__).parent
original = root / 'verify-package06.py'
program = original.read_text().replace(
    'b26334ace99512970c81809b29d5ad19c7e07c4c',
    '24927b864e3c7bc7e413f9929fbf917a5973ea5e',
)
exec(compile(program, str(original), 'exec'))
