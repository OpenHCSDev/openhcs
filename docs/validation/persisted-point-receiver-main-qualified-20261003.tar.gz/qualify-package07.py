"""Whole combined wheel and original qualified dependencies; no native start."""
from pathlib import Path

root = Path(__file__).parent
original = root / 'qualify-package03.py'
program = original.read_text().replace('target03', 'target04').replace('target02', 'target03')
program = program.replace('wheels02', 'wheels03')
program = program.replace(
    "expected_sha = 'aa1978db7b785e656668c68cf0ad5efd7a5f1cfe52231a519e851b649eb46007'",
    'expected_sha = hashlib.sha256(wheel.read_bytes()).hexdigest()',
).replace(
    "records = [(wheel, ('openhcs/', 'benchmark/'), prior)]",
    "records = [(wheel, ('openhcs/', 'benchmark/'), None)]",
).replace(
    'if name.startswith(prefixes):',
    'if name.startswith(prefixes):',
).replace(
    '                assert (target / name).read_bytes() == (qualified_target / name).read_bytes(), name',
    '                if qualified_target is not None:\n                    assert (target / name).read_bytes() == (qualified_target / name).read_bytes(), name',
)
program = program.replace(
    'assert actual_paths == recorded_paths, sorted(str(p) for p in actual_paths ^ recorded_paths)',
    '''entry_names = {ep.name for info in target.glob('*.dist-info')
               for ep in Distribution.at(info).entry_points
               if ep.group in ('console_scripts', 'gui_scripts')}
generated_scripts = {target / 'bin' / name for name in entry_names}
assert {p for p in (target / 'bin').iterdir()} == generated_scripts
for path in generated_scripts:
    assert path.read_bytes() == (prior / 'bin' / path.name).read_bytes(), str(path)
assert actual_paths == recorded_paths | generated_scripts, sorted(str(p) for p in actual_paths ^ (recorded_paths | generated_scripts))''',
).replace(
    "'actual_target_files': len(actual_paths), 'unaccounted_files': [],",
    "'actual_target_files': len(actual_paths), 'unaccounted_files': [], 'declared_console_and_gui_scripts_equal_original_target': sorted(entry_names),",
).replace(
    'bd6d8af79eba77f936c0a0c8fc4fc26e92f67eae',
    'b26334ace99512970c81809b29d5ad19c7e07c4c',
).replace(
    "str(root / 'QUALIFICATION02.rst')", "str(root / 'package06.log')",
).replace(
    "str(root / 'package02.log')", "str(root / 'package06.log')",
).replace(
    "str(root / 'installed-control02.log')", "str(root / 'source-control12.log')",
).replace(
    "'pipeline_document': str(root / 'POINTS494_95/author-workspace/output/pipeline-public95.py'),",
    "'public_case': 'NEW standalone unchanged989B archive reopen; no original failed producer replay',",
).replace(
    "'source_packet': str(root / 'POINTS494_95/author-workspace/output/SOURCE-PACKET.rst'),",
    "'source_packet': str(root / 'COMBINED-MAIN13-SOURCE-PACKET.rst'),",
).replace(
    "'package_and_dependency_admission': True,",
    """'package_and_dependency_admission': True,
    'dependency_declared_floors': 'main objectstate>=1.1.8,<2; python-introspect>=0.1.14,<0.2',
    'root_stack_imported': False,
    'source_components': {'main':'f7de9efad393bce83a3756a271f0cd4383783ea9',
                          'receiver524':'a354bfa48857df8b8f21198cc78b1b6965495361',
                          'catalog511':'b1d0b6c3e52842604a83bd3fda85c415e7fa8c5d',
                          'retirement522':'b2fa845721ca84acee978d2d3ab65ab4f0541b6b'},
    'bounded_scope': {name: (Path('/sys/fs/cgroup') / Path('/proc/self/cgroup').read_text().strip().split('::', 1)[1].lstrip('/') / name).read_text().strip()
                      for name in ('memory.max', 'memory.peak', 'memory.swap.max', 'memory.events', 'cpu.max')},""",
)
exec(compile(program, str(original), 'exec'))
