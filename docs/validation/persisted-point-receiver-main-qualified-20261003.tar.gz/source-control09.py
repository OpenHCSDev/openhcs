"""Reuse the original bounded source-control runner after coherent repair."""
from pathlib import Path

root = Path(__file__).parent
original = (root / 'source-control08.py').read_text()
original = original.replace('root / "source08"', 'root / "source09"')
original = original.replace('source-control08-scratch', 'source-control09-scratch')
original = original.replace(
    '    "-q",',
    '''    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_roi_source_metadata.py",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_graph_roi_source_roundtrip_134.py",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_streaming_service.py::test_reopen_native_roi_archives_preserves_per_file_source_and_calibration",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_streaming_service.py::test_3d_point_archive_reopens_with_native_z_domain_and_features",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_streaming_service.py::test_explicit_native_reopening_rejects_an_external_roi_without_source",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_spatial_presentation_owns_scale_and_world_translation",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_calibrated_native_image_point_and_semantic_navigation_agree_without_qt",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_shape_features_exclude_source_transport_without_mutating_payload",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_points_layer_uses_exact_fractional_z_from_native_roi_metadata",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_fractional_z_points_are_relative_to_the_declared_anchor",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_points_layer_rejects_fractional_z_without_z_axis",
    "-o", "addopts=", "-q",''',
)
exec(compile(original, str(root / 'source-control08.py'), 'exec'))
