"""Correct count labels without modifying the original qualifier's program."""
from pathlib import Path

root = Path(__file__).parent
original = root / 'qualify-package07.py'
program = original.read_text().replace(
    'wheel_payloads_equal_to_original_qualified_targets', 'wheel_target_payload_counts'
).replace(
    "str(root / 'source-control12.log')", "str(root / 'installed-control16.log')"
)
exec(compile(program, str(original), 'exec'))
