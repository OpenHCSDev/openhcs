"""Final exact receipt labels; earlier qualification observations preserved."""
from pathlib import Path

root = Path(__file__).parent
original = root / 'qualify-package07.py'
program = original.read_text().replace(
    'wheel_payloads_equal_to_original_qualified_targets', 'wheel_target_payload_counts'
).replace(
    "str(root / 'source-control12.log')", "str(root / 'installed-control16.log')"
).replace(
    "str(prior / 'openhcs/processing/backends/lib_registry/registry_service.py')",
    "str(target / 'openhcs/processing/backends/lib_registry/registry_service.py')",
).replace(
    "'source_packet': str(root / 'COMBINED-MAIN13-SOURCE-PACKET.rst'),",
    """'source_packet': str(root / 'COMBINED-MAIN13-SOURCE-PACKET.rst'),
    'reviewed_source_head': '24927b864e3c7bc7e413f9929fbf917a5973ea5e',
    'reviewed_receiver_head': 'b8925caa544b6d47323fca7cb95653b159bb52dc',
    'reviewed_complete_packaged_input_equality_log': str(root / 'package08.log'),
    'no_rebuild_after_test_only_consumer_closure': True,""",
)
exec(compile(program, str(original), 'exec'))
