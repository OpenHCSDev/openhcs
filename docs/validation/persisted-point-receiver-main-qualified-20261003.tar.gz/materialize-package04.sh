#!/usr/bin/env bash
# A distinct ordinary private wheel projection; no runtime/bootstrap or build.
set -euo pipefail
package_root=/home/ts/wt/openhcs-issue-batch-20260929/engineering494
qualified_wheels=/home/ts/wt/openhcs-issue-batch-20260929/next-h004-preparation-20261002/official30-package-implementation-20261003/scratch/catalog511-package01/wheels
paired_python=/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python
test ! -e "$package_root/target04"
export PYTHONDONTWRITEBYTECODE=1 PIP_NO_CACHE_DIR=1 PIP_DISABLE_PIP_VERSION_CHECK=1
"$paired_python" -B -m pip install --no-deps --no-index --no-compile \
  --target "$package_root/target04" \
  "$package_root/wheels03/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl" \
  "$qualified_wheels/objectstate-1.1.8-py3-none-any.whl" \
  "$qualified_wheels/python_introspect-0.1.14-py3-none-any.whl"
scope_path=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
for resource_file in memory.max memory.peak memory.swap.max memory.swap.peak memory.events cpu.max; do
  printf '%s: ' "$resource_file"
  tr '\n' ' ' < "/sys/fs/cgroup$scope_path/$resource_file"
  printf '\n'
done
