"""Same receiver regression family through ordinary combined installed bytes."""
from pathlib import Path

root = Path(__file__).parent
program = (root / 'source-control12.py').read_text().replace('source12', 'target04')
program = program.replace('source-control12-scratch', 'installed-control13-scratch')
exec(compile(program, str(root / 'source-control12.py'), 'exec'))
