#!/usr/bin/env bash
set -euo pipefail
source_root=/home/ts/wt/openhcs-basicpy-readiness-20260929
package_root=/home/ts/wt/openhcs-issue-batch-20260929/engineering494
paired_python=/home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python
test "$(git -C "$source_root" rev-parse HEAD)" = b26334ace99512970c81809b29d5ad19c7e07c4c
test -z "$(git -C "$source_root" diff --name-only HEAD -- openhcs benchmark packaging setup.py pyproject.toml scripts)"
cd "$source_root"
"$paired_python" -B -m build --wheel --no-isolation --outdir "$package_root/wheels03"
scope_path=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
for resource_file in memory.max memory.peak memory.swap.max memory.swap.peak memory.events cpu.max; do
    printf '%s: ' "$resource_file"
    tr '\n' ' ' < "/sys/fs/cgroup$scope_path/$resource_file"
    printf '\n'
done
