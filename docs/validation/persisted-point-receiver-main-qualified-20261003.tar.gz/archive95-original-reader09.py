"""Read only the original tiny public fixture with the installed ROI owners."""
from hashlib import sha256
import json
from pathlib import Path

from polystore.roi import load_rois_from_zip
from openhcs.core.roi_source_metadata import ROIArchiveSourceMetadata
from openhcs.core.roi_point_metadata import ROIFractionalZ
from openhcs.core.steps.stream_component_semantics import StreamImagePayloadMetadataProjector
from openhcs.serialization.json import to_jsonable

path = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering494/POINTS494_95/author-workspace/output/results01/input_openhcs/results/A01_site-1_channel-1_timepoint-1_fixture_centres_494_step0_points.roi.zip')
rois = load_rois_from_zip(path)
metadata = ROIArchiveSourceMetadata.decode(rois)
assert metadata is not None
domain = ROIFractionalZ.source_component_domain(rois, metadata)
assert domain is not None
geometry = ROIArchiveSourceMetadata.geometry(rois)
fields = StreamImagePayloadMetadataProjector.item_fields(metadata, tuple(key.value for key in __import__('openhcs.constants.constants', fromlist=['AllComponents']).AllComponents))
print(json.dumps(dict(
    archive=str(path), archive_size=path.stat().st_size,
    archive_sha256=sha256(path.read_bytes()).hexdigest(), roi_count=len(rois),
    roi_metadata=[roi.metadata for roi in rois],
    decoded_metadata=to_jsonable(metadata),
    fractional_z=[ROIFractionalZ.decode(roi.metadata).value for roi in rois],
    guarded_source_domain=to_jsonable(domain),
    geometry_metadata=[roi.metadata for roi in geometry],
    viewer_item_fields=fields,
    archive_source_present=all(ROIArchiveSourceMetadata.FIELD in roi.metadata for roi in rois),
    geometry_source_present=any(ROIArchiveSourceMetadata.FIELD in roi.metadata for roi in geometry),
    scope='Original installed ROI reader/decode/guard/projector only. No native, viewer, compilation, science or fixture mutation.'
), indent=2))
