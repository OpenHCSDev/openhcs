"""Small receiving observation of existing qualified wheels; no catalog start."""
import ast
import base64
from dataclasses import dataclass
import hashlib
import importlib
from importlib.metadata import Distribution
import inspect
import json
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
target = root / 'target03'
prior = root / 'target02'
copernicus = root.parent / 'next-h004-preparation-20261002/official30-package-implementation-20261003'
dependency_proof = copernicus / 'catalog511-bytes01.json'
assert hashlib.sha256(dependency_proof.read_bytes()).hexdigest() == 'cff18e17117256148e0ac77cf8cf548ca50ca461cec34e27ccd7fee822b8465d'
qualified = json.loads(dependency_proof.read_text())
assert qualified['status'] == 'PASS'
dependency_target = Path(qualified['target'])
wheel = root / 'wheels02/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl'
expected_sha = 'aa1978db7b785e656668c68cf0ad5efd7a5f1cfe52231a519e851b649eb46007'
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == expected_sha
records = [(wheel, ('openhcs/', 'benchmark/'), prior)]
for receipt in qualified['dependency_receipts']:
    dependency_wheel = Path(receipt['wheel'])
    assert hashlib.sha256(dependency_wheel.read_bytes()).hexdigest() == receipt['wheel_sha256']
    prefix = receipt['api_source'].split('/')[0] + '/'
    records.append((dependency_wheel, (prefix,), dependency_target))

payload_counts = {}
for archive_path, prefixes, qualified_target in records:
    count = 0
    with ZipFile(archive_path) as archive:
        for name in archive.namelist():
            if name.endswith('/') or name.endswith('.dist-info/RECORD'):
                continue
            assert (target / name).read_bytes() == archive.read(name), name
            if name.startswith(prefixes):
                assert (target / name).read_bytes() == (qualified_target / name).read_bytes(), name
                count += 1
    payload_counts[archive_path.name] = count

# Use each installed distribution's original RECORD/PackagePath hash owner.
installed_records = {}
recorded_paths = set()
for info in target.glob('*.dist-info'):
    distribution = Distribution.at(info)
    files = distribution.files
    assert files is not None
    for member in files:
        path = Path(member.locate()).resolve()
        assert path.is_relative_to(target), str(path)
        data = path.read_bytes()
        if member.size is not None:
            assert len(data) == member.size, str(member)
        if member.hash is not None:
            digest = hashlib.new(member.hash.mode, data).digest()
            assert base64.urlsafe_b64encode(digest).rstrip(b'=').decode() == member.hash.value, str(member)
        recorded_paths.add(path)
    installed_records[info.name] = len(files)
actual_paths = {p.resolve() for p in target.rglob('*') if p.is_file()}
assert actual_paths == recorded_paths, sorted(str(p) for p in actual_paths ^ recorded_paths)
assert len(installed_records) == 3

module_origins = {}
for name in ('openhcs', 'objectstate', 'objectstate.lazy_factory',
             'python_introspect', 'python_introspect.signature_analyzer'):
    module = importlib.import_module(name)
    path = Path(module.__file__).resolve()
    assert path.is_relative_to(target), (name, str(path))
    module_origins[name] = str(path)
from objectstate import LazyDataclassFactory
from python_introspect import SignatureAnalyzer
assert callable(LazyDataclassFactory.registered_type_pairs)
assert isinstance(LazyDataclassFactory.registered_type_pairs(), tuple)

@dataclass
class ReadinessDeclaration494:
    """Own tiny source-bearing readiness check, not a processing function."""
    value: int = 1

SignatureAnalyzer.prepare_dataclass_declaration(ReadinessDeclaration494)
for receipt in qualified['dependency_receipts']:
    assert hashlib.sha256((target / receipt['api_source']).read_bytes()).hexdigest() == receipt['api_source_sha256']

backing = Path('/home/ts/wt/basicpy-live-candidate-20260930/.venv/lib/python3.12/site-packages')
original_api_absence = {}
for receipt in qualified['dependency_receipts']:
    source = backing / receipt['api_source']
    tree = ast.parse(source.read_bytes())
    owner, = (n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == receipt['api_owner'])
    missing = receipt['api_method'] not in {n.name for n in owner.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    assert missing
    original_api_absence[receipt['api_owner']] = {'source': str(source), 'missing': receipt['api_method']}

print(json.dumps({
    'status': 'PASS',
    'target': str(target),
    'source_head': 'bd6d8af79eba77f936c0a0c8fc4fc26e92f67eae',
    'wheel': str(wheel), 'wheel_sha256': expected_sha,
    'original_target': str(prior),
    'original_whole_source_qualification': str(root / 'QUALIFICATION02.rst'),
    'original_whole_source_log': str(root / 'package02.log'),
    'original_source_installed_controls': str(root / 'installed-control02.log'),
    'dependency_receiving_proof': str(dependency_proof),
    'dependency_receipts': qualified['dependency_receipts'],
    'wheel_payloads_equal_to_original_qualified_targets': payload_counts,
    'installed_records': installed_records,
    'actual_target_files': len(actual_paths), 'unaccounted_files': [],
    'module_origins': module_origins,
    'dependency_api_calls': ['LazyDataclassFactory.registered_type_pairs()',
                             'SignatureAnalyzer.prepare_dataclass_declaration(ReadinessDeclaration494)'],
    'original_shared_api_absence': original_api_absence,
    'required_by_installed_registry': str(prior / 'openhcs/processing/backends/lib_registry/registry_service.py'),
    'package_and_dependency_admission': True,
    'catalog_native_viewer_launched': False,
    'public_live_acceptance': 'NOT RUN; parent-only released engineering slot',
    'case_root': str(root / 'POINTS494_95/author-workspace/output'),
    'pipeline_document': str(root / 'POINTS494_95/author-workspace/output/pipeline-public95.py'),
    'source_packet': str(root / 'POINTS494_95/author-workspace/output/SOURCE-PACKET.rst'),
}, sort_keys=True, indent=2))
