"""Reuse the original wheel verifier and current declaration-owned asset closure."""
from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import zipfile

root = Path(__file__).parent
source = Path('/home/ts/wt/openhcs-basicpy-readiness-20260929')
expected = '39244bab1d47d5af3c87ff96f70014ff091c67ee'
original_path = root.parent / 'carrier434-installed-20261002/engineering463-installed/verify_wheel.py'
original = original_path.read_text()
adapted = original.replace(
    "source = Path('/home/ts/wt/openhcs-basicpy-parent-integration-20260930')",
    f"source = Path({str(source)!r})",
).replace('47e39ebd4c954d1088b9bf6b5e5419b79646c63e', expected)
adapted = adapted.replace(
    "assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True).strip()",
    "assert not subprocess.check_output(['git', 'diff', '--name-only', 'HEAD', '--', 'openhcs', 'benchmark', 'packaging', 'setup.py', 'pyproject.toml', 'scripts'], cwd=source, text=True).strip()",
).replace("root / 'wheels'", "root / 'wheels01'").replace("root / 'target'", "root / 'target01'")
adapted = adapted.replace("name.startswith('openhcs/')", "name.startswith(('openhcs/', 'benchmark/'))")
adapted = adapted.replace('source_clean=True', 'source_payload_clean=True')
exec(compile(adapted, str(original_path), 'exec'))

helpers = runpy.run_path(str(source / 'scripts/build_mcp_knowledge_assets.py'))
projections = helpers['knowledge_source_projections'](
    source / helpers['KNOWLEDGE_MANIFEST_RELATIVE_PATH'], source_root=source,
)
bundle = helpers['AgentSkillBundle'].from_manifest(source / helpers['AGENT_PLUGIN_MANIFEST_PATH'])
projections.update({path.relative_to(source): path for path in bundle.source_paths()})
wheel, = (root / 'wheels01').glob('*.whl')
asset_records = []
with zipfile.ZipFile(wheel) as archive:
    for relative, path in projections.items():
        name = (helpers['PACKAGED_KNOWLEDGE_ROOT_RELATIVE_PATH'] / relative).as_posix()
        data = path.read_bytes()
        assert data == archive.read(name) == (root / 'target01' / name).read_bytes(), name
        asset_records.append(dict(source=str(relative), packaged=name, sha256=hashlib.sha256(data).hexdigest()))
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=source).decode().split('\0')
    native_sources = tuple(name for name in tracked if name.startswith('openhcs/') and name.endswith('.cpp'))
    for name in native_sources:
        assert (source / name).read_bytes() == archive.read(name) == (root / 'target01' / name).read_bytes(), name
    native_binaries = tuple(name for name in archive.namelist() if name.startswith('openhcs/') and name.endswith('.so'))
    assert len(native_binaries) == 2, native_binaries
    for name in native_binaries:
        assert archive.read(name) == (root / 'target01' / name).read_bytes(), name
skill_root, = bundle.skill_roots()
skill_members = tuple(path for path in bundle.source_paths() if path.is_relative_to(skill_root))
print(json.dumps(dict(
    all_declared_knowledge_and_skill_members=len(projections),
    plugin_bundle_members=len(tuple(bundle.source_paths())), full_skill_members=len(skill_members),
    native_sources=native_sources, native_binaries=native_binaries,
    source_wheel_target_equal=True, asset_records=asset_records,
), sort_keys=True))
