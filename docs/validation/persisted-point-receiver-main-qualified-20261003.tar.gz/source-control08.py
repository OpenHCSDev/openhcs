"""New Root-integrated source observation; previous failed controls stay frozen."""
import json
from pathlib import Path
import sys

import pytest
from openhcs.core import roi_point_metadata, source_metadata, source_image_provenance
from openhcs.core.roi_point_metadata import ROIFractionalZ
from openhcs.core.runtime_image_values import ImagePayloadMetadata
from openhcs.core.source_image_provenance import SourceImageProvenancePlanes
from polystore.roi import ROI, PointShape

root = Path(__file__).parent
source = (root / "source08").resolve()
for module in (roi_point_metadata, source_metadata, source_image_provenance):
    assert Path(module.__file__).resolve().is_relative_to(source)
    print("Actual owner source:", module.__file__, flush=True)

facts = json.loads((root / "PUBLIC-PLANE-FACTS03.json").read_text())
files = facts["source_workspace"]["files"]
planes = SourceImageProvenancePlanes.from_components(
    paths=tuple(record["source_path"] for record in files),
    component_metadata=tuple(record["source_metadata"] for record in files),
)
metadata = ImagePayloadMetadata(source_image_provenance_planes=planes)
rois = [ROIFractionalZ(1.5).bind(ROI(shapes=[PointShape(y=1.5, x=2.5)]))]
domain = ROIFractionalZ.source_component_domain(rois, metadata)
assert tuple(dict(plane) for plane in domain) == tuple(record["source_metadata"] for record in files)
assert tuple(plane["z_index"] for plane in domain) == ("0", "1", "2", "3")
print("Exact retained unmodified public source records/domain/anchor: PASS", flush=True)

status = pytest.main([
    "--noconftest", "--import-mode=importlib", "-p", "no:cacheprovider",
    "--basetemp=" + str(root / "source-control08-scratch"),
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_live_fractional_z_point_source.py",
    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_source_provenance_nested_identity.py",
    "-q",
])
scope_path = Path("/proc/self/cgroup").read_text().strip().split(":", 2)[2]
scope = Path("/sys/fs/cgroup" + scope_path)
for name in ("memory.max", "memory.peak", "memory.swap.max", "memory.swap.peak", "memory.events", "cpu.max"):
    print(name + ": " + (scope / name).read_text().replace("\n", " "), flush=True)
sys.exit(status)
