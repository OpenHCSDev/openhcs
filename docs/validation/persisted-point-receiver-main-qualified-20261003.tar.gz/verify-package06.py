"""Reuse original whole source/asset/native wheel qualification for main stack."""
from pathlib import Path

root = Path(__file__).parent
original = root / 'verify-package01.py'
program = original.read_text().replace(
    '39244bab1d47d5af3c87ff96f70014ff091c67ee',
    'b26334ace99512970c81809b29d5ad19c7e07c4c',
).replace('wheels01', 'wheels03').replace('target01', 'target04')
exec(compile(program, str(original), 'exec'))
