Main-only receiver524/catalog511/retirement522 receiving target
=============================================================

READY: ordinary qualified private target, public native receiving NOT RUN.
No original failed producer execution is replayed. Parent owns all runtime95
admission/launch/custody and the current three scientific authors remain untouched.

Exact target/source
-------------------

Target: /home/ts/wt/openhcs-issue-batch-20260929/engineering494/target04
Paired Python: /home/ts/wt/openhcs-paired-raw-installed-parent-20261001/.venv/bin/python
Wheel: engineering494/wheels03/openhcs-0.8.7-cp311-abi3-linux_x86_64.whl
Wheel SHA256: d3cb03f47c2831a6287a6f510de931efcc861bd7c8c43a8076704eae074b3639
Wheel build source: b26334ace99512970c81809b29d5ad19c7e07c4c
Current reviewed source:24927b864e3c7bc7e413f9929fbf917a5973ea5e
The intervening commits contain test-consumer/validation-doc corrections only;
all tracked package/build/knowledge/skill inputs are byte-equal, qualified in
package08.log. One build only; no needless second wheel or environment.

Normal main-based merges on the SAME reused owned checkout:

* Main f7de9efad393bce83a3756a271f0cd4383783ea9 (fresh remote fetch).
* Receiver524 initial a354bfa48857df8b8f21198cc78b1b6965495361;
  final test-consumer checkpoint b8925caa544b6d47323fca7cb95653b159bb52dc.
* Released511 b1d0b6c3e52842604a83bd3fda85c415e7fa8c5d, three production files
  byte-equal reviewed cb263946; includes newly released canonical guide checkpoint.
* Released522 b2fa845721ca84acee978d2d3ab65ab4f0541b6b, nine production files
  byte-equal reviewed6c49bedd8, with published source/native-receiving receipts.

Exactly15 production paths: five receiver plus three catalog plus nine retirement
minus two shared native files. No Root394 provenance/compiler/materialization/
graph changes imported. Main pyproject/gitlinks/source metadata/provenance and
producer/materialization owners are unchanged. Main floors remain ObjectState
>=1.1.8 and python-introspect>=.14. The published494 e6c0bf77f/full Root stack
remains separate, with honest157-file disclosure; it is NOT merged by this target.
Seven dirty foreign gitlinks are unmodified and excluded from all commits.

Qualified dependencies and package
---------------------------------

Existing retained wheels, no download/shared environment mutation:
ObjectState9c31e4b07b5537c0ed2307c5a63034c708b86bbb/1.1.8 and
python-introspect6f5ac0b79d6cef163df6a8389e72a889a91ed548/.14. All30+12 source
members match original snapshots/wheels/private target. Their actual
registered_type_pairs and prepare_dataclass_declaration API calls pass.
Dependency original qualification cff18e17117256148e0ac77cf8cf548ca50ca461cec34e27ccd7fee822b8465d
is retained under official30-package-implementation-20261003/catalog511-bytes01.json.

815 tracked OpenHCS/benchmark package files,90 declared knowledge/skill assets,
all13 skill files, both native C++ sources/extensions are source/wheel/target
byte-equal.984 actual target files covered by original distribution RECORDs and
declared9 console/gui entry points; no unaccounted files. New511 guide bytes are
honestly this target identity, NOT a relabel of earlier511/SCI505 targets.

Source and installed controls
-----------------------------

Main-only source39PASS5.20s/332959744B peak. Combined installed same39PASS5.48s/
300462080B. Final complete receiver/test-consumer family49PASS5.26s/296763392B,
512MiB/noSwap/CPU1/OOM0. Actual original989B archive independently opened by the
unchanged original PolyStore/typed decoder: four original source records Z0..3,
fractionalZ1.5/object7 and declared ZYX2/.65/.65 micrometers admitted unchanged.
No raw pixels or science data consulted. Old reader/public failure journals intact.

The extended consumer check first failed3/49 from a mistaken test-only attempt
to call presentation methods on ViewerLayerAxisProjection. Original return-type
declarations determined restoring its untouched contract/assertions. This failed
installed-control15.log remains;16 proves the corrected49 cases. Only actual
NapariAxisPresentation navigation consumers acquire mandatory declared scale.

Original AST tool covers704 production plus95 actual PolyStore/ZMQ modules with
zero parse omissions, before/after/combined. This named census is not a whole
NRA equivalence proof. Singer33 source model/queue proofs and Copernicus79 source
proofs remain their independently qualified exact strengths, not new public-native
acceptance. Both owners released their exact source and prohibited duplicate builds.

One ordinary build512MiB cap/283668480B peak/Swap0/OOM0; private materialization
111001600B peak. All our builder/check helpers terminal; no owned live native,
viewer, MCP, provider, X or catalog has been started in this task.

Machine-readable handoff: READY-MAIN13.json and PACKAGE09-QUALIFICATION.json.
The reused qualifier's legacy wheel_payloads_equal_to_original_qualified_targets
field contains per-wheel target payload counts; OpenHCS907 is compared with its
NEW ordinary wheel and complete current source, NOT the old Root target.
Only dependency30/12 members are also compared with original qualified targets.
Original package08 verifier-wrapper syntax failure is retained; it made no
package change and the final whole RECORD/dependency qualifier09 completed0.

Actual next public case and boundary
-----------------------------------

Parent-owned NEW standalone receiving context on admitted95, using only the exact
unchanged original archive at POINTS494_95/author-workspace/output/results01/
input_openhcs/results/A01_site-1_channel-1_timepoint-1_fixture_centres_494_step0_points.roi.zip
(989B/SHA256 fd0a372f3100c73da9533b308d44c2f85fa7a86b733e2608ae986135cb4e401a).
Use original public source inventory and stream_plate_files_to_viewer, no manual
metadata, fallback source, decoder, catalog copy or original9292bfb8 job replay.

Read back entire transported metadata/domain, feature row, fractionalZ and native
world transform; inspect raw-only/point-only/combined matched XY/trueXZ/trueYZ.
Point-only hides every image but retains raw mounted/source context. Then use
Singer's typed producer-identity retirement on the same viewer; preserve raw,
refuse pending/active routes and reopen the same immutable archive NEW once.
Copernicus catalog readiness journey is independent on the same admitted native.
Exact typed closes/process-gone proof and original journals/captures required.

No public render/calibration/retirement/RSS acceptance is claimed yet. Automatic
producer success remains Root435 publication-conflict ownership; the failed
9292bfb8 and original partial UI failures stay immutable. No SCI/biological pass,
count, or closure of all152/134 orthogonal requirements is claimed.
