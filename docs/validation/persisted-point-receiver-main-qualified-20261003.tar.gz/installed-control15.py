"""Final consumer-closure shard through unchanged combined installed bytes."""
from pathlib import Path

root = Path(__file__).parent
program = (root / 'source-control09.py').read_text()
program = program.replace('source09', 'target04').replace(
    'source-control09-scratch', 'installed-control15-scratch'
)
program = program.replace(
    "exec(compile(original, str(root / 'source-control08.py'), 'exec'))",
    '''original = original.replace('test_live_fractional_z_point_source.py', 'test_point_roi_receiver_domain.py')
original = original.replace('    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_source_provenance_nested_identity.py",\\n', '')
original = original.replace('    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_graph_roi_source_roundtrip_134.py",\\n', '')
original = original.replace('    "-o", "addopts=", "-q",',
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_shared_axis_navigation.py",\\n'
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_display_pipeline_projects_route_axes_locally",\\n'
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_display_pipeline_uses_declared_domain_independent_of_arrival_order",\\n'
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_display_pipeline_projects_aggregate_payload_axes_into_route_domain",\\n'
    '    "/home/ts/wt/openhcs-basicpy-readiness-20260929/tests/unit/test_napari_streaming_handlers.py::test_napari_axis_projector_preserves_route_offset_in_shared_viewer_domain",\\n'
    '    "-o", "addopts=", "-q",')
exec(compile(original, str(root / 'source-control08.py'), 'exec'))''',
)
exec(compile(program, str(root / 'source-control09.py'), 'exec'))
