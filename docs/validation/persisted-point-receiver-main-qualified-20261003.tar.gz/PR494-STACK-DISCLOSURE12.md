## Stack disclosure and receiver split

This published head `e6c0bf77f8e4d24d80c0463e214070bc018a3301` is ROOT-DEPENDENT, not a main-only point fix. Its ancestry imports Root394 `4eaacf17` and full `b312148855b6ed486442d15e9395a09e453d77c6`. Against verified remote main `f7de9efad393bce83a3756a271f0cd4383783ea9`, GitHub shows 157 inherited/owned files (93 production). This PR must NOT merge those unreviewed Root files into main under point-repair acceptance. All previous heads and qualification evidence remain unchanged.

Parent authorizes a separate MAIN-BASED RECEIVER-ONLY draft with the existing five receiver owners, preserving this producer checkpoint and Root435 dependency. The standalone unchanged 989-byte archive receiving journey will use that separate receiver with reviewed511/519, not this full Root stack. No producer execution replay or SCI package mutation. The prior source results below apply to their exact Root-dependent source, not automatically to the new main-based split.

## Actual status

Receiver source repair is implemented; **full public producer acceptance is not complete**. This is partial #152/#134, not closure of all orthogonal/output acceptance.

Latest coherent source is `e6c0bf77f` (normal main `f7de9efad` integration). It includes `c7a11af98`, with native world translation now requiring the owner's scale rather than retaining an optional unscaled branch. Seven foreign dirty gitlinks are preserved and excluded from authored commits.

## What changed

- The original typed PointROI producer retains represented source planes and an exact first-source anchor through original materialization/live stream declarations.
- Persisted `StreamingService.stream_rois` now transports the original source-bound ROI. `ROIArchiveSourceMetadata` owns the single feature-only source exclusion reused by native Points and Shapes; reopening no longer discards the transported source record.
- Native fractional-Z Points retains the represented source span from its anchor, not only anchor through the occupied point's ceiling. Existing missing-Z/anchor/fractional/domain guards remain.
- `NapariAxisPresentation` derives scale, units and world translation together for Image/Shapes/Points and shared-axis reprojection. Declared three-dimensional spacing calibrates Z; two-dimensional/unspecified spacing does not invent Z, and selectors/bands remain dimensionless.

No alternate codec, registry, axis-domain mirror, source-provenance reconstruction or Root publication/compilation edit. Singer #522 confirms these native methods are disjoint from his retirement lifecycle (#522 comment5966729112).

## Real failed journey and exact remaining boundaries

Parent-owned engineering95 original public compile completed, but execute `9292bfb8-4d2e-4e54-9bcc-5af998083fe5` **FAILED** at `project_runtime_artifacts` with conflicting metadata for a persisted image occurrence, after points were saved/streamed. Root #435/#394 owns that join. The actual conflicting address/metadata pair is not logged; no speculative guard weakening or writer replay was performed. Owner request: https://github.com/OpenHCSDev/openhcs/pull/394#issuecomment-5966649172

Original PolyStore readback of the actual 989-byte ZIP proves all four original source planes, fractional Z1.5/object7 and2/.65/.65 micrometer spacing intact. Archive SHA256 `fd0a372f3100c73da9533b308d44c2f85fa7a86b733e2608ae986135cb4e401a`. The old public reopen dropped the source record, narrowed route Z0..3 to0..2 and displayed Z scale1. All9 original XY/XZ/YZ PNGs were personally opened: rendering is real, calibrated/source-preserving acceptance is not claimed.

## Qualification at its actual strength

- Prior ordinary target02/03 whole package and paired dependency qualification remain frozen at their original source; they do not contain this newest receiver repair.
- Final coherent source: **59 passed**,8.26s,279,625,728-byte peak,512MiB/noSwap/oneCPU,OOM0. Original failed direct-source import and the test's incorrect pre-writer comparison are retained. The corrected assertion compares entire original saved metadata against entire reopened metadata and original plane provenance; no failing field is removed.
- Original writer/ZIP/source guard regression family plus native feature and2D/3D/relative/unspecified world-transform controls. Real Napari Image/Points coordinate transforms and Dims semantic navigation exercised without a Qt application/server.
- Before/after full named AST census:704 production+95 actual dependency modules,zero parse omissions. Existing owner/consumer family and removed native translation copies recorded; this is source evidence, not a full NRA equivalence proof.

Evidence: `docs/validation/live-fractional-z-point-projection-152.rst`; persistent `engineering494/RECEIVER11-QUALIFICATION.rst`, original reader JSON, before/final AST inventories, source control logs and parent public journals/captures. No scientist contact, installed hot patch or new runtime was made by this repair.

Next parent-authorized step is one ordinary qualified whole target, coordinated with511/519 owners first, then a **distinct new public reopen-only context using the unchanged original archive**. Automatic producer success still depends on Root's publication repair; no CI wait and no failed/UNKNOWN operation replay.

