50395 categorical-source receiving checkpoint
=============================================

Actual negative preserved, no replay
-----------------------------------

Parent sole original PTY83658/native6014 PID2355303 owns all public calls.
Default01 session-1/compile job-1 completed; execution job-2 COMPLETE did NOT
prove the joins. Original public sample: raw uint16 IDs2/7, result Objects_step0
int32 maximum0; shape/filter empty. Original runtime/mcp.stdout raw sample starts
at4262 (maximum7) and result sample at4550 (maximum0). Source/input/output/export
and original five-module #516 failure remain untouched. Removed01 has successful
artifact-plan and session2 only: DO NOT compile/execute that known-bad Grayscale
source. No session/job/public request was issued by Singer.

Original source diagnosis, not a new numerical recipe
----------------------------------------------------

NamesAndTypesModule.contribute_source_bindings decodes the declaration through
CellProfilerSourceImageType.from_literal. GRAYSCALE declares ImageArtifactType /
PRIMARY_PLANE, whereas OBJECTS declares ObjectLabelsArtifactType / SOURCE_ARTIFACT.
apply_source_binding_payload does NOT itself normalize this single-channel
Grayscale plane: monochrome conversion runs only with a declared channel axis.

The runtime image path DOES normalize: ImageArtifactTypeStrategy.runtime_input_value
calls normalize_cellprofiler_image_payload; CellProfilerModuleExecutor._image_request
uses the image strategy for primary image inputs (and normalizes the main-flow
carrier when no primary image inputs exist). normalize_image_payload_intensity
divides integer pixels by metadata intensity scale or the conventional dtype
scale. uint16 default scale is65535. ConvertImageToObjects preserve_label then
casts that float image to int32. Thus values2/7 in that intensity contract become
fractions and truncate to0. This source path explains the observed all-zero
upstream result; the actual normalized intermediate was not separately captured.
It does NOT show a regression in503's categorical shape association.

Supported categorical declaration: NamesAndTypes ``Select the image type:Objects``
and ``Name to assign these objects:Objects``. The original typed artifact loader
RuntimeAdapterRequest.source_artifact_payload uses matched workspace members,
VFS/source projection and apply_source_binding_payload. ObjectLabelsArtifactType
normalizes through normalize_source_label_data, which leaves a scalar label
matrix unchanged. ObjectLabelsArtifactTypeStrategy.object_labels builds the
nominal label set through SourceImageObjectLabelBuildRequest and the present-ID
domain; it does not pass label IDs through image-intensity normalization.
SourceProjectionSet.execution_anchor_projections explicitly supports artifact-only
source sets. Existing source fixtures test artifact-only workspace materialization
and public NamesAndTypes Objects import/compilation; they were read, not rerun.

The categorical source therefore replaces NamesAndTypes Grayscale + numeric
ConvertImageToObjects with one existing typed source declaration. Shape and
FilterObjects receive the same Objects2/7 directly; no source remapping, private
cast/rescaling algorithm, second loader, invented binding or installed patch.
The image carrier may still normalize independently; labels own categorical IDs.

Two NEW complete documents, ordinary original importer
-----------------------------------------------------

All files are in the original writable output root:
/home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output

* labels503-default02.cppipe + pipeline-default02.py: NamesAndTypes Objects,
  MeasureObjectSizeShape Objects, FilterObjects Objects -> RetainedDefault,
  removed flag omitted; distinct results-default02.
* labels503-removed02.cppipe + pipeline-removed02.py: same categorical source
  and shape, one FilterObjects Objects -> RetainedEnabled, removed-enabled
  RemovedEnabled; distinct results-removed02.

Each Python document imports its own CPPipe using import_cellprofiler_pipeline,
then ordinary pipeline_steps/pipeline_config with original filename metadata,
Z stack, channel group,1um SourceVoxelSpacing and streaming disabled. External
filter module_num3 is NOT an asserted public producer identity. Obtain each
actual typed producer/relationship identity from its returned artifact-plan;
do not reuse01's module_3 or original full-five4/5 guesses.

Next commands for PARENT'S EXISTING retained shell only:

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-default02.py --global-config-id config-1 --json

  artifact-plan /home/ts/wt/openhcs-issue-batch-20260929/engineering503/LABELS503_95/author-workspace/output/input --source-file pipeline-removed02.py --global-config-id config-1 --json

Only after each actual successful plan, create a NEW source session/compile/
execute handle through the original public route and normal admission. Use new
exclusive default02-values.json / removed02-values.json exports. Do not execute
session2/removed01 or replay an original uncertain handle. No new client/startup.

Unchanged required joins
-----------------------

Original12x15uint16 source remains EXACT byte hash
1025c880c8323c87af23b10556cf11d423df9df4046876f2fdf1557d621d826e.
Source2 rows0:2/cols2:5 area6, source7 rows6:10/cols8:13 area20; background0.
Both exact categorical IDs must reach shape object_label/LABEL_ID rows with
AreaShape_Area6/20. Absent declared-domain rows retain original missing rules;
no row-ordinal/count-only shortcut. Retained1 must occupy source7's exact20
pixels; complement1 source2's exact6 pixels in a separate removed domain.
Typed directed parent_child source Objects -> named target, parent/child roles,
actual producer identity, parent_id7/child_id1 retained and2/1 removed; raw
source_ids/target_ids must agree. Default4/enabled6 return ABI, no default removed
artifact. Source declaration changes neither IDs/areas nor lineage expectations.

Canonical VALUES reader
----------------------

The .json suffix is not a wire-format declaration. Original server
ZMQExecutionServer._export_runtime_observation selects VALUES export using
ZMQRuntimeExecutionObservationExport.from_execution and .write (gzip/pickle).
Use ``ZMQRuntimeExecutionObservationExport.read(Path(export_path))`` from
openhcs.runtime.zmq_execution_observation, then its existing .observation().
The read owner checks nominal type/schema; do not json.loads, manually unpickle,
mirror records into an alternate schema or mutate the original export. No export
was decoded by Singer and no product imports were performed at this checkpoint.

Pins, ownership and qualification limit
--------------------------------------

Sourcec031 / whole immutable target02 still qualified. infrastructure.py,
source_image_semantics.py and runtime/artifact_binding.py SHA-equal source/target
at this checkpoint; their hashes are respectively83ba9be2d39e9917fbb4ce31ac010d17a3f16716ce22c52f3f41e46d5844b5a0,
c0488e4c7b36d10df2abe730e9002e7ce82f0eb9473148d3d56f64ca9ec09075,
0e36ce03185b9b5cf359ed2d5a52a49b23a456ccb054d7fd9a7b2500a876896a.
Root394 now b312148855b6ed486442d15e9395a09e453d77c6 remains shared source/
reconstruction integration owner. #516 is independently filed with exact
Root contact5965875069; no shared source change or whole394 claim here.

Latest NRA/audit catalog review applied IDEN-1 and BOUND-2: the source fact is
categorical identity, not intensity; original nominal source/artifact strategies
own the route. No parallel authority or consumer switch was introduced.
Existing complete111-family AST and original positive/negative source qualification
remain pinned historical evidence, not a rerun or proof of02's installed route.
Only new documents' Python AST syntax was checked; actual import/artifact-plan/
compile/execution/pixel/table/lineage qualification remains parent-owned.
No tests/build/install/native/viewer/scientific call/contact or raw rewrite.

New02 SHA256:
default CPPipe47373904fb84c256834a17852e8346f47e7b1a4fbe9f93a4a7702acef4b52b71
removed CPPipea1166b6f646f037c5736b45bc34a31e772a93d5c8e68eea9fd7f277117c30b1d
default Pythonfa42abb33d76ce62b10266f63ca9cf986848dedf9657a06bc2d970a817470fa7
removed Python5b6b4ad49bfadf1a8a3953e157376cf566e2cf4bc5fd8c77a60e9b43d17e69a8
