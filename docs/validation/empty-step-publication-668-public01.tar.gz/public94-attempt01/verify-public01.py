"""Original engineering599 reply reader, exact two-well669 acceptance."""
from pathlib import Path

original = Path('/home/ts/wt/openhcs-issue-batch-20260929/engineering599/public94-combined02/verify-received02.py')
reader = original.read_text().partition('import numpy as np')[0]
reader = reader.replace("target = engineering / 'package02/target'", "target = engineering / 'target'")
reader = reader.replace("output = root / 'ENGINEERING600614_94/author-workspace/output'", "output = root / 'ENGINEERING669_94/author-workspace/output'")
exec(compile(reader, str(original), 'exec'))

import numpy as np
import openhcs
from openhcs.core.runtime_image_values import image_payload_data, image_payload_metadata
from openhcs.core.source_metadata import SourceVoxelSpacing
from openhcs.core.measurement_row_materialization import measurement_rows
from openhcs.runtime.zmq_execution_observation import ZMQRuntimeExecutionObservationExport

assert Path(openhcs.__file__).is_relative_to(target)
export = ZMQRuntimeExecutionObservationExport.read(output / 'values01.json')
observation = export.require_valid_observation()
assert export.execution_id == '498531a7-5b1b-4e2c-8d88-b8203ee5a34a'
assert set(observation.records_by_axis) == {'A01', 'A04'}
inventory, = [item['payloads'][0] for item in replies if item['tool'] == 'openhcs_query_plate_files']
assert not inventory['errors'] and inventory['truncated_count'] == 0
images = [r for r in inventory['records'] if r['kind'] == 'image']
tables = [r for r in inventory['records'] if r['file_format'] == 'CSV']
assert len(images) == len(tables) == 2
expected = np.zeros((12, 15), dtype=np.uint16)
expected[2:4, 2:5] = 2
expected[6:10, 8:13] = 7
samples = [item['payloads'][0] for item in replies if item['tool'] == 'openhcs_sample_plate_image']
assert len(samples) == 2
validated = []
for well, records in observation.records_by_axis.items():
    sample, = [s for s in samples if s['source_metadata']['well'] == well]
    assert not sample['errors'] and sample['sample_included']
    assert sample['dtype'] == 'uint16' and sample['sample_shape'] == [12, 15]
    assert sample['selected_resolution_index'] == 0
    np.testing.assert_array_equal(np.asarray(sample['sample_values']), expected)
    sm = sample['source_metadata']
    assert (sm['site'], sm['channel'], sm['z_index'], sm['timepoint']) == (1, 1, 1, 1)
    assert sm['OpenHCSSourceVoxelSpacingZYX'] == '0.5,0.5'
    assert sm['OpenHCSSourceVoxelSpacingUnit'] == 'micrometers'
    image, = [r for r in records if r.key.name == 'PersistedLabels']
    np.testing.assert_array_equal(np.asarray(image_payload_data(image.data)).squeeze(), expected)
    metadata = image_payload_metadata(image.data)
    assert metadata.source_voxel_spacing == SourceVoxelSpacing((0.5, 0.5))
    identities = metadata.source_provenance.represented_source_identities
    assert identities and all(i.component_metadata['well'] == well for i in identities)
    table, = [r for r in records if r.key.name == 'MeasureObjectSizeShape_2_measurements']
    rows = measurement_rows((table.data,))
    areas = {int(row['object_label']): float(row['AreaShape_Area']) for row in rows}
    assert areas == {2: 6.0, 7: 20.0}
    assert table.key.scope.axis_id == well and table.key.scope.value == '1'
    csv, = [r for r in tables if Path(r['key']).name.startswith(well + '_')]
    assert not csv['preview']['truncated']
    assert {int(r['object_label']): float(r['AreaShape_Area']) for r in csv['preview']['csv_rows']} == areas
    source = output / 'acquisition' / (well + '_s1_w1_z1_t1_Labels.tif')
    assert hashlib.sha256(source.read_bytes()).hexdigest() == '77812846c37b6ab7e0772ee1aa2b800e9def26dda26d7326e3932e5dcbacf1e4'
    validated.append({'well': well, 'pixels': 180, 'maximum_absolute_error': 0, 'areas': areas, 'source_identities': len(identities)})
print(json.dumps({'status': 'PASS', 'source_head': 'cf10bb670a3c0e0e264e3d0641872669e38beaa8',
    'imported': str(openhcs.__file__), 'execution_id': export.execution_id,
    'canonical_observation_valid': True, 'public_samples': validated,
    'transcript_sha256': hashlib.sha256(transcript.read_bytes()).hexdigest()}, indent=2))
