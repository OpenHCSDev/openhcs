669 installed two-well default-publication receiving
==================================================

PASS at the affected public user path, not biological accuracy or exact race
overlap proof. Whole receiving06 source cf10bb670a3c0e0e264e3d0641872669e38beaa8
remained immutable. Both wells used default automatic publication, two worker
threads, original CPPipe import, categorical source and registered operations.
No artifacts-only workaround, second client, viewer or scientific input.

Original recorded client PTY73939, epoch1791148347, scope
engineering669-receiving06-public94-20261004-engineering669_94-mcp.scope,
InvocationID fd44a9058ce34c0f8d07823fc975cc82; MCP575160. Native600635
create_time1791148433.08 at TCP6012/ACK7012 reached READY, then the same catalog
owner returned outcome ready. Original stdin/stdout/timing are in
ENGINEERING669_94/author-workspace/output/runtime/mcp.*.

Artifact plan: errors[], two axes A01/A04, two workers, four step-axis entries,
no truncation and no viewer streaming. Compilation job-1
20ed1d96-c554-469f-8325-2178b49586ab COMPLETE. One execution job-2
498531a7-5b1b-4e2c-8d88-b8203ee5a34a COMPLETE/errors[], native end-start
1791148875.9364147 - 1791148875.376505 = 0.5599097 seconds.

Public inventory exposes both saved label images and both measurement CSVs.
Each resolution0 12x15 uint16 image matches all180 synthetic input pixels
exactly: label2 at rows2:4/columns2:5, label7 at rows6:10/columns8:13.
Returned well/site/channel/Z/time identities are correct; XY .5/.5 micrometers.
Canonical values01.json require_valid_observation passes. Each well's typed
MeasurementTable joins object_label2->Area6 and7->Area20, matching public CSV
previews. Saved images retain original source provenance/calibration. Exact
proof: verify-public01.py and terminal0 verify-public01.log, 298120KiB peak.

Public typed close on the ORIGINAL complete native handle returned errors[],
request_attempted/acknowledged/endpoint_terminated/process_exited/succeeded TRUE.
Native600635 and MCP575160 independently absent; ports6012/7012/6013/7013 absent.
Client EOF terminal2 retains known argument/discovery negatives, not shutdown
failure. Original scope inactive/dead. Observed scope peak1728528384 bytes before
closure; MemoryMax/MemorySwapMax infinity, no agent-invented caps.

Retained negatives: historical context CLI alias rejected before dispatch;
first JSON source argument quoting rejected by argparse before dispatch. The
correct complete source session was created once; compile and execute each
submitted once. No UNKNOWN operation replay. These command errors remain in
the original journals. UI PlateManager not updated is the expected headless
workflow warning, not default output publication failure.

94 is returned to Dewey with original X/VNC helpers untouched. Three science
authors and their frozen packages were not contacted or changed. 663's separate
representative3D compile remains unverified; this acceptance does not claim it.
676 aggregate-plane source is NOT installed in receiving06. Singer explicitly
confirmed the shared function_outputs.py hunk is disjoint; normal main
integration and live aggregate-plane acceptance remain required for676.
