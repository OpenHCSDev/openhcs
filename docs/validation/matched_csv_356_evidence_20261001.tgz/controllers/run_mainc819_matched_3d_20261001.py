import fcntl,json,os,subprocess,sys
from pathlib import Path
from benchmark.runtime_env import configure_headless_cpu_benchmark_runtime
configure_headless_cpu_benchmark_runtime('WARNING')
root=Path('/home/ts/code/projects/openhcs');runs=root.parent/'openhcs-benchmark-runs'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='c81963475e6221961be5209c47c36f5f4c222521'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
from scripts.mcp_thesis_demo_live import official_runtime_lock_path
lock=official_runtime_lock_path();lock.parent.mkdir(parents=True,exist_ok=True)
from benchmark.matched_cellprofiler_batch import main
output=runs/'mainc819-matched-3d-native-openhcs-1w1j-20261001'
assert not output.exists()
with lock.open('a+') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 result=main(['--manifest',str(root/'benchmark/manifests/official30_portable_axis1.json'),'--case','cp_tutorial_3d_monolayer','--well-count','1','--output-dir',str(output),'--repetitions','2','--openhcs-workers','1','--native-jobs','1','--native-python',str(root/'.venv-cellprofiler39/bin/python')])
assert result==0,result
print('Matched 3D driver completed with fresh native outputs.',flush=True)
