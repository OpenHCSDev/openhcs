import json,csv,sys,xml.etree.ElementTree as E
from pathlib import Path
runs=Path('/home/ts/code/projects/openhcs-benchmark-runs');folder=runs/'matched-csv-viewer-qualified-imflow-native-openhcs-1w1j-20261001'
r=json.loads((folder/'report.json').read_text())
assert r['source_commit']=='37e4c7aadddbf4df444490312d17f3a4723822aa' and r['source_dirty'] is False
assert len(r['candidate'])==3
for row in r['candidate']:
 assert not any(row[k] for k in ('database_differences','csv_differences','image_differences','unexpected_output_files','missing_declared_output_files'))
 assert row['native_output_file_count']==row['candidate_output_file_count']==1
assert r['native_input_inventory']==r['native_input_inventory_after']
n=json.loads((folder/'native_report.json').read_text());assert [o['repetition'] for o in n['observations']]==[-1,0,1]
assert all(o['image_set_count']==2 for o in n['observations'])
t=E.parse(runs/'matched-csv-viewer-qualified-broad-final-20261001.xml').getroot().find('testsuite')
cases=t.findall('testcase');unique={(c.attrib['classname'],c.attrib['name']) for c in cases}
assert len(cases)==len(unique)==2673 and all(t.attrib[k]=='0' for k in ('failures','errors','skipped'))
assert not any(t.findall('.//'+k) for k in ('failure','error','skipped'))
csv.field_size_limit(sys.maxsize)
p=list(csv.DictReader((runs/'matched-csv-synced-parity-20261001/observations.csv').open()))
assert len(p)==30 and all(x['equivalent']=='True' and int(x['difference_count'])==0 for x in p)
result={'source':r['source_commit'],'native_repetitions':len(n['observations']),'candidate_repetitions':len(r['candidate']),'differences':0,'inputs_unchanged':True,'unique_test_cases':len(unique),'xml_aggregate_tests':t.attrib['tests'],'original_verifier_counterexample':'The initial verifier incorrectly required testsuite.tests=2673; the aggregate attribute is 2715. All 2673 unique testcase elements pass with zero failure/error/skip elements, matching the terminal pytest summary. Original XML retained.','native_reference_cases':len(p),'timing_claim':r['timing_claim']}
(runs/'matched-csv-final-acceptance-verifier-20261001.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
