import hashlib,json,shutil
from pathlib import Path
runs=Path('/home/ts/code/projects/openhcs-benchmark-runs')
storage=Path('/var/tmp/openhcs-benchmark-preserved-ts-20261001');storage.mkdir(exist_ok=True)
for name in ('matched-csv-producer-native-parity-20261001','matched-csv-native-contract-parity-20261001','matched-csv-family-parity-20261001'):
 source=runs/name;target=storage/name
 assert source.is_dir() and not source.is_symlink() and not target.exists()
 before={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
 shutil.copytree(source,target)
 after={str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest() for p in target.rglob('*') if p.is_file()}
 assert before==after
 shutil.rmtree(source);source.symlink_to(target,target_is_directory=True)
 (runs/(name+'-storage-receipt.json')).write_text(json.dumps({'source_path':str(source),'preserved_path':str(target),'file_sha256':before,'scope':'Byte-identical completed/superseded candidate outputs moved to available filesystem; original paths preserved through symlinks, no files discarded.'},indent=2)+'\n')
 print(json.dumps({'source':str(source),'preserved':str(target),'files':len(before)}),flush=True)
