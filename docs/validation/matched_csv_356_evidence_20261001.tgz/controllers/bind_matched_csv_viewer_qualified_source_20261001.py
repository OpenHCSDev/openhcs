import hashlib,json,subprocess
from pathlib import Path
from importlib.metadata import version
from benchmark.runtime_env import configure_headless_cpu_benchmark_runtime
configure_headless_cpu_benchmark_runtime('WARNING')
from openhcs.interop.cellprofiler.module_declarations import CellProfilerModule
root=Path('/home/ts/code/projects/openhcs-matched-csv-fix');runs=root.parent/'openhcs-benchmark-runs'
r=json.loads((runs/'matched-csv-family-source-binding-20261001.json').read_text())
previous=r['revision'];r['previous_production_checkpoint']=previous
r['revision']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
r['base']='fe7ad23cc6ffc43eebac0e315d411142e4057364'
r['child_revisions']['external/pyqt-reactive']='ad4948775ab81180a354d4b793d17ee5ddff3972'
r['tracked_worktree_clean']=not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
assert r['tracked_worktree_clean']
for path,pin in r['child_revisions'].items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root/path,text=True).strip()==pin
for path,sha in r['binary_sha256'].items():assert hashlib.sha256((root/path).read_bytes()).hexdigest()==sha
for package,old in r['packages'].items():assert version(package)==old
for name,binding in r['module_location_contracts'].items():
 owner=CellProfilerModule.require_module(name)
 actual={'mro':[f'{t.__module__}.{t.__qualname__}' for t in owner.__mro__],'row_type':owner.object_location_measurement_row_type().__name__}
 assert actual==binding,(name,actual)
 r['module_location_contracts'][name]=actual
r['full30_qualified_checkpoint']='4f94e394148006953458ee6fbcbcacbb831e0661'
r['full30_scientific_tree_binding']={path:subprocess.check_output(['git','rev-parse',r['revision']+':'+path],cwd=root,text=True).strip() for path in ('openhcs/core','openhcs/interop','openhcs/processing','benchmark','scripts','setup.py')}
for path,value in r['full30_scientific_tree_binding'].items():
 assert value==subprocess.check_output(['git','rev-parse',r['full30_qualified_checkpoint']+':'+path],cwd=root,text=True).strip(),path
r['source_checks_checkpoint']='0914ec2dda113a18bd11b61677e8cad91b88fff9'
for path in ('openhcs','benchmark','scripts'):
 assert subprocess.check_output(['git','rev-parse',r['revision']+':'+path],cwd=root,text=True)==subprocess.check_output(['git','rev-parse',r['source_checks_checkpoint']+':'+path],cwd=root,text=True),path
r['merged_main_delta']=subprocess.check_output(['git','diff','--name-only',previous,r['revision']],cwd=root,text=True).splitlines()
r['production_tree_sha256']={path:hashlib.sha256((root/path).read_bytes()).hexdigest() for path in subprocess.check_output(['git','ls-files','openhcs','benchmark','scripts','setup.py'],cwd=root,text=True).splitlines() if (root/path).is_file()}
(runs/'matched-csv-viewer-qualified-source-binding-20261001.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'revision':r['revision'],'base':r['base'],'owners':len(r['module_location_contracts']),'production_files':len(r['production_tree_sha256'])}))
