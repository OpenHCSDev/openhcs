import csv, hashlib, io, json, shutil, subprocess, tarfile
from pathlib import Path
runs=Path('/home/ts/code/projects/openhcs-benchmark-runs')
root=Path('/home/ts/code/projects/openhcs-matched-csv-fix')
head='37e4c7aadddbf4df444490312d17f3a4723822aa'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
parity=runs/'matched-csv-synced-parity-20261001'
rows=list(csv.DictReader((parity/'observations.csv').open()))
assert len(rows)==30 and all(row['equivalent']=='True' and int(row['difference_count'])==0 for row in rows)
imflow=runs/'matched-csv-viewer-qualified-imflow-native-openhcs-1w1j-20261001'
report=json.loads((imflow/'report.json').read_text())
assert report['source_commit']==head and report['source_dirty'] is False
assert len(report['candidate'])==3
for row in report['candidate']:
 assert not any(row[key] for key in ('database_differences','csv_differences','image_differences','unexpected_output_files','missing_declared_output_files'))
assert report['native_input_inventory']==report['native_input_inventory_after']
files={}
for path in sorted(runs.glob('matched-csv-*')):
 if path.is_file() and path.suffix in ('.log','.xml','.json','.txt'):
  files[path.name]=path
for folder in (parity,runs/'matched-csv-family-parity-20261001',runs/'matched-csv-native-contract-parity-20261001',runs/'matched-csv-producer-native-parity-20261001',runs/'matched-csv-native-parity-20261001'):
 for name in ('observations.csv','observations.jsonl','phase_timing.csv','suite_metadata.json','summary.csv'):
  path=folder/name
  if path.is_file():files[str(path.relative_to(runs))]=path
for folder in (imflow,runs/'matched-csv-family-imflow-native-openhcs-1w1j-20261001',runs/'matched-csv-native-contract-imflow-native-openhcs-1w1j-20261001',runs/'matched-csv-producer-imflow-native-openhcs-1w1j-20261001',runs/'matched-csv-fixed-imflow-native-openhcs-1w1j-20261001',runs/'matched-csv-fixed-3d-native-openhcs-1w1j-20261001',runs/'mainc819-matched-3d-native-openhcs-1w1j-20261001'):
 for name in ('report.json','candidate_report.json','native_report.json','native_request.json','native_stderr.log','native_stdout.log','pilot_provenance.json','equivalence_policy.json','imported_pipeline.py'):
  path=folder/name
  if path.is_file():files[str(path.relative_to(runs))]=path
 evidence=folder/'candidate_evidence'
 if evidence.is_dir():
  for path in evidence.glob('*/measured_pipeline_receipt.json'):
   files[str(path.relative_to(runs))]=path
for path in sorted(Path('/tmp').glob('run_matched_csv*20261001.py')):
 files['controllers/'+path.name]=path
for name in ('run_mainc819_matched_3d_20261001.py','census_refill_preparation_20260930.py','matched_csv_356_ownership_20261001.txt','matched_csv_viewer_fixtures_issue_20261001.md','matched_csv_issue_20261001.md','matched_volume_issue_20261001.md','matched_csv_storage_issue_20261001.md','preserve_matched_csv_outputs_20261001.py','bind_matched_csv_synced_source_20261001.py','bind_matched_csv_viewer_synced_source_20261001.py','bind_matched_csv_viewer_qualified_source_20261001.py','package_matched_csv_evidence_20261001.py','verify_matched_csv_final_acceptance_20261001.py'):
 path=Path('/tmp')/name
 if path.is_file():files['controllers/'+path.name]=path
archive=root/'docs/validation/matched_csv_356_evidence_20261001.tgz'
archive.parent.mkdir(parents=True,exist_ok=True)
sums=[]
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,path in sorted(files.items()):
  digest=hashlib.sha256(path.read_bytes()).hexdigest();sums.append(f'{digest}  {name}')
  tar.add(path,arcname=name,recursive=False)
 data=('\n'.join(sums)+'\n').encode();info=tarfile.TarInfo('SHA256SUMS');info.size=len(data);tar.addfile(info,io.BytesIO(data))
print(json.dumps(dict(archive=str(archive),files=len(files),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())))
