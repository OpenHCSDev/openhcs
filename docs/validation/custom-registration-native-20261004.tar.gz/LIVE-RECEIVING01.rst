567 original installed TCP receiving
====================================

Status at 2026-10-04T02:29:37Z: one original client and native runtime active;
registration/status acceptance pending. This is not a successful-registration
claim. Singer owns semantic acceptance; Dewey retains physical PTY15414 custody.
Cross-thread write_stdin could not address that PTY; no input was sent by Singer
through that failed tool lookup. No second client was started.

The qualified ordinary whole wheel is source8513a7d2483ea09a2ec6b9e9f0193a5a16a56902,
SHA256 9fde2794d19f5d57837a67c4672e1f1053eed3c95c71ebae7f37c160655756de.
Published567 head0aaf14cba changes only the receiving receipt, not production.
Original QUALIFICATION01.rst and READY567.json retain815 tracked payloads,
90 declared resources,13 skill files,984 RECORD entries and nine installed
controls. No new build or install.

One original recorded CLI runs from released Dewey operations under canonical
FUND slot ADMIN_REGISTRATION56794, invocation787d442349b8407891ced5b3a15b8e84.
Actual scope engineering567-public94-20261004-admin_registration56794-mcp.scope
reports MemoryMax=infinity, MemorySwapMax=infinity, CPUQuotaPerSecUSec=1s,
Slice=openhcs-blindsol3phase03.slice. Native188784 belongs to this exact scope.
Historical packet cap wording is superseded by explicit owner withdrawal and
merged577; ordinary API timeouts, path policy and process custody are unchanged.

Original health replies errors=[], status=ok, stale_source_paths=[], packaged
resources ready86, MCP177709. Its server_source_path is exact qualified target01.
Original native bootstrap returns PID188784/create1791080888.84, native6012TCP,
ACK7012, and actual launch_plan/store; ready=false is a startup observation,
not a failure or permission to issue another bootstrap. Both /proc command lines
activate the same full qualified target01 with the original paired interpreter.

Original complete input/output/timing remain in
ADMIN_REGISTRATION56794/author-workspace/output/runtime/mcp.stdin,
mcp.stdout and mcp.timing. Native original log/startup journal are
runtime/scratch/data/openhcs/logs/openhcs_zmq_server_port_6012_1791080889637783938.log
and the same basename.startup.jsonl beneath that output root.

The single154-byte source-packet/registration_observation_probe_567.py is
registered but never executed. Acceptance remains exact once-only registration,
same-incarnation returned handle/content identity, read-only native publication
and persisted-source proof, followed by original exact native close and CLI
terminal disposition. No viewer, images, scientific input, pipeline, provider,
original UNKNOWN replay or changed frozen scientific target is authorised here.

Public registration and observation received
-------------------------------------------

Original public lifecycle observation returns ready=true on the retained
bootstrap handle. Explicit catalogue preparation and its original status return
READY on the same6012/incarnation before the source-bearing request.

One recorded registration returns errors=[], registered_count=1, persisted=true,
one source path in the actual launch-plan store and canonical function identity
openhcs:registration_observation_probe_567. Its original observation_handle
contains the exact original connection, native identity, source digest, function
name, persist=true and actual store. No source was evaluated on images.

One read-only status returns errors=[], outcome=registered, the unchanged
observation_handle, one published_sources entry and persisted_source equal to
that entry. Both content identities are the original frozen fixture's exact
SHA2564398ac619555f8a1c0459dbbcb1a6440862fab50602cea1485c756c6ebd1e828.
cmp of frozen fixture and the returned native persisted source is terminal0.

PUBLIC-REPLIES01.json is a JSON projection of the complete original public batch
replies, not a second codec or replacement journal. Original jq assertions over
the once-only bootstrap/registration/status replies retain true in
PUBLIC-RELATIONS01.stdout: exact handle/connection/incarnation/store/digest/name,
registered_count1, one function/path, empty errors and matching published/saved
source proofs. Original mcp.stdin contains exactly one registration and one
registration-status request. Raw journals remain unchanged.

This is actual installed TCP native registration/observation acceptance, not
merely catalogue visibility or count agreement. Known uncertain old H002/#131
requests were not replayed; no induced timeout/uncertain live recovery is claimed.
Closure and original terminal received
-------------------------------------

The next original exact close returns errors=[], request_attempted=true,
acknowledged=true, process_exited=true, endpoint_terminated=true, succeeded=true;
returned process_identity is the original188784/create1791080888.84. At
2026-10-04T02:36:04Z independent ps finds both188784/native and177709/MCP absent,
and ss finds no6012/7012 listeners. No viewer was started. Numerical native
exit code is unknown; typed process_exited is not a fabricated numeric code.

Original recorded shell ends at2026-10-03T22:35:02-04:00 with
COMMAND_EXIT_CODE=1. Preserve that actual terminal1, not a claimed clean0.
Every complete original public batch has errors=[], every result mcp_error=false
and payload errors=[]; no original operation is UNKNOWN in this receiving case.
The nonzero shell disposition is separate from those successful public native
registration/status/closure replies, and its cause is not inferred here.
Dewey retains original outer PTY terminal observation custody.

This completes the focused installed/native registration-observation case.
It does not prove runtime image execution, biology, live fault injection or
repair/replay of any original uncertain registration. There was no new build,
install, environment, worktree, cap, timeout change or scientific hot update.
