Installed15 engineering final custody
====================================

Original client17936 is terminal exit1. Its recorder footer at2026-10-05
12:33:19-04:00 preserves earlier request/capture/retirement failures. This is
not a child shutdown failure and does not negate the independent #748 pass.

Viewer690321/create1791216354.97 and native648055/create1791215470.77 each
returned all five positive exact close flags. Independent ps finds both absent.
The same original client received exit once; no replay, adoption or restart.
All three closed client journals are separately sealed after fuser found no
writers. The inherited95 helpers remain owned and are not stopped.

Qualified #748: full scalar MINISBLACK four-plane TIFF and saved Points/Shapes
reopen on one viewer, numerical/full domain/spacing identities, genuine XY/XZ/YZ
and fourteen original native PNGs. Planck independently verified sixteen controls.
See OWNER-748-SAVED-REOPEN-ACCEPTANCE15.rst and PLANCK-PUBLIC-ACCEPTANCE16.rst.

Failed #522: exact middle source retirement returned an error and partially
mutated the scene. The middle route disappeared, raw/Points well domain shrank
3-to-2, Points selection was lost, Shapes domain and current well ordinal stayed
old. Complete before/after state, source payloads, requests, captures and failure
remain preserved. Singer owns the existing selection/rematerialization repair.
No selection reset or retirement replay is counted as acceptance.

No current science bundle or frozen run was changed. Original older14 failure
and closure remain distinct. Receiving15 is not replaced or hotpatched.
