import json
from pathlib import Path
from functools import partial
from multiprocessing.shared_memory import SharedMemory
from types import SimpleNamespace

import numpy as np
import pytest
from polystore.base import DataSink
from polystore.fiji_stream import FijiStreamingBackend
from polystore.filemanager import FileManager
from polystore.disk import DiskStorageBackend
from polystore.memory import MemoryStorageBackend
from polystore.roi import PointShape, load_rois_from_zip
from polystore.roi_converters import NapariROIConverter
from polystore.napari_stream import NapariStreamingBackend
from polystore.streaming import (
    StreamingBatchMessageBuilder,
    StreamingBatchMessageRequest,
)
from polystore.streaming.identity import (
    FixedStreamProducerIdentityKind,
    StreamProducerIdentity,
)
from polystore.streaming_constants import StreamingDataType
from polystore.streaming.viewer_transport import (
    BatchViewerStreamSourceMetadata,
    ViewerDisplayConfigABC,
    ViewerFilenameParserABC,
    ViewerMetadataHandlerABC,
    ViewerMicroscopeHandlerABC,
    ViewerStreamBackendKwargs,
    ViewerStreamProducer,
    ViewerStreamRequest,
    ViewerStreamSource,
    ViewerStreamSourceIdentity,
)
from zmqruntime.config import TransportMode
from zmqruntime.viewer_protocol import ViewerTransportEndpoint, ViewerWireField

import openhcs  # noqa: F401
from openhcs.constants.constants import AllComponents, VariableComponents
from openhcs.core.components.parser_metaprogramming import FilenameParseResult
from openhcs.core.config import AnalysisConsolidationConfig
from openhcs.core.measurement_row_materialization import (
    MeasurementProjectedColumnarRows,
)
from openhcs.core.runtime_image_values import (
    ImageMetadataPayload,
    ImagePayloadMetadata,
)
from openhcs.core.runtime_measurements import (
    MeasurementScope,
    MeasurementSubject,
    MeasurementTable,
    ObjectCoreMeasurementFeature,
)
from openhcs.core.roi_point_metadata import ROIFractionalZ
from openhcs.core.roi_source_metadata import ROIArchiveSourceMetadata, ROIPlaneMetadata
from openhcs.runtime.viewer_component_system import (
    ViewerComponentValueDomainPayload,
    ViewerLayerAxisProjection,
)
from openhcs.runtime.napari_streaming_handlers import (
    NapariStreamLayerAddress,
    NapariStreamLayerItem,
)
from openhcs.core.runtime_object_label_building import (
    SourceImageObjectLabelBuildRequest,
)
from openhcs.core.runtime_object_label_domains import (
    ObjectLabelDomain,
    ObjectLabelDomainScope,
)
from openhcs.core.runtime_object_labels import (
    ObjectLabelRepresentation,
    ObjectLabelSet,
    ObjectLabelPayload,
    ObjectLabelVariantData,
)
from openhcs.core.runtime_plane_projection import (
    RuntimePlaneAxis,
    RuntimePlaneAxisValueProjection,
)
from openhcs.core.runtime_sparse_labels import SparseIJVLabelRows
from openhcs.core.runtime_slice_projection import RuntimeProjectionPlaneMetadata
from openhcs.core.runtime_tabular_values import FieldSpec
from openhcs.core.measurement_row_materialization import MeasurementSparseColumnarRows
from openhcs.core.source_image_provenance import (
    SourceImageIdentity,
    SourceImageProvenancePlanes,
)
from openhcs.core.source_metadata import (
    SOURCE_PLANE_COUNT_FIELD,
    SOURCE_PLANE_INDEX_FIELD,
    SourceVoxelSpacing,
)
from openhcs.core.source_spatial_domain import SourceSpatialDomain
from openhcs.microscopes.source_schema import SourceSchemaFilenameParser
from openhcs.processing.materialization import (
    CsvOptions,
    ImageFileOptions,
    JsonOptions,
    MaterializationSpec,
    MaterializedFilenameIdentity,
    PointROIOptions,
    ROIOptions,
    TiffStackOptions,
    csv_only,
    json_materializer,
    json_only,
    materialize,
    materialization_outputs,
    tabular_field_names_from_materialization,
    text_only,
    tiff_stack,
)
from openhcs.processing.backends.analysis.consolidate_analysis_results import (
    analysis_file_path_is_included,
)
from openhcs.processing.materialization.core import (
    MaterializationInputItem,
    Output,
    ROIMaterializationArchiveIdentity,
    ROIMaterializationTarget,
    ROIMaterializationTargetCoalescer,
    RuntimePlaneStackAxesProjectionSelection,
    ViewerStreamBackendCallKwargs,
)


def _memory_materialize(spec, data, path, filemanager):
    return materialize(
        spec,
        data=data,
        path=path,
        filemanager=filemanager,
        backends=["memory"],
        backend_kwargs={},
    )


def test_retained_full_stack_stream_preserves_absolute_calibration_and_integer_pixels(viewer_ack_return_route):
    labels = np.zeros((2, 8, 9), dtype=np.int32)
    labels[0, 2:4, 3:5] = 70001
    labels[1, 6, 7] = 2
    spacing = SourceVoxelSpacing((1.3556, 1.3556))
    metadata = ImagePayloadMetadata(
        plane_axis=RuntimePlaneAxis.SOURCE_BINDING,
        source_voxel_spacing=spacing,
        source_spatial_domain=SourceSpatialDomain(
            origin_yx=(0, 0), source_shape_yx=(8, 9)
        ),
        source_component_metadata={
            "well": "A01",
            "site": 1,
            "z_index": 1,
            "timepoint": 1,
        },
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s001_w2_z001_t001.tif",
            ),
            component_metadata=tuple(
                {
                    "well": "A01",
                    "site": 1,
                    "channel": channel,
                    "z_index": 1,
                    "timepoint": 1,
                }
                for channel in (1, 2)
            ),
        ),
    )
    payload = SourceImageObjectLabelBuildRequest(
        image=metadata.payload_with(np.zeros_like(labels)),
        labels=labels,
        plane_projection=RuntimePlaneAxisValueProjection.preserve(
            axis=RuntimePlaneAxis.SOURCE_BINDING, axis_size=2
        ),
    ).payload()
    filemanager = FileManager({"memory": MemoryStorageBackend()})
    outputs = materialization_outputs(
        MaterializationSpec(
            ImageFileOptions(
                filename_suffix=".labels.tif",
                filename_identity=MaterializedFilenameIdentity.ARTIFACT_NAME,
            )
        ),
        payload,
        "/analysis/A01_labels",
        filemanager,
    )
    assert len(outputs) == 1
    output = outputs[0]
    assert output.variable_components == ()
    assert output.metadata.source_voxel_spacing == spacing
    np.testing.assert_array_equal(output.content, labels)
    batches = _viewer_stream_backend_kwargs().filemanager_batches(outputs)
    assert len(batches) == 1
    projected_outputs, kwargs = batches[0]
    assert projected_outputs == outputs
    request = kwargs["stream_request"]
    assert request.source.item_fields["plane_component_values"] == {
        "channel": ["1", "2"]
    }
    backend = NapariStreamingBackend()
    try:
        batch = StreamingBatchMessageBuilder.build(
            backend,
            StreamingBatchMessageRequest(
                return_route=viewer_ack_return_route,
                data_list=[output.content],
                file_paths=[output.path],
                stream_request=request,
                component_names_request=backend.component_names_request(request),
                display_payload_extra=backend.display_payload_extra(request),
            ),
        )
        item = batch.batch_images[0]
        memory = SharedMemory(name=item["shm_name"])
        try:
            transmitted = np.ndarray(
                item["shape"], dtype=item["dtype"], buffer=memory.buf
            ).copy()
        finally:
            memory.close()
        assert transmitted.dtype == labels.dtype
        np.testing.assert_array_equal(transmitted, labels)
        assert output.metadata.source_voxel_spacing == spacing
        assert payload.metadata.source_voxel_spacing == spacing
    finally:
        backend.cleanup()


def test_image_file_materialization_densifies_sparse_named_object_labels() -> None:
    labels = SparseIJVLabelRows(
        np.array(
            (
                (1, 2, 7),
                (3, 4, 9),
            ),
            dtype=np.int32,
        )
    )
    payload = ObjectLabelSet(
        name="Worms",
        variant_data=ObjectLabelVariantData(labels=labels),
        representation=ObjectLabelRepresentation.SPARSE_IJV,
        source_spatial_domain=SourceSpatialDomain(
            origin_yx=(0, 0),
            source_shape_yx=(6, 8),
        ),
    )
    filemanager = FileManager({"memory": MemoryStorageBackend()})

    (output,) = materialization_outputs(
        MaterializationSpec(
            ImageFileOptions(
                filename_suffix=".labels.tif",
                filename_identity=MaterializedFilenameIdentity.ARTIFACT_NAME,
            )
        ),
        payload,
        "/analysis/A01_worms",
        filemanager,
        artifact_source_identity=SourceImageIdentity(
            path="/input/A01_s001_w1_z001_t001.tif",
        ),
    )

    assert isinstance(output.content, np.ndarray)
    assert output.content.shape == (6, 8)
    assert output.content[1, 2] == 7
    assert output.content[3, 4] == 9


def test_declared_path_selection_preserves_outputs_without_rendering_rois(monkeypatch):
    data = {
        "rows": [{"count": 2, "intensity": 1.25}],
        "mask": np.ones((8, 8), dtype=np.int32),
    }
    csv_options = CsvOptions(source="rows")
    json_options = JsonOptions(source="rows")
    filemanager = FileManager({"memory": MemoryStorageBackend()})
    expected = materialization_outputs(
        MaterializationSpec(csv_options, json_options),
        data,
        "/analysis/A01_counts",
        filemanager,
    )
    monkeypatch.setattr(
        "polystore.roi.extract_rois_from_labeled_mask",
        lambda *args, **kwargs: pytest.fail("Unselected ROI writer executed"),
    )
    actual = materialization_outputs(
        MaterializationSpec(csv_options, ROIOptions(source="mask"), json_options),
        data,
        "/analysis/A01_counts",
        filemanager,
        output_path_filter=partial(
            analysis_file_path_is_included,
            analysis_consolidation_config=AnalysisConsolidationConfig(
                file_extensions=(".csv", ".json"),
                exclude_patterns=(),
            ),
        ),
    )
    assert [(output.path, output.content) for output in actual] == [
        (output.path, output.content) for output in expected
    ]
    assert len(actual) == 2
    assert actual[0].require_text_content() == "count,intensity\r\n2,1.25\r\n"


def test_roi_output_projection_preserves_requested_summary_content():
    filemanager = FileManager({"memory": MemoryStorageBackend()})
    spec = MaterializationSpec(ROIOptions(min_area=0))
    data = np.ones((8, 8), dtype=np.int32)
    all_outputs = materialization_outputs(
        spec, data, "/analysis/A01_labels", filemanager
    )
    summaries = materialization_outputs(
        spec,
        data,
        "/analysis/A01_labels",
        filemanager,
        output_path_filter=lambda path: path.suffix == ".txt",
    )
    assert len(summaries) == 1
    assert [(output.path, output.content) for output in summaries] == [
        (output.path, output.content)
        for output in all_outputs
        if output.path.endswith(".txt")
    ]


class _TestViewerDisplayConfig(ViewerDisplayConfigABC):
    COMPONENT_ORDER = AllComponents.ordered_names()
    variable_size_handling = None
    auto_contrast = True

    def component_modes(self):
        return {}

    def display_payload_extra(self):
        return {}


class _TestViewerFilenameParser(ViewerFilenameParserABC):
    def parse_filename(self, filename):
        import re

        match = re.match(
            r"(?P<well>[A-Z]\d{2})_s(?P<site>\d+)_w(?P<channel>\d+)"
            r"(?:_z(?P<z_index>\d+))?(?:_t(?P<timepoint>\d+))?"
            r"(?P<extension>\.[^.]+)?$",
            filename,
        )
        if match is None:
            return None
        parsed = {
            key: value for key, value in match.groupdict().items() if value is not None
        }
        parsed.setdefault("z_index", "1")
        parsed.setdefault("timepoint", "1")
        return FilenameParseResult(
            ((component, parsed[component.value]) for component in AllComponents),
            extension=parsed.get("extension", ".tif"),
        )


class _TestViewerMetadataHandler(ViewerMetadataHandlerABC):
    def get_component_values(self, plate_path, component_name):
        return {}


class _TestViewerMicroscopeHandler(ViewerMicroscopeHandlerABC):
    parser = _TestViewerFilenameParser()
    metadata_handler = _TestViewerMetadataHandler()


def _viewer_stream_backend_kwargs():
    display_config = _TestViewerDisplayConfig()
    request = ViewerStreamRequest(
        viewer_transport=ViewerTransportEndpoint(
            host="localhost",
            port=5555,
            transport_mode=TransportMode.IPC,
        ),
        display_config=display_config,
        source=ViewerStreamSource(
            identity=ViewerStreamSourceIdentity(
                microscope_handler=_TestViewerMicroscopeHandler(),
                plate_path="/tmp/test_plate",
            ),
            metadata=BatchViewerStreamSourceMetadata(
                {
                    "timepoint": 1,
                    "z_index": 1,
                    "site": 1,
                    "well": "A01",
                    "channel": 1,
                }
            ),
        ),
        producer=ViewerStreamProducer.from_identity(
            StreamProducerIdentity.fixed_output(
                FixedStreamProducerIdentityKind.DIRECT,
                "test",
            )
        ),
    )
    return ViewerStreamBackendCallKwargs(ViewerStreamBackendKwargs(request))


def _viewer_stream_backend_kwargs_for_display(display_config):
    request = ViewerStreamRequest(
        viewer_transport=ViewerTransportEndpoint(
            host="localhost",
            port=5555,
            transport_mode=TransportMode.IPC,
        ),
        display_config=display_config,
        source=ViewerStreamSource(
            identity=ViewerStreamSourceIdentity(
                microscope_handler=_TestViewerMicroscopeHandler(),
                plate_path="/tmp/test_plate",
            ),
            metadata=BatchViewerStreamSourceMetadata(
                {
                    "timepoint": 1,
                    "z_index": 1,
                    "site": 1,
                    "well": "A01",
                    "channel": 1,
                }
            ),
        ),
        producer=ViewerStreamProducer.from_identity(
            StreamProducerIdentity.fixed_output(
                FixedStreamProducerIdentityKind.DIRECT,
                "test",
            )
        ),
    )
    return ViewerStreamBackendCallKwargs(ViewerStreamBackendKwargs(request))


def _stream_component_metadata(saved_item):
    stream_request = saved_item[3]["stream_request"]
    return stream_request.source.metadata.component_metadata_for_item(
        saved_item[1],
        0,
    )


def test_viewer_backend_batches_distinct_timepoints_by_exact_output_path() -> None:
    backend_kwargs = _viewer_stream_backend_kwargs()
    outputs = tuple(
        Output(
            path=f"/tmp/DrosophilaEmbryo-{timepoint:04d}.png",
            content=np.zeros((1, 8, 8, 3), dtype=np.uint8),
            metadata=ImagePayloadMetadata(
                source_path=f"/input/Sequence1_t{timepoint:03d}.tif",
                source_component_metadata={
                    "well": "Sequence1",
                    "site": 1,
                    "channel": 1,
                    "z_index": 1,
                    "timepoint": timepoint,
                },
                source_spatial_domain=SourceSpatialDomain(source_shape_yx=(8, 8)),
            ),
        )
        for timepoint in range(3)
    )

    batches = backend_kwargs.filemanager_batches(outputs)

    assert len(batches) == 1
    batch_outputs, kwargs = batches[0]
    assert batch_outputs == outputs
    stream_request = kwargs["stream_request"]
    assert tuple(
        stream_request.source.metadata.component_metadata_for_item(
            output.path,
            index,
        )["timepoint"]
        for index, output in enumerate(outputs)
    ) == (0, 1, 2)


def _stream_materialize(spec, data, path, filemanager, context=None):
    return materialize(
        spec,
        data=data,
        path=path,
        filemanager=filemanager,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        context=context,
    )


@pytest.mark.unit
def test_materialization_spec_candidate_paths_follow_registered_writers() -> None:
    assert csv_only(suffix=".csv").candidate_paths("/tmp/A01_measurements.pkl") == (
        "/tmp/A01_measurements.csv",
    )
    assert json_only().candidate_paths("/tmp/metadata.json") == ("/tmp/metadata.json",)
    assert text_only().candidate_paths("/tmp/report.txt") == ("/tmp/report.txt",)
    assert MaterializationSpec(ROIOptions()).candidate_paths(
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip"
    ) == (
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip",
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_segmentation_summary.txt",
    )
    assert tiff_stack().candidate_paths("/tmp/Overlay.pkl") == (
        "/tmp/Overlay_slice_000.tif",
        "/tmp/Overlay_summary.txt",
    )
    assert tiff_stack().candidate_paths("/tmp/A01_s001_w1_z001_t001.tif") == (
        "/tmp/A01_s001_w1_z001_t001.tif",
        "/tmp/A01_s001_w1_z001_t001_summary.txt",
    )


@pytest.mark.unit
def test_materialization_spec_declares_filename_identity() -> None:
    assert tiff_stack().uses_source_identity_filename()
    assert not tiff_stack(
        TiffStackOptions(filename_identity=MaterializedFilenameIdentity.ARTIFACT_NAME)
    ).uses_source_identity_filename()


@pytest.mark.parametrize(
    ("component", "component_values"),
    (
        (VariableComponents.TIMEPOINT, (0, 1)),
        (VariableComponents.Z_INDEX, (1, 2)),
    ),
)
def test_indexed_image_materialization_streams_each_declared_component_plane(
    component,
    component_values,
) -> None:
    data = np.zeros((2, 1, 8, 8, 3), dtype=np.uint8)
    payload = ImageMetadataPayload(
        data=data,
        metadata=ImagePayloadMetadata(
            plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
            source_channel_axis=-1,
            source_image_provenance_planes=(
                SourceImageProvenancePlanes.from_components(
                    component_metadata=tuple(
                        {
                            "well": "A01",
                            "site": 1,
                            "channel": 1,
                            "z_index": 1,
                            "timepoint": 1,
                            component.value: value,
                        }
                        for value in component_values
                    )
                )
            ),
        ),
    )
    spec = MaterializationSpec(
        ImageFileOptions(
            filename_identity=MaterializedFilenameIdentity.ARTIFACT_NAME,
            relative_path_template="frame-{index:04d}.png",
        )
    )
    assert spec.emits_variable_component_planes(payload)

    filemanager = _RecordingFileManager()
    materialize(
        spec,
        data=payload,
        path="/tmp/SavedImage",
        filemanager=filemanager,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        variable_components=(component,),
    )

    assert len(filemanager.saved) == 2
    streamed_components = []
    for _content, path, _backend, kwargs in filemanager.saved:
        request = kwargs["stream_request"]
        streamed_components.append(
            dict(request.source.metadata.component_metadata_for_item(path, 0))[
                component.value
            ]
        )
    assert tuple(streamed_components) == component_values


def _two_plane_roi_labels():
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    return labels


class _RecordingBackend(DataSink):
    requires_filesystem_validation = False

    def supports_file_path(self, _path):
        return True

    def save(self, data, identifier, **kwargs):
        raise AssertionError("Recording file manager owns save interception")

    def save_batch(self, data_list, identifiers, **kwargs):
        raise AssertionError("Recording file manager owns save interception")


class _RecordingFileManager:
    def __init__(self):
        self.saved = []

    def _get_backend(self, _backend):
        return _RecordingBackend()

    def save(self, content, path, backend, **kwargs):
        self.saved.append((content, path, backend, kwargs))

    def save_batch(self, contents, paths, backend, **kwargs):
        self.saved.extend(
            (content, path, backend, kwargs)
            for content, path in zip(contents, paths, strict=True)
        )


class _SourceSchemaMicroscopeHandler:
    parser = SourceSchemaFilenameParser()


class _SourceSchemaProcessingContext:
    microscope_handler = _SourceSchemaMicroscopeHandler()


def _addressable_roi_label_payload(
    first_path, second_path, first_metadata, second_metadata
):
    return ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=_two_plane_roi_labels()),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(first_path, second_path),
            component_metadata=(first_metadata, second_metadata),
        ),
    )


def _unaddressed_roi_label_payload():
    return ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=_two_plane_roi_labels()),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(None, None), component_metadata=(None, None)
        ),
    )


def _roi_target(roi_path, labels, metadata):
    return ROIMaterializationTarget(
        archive=ROIMaterializationArchiveIdentity.from_metadata(
            path=roi_path,
            metadata=metadata,
        ),
        items=(
            MaterializationInputItem(
                value=ObjectLabelPayload(
                    variant_data=ObjectLabelVariantData(labels=labels)
                ),
                source_description="materialization payload",
            ),
        ),
    )


@pytest.mark.unit
def test_materialize_strips_roi_zip_compound_suffix_for_json() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})

    spec = MaterializationSpec(JsonOptions(filename_suffix=".json"))
    out = materialize(
        spec,
        data={"ok": True},
        path="/tmp/A01_test_output.roi.zip",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_test_output.json"
    assert fm.load(out, "memory") == json.dumps({"ok": True}, indent=2, default=str)


@pytest.mark.unit
def test_csv_materialization_preserves_declared_fields_for_empty_rows() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})

    out = materialize(
        csv_only(fields=["object_label", "area"]),
        data=[],
        path="/tmp/A01_measurements",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_measurements_details.csv"
    assert fm.load(out, "memory").splitlines()[0] == "object_label,area"


@pytest.mark.unit
def test_measurement_table_materializes_csv_and_json_without_losing_its_owner() -> None:
    table = MeasurementTable(
        name="centres",
        rows=MeasurementSparseColumnarRows.from_rows(
            ({"object_label": 7, "z": 2.375, "y": 1.25, "x": 3.5},),
            fields=(
                FieldSpec("object_label", int),
                FieldSpec("z", float),
                FieldSpec("y", float),
                FieldSpec("x", float),
            ),
        ),
        source_path="/source/image.ome.tif",
        subject=MeasurementSubject(MeasurementScope.OBJECT, "nuclei", "object_label"),
    )
    fm = FileManager({"memory": MemoryStorageBackend()})

    materialize(
        MaterializationSpec(
            CsvOptions(filename_suffix=".csv"),
            JsonOptions(filename_suffix=".json"),
        ),
        data=table,
        path="/tmp/centres",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert fm.load("/tmp/centres.csv", "memory").splitlines() == [
        "object_label,z,y,x",
        "7,2.375,1.25,3.5",
    ]
    assert json.loads(fm.load("/tmp/centres.json", "memory")) == [
        {"object_label": 7, "z": 2.375, "y": 1.25, "x": 3.5}
    ]
    assert table.source_path == "/source/image.ome.tif"
    assert table.subject.object_id_field == "object_label"


@pytest.mark.unit
@pytest.mark.parametrize("source_z_origin", (0, 10))
def test_point_roi_materialization_native_reopen_preserves_fractional_z(
    tmp_path,
    source_z_origin,
) -> None:
    table = MeasurementTable(
        name="centres",
        rows=MeasurementSparseColumnarRows.from_rows(
            (
                {
                    "object_label": 7,
                    "center_z": 2.375,
                    "center_y": 1.25,
                    "center_x": 3.5,
                    "response": 4.75,
                },
            ),
            fields=(
                FieldSpec("object_label", int),
                FieldSpec("center_z", float),
                FieldSpec("center_y", float),
                FieldSpec("center_x", float),
                FieldSpec("response", float),
            ),
        ),
        source_path="/source/image.ome.tif",
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=("/source/image.ome.tif",) * 4,
            component_metadata=tuple(
                {"well": "A01", "site": 1, "channel": 1, "z_index": z, "timepoint": 1}
                for z in range(source_z_origin, source_z_origin + 4)
            ),
        ),
        subject=MeasurementSubject(MeasurementScope.OBJECT, "nuclei", "object_label"),
    )
    feature = ObjectCoreMeasurementFeature
    archive = materialize(
        MaterializationSpec(
            PointROIOptions(
                z_feature=feature.CENTER_Z,
                y_feature=feature.CENTER_Y,
                x_feature=feature.CENTER_X,
            )
        ),
        data=table,
        path=str(tmp_path / "centres"),
        filemanager=FileManager({"disk": DiskStorageBackend()}),
        backends=["disk"],
        backend_kwargs={},
    )
    rois = load_rois_from_zip(tmp_path / "centres_points.roi.zip")
    assert archive == str(tmp_path / "centres_points.roi.zip")
    assert len(rois) == 1
    assert rois[0].metadata["label"] == 7
    assert rois[0].metadata["object_label"] == 7
    assert rois[0].metadata["response"] == 4.75
    assert rois[0].shapes == [PointShape(y=1.25, x=3.5)]
    assert ROIFractionalZ.decode(rois[0].metadata) == ROIFractionalZ(2.375)
    metadata = ROIArchiveSourceMetadata.decode(rois)
    assert metadata.source_path == "/source/image.ome.tif"
    source_domain = ROIFractionalZ.source_component_domain(rois, metadata)
    z_values = [plane["z_index"] for plane in source_domain]
    assert z_values == list(range(source_z_origin, source_z_origin + 4))
    viewer_server = pytest.importorskip("openhcs.runtime.napari_viewer_server")
    projection = ViewerLayerAxisProjection(
        projected_axis_components=("z_index",),
        component_values={"z_index": z_values},
        routed_component_values={"z_index": z_values},
        axis_offsets=(0,),
    )
    item = NapariStreamLayerItem(
        data=NapariROIConverter.rois_to_shapes(rois),
        producer=StreamProducerIdentity.pipeline_output(
            output_kind="artifact", output_key="centres",
            projection_key="centres", step_name="Synthetic Centres",
            pipeline_position=0, step_scope_id="synthetic-centres",
        ),
        address=NapariStreamLayerAddress(
            components=source_domain[0], path=archive,
            stream_layer_data_type=StreamingDataType.POINTS,
        ),
        image_metadata=metadata,
        plane_component_domain=ViewerComponentValueDomainPayload.from_wire_mapping(
            {"z_index": z_values}, context="materialized point source domain",
        ),
    )
    points, properties = viewer_server._build_nd_points([item], projection)
    assert points.tolist() == [[2.375, 1.25, 3.5]]
    assert properties["label"] == [7]
    assert properties["object_label"] == [7]
    assert properties["response"] == [4.75]
    assert properties[NapariStreamLayerItem.ELEMENT_IDENTITY_FEATURE] == [
        item.element_identity(0)
    ]
    from napari.layers import Points

    native_layer = Points(points, properties=properties)
    assert native_layer.features.loc[0, "response"] == 4.75


@pytest.mark.unit
@pytest.mark.parametrize("source_z_origin", (0, 10))
@pytest.mark.parametrize("variable_components", ((), (VariableComponents.Z_INDEX,)))
def test_payload_label_roi_reopen_preserves_geometric_plane_domain(
    tmp_path, source_z_origin, variable_components,
):
    labels = np.zeros((4, 5, 7), dtype=np.int32)
    labels[0, 1:4, 2:5] = 7
    labels[2, 1:4, 2:5] = 7
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        domain=ObjectLabelDomain(scope=ObjectLabelDomainScope.PAYLOAD),
        plane_axis=None,
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=("/source/volume.ome.tif",) * 4,
            component_metadata=tuple(
                {"well": "A01", "site": 1, "channel": 1, "z_index": z, "timepoint": 1}
                for z in range(source_z_origin, source_z_origin + 4)
            ),
        ),
        source_spatial_domain=SourceSpatialDomain(source_shape_yx=(5, 7)),
        parent_image_source_voxel_spacing=SourceVoxelSpacing((2.0, 0.65, 0.65)),
    )
    archive = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload, path=str(tmp_path / "volume"),
        filemanager=FileManager({"disk": DiskStorageBackend()}),
        backends=["disk"], variable_components=variable_components,
    )
    rois = load_rois_from_zip(Path(archive))
    metadata = ROIArchiveSourceMetadata.decode(rois)
    assert payload.plane_axis is None
    assert metadata.plane_axis is (
        RuntimePlaneAxis.RUNTIME_SLICE if variable_components else None
    )
    assert metadata.source_voxel_spacing.values_zyx == (2.0, 0.65, 0.65)
    domain = ROIArchiveSourceMetadata.source_component_domain(rois, metadata)
    z_values = tuple(range(source_z_origin, source_z_origin + 4))
    assert tuple(plane["z_index"] for plane in domain) == z_values
    assert [ROIPlaneMetadata(roi.metadata).indices() for roi in rois] == [(0,), (2,)]
    fields = ROIArchiveSourceMetadata.stream_item_fields(rois, metadata, {})
    assert fields[ViewerWireField.PLANE_COMPONENT_VALUES.value] == {
        "z_index": tuple(str(value) for value in z_values),
    }
    # This geometric-domain projection never invents an image-plane field.
    assert ViewerWireField.PLANE_AXIS.value not in fields
    from openhcs.runtime.napari_streaming_handlers import (
        NapariAggregateAxisBinding, NapariAggregateAxisBindingSet,
        NapariShapeLayerPayload, NapariStreamLayerAddress, NapariStreamLayerItem,
    )
    from openhcs.runtime.viewer_component_system import ViewerComponentValueDomainPayload
    from polystore.streaming_constants import StreamingDataType
    plane_domain = ViewerComponentValueDomainPayload.from_wire_mapping(
        fields[ViewerWireField.PLANE_COMPONENT_VALUES.value], context="saved label ROI",
    )
    assert plane_domain.to_wire_mapping() == {"z_index": list(z_values)}

    native = NapariShapeLayerPayload.build(
        layer_items=[NapariStreamLayerItem(
            data=NapariROIConverter.rois_to_shapes(rois),
            producer=StreamProducerIdentity.fixed_output(
                FixedStreamProducerIdentityKind.MANUAL, "volume_reopen",
            ),
            address=NapariStreamLayerAddress(domain[0], archive, StreamingDataType.SHAPES),
            image_metadata=metadata,
            plane_component_domain=plane_domain,
        )],
        axis_projection=ViewerLayerAxisProjection(
            projected_axis_components=("z_index",),
            component_values={"z_index": list(z_values)},
            routed_component_values={"z_index": list(z_values)}, axis_offsets=(0,),
        ),
        aggregate_axis_bindings=NapariAggregateAxisBindingSet((
            NapariAggregateAxisBinding("z_index", 0, z_values),
        )),
    )
    assert native.ndim == 3
    assert [np.unique(shape[:, 0]).tolist() for shape in native.data] == [[0], [2]]
    assert native.features["label"] == [7, 7]
    from napari.layers import Shapes
    layer = Shapes(native.data, shape_type=native.shape_types, features=native.features)
    assert layer.ndim == 3
    assert layer.features["label"].tolist() == [7, 7]


@pytest.mark.unit
@pytest.mark.parametrize("metadata", (
    {"plane_indices": (4,), "plane_shape": (4,)},
    {"plane_indices": (0,)},
    {"plane_indices": (0, 1), "plane_shape": (4,)},
))
def test_roi_geometric_plane_metadata_rejects_invalid_projection(metadata):
    with pytest.raises(ValueError):
        ROIPlaneMetadata.common_shape((metadata,))


@pytest.mark.unit
@pytest.mark.parametrize(
    ("source_path", "rows", "error"),
    [
        (None, ((7, 2.375, 1.25, 3.5),), "source-image path"),
        ("/source/image.ome.tif", ((7, float("nan"), 1.25, 3.5),), "finite"),
        ("/source/image.ome.tif", (), "at least one"),
    ],
)
def test_point_roi_materialization_rejects_unreopenable_results(
    tmp_path, source_path, rows, error
) -> None:
    fields = (
        FieldSpec("object_label", int),
        FieldSpec("center_z", float),
        FieldSpec("center_y", float),
        FieldSpec("center_x", float),
    )
    table = MeasurementTable(
        name="centres",
        rows=MeasurementSparseColumnarRows.from_rows(
            tuple(dict(zip((field.name for field in fields), row)) for row in rows),
            fields=fields,
        ),
        source_path=source_path,
        subject=MeasurementSubject(MeasurementScope.OBJECT, "nuclei", "object_label"),
    )
    feature = ObjectCoreMeasurementFeature
    with pytest.raises(ValueError, match=error):
        materialize(
            MaterializationSpec(
                PointROIOptions(
                    z_feature=feature.CENTER_Z,
                    y_feature=feature.CENTER_Y,
                    x_feature=feature.CENTER_X,
                )
            ),
            data=table,
            path=str(tmp_path / "invalid"),
            filemanager=FileManager({"disk": DiskStorageBackend()}),
            backends=["disk"],
            backend_kwargs={},
        )
    assert not (tmp_path / "invalid_points.roi.zip").exists()


@pytest.mark.unit
def test_csv_materialization_preserves_declared_field_order_for_dict_rows() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})

    out = materialize(
        csv_only(fields=["object_label", "area"]),
        data=[{"area": 9, "object_label": 1, "ignored": 99}],
        path="/tmp/A01_measurements",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_measurements_details.csv"
    assert fm.load(out, "memory").splitlines() == ["object_label,area", "1,9"]


@pytest.mark.unit
def test_csv_materialization_expands_columnar_rows() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})

    out = materialize(
        csv_only(fields=["object_label", "area"]),
        data=MeasurementProjectedColumnarRows(
            {
                "object_label": (1, 2),
                "area": (9.0, 10.5),
            },
            fields=(
                FieldSpec("object_label", int),
                FieldSpec("area", float),
            ),
        ),
        path="/tmp/A01_measurements",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_measurements_details.csv"
    assert fm.load(out, "memory").splitlines() == [
        "object_label,area",
        "1,9.0",
        "2,10.5",
    ]


@pytest.mark.unit
def test_csv_materialization_expands_mapping_columns() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})

    out = materialize(
        csv_only(
            fields=[
                "relationship_type",
                "parent_id",
                "child_id",
                "slice_index",
                "slice_count",
            ]
        ),
        data={
            "relationship_type": "parent_child",
            "parent_id": (10, 11),
            "child_id": (1, 2),
            "slice_count": 2,
            "source_component_metadata": {"channel": "1"},
        },
        path="/tmp/A01_relationships",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_relationships_details.csv"
    assert fm.load(out, "memory").splitlines() == [
        "relationship_type,parent_id,child_id,slice_index,slice_count",
        "parent_child,10,1,0,2",
        "parent_child,11,2,1,2",
    ]


@pytest.mark.unit
def test_json_materialization_filters_to_declared_fields() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})

    out = materialize(
        json_materializer(fields=["object_label", "area"]),
        data=[{"object_label": 1, "area": 9, "ignored": 99}],
        path="/tmp/A01_measurements",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_measurements.json"
    assert json.loads(fm.load(out, "memory")) == [{"object_label": 1, "area": 9}]


@pytest.mark.unit
def test_tabular_field_names_from_materialization_reads_csv_and_json_options() -> None:
    assert tabular_field_names_from_materialization(
        csv_only(fields=["object_label", "area"])
    ) == ("object_label", "area")


@pytest.mark.unit
def test_empty_columnar_csv_retains_its_nominal_schema() -> None:
    filemanager = FileManager({"memory": MemoryStorageBackend()})
    rows = MeasurementProjectedColumnarRows(
        columns={"cell_id": (), "area": ()},
        fields=(FieldSpec("cell_id", int), FieldSpec("area", float)),
        declared_object_measurement_domain_covered=True,
        object_row_identity=None,
    )

    output_path = materialize(
        csv_only(),
        data=rows,
        path="/tmp/A01_cells",
        filemanager=filemanager,
        backends=["memory"],
        backend_kwargs={},
    )

    assert filemanager.load(output_path, "memory") == "cell_id,area\r\n"
    assert tabular_field_names_from_materialization(
        json_only(fields=["object_label", "area"])
    ) == ("object_label", "area")


@pytest.mark.unit
def test_tiff_stack_preserves_channels_last_color_image_as_single_file() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    image = np.zeros((5, 7, 3), dtype=np.uint8)

    out = materialize(
        tiff_stack(),
        data=image,
        path="/tmp/A01_rgb",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_rgb_slice_000.tif"
    assert fm.exists(out, "memory")
    assert not fm.exists("/tmp/A01_rgb_slice_001.tif", "memory")


@pytest.mark.unit
def test_tiff_stack_splits_scalar_3d_stack_by_plane() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    stack = ImageMetadataPayload(
        data=np.zeros((3, 5, 7), dtype=np.uint8),
        metadata=ImagePayloadMetadata(
            plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        ),
    )

    out = materialize(
        tiff_stack(),
        data=stack,
        path="/tmp/A01_stack",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    assert out == "/tmp/A01_stack_slice_000.tif"
    assert fm.exists("/tmp/A01_stack_slice_000.tif", "memory")
    assert fm.exists("/tmp/A01_stack_slice_001.tif", "memory")
    assert fm.exists("/tmp/A01_stack_slice_002.tif", "memory")
    assert not fm.exists("/tmp/A01_stack_slice_003.tif", "memory")


@pytest.mark.unit
def test_tiff_stack_streaming_saves_per_slice_component_metadata() -> None:
    fm = _RecordingFileManager()
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=np.zeros((2, 5, 7), dtype=np.int32)),
        plane_axis=RuntimePlaneAxis.SOURCE_BINDING,
        domain=ObjectLabelDomain(
            scope=ObjectLabelDomainScope.PLANE,
            declared_object_id_domains=((), ()),
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            component_metadata=(
                {"well": "A01", "site": 1, "z_index": 1, "channel": 1, "timepoint": 1},
                {"well": "A01", "site": 2, "z_index": 1, "channel": 1, "timepoint": 1},
            )
        ),
    )

    materialize(
        tiff_stack(),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_NucleiObjects3D_step9",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
    )

    saved_slices = [
        item
        for item in fm.saved
        if item[1].endswith(("_slice_000.tif", "_slice_001.tif"))
    ]
    assert [_stream_component_metadata(item) for item in saved_slices] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 1},
        {"timepoint": 1, "z_index": 1, "site": 2, "well": "A01", "channel": 1},
    ]


@pytest.mark.unit
def test_tiff_stack_streaming_projects_scalar_metadata_over_declared_stack_axis() -> (
    None
):
    fm = _RecordingFileManager()
    payload = ImageMetadataPayload(
        data=np.zeros((2, 5, 7), dtype=np.float32),
        metadata=ImagePayloadMetadata(
            plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
            source_component_metadata={
                "well": "A01",
                "site": 1,
                "z_index": 1,
                "channel": 3,
                "timepoint": 1,
            },
        ),
    )

    materialize(
        tiff_stack(),
        data=payload,
        path="/tmp/A01_s001_w3_z001_t001_DerivedStack_step6",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        variable_components=(VariableComponents.Z_INDEX,),
    )

    saved_images = [
        item
        for item in fm.saved
        if item[1].endswith(("_slice_000.tif", "_slice_001.tif"))
    ]
    assert [_stream_component_metadata(item) for item in saved_images] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 3},
        {"timepoint": 1, "z_index": 2, "site": 1, "well": "A01", "channel": 3},
    ]


@pytest.mark.unit
def test_tiff_stack_projection_skips_axes_already_varying_in_slice_metadata() -> None:
    items = tuple(
        MaterializationInputItem(
            value=ImagePayloadMetadata(
                source_component_metadata={
                    AllComponents.WELL.value: "A01",
                    AllComponents.SITE.value: 1,
                    AllComponents.Z_INDEX.value: index + 1,
                    AllComponents.CHANNEL.value: 3,
                    AllComponents.TIMEPOINT.value: 1,
                },
            ).payload_with(np.zeros((5, 7), dtype=np.float32), None),
            source_description="materialization payload",
            runtime_plane_metadata=RuntimeProjectionPlaneMetadata(
                plane_indices=(index,),
                plane_shape=(3,),
            ),
        )
        for index in range(3)
    )

    axes = RuntimePlaneStackAxesProjectionSelection(
        (VariableComponents.Z_INDEX, VariableComponents.CHANNEL),
        items,
    ).axes()

    assert axes == frozenset()


@pytest.mark.unit
def test_tiff_stack_projection_rejects_ambiguous_scalar_declared_axes() -> None:
    items = tuple(
        MaterializationInputItem(
            value=ImagePayloadMetadata(
                source_component_metadata={
                    AllComponents.WELL.value: "A01",
                    AllComponents.SITE.value: 1,
                    AllComponents.CHANNEL.value: 3,
                },
            ).payload_with(np.zeros((5, 7), dtype=np.float32), None),
            source_description="materialization payload",
            runtime_plane_metadata=RuntimeProjectionPlaneMetadata(
                plane_indices=(index,),
                plane_shape=(3,),
            ),
        )
        for index in range(3)
    )

    with pytest.raises(ValueError, match="cannot map runtime plane metadata"):
        RuntimePlaneStackAxesProjectionSelection(
            (VariableComponents.Z_INDEX, VariableComponents.CHANNEL),
            items,
        ).axes()


@pytest.mark.unit
def test_tiff_stack_projection_uses_artifact_scalar_z_origin() -> None:
    items = tuple(
        MaterializationInputItem(
            value=np.zeros((5, 7), dtype=np.float32),
            source_description="materialization payload",
            runtime_plane_metadata=RuntimeProjectionPlaneMetadata(
                plane_indices=(index,),
                plane_shape=(3,),
            ),
        )
        for index in range(3)
    )

    axes = RuntimePlaneStackAxesProjectionSelection(
        (VariableComponents.Z_INDEX, VariableComponents.CHANNEL),
        items,
        SourceImageIdentity(
            component_metadata={
                AllComponents.WELL.value: "A01",
                AllComponents.SITE.value: 1,
                AllComponents.Z_INDEX.value: 1,
                AllComponents.CHANNEL.value: 3,
            },
        ),
    ).axes()

    assert axes == frozenset((AllComponents.Z_INDEX.value,))


@pytest.mark.unit
def test_tiff_stack_streaming_preserves_runtime_source_plane_metadata() -> None:
    fm = _RecordingFileManager()
    payload = ImagePayloadMetadata(
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        source_path="/tmp/A01_s001_w3_z001_t001.tif",
        source_component_metadata={
            "well": "A01",
            "site": 1,
            "z_index": 1,
            "channel": 3,
            "timepoint": 1,
            SOURCE_PLANE_INDEX_FIELD: "0",
            SOURCE_PLANE_COUNT_FIELD: "2",
        },
    ).payload_with(np.zeros((2, 5, 7), dtype=np.float32), None)

    materialize(
        tiff_stack(),
        data=payload,
        path="/tmp/A01_s001_w3_z001_t001_DerivedStack_step6",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        variable_components=(
            VariableComponents.Z_INDEX,
            VariableComponents.CHANNEL,
        ),
    )

    saved_images = [
        item
        for item in fm.saved
        if item[1].endswith(("_slice_000.tif", "_slice_001.tif"))
    ]
    assert [_stream_component_metadata(item) for item in saved_images] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 3},
        {"timepoint": 1, "z_index": 2, "site": 1, "well": "A01", "channel": 3},
    ]


@pytest.mark.unit
def test_tiff_stack_streaming_projects_artifact_identity_over_declared_stack_axis() -> (
    None
):
    fm = _RecordingFileManager()

    materialize(
        tiff_stack(),
        data=ImageMetadataPayload(
            data=np.zeros((2, 5, 7), dtype=np.float32),
            metadata=ImagePayloadMetadata(
                plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
            ),
        ),
        path="/tmp/A01_s001_w3_z001_t001_DerivedStack_step6",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        artifact_source_identity=SourceImageIdentity(
            component_metadata={
                "well": "A01",
                "site": 1,
                "z_index": 1,
                "channel": 3,
                "timepoint": 1,
            },
        ),
        variable_components=(VariableComponents.Z_INDEX,),
    )

    saved_images = [
        item
        for item in fm.saved
        if item[1].endswith(("_slice_000.tif", "_slice_001.tif"))
    ]
    assert [_stream_component_metadata(item) for item in saved_images] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 3},
        {"timepoint": 1, "z_index": 2, "site": 1, "well": "A01", "channel": 3},
    ]


@pytest.mark.unit
def test_tiff_stack_streaming_uses_single_plane_scalar_source_identity() -> None:
    fm = _RecordingFileManager()
    payload = ImageMetadataPayload(
        data=np.zeros((5, 7, 3), dtype=np.float32),
        metadata=ImagePayloadMetadata(
            source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
                component_metadata=(
                    {
                        "well": "A01",
                        "site": 1,
                        "z_index": 1,
                        "channel": 3,
                        "timepoint": 1,
                    },
                )
            ),
        ),
    )

    materialize(
        tiff_stack(),
        data=payload,
        path="/tmp/A01_s001_w3_z001_t001_SanityCheck_step6",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
    )

    saved_images = [item for item in fm.saved if item[1].endswith(".tif")]
    assert len(saved_images) == 1
    assert _stream_component_metadata(saved_images[0]) == {
        "timepoint": 1,
        "z_index": 1,
        "site": 1,
        "well": "A01",
        "channel": 3,
    }


@pytest.mark.unit
def test_materialized_tiff_output_uses_artifact_source_identity_as_fallback() -> None:
    fm = _RecordingFileManager()
    payload = ImageMetadataPayload(
        data=np.zeros((5, 7, 3), dtype=np.float32),
        metadata=ImagePayloadMetadata(
            source_component_metadata={
                "well": "A01",
                "site": 1,
                "z_index": 1,
                "channel": 3,
            },
        ),
    )

    materialize(
        tiff_stack(),
        data=payload,
        path="/tmp/A01_s001_w3_z001_t020_AdjacentImage_step6",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={
            "napari_stream": _viewer_stream_backend_kwargs_for_display(
                _TestViewerDisplayConfig()
            )
        },
        artifact_source_identity=SourceImageIdentity(
            component_metadata={
                "well": "A01",
                "site": 1,
                "z_index": 1,
                "channel": 1,
                "timepoint": 20,
            },
        ),
    )

    saved_images = [item for item in fm.saved if item[1].endswith(".tif")]
    assert len(saved_images) == 1
    assert _stream_component_metadata(saved_images[0]) == {
        "well": "A01",
        "site": 1,
        "z_index": 1,
        "channel": 3,
        "timepoint": 20,
    }


@pytest.mark.unit
def test_roi_materialization_offsets_object_label_payload_geometry() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    labels = np.zeros((8, 8), dtype=np.int32)
    labels[2:6, 3:7] = 1
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        source_spatial_domain=SourceSpatialDomain(origin_yx=(10, 20)),
    )

    out = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    rois = fm.load(out, "memory")
    assert out == "/tmp/A01_Nuclei_step3_rois.roi.zip"
    assert rois[0].metadata["bbox"] == (12, 23, 16, 27)
    assert rois[0].metadata["centroid"] == (13.5, 24.5)
    assert float(rois[0].shapes[0].coordinates[:, 0].min()) >= 11.5
    assert float(rois[0].shapes[0].coordinates[:, 1].min()) >= 22.5


@pytest.mark.unit
def test_roi_viewer_stream_preserves_source_spatial_domain() -> None:
    fm = _RecordingFileManager()
    labels = np.zeros((8, 8), dtype=np.int32)
    labels[2:6, 3:7] = 1
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        source_component_metadata={
            "well": "A01",
            "site": 1,
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
        },
        source_spatial_domain=SourceSpatialDomain(
            origin_yx=(10, 20),
            source_shape_yx=(100, 200),
        ),
    )

    materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
    )

    roi_outputs = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert len(roi_outputs) == 1
    stream_source = roi_outputs[0][3]["stream_request"].source
    assert stream_source.item_fields == {
        "spatial_origin_yx": [10, 20],
        "source_spatial_shape_yx": [100, 200],
        ViewerWireField.IMAGE_METADATA.value: ImagePayloadMetadata(
            source_spatial_domain=SourceSpatialDomain(
                origin_yx=(10, 20),
                source_shape_yx=(100, 200),
                value_name="ROI materialization source image",
            )
        ).to_viewer_image_metadata(),
    }


@pytest.mark.unit
def test_roi_materialization_extracts_each_plane_from_object_label_stack() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
    )

    out = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    rois = fm.load(out, "memory")
    assert out == "/tmp/A01_Nuclei_step3_rois.roi.zip"
    assert [roi.metadata["label"] for roi in rois] == [1, 2]
    assert [roi.metadata["plane_indices"] for roi in rois] == [(0,), (1,)]
    assert all(roi.metadata["plane_shape"] == (2,) for roi in rois)
    assert all(roi.metadata["spatial_origin_yx"] == (0, 0) for roi in rois)
    assert all(roi.metadata["source_spatial_shape_yx"] == (8, 8) for roi in rois)
    summary = fm.load(
        "/tmp/A01_Nuclei_step3_segmentation_summary.txt",
        "memory",
    )
    assert "Spatial dimensions: 2D" in summary
    assert "Projected source planes: 2" in summary
    assert "Z-planes" not in summary


@pytest.mark.unit
def test_roi_materialization_preserves_payload_scoped_volume_in_one_archive() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=_two_plane_roi_labels())
    )

    out = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    rois = fm.load(out, "memory")
    assert payload.object_label_domain().scope is ObjectLabelDomainScope.PAYLOAD
    assert out == "/tmp/A01_Nuclei_step3_rois.roi.zip"
    assert [roi.metadata["label"] for roi in rois] == [1, 2]
    assert [roi.metadata["plane_indices"] for roi in rois] == [(0,), (1,)]
    assert all(roi.metadata["plane_shape"] == (2,) for roi in rois)


@pytest.mark.unit
def test_roi_streaming_maps_payload_scoped_volume_planes_from_provenance(viewer_ack_return_route) -> None:
    fm = _RecordingFileManager()
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=_two_plane_roi_labels()),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s001_w1_z002_t001.tif",
            ),
            component_metadata=(
                {
                    "well": "A01",
                    "site": 1,
                    "channel": 1,
                    "z_index": 1,
                    "timepoint": 1,
                },
                {
                    "well": "A01",
                    "site": 1,
                    "channel": 1,
                    "z_index": 2,
                    "timepoint": 1,
                },
            ),
        ),
    )

    materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        variable_components=(VariableComponents.Z_INDEX,),
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert len(roi_saves) == 1
    roi_content, roi_path, _backend, stream_kwargs = roi_saves[0]
    stream_request = stream_kwargs["stream_request"]
    item_fields = stream_request.source.item_fields
    assert item_fields["plane_axis"] == RuntimePlaneAxis.RUNTIME_SLICE.value
    assert item_fields["plane_component_values"] == {"z_index": ["1", "2"]}

    napari_backend = NapariStreamingBackend()
    streamed_item = StreamingBatchMessageBuilder.build(
        napari_backend,
        StreamingBatchMessageRequest(
            return_route=viewer_ack_return_route,
            data_list=[roi_content],
            file_paths=[roi_path],
            stream_request=stream_request,
            component_names_request=napari_backend.component_names_request(
                stream_request
            ),
            display_payload_extra=napari_backend.display_payload_extra(stream_request),
        ),
    ).batch_images[0]
    assert streamed_item["plane_axis"] == RuntimePlaneAxis.RUNTIME_SLICE.value
    assert streamed_item["plane_component_values"] == {"z_index": ["1", "2"]}


@pytest.mark.unit
def test_roi_materialization_projects_singleton_object_label_stack() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    labels = np.zeros((1, 8, 8), dtype=np.int32)
    labels[0, 2:6, 3:7] = 1
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,),),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            component_metadata=({"well": "A01", "site": 1, "channel": 1},),
        ),
    )

    out = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )

    rois = fm.load(out, "memory")
    assert out == "/tmp/A01_Nuclei_step3_rois.roi.zip"
    assert [roi.metadata["label"] for roi in rois] == [1]


@pytest.mark.unit
def test_roi_streaming_preserves_singleton_projected_source_metadata() -> None:
    fm = _RecordingFileManager()
    labels = np.zeros((1, 8, 8), dtype=np.int32)
    labels[0, 2:6, 3:7] = 1
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,),),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=("/input/A01_s001_w1_z001_t001.tif",),
            component_metadata=({"well": "A01", "site": 1, "channel": 1},),
        ),
    )

    out = _stream_materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        payload,
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        fm,
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert out == "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip"
    assert [item[1] for item in roi_saves] == [
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip",
    ]
    assert [_stream_component_metadata(item) for item in roi_saves] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 1},
    ]


@pytest.mark.unit
def test_roi_streaming_maps_singleton_plane_from_exact_output_component(
    viewer_ack_return_route,
) -> None:
    fm = _RecordingFileManager()
    labels = np.zeros((1, 8, 8), dtype=np.int32)
    labels[0, 2:6, 3:7] = 1
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        source_path="/input/A01_s001_w1_z001_t001.tif",
        source_component_metadata={
            "site": 1,
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
            "well": "A01",
        },
    )
    assert payload.object_label_domain().scope is ObjectLabelDomainScope.PAYLOAD

    materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        variable_components=(VariableComponents.SITE,),
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert len(roi_saves) == 1
    roi_content, roi_path, _backend, stream_kwargs = roi_saves[0]
    stream_request = stream_kwargs["stream_request"]
    assert stream_request.source.item_fields == {
        "plane_axis": RuntimePlaneAxis.RUNTIME_SLICE.value,
        "plane_component_values": {"site": ["1"]},
        "spatial_origin_yx": [0, 0],
        "source_spatial_shape_yx": [8, 8],
        ViewerWireField.IMAGE_METADATA.value: ImagePayloadMetadata(
            source_spatial_domain=SourceSpatialDomain(
                origin_yx=(0, 0),
                source_shape_yx=(8, 8),
                value_name="ROI materialization source image",
            ),
            plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        ).to_viewer_image_metadata(),
    }

    napari_backend = NapariStreamingBackend()
    streamed_item = StreamingBatchMessageBuilder.build(
        napari_backend,
        StreamingBatchMessageRequest(
            return_route=viewer_ack_return_route,
            data_list=[roi_content],
            file_paths=[roi_path],
            stream_request=stream_request,
            component_names_request=napari_backend.component_names_request(
                stream_request
            ),
            display_payload_extra=napari_backend.display_payload_extra(stream_request),
        ),
    ).batch_images[0]
    assert streamed_item["plane_axis"] == RuntimePlaneAxis.RUNTIME_SLICE.value
    assert streamed_item["plane_component_values"] == {"site": ["1"]}


@pytest.mark.unit
def test_generic_object_labels_feed_napari_and_fiji_roi_transports(
    viewer_ack_return_route,
) -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    labels = np.zeros((8, 8), dtype=np.int32)
    labels[2:6, 3:7] = 1
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
    )
    roi_path = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_cells_step3.roi.zip",
        filemanager=fm,
        backends=["memory"],
        backend_kwargs={},
    )
    rois = fm.load(roi_path, "memory")
    stream_request = _viewer_stream_backend_kwargs().values.stream_request
    napari_backend = NapariStreamingBackend()
    napari_items = StreamingBatchMessageBuilder.build(
        napari_backend,
        StreamingBatchMessageRequest(
            return_route=viewer_ack_return_route,
            data_list=[rois],
            file_paths=[roi_path],
            stream_request=stream_request,
            component_names_request=napari_backend.component_names_request(
                stream_request
            ),
            display_payload_extra=napari_backend.display_payload_extra(stream_request),
        ),
    ).batch_images
    fiji_backend = FijiStreamingBackend()
    fiji_items = StreamingBatchMessageBuilder.build(
        fiji_backend,
        StreamingBatchMessageRequest(
            return_route=viewer_ack_return_route,
            data_list=[rois],
            file_paths=[roi_path],
            stream_request=stream_request,
            component_names_request=fiji_backend.component_names_request(
                stream_request
            ),
            display_payload_extra=fiji_backend.display_payload_extra(stream_request),
        ),
    )
    fiji_items = fiji_items.batch_images

    assert [item["data_type"] for item in napari_items] == ["shapes"]
    assert [item["data_type"] for item in fiji_items] == ["rois"]
    assert napari_items[0]["shapes"]
    assert fiji_items[0]["rois"]


@pytest.mark.unit
def test_roi_materialization_splits_addressable_label_planes_for_streaming() -> None:
    fm = _RecordingFileManager()
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s002_w1_z001_t001.tif",
            ),
            component_metadata=(
                {"well": "A01", "site": 1, "channel": 1},
                {"well": "A01", "site": 2, "channel": 1},
            ),
        ),
    )

    out = materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert out == "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip"
    assert [item[1] for item in roi_saves] == [
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip",
        "/tmp/A01_s002_w1_z001_t001_Nuclei_step3_rois.roi.zip",
    ]
    assert [_stream_component_metadata(item) for item in roi_saves] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 1},
        {"timepoint": 1, "z_index": 1, "site": 2, "well": "A01", "channel": 1},
    ]
    assert [len(item[0]) for item in roi_saves] == [1, 1]
    assert all(
        "plane_indices" not in roi.metadata and "plane_shape" not in roi.metadata
        for content, _path, _backend, _kwargs in roi_saves
        for roi in content
    )


@pytest.mark.unit
def test_roi_materialization_replaces_parser_equivalent_reference_source_prefix() -> (
    None
):
    fm = _RecordingFileManager()
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/images_Illum-corrected/plate1_A14_site1_Ch1.tif",
                "/input/images_Illum-corrected/plate1_A14_site2_Ch1.tif",
            ),
            component_metadata=(
                {
                    "well": "A14",
                    "site": 1,
                    "channel": 1,
                    "z_index": 1,
                    "timepoint": 1,
                    "extension": ".tif",
                },
                {
                    "well": "A14",
                    "site": 2,
                    "channel": 1,
                    "z_index": 1,
                    "timepoint": 1,
                    "extension": ".tif",
                },
            ),
        ),
    )

    out = _stream_materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        payload,
        "/tmp/A14_s001_w1_z001_t001_Nuclei_step0.roi.zip",
        fm,
        context=_SourceSchemaProcessingContext(),
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert out == "/tmp/plate1_A14_site1_Ch1_Nuclei_step0_rois.roi.zip"
    assert [item[1] for item in roi_saves] == [
        "/tmp/plate1_A14_site1_Ch1_Nuclei_step0_rois.roi.zip",
        "/tmp/plate1_A14_site2_Ch1_Nuclei_step0_rois.roi.zip",
    ]
    assert [_stream_component_metadata(item) for item in roi_saves] == [
        {
            "well": "A14",
            "site": 1,
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
        },
        {
            "well": "A14",
            "site": 2,
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
        },
    ]


@pytest.mark.unit
def test_roi_materialization_uses_filename_identity_without_restoring_collapsed_site() -> (
    None
):
    filemanager = _RecordingFileManager()
    payload = _addressable_roi_label_payload(
        None,
        None,
        {
            "well": "A01",
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
            "extension": ".tif",
        },
        {
            "well": "A01",
            "channel": 2,
            "z_index": 1,
            "timepoint": 1,
            "extension": ".tif",
        },
    )

    outputs = materialization_outputs(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_neurons_step5.roi.zip",
        filemanager=filemanager,
        context=_SourceSchemaProcessingContext(),
        artifact_source_identity=SourceImageIdentity(
            component_metadata={
                "well": "A01",
                "z_index": 1,
                "timepoint": 1,
                "extension": ".tif",
            }
        ),
        artifact_filename_identity=SourceImageIdentity(
            path="/input/A01_s001_w1_z001_t001.tif",
            component_metadata={
                "well": "A01",
                "site": 1,
                "channel": 1,
                "z_index": 1,
                "timepoint": 1,
                "extension": ".tif",
            },
        ),
    )

    roi_outputs = [output for output in outputs if output.path.endswith(".roi.zip")]
    assert [output.path for output in roi_outputs] == [
        "/tmp/A01_neurons_step5_A01_s001_w1_z001_t001_rois.roi.zip",
        "/tmp/A01_neurons_step5_A01_s001_w2_z001_t001_rois.roi.zip",
    ]
    assert [
        dict(output.metadata.source_component_metadata or {}) for output in roi_outputs
    ] == [
        {
            "well": "A01",
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
            "extension": ".tif",
        },
        {
            "well": "A01",
            "channel": 2,
            "z_index": 1,
            "timepoint": 1,
            "extension": ".tif",
        },
    ]


@pytest.mark.unit
def test_roi_streaming_applies_target_metadata_without_scalar_stream_metadata() -> None:
    fm = _RecordingFileManager()
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s002_w1_z001_t001.tif",
            ),
            component_metadata=(
                {"well": "A01", "site": 1, "channel": 1},
                {"well": "A01", "site": 2, "channel": 1},
            ),
        ),
    )

    materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert [_stream_component_metadata(item) for item in roi_saves] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A01", "channel": 1},
        {"timepoint": 1, "z_index": 1, "site": 2, "well": "A01", "channel": 1},
    ]


@pytest.mark.unit
def test_roi_materialization_coalesces_duplicate_stream_targets() -> None:
    fm = _RecordingFileManager()
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s001_w1_z001_t001.tif",
            ),
            component_metadata=(
                {"well": "A01", "site": 1, "channel": 1},
                {"well": "A01", "site": 1, "channel": 1},
            ),
        ),
    )

    materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert [item[1] for item in roi_saves] == [
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip",
    ]
    assert _stream_component_metadata(roi_saves[0]) == {
        "timepoint": 1,
        "z_index": 1,
        "site": 1,
        "well": "A01",
        "channel": 1,
    }
    assert len(roi_saves[0][0]) == 2


@pytest.mark.unit
def test_roi_materialization_coalesces_source_stack_archive_with_artifact_identity() -> (
    None
):
    fm = _RecordingFileManager()
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s001_w1_z001_t001.tif",
            ),
            component_metadata=(
                {
                    "well": "A01",
                    "site": 1,
                    "channel": 1,
                    "z_index": 1,
                    "timepoint": 1,
                    "extension": ".tif",
                },
                {
                    "well": "A01",
                    "site": 1,
                    "channel": 1,
                    "z_index": 2,
                    "timepoint": 1,
                    "extension": ".tif",
                },
            ),
        ),
    )

    materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        data=payload,
        path="/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        filemanager=fm,
        backends=["napari_stream"],
        backend_kwargs={"napari_stream": _viewer_stream_backend_kwargs()},
        artifact_source_identity=SourceImageIdentity(
            component_metadata={
                "well": "A01",
                "site": 1,
                "channel": 1,
                "z_index": 1,
                "timepoint": 1,
                "extension": ".tif",
            },
        ),
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert [item[1] for item in roi_saves] == [
        "/tmp/A01_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip",
    ]
    assert _stream_component_metadata(roi_saves[0]) == {
        "timepoint": 1,
        "z_index": 1,
        "site": 1,
        "well": "A01",
        "channel": 1,
    }
    assert len(roi_saves[0][0]) == 2


@pytest.mark.unit
def test_roi_materialization_coalesces_same_stream_address_from_distinct_sources() -> (
    None
):
    roi_path = "/tmp/plate1_A14_site1_Ch1_Nuclei_step0_rois.roi.zip"
    coalesced = ROIMaterializationTargetCoalescer().coalesce(
        (
            _roi_target(
                roi_path,
                np.zeros((8, 8), dtype=np.int32),
                ImagePayloadMetadata(
                    source_path="/input/source_a.tif",
                    source_component_metadata={
                        "well": "A14",
                        "site": 1,
                        "channel": 1,
                    },
                ),
            ),
            _roi_target(
                roi_path,
                np.ones((8, 8), dtype=np.int32),
                ImagePayloadMetadata(
                    source_path="/input/source_b.tif",
                    source_component_metadata={
                        "well": "A14",
                        "site": 1,
                        "channel": 1,
                    },
                ),
            ),
        )
    )

    assert len(coalesced) == 1
    assert coalesced[0].archive.path == roi_path
    assert len(coalesced[0].items) == 2


@pytest.mark.unit
def test_roi_materialization_coalesces_localized_duplicate_source_stems() -> None:
    roi_path = "/tmp/plate1_A14_site1_Ch1_Nuclei_step0_rois.roi.zip"
    coalesced = ROIMaterializationTargetCoalescer().coalesce(
        (
            _roi_target(
                roi_path,
                np.zeros((8, 8), dtype=np.int32),
                ImagePayloadMetadata(
                    source_path="/tutorial/images_Illum-corrected/plate1_A14_site1_Ch1.tif",
                    source_component_metadata={
                        "well": "A14",
                        "site": 1,
                        "channel": 1,
                    },
                ),
            ),
            _roi_target(
                roi_path,
                np.ones((8, 8), dtype=np.int32),
                ImagePayloadMetadata(
                    source_path="/tutorial/Archive_EN/images_Illum-corrected/plate1_A14_site1_Ch1.tif",
                ),
            ),
        )
    )

    assert len(coalesced) == 1
    assert coalesced[0].archive.path == roi_path
    assert len(coalesced[0].items) == 2
    assert dict(coalesced[0].archive.source_component_metadata) == {
        "well": "A14",
        "site": 1,
        "channel": 1,
    }


@pytest.mark.unit
def test_roi_materialization_rejects_component_conflict_after_path_only_target() -> (
    None
):
    roi_path = "/tmp/plate1_A14_site1_Ch1_Nuclei_step0_rois.roi.zip"
    with pytest.raises(ValueError, match="conflicting stream identities"):
        ROIMaterializationTargetCoalescer().coalesce(
            (
                _roi_target(
                    roi_path,
                    np.zeros((8, 8), dtype=np.int32),
                    ImagePayloadMetadata(
                        source_path="/tutorial/Archive_EN/images_Illum-corrected/plate1_A14_site1_Ch1.tif",
                    ),
                ),
                _roi_target(
                    roi_path,
                    np.ones((8, 8), dtype=np.int32),
                    ImagePayloadMetadata(
                        source_path="/tutorial/images_Illum-corrected/plate1_A14_site1_Ch1.tif",
                        source_component_metadata={
                            "well": "A14",
                            "site": 1,
                            "channel": 1,
                        },
                    ),
                ),
                _roi_target(
                    roi_path,
                    np.full((8, 8), 2, dtype=np.int32),
                    ImagePayloadMetadata(
                        source_path="/tutorial/images_Illum-corrected/plate1_A14_site2_Ch1.tif",
                        source_component_metadata={
                            "well": "A14",
                            "site": 2,
                            "channel": 1,
                        },
                    ),
                ),
            )
        )


@pytest.mark.unit
def test_roi_materialization_rejects_conflicting_duplicate_archive_identity() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    payload = _addressable_roi_label_payload(
        "/input/A01_s001_w1_z001_t001.tif",
        "/input/A01_s001_w1_z001_t001.tif",
        {"well": "A01", "site": 1, "channel": 1},
        {"well": "A01", "site": 2, "channel": 1},
    )

    with pytest.raises(ValueError, match="conflicting stream identities"):
        _memory_materialize(
            MaterializationSpec(ROIOptions(min_area=0)),
            payload,
            "/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
            fm,
        )


@pytest.mark.unit
def test_roi_materialization_uses_source_context_for_partial_label_stack() -> None:
    fm = _RecordingFileManager()
    source_image = ImageMetadataPayload(
        data=np.zeros((2, 8, 8), dtype=np.float32),
        metadata=ImagePayloadMetadata(
            source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
                paths=(
                    "/input/A02_s001_w1_z001_t001.tif",
                    "/input/A02_s002_w1_z001_t001.tif",
                ),
                component_metadata=(
                    {"well": "A02", "site": 1, "channel": 1},
                    {"well": "A02", "site": 2, "channel": 1},
                ),
            )
        ),
    )
    payload = _unaddressed_roi_label_payload().with_source_image_context(source_image)

    _stream_materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        payload,
        "/tmp/A02_s001_w1_z001_t001_Nuclei_step3.roi.zip",
        fm,
    )

    roi_saves = [item for item in fm.saved if item[1].endswith(".roi.zip")]
    assert [item[1] for item in roi_saves] == [
        "/tmp/A02_s001_w1_z001_t001_Nuclei_step3_rois.roi.zip",
        "/tmp/A02_s002_w1_z001_t001_Nuclei_step3_rois.roi.zip",
    ]
    assert [_stream_component_metadata(item) for item in roi_saves] == [
        {"timepoint": 1, "z_index": 1, "site": 1, "well": "A02", "channel": 1},
        {"timepoint": 1, "z_index": 1, "site": 2, "well": "A02", "channel": 1},
    ]


@pytest.mark.unit
def test_roi_materialization_rejects_unaddressed_stack_provenance_slots() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    payload = _unaddressed_roi_label_payload()

    with pytest.raises(ValueError, match="per-plane source identity"):
        _memory_materialize(
            MaterializationSpec(ROIOptions(min_area=0)),
            payload,
            "/tmp/A01_s001_w1_z001_t001_Nuclei_step3.roi.zip",
            fm,
        )


@pytest.mark.unit
def test_roi_materialization_spec_reports_projected_source_identities() -> None:
    labels = np.zeros((2, 8, 8), dtype=np.int32)
    labels[0, 1:4, 1:4] = 1
    labels[1, 4:7, 4:7] = 2
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=labels),
        plane_axis=RuntimePlaneAxis.SOURCE_BINDING,
        domain=ObjectLabelDomain(
            declared_object_id_domains=((1,), (2,)),
            scope=ObjectLabelDomainScope.PLANE,
        ),
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=(
                "/input/A01_s001_w1_z001_t001.tif",
                "/input/A01_s001_w2_z001_t001.tif",
            ),
            component_metadata=(
                {
                    "well": "A01",
                    "site": 1,
                    "channel": 1,
                    "z_index": 1,
                    "timepoint": 1,
                    "extension": ".tif",
                },
                {
                    "well": "A01",
                    "site": 1,
                    "channel": 2,
                    "z_index": 1,
                    "timepoint": 1,
                    "extension": ".tif",
                },
            ),
        ),
    )
    spec = MaterializationSpec(ROIOptions(min_area=0))

    assert spec.emits_variable_component_planes(payload) is True
    assert [
        identity.component_metadata
        for identity in spec.emitted_source_identities(payload)
    ] == [
        {
            "well": "A01",
            "site": 1,
            "channel": 1,
            "z_index": 1,
            "timepoint": 1,
            "extension": ".tif",
        },
        {
            "well": "A01",
            "site": 1,
            "channel": 2,
            "z_index": 1,
            "timepoint": 1,
            "extension": ".tif",
        },
    ]


@pytest.mark.unit
def test_roi_materialization_treats_non_spatial_label_payload_as_empty() -> None:
    fm = FileManager({"memory": MemoryStorageBackend()})
    payload = ObjectLabelPayload(
        variant_data=ObjectLabelVariantData(labels=np.asarray(0, dtype=np.int32))
    )

    out = _memory_materialize(
        MaterializationSpec(ROIOptions(min_area=0)),
        payload,
        "/tmp/A01_Worms_step3.roi.zip",
        fm,
    )

    assert out == "/tmp/A01_Worms_step3_segmentation_summary.txt"
    assert "No ROIs extracted" in fm.load(out, "memory")


@pytest.mark.parametrize("intrinsic", (False, True))
def test_declared_volume_save_preserves_pixels_and_exact_plane_selection(
    tmp_path, intrinsic
):
    from openhcs.core.artifacts import ImageArtifactType
    from openhcs.processing.materialization.options import MaterializedFilenameIdentity
    from openhcs.core.component_group_scope import RuntimeExecutionAxisScope
    from openhcs.core.image_file_serialization import TiffImageFileFormat
    from openhcs.core.runtime_image_values import (
        image_payload_data, image_payload_mask, image_payload_metadata,
    )
    from openhcs.core.runtime_slice_projection import RuntimeSliceProjection
    from openhcs.core.source_projection import SourceArtifactProjection, SourcePixelRef
    from openhcs.core.source_spatial_domain import VolumeSourceSpatialDomain
    from openhcs.core.source_workspace_projection import (
        VirtualWorkspaceImagePayloadProjection,
    )
    from openhcs.core.virtual_workspace_metadata import (
        VirtualWorkspaceSourceProjectionEntries,
    )
    from openhcs.processing.materialization import prepare_materialization
    import tifffile

    pixels = np.arange(3 * 4 * 5, dtype=np.uint16).reshape(3, 4, 5)
    mask = pixels % 3 != 0
    paths = tuple(f"/source/A01_s001_w2_z{z:03d}_t001.tif" for z in (1, 2, 3))
    components = tuple(
        {"well": "A01", "site": 1, "channel": 2, "z_index": z, "timepoint": 1}
        for z in (1, 2, 3)
    )
    domain = (
        VolumeSourceSpatialDomain(
            source_depth=3, source_shape_yx=(4, 5), origin_yx=(0, 0)
        )
        if intrinsic
        else SourceSpatialDomain(source_shape_yx=(4, 5), origin_yx=(0, 0))
    )
    metadata = ImagePayloadMetadata(
        plane_axis=RuntimePlaneAxis.RUNTIME_SLICE,
        source_spatial_domain=domain,
        source_voxel_spacing=SourceVoxelSpacing((2.0, 1.0, 0.5)),
        source_image_names=("DNA",),
        source_component_metadata={
            "well": "A01",
            "site": 1,
            "channel": 2,
            "timepoint": 1,
            "extension": ".tif",
        },
        source_image_provenance_planes=SourceImageProvenancePlanes.from_components(
            paths=paths,
            component_metadata=components,
        ),
    )
    payload = metadata.payload_with(pixels, mask)
    manager = FileManager({"disk": DiskStorageBackend()})
    spec = MaterializationSpec(ImageFileOptions(
        filename_suffix=".tif",
        filename_identity=MaterializedFilenameIdentity.SOURCE_IDENTITY,
    ))
    batch = prepare_materialization(
        spec,
        payload,
        str(tmp_path / "output"),
        manager,
        ("disk",),
        context=_SourceSchemaProcessingContext(),
        variable_components=(VariableComponents.Z_INDEX,),
        artifact_filename_identity=SourceImageIdentity(
            component_metadata={**components[0], "extension": ".tif"},
        ),
    )
    batch.save()
    assert len(batch.outputs) == (1 if intrinsic else 3)
    if not intrinsic:
        for index, output in enumerate(batch.outputs):
            np.testing.assert_array_equal(tifffile.imread(output.path), pixels[index])
        return

    (output,) = batch.outputs
    assert Path(output.path).name == "A01_s001_w2_z001_t001.tif"
    assert image_payload_metadata(payload).source_component_metadata.get("z_index") is None
    assert output.metadata.source_component_metadata.get("z_index") is None
    assert output.metadata.source_provenance.source_plane_count == 3
    np.testing.assert_array_equal(tifffile.imread(output.path), pixels)
    saved_metadata = TiffImageFileFormat().persisted_metadata(
        Path(output.path), payload
    )
    projection = SourceArtifactProjection(
        address=SourceArtifactProjection.scalar_address_for_image_metadata(
            saved_metadata
        ),
        ref=SourcePixelRef("disk", output.path),
        source_alias="DNA",
        artifact_kind=ImageArtifactType,
        image_metadata=saved_metadata,
        execution_scope=RuntimeExecutionAxisScope.from_raw(
            "A01",
            component="channel",
            value="2",
            fixed_component_values=(
                (AllComponents.SITE, "1"),
                (AllComponents.TIMEPOINT, "1"),
            ),
        ),
    )
    assert projection.address is None
    entries = VirtualWorkspaceSourceProjectionEntries.from_projection_paths(
        ((projection, "images/volume.tif"),)
    )
    document = {}
    entries.merge_into_subdirectory(document)
    decoded = VirtualWorkspaceSourceProjectionEntries.from_subdirectory(
        json.loads(json.dumps(document))
    )
    restored = decoded.entries["images/volume.tif"]
    assert restored.execution_scope == projection.execution_scope
    assert isinstance(
        restored.image_metadata.source_spatial_domain, VolumeSourceSpatialDomain
    )
    assert restored.image_metadata.source_spatial_domain.source_depth == 3
    reloaded = VirtualWorkspaceImagePayloadProjection(
        persisted_metadata=restored.image_metadata
    ).apply(metadata.payload_with(tifffile.imread(output.path), mask.copy()))
    for index in range(3):
        physical_plane = SourcePixelRef(
            "disk", output.path, source_axis_indices=(index,)
        ).load(
            {"disk": manager._get_backend("disk")},
            base_path=tmp_path,
        )
        np.testing.assert_array_equal(physical_plane, pixels[index])
        plane = RuntimeSliceProjection.value_for_slice(
            reloaded,
            RuntimePlaneAxisValueProjection.preserve(
                axis=RuntimePlaneAxis.RUNTIME_SLICE, axis_size=3
            ).selected_plane(index),
        )
        np.testing.assert_array_equal(image_payload_data(plane), pixels[index])
        np.testing.assert_array_equal(image_payload_mask(plane), mask[index])
        assert plane.metadata.source_path == paths[index]
        assert plane.metadata.source_component_metadata["z_index"] == index + 1
        assert type(plane.metadata.source_spatial_domain) is SourceSpatialDomain
        assert plane.metadata.source_voxel_spacing == metadata.source_voxel_spacing
