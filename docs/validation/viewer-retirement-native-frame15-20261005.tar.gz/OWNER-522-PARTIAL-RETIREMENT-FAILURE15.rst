Selected-source retirement failed after partial mutation
=======================================================

The original client17936/native648055 executed the existing public retirement
once. Job4 was already COMPLETE with errors[]. No retirement replay, selection
repair, pipeline execution, or live package replacement followed this failure.

Reply: applied=false; viewer_presentation_failed:
Rematerialized selected source members have no displayed geometry on the current slice.

Before: true A01/A02/A03 well extent3; Points selected A03 index1 and Shapes
selected A03/Z2 index3. Camera and slice were recorded at well ordinal2/Z2.
One producer-exact manual A02 route was requested for retirement.

Immediate read-only result: the middle route is absent. Raw and Points domains
became A01/A03 (extent2), but Points selection became empty. Shapes retained the
old A01/A02/A03 domain and selected index3. Current well ordinal remained2.
This is partial state mutation despite the error reply, not successful
selection-preserving retirement and not proof that no side effect occurred.

Singer owns the existing #522 survivor/rematerialization family. Acceptance:
one coherent source-owned domain migration must retain A03 selections and
geometry for raw, Points and Shapes, move the current slice from old ordinal2
to new ordinal1, and preserve source identity/calibration and matched camera.
No manual reselection or second retirement may qualify this failed incarnation.

The independent #748 saved scalar volume/Points/Shapes reopen passed; see
OWNER-748-SAVED-REOPEN-ACCEPTANCE15.rst and PLANCK-PUBLIC-ACCEPTANCE16.rst.
